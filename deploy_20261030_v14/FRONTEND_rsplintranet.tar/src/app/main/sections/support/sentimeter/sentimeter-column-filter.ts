import { DatePipe } from '@angular/common';
import { Component, OnDestroy, ViewChild, computed, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { Popover, PopoverModule } from 'primeng/popover';
import { SelectModule } from 'primeng/select';
import { Observable, Subscription } from 'rxjs';

export type ColumnField =
  | 'ticketNo' | 'callDate' | 'customerName' | 'executiveName' | 'customerMood' | 'softwareName' | 'callDurationSeconds';

/** ticket = numbers, category = checkbox values only, text = values + contains,
 * date = values + Before/After/Between, duration = numeric operator in seconds. */
export type ColumnKind = 'ticket' | 'category' | 'text' | 'date' | 'duration';

export type DurationOp = 'eq' | 'gt' | 'gte' | 'lt' | 'lte' | 'between';

export interface ColumnFilterValue {
  values?: string[];
  contains?: string;
  from?: string | null;
  to?: string | null;
  operator?: DurationOp;
  value?: number;
  valueTo?: number | null;
}

export interface FilterOptionsResult {
  values: { value: string; callCount: number }[];
  totalValues: number;
}

type DateOp = '' | 'before' | 'after' | 'between';

/** Excel-style header filter: opens a popover with search, Select all / Clear,
 * a checkbox list of server-supplied distinct values, and Apply / Cancel.
 * Nothing changes until Apply; Cancel (or closing) discards the draft. */
@Component({
  selector: 'app-sentimeter-column-filter',
  imports: [FormsModule, ButtonModule, CheckboxModule, DatePickerModule, InputTextModule, PopoverModule, SelectModule, DatePipe],
  templateUrl: './sentimeter-column-filter.html',
  styleUrl: './sentimeter-column-filter.scss'
})
export class SentimeterColumnFilter implements OnDestroy {
  readonly label = input.required<string>();
  readonly kind = input.required<ColumnKind>();
  readonly value = input<ColumnFilterValue | null>(null);
  readonly loadOptions = input<((search: string) => Observable<FilterOptionsResult>) | null>(null);
  readonly applied = output<ColumnFilterValue | null>();

  @ViewChild('pop') pop?: Popover;

  readonly options = signal<{ value: string; callCount: number }[]>([]);
  readonly totalValues = signal(0);
  readonly loading = signal(false);
  readonly error = signal<string | null>(null);
  readonly active = computed(() => isActive(this.value()));

  search = '';
  selected = new Set<string>();
  contains = '';
  dateOp: DateOp = '';
  dateFrom: Date | null = null;
  dateTo: Date | null = null;
  durOp: DurationOp | '' = '';
  durValue = '';
  durValueTo = '';
  validation: string | null = null;

  readonly dateOps = [
    { label: 'Any date', value: '' },
    { label: 'Before (on or before)', value: 'before' },
    { label: 'After (on or after)', value: 'after' },
    { label: 'Between', value: 'between' }
  ];
  readonly durationOps = [
    { label: 'No duration filter', value: '' },
    { label: 'Equals', value: 'eq' },
    { label: 'Greater than', value: 'gt' },
    { label: 'Greater or equal', value: 'gte' },
    { label: 'Less than', value: 'lt' },
    { label: 'Less or equal', value: 'lte' },
    { label: 'Between', value: 'between' }
  ];

  private searchTimer: ReturnType<typeof setTimeout> | null = null;
  private sub: Subscription | null = null;

  open(event: Event): void {
    // Draft = the currently applied filter.
    const v = this.value() ?? {};
    this.selected = new Set(v.values ?? []);
    this.contains = v.contains ?? '';
    this.dateFrom = v.from ? parseIsoDate(v.from) : null;
    this.dateTo = v.to ? parseIsoDate(v.to) : null;
    this.dateOp = v.from && v.to ? 'between' : v.from ? 'after' : v.to ? 'before' : '';
    this.durOp = v.operator ?? '';
    this.durValue = v.value != null ? toMmss(v.value) : '';
    this.durValueTo = v.valueTo != null ? toMmss(v.valueTo) : '';
    this.validation = null;
    this.search = '';
    if (this.kind() !== 'duration') this.fetch();
    this.pop?.toggle(event);
  }

  onSearch(): void {
    if (this.searchTimer) clearTimeout(this.searchTimer);
    this.searchTimer = setTimeout(() => this.fetch(), 300);
  }

  private fetch(): void {
    const load = this.loadOptions();
    if (!load) return;
    this.sub?.unsubscribe();
    this.loading.set(true);
    this.error.set(null);
    this.sub = load(this.search.trim()).subscribe({
      next: (d) => {
        this.options.set(d.values);
        this.totalValues.set(d.totalValues);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Could not load values.');
        this.loading.set(false);
      }
    });
  }

  isChecked(v: string): boolean {
    return this.selected.has(v);
  }

  toggleValue(v: string, checked: boolean): void {
    if (checked) this.selected.add(v);
    else this.selected.delete(v);
  }

  /** Select all = every value currently listed (i.e. matching the search). */
  selectAll(): void {
    this.options().forEach((o) => this.selected.add(o.value));
  }

  clearSelection(): void {
    this.selected.clear();
  }

  readonly allListedChecked = (): boolean => this.options().length > 0 && this.options().every((o) => this.selected.has(o.value));

  apply(): void {
    this.validation = null;
    const out: ColumnFilterValue = {};
    if (this.kind() === 'duration') {
      if (this.durOp) {
        const a = parseMmss(this.durValue);
        const b = parseMmss(this.durValueTo);
        if (a === null || (this.durOp === 'between' && b === null)) {
          this.validation = 'Enter duration as MM:SS (e.g. 04:30) or seconds.';
          return;
        }
        out.operator = this.durOp;
        out.value = a;
        out.valueTo = this.durOp === 'between' ? b : null;
      }
    } else {
      if (this.selected.size) out.values = [...this.selected];
      if (this.kind() === 'text' && this.contains.trim()) out.contains = this.contains.trim();
      if (this.kind() === 'date') {
        const needFrom = this.dateOp === 'after' || this.dateOp === 'between';
        const needTo = this.dateOp === 'before' || this.dateOp === 'between';
        if ((needFrom && !this.dateFrom) || (needTo && !this.dateTo)) {
          this.validation = 'Pick the date(s) for this condition.';
          return;
        }
        if (needFrom) out.from = toIsoDate(this.dateFrom!);
        if (needTo) out.to = toIsoDate(this.dateTo!);
      }
    }
    this.applied.emit(isActive(out) ? out : null);
    this.pop?.hide();
  }

  cancel(): void {
    this.pop?.hide();
  }

  displayValue(v: string): string {
    return v === '' ? '(Blanks)' : v;
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
    if (this.searchTimer) clearTimeout(this.searchTimer);
  }
}

export function isActive(v: ColumnFilterValue | null | undefined): boolean {
  return !!v && (!!v.values?.length || !!v.contains || !!v.from || !!v.to || !!v.operator);
}

/** "04:30" → 270, "270" → 270; null when unparseable. */
export function parseMmss(s: string): number | null {
  const t = (s ?? '').trim();
  if (/^\d+$/.test(t)) return Number(t);
  const m = /^(\d+):([0-5]\d)$/.exec(t);
  return m ? Number(m[1]) * 60 + Number(m[2]) : null;
}

export function toMmss(seconds: number): string {
  return `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
}

function toIsoDate(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function parseIsoDate(s: string): Date {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d);
}
