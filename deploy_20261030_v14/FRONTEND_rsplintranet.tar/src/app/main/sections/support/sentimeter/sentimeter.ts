import { DatePipe, DecimalPipe, NgTemplateOutlet } from '@angular/common';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { ChangeDetectorRef, Component, ElementRef, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Observable, firstValueFrom } from 'rxjs';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelectModule } from 'primeng/multiselect';
import { TableLazyLoadEvent, TableModule } from 'primeng/table';

import { API_BASE_URL } from '../../../../shared/api-config';
import { ExcelColumn, exportToExcel } from '../../../../shared/export-excel';
import {
  ColumnField, ColumnFilterValue, FilterOptionsResult, SentimeterColumnFilter, isActive, toMmss
} from './sentimeter-column-filter';

/** Row of GET /data — feeds the summary panels and the All Calls table. */
interface CallRow {
  id: number;
  call_date: string | null;
  executive_name: string | null;
  customer_name: string | null;
  software_name: string | null;
  customer_mood: string | null;
  keywords: string | null;
  call_duration: number | null;
  mood_reason: string | null;
}

interface KeywordItem {
  keyword: string;
  /** Distinct calls containing the keyword — bubble size. */
  callCount: number;
  /** Distinct nonblank customer names — X axis. */
  distinctCustomers: number;
  /** Mean call duration in seconds (unrounded), null if none valid — Y axis. */
  averageDurationSeconds: number | null;
  averageDurationDisplay: string | null;
  moodCounts: Record<string, number>;
}

interface LabelChip {
  x: number;
  y: number;
  w: number;
  text: string;
}

interface BubbleSlice {
  mood: string;
  count: number;
  color: string;
  /** SVG path of the pie slice; null when this mood is the whole bubble. */
  path: string | null;
}

interface Bubble extends KeywordItem {
  x: number;
  y: number;
  r: number;
  /** One pie slice per mood, sized by its share of the keyword's calls. */
  slices: BubbleSlice[];
  /** High-contrast label chip, or null when it would collide (tooltip/table still show it). */
  label: LabelChip | null;
}

interface Tick {
  pos: number;
  text: string;
}

interface KeywordCall {
  ticketNo: number;
  callDate: string | null;
  customerName: string | null;
  executiveName: string | null;
  customerMood: string;
  softwareName: string | null;
  callDurationSeconds: number | null;
  callDurationDisplay: string | null;
}

interface KeywordCallsPage {
  items: KeywordCall[];
  moodCounts: Record<string, number>;
  page: number;
  pageSize: number;
  totalItems: number;
  totalPages: number;
}

type ContentType = 'shortSummary' | 'longSummary' | 'transcript';

interface KeywordExclusion {
  exclusionId: number;
  keyword: string;
  reason: string | null;
  isActive: boolean;
  createdAt: string | null;
  updatedAt: string | null;
}

interface ExecutiveSummary {
  name: string;
  calls: number;
  totalSeconds: number;
}

interface MoodBreakdown {
  name: string;
  calls: number;
  moods: Record<string, number>;
  segments: { mood: string; count: number; pct: number; color: string }[];
}

/** Mood colours (shared config). Labels come from the data; known ones get a
 * fixed colour, anything else falls back by wording, then to neutral grey. */
const MOOD_COLORS: Record<string, string> = {
  satisfied: '#16a34a',
  positive: '#16a34a',
  neutral: '#eab308',
  concerned: '#f97316',
  frustrated: '#dc2626',
  negative: '#dc2626'
};
const NEUTRAL_COLOR = '#64748b';

export function moodColor(mood: string | null | undefined): string {
  const s = (mood ?? '').trim().toLowerCase();
  if (MOOD_COLORS[s]) return MOOD_COLORS[s];
  if (/happy|satisf|good|excited|delight|positive/.test(s)) return '#16a34a';
  if (/angry|frustrat|sad|unhappy|disappoint|upset|negative/.test(s)) return '#dc2626';
  if (/concern|worr|anxious/.test(s)) return '#f97316';
  if (/^neutral|mixed|normal|okay/.test(s)) return '#eab308';
  return NEUTRAL_COLOR;
}

/** Smallest 1/2/2.5/5 × 10^n step ≥ v, so ticks read cleanly. */
function niceStep(v: number): number {
  const pow = Math.pow(10, Math.floor(Math.log10(Math.max(v, 1e-9))));
  for (const m of [1, 2, 2.5, 5, 10]) {
    if (m * pow >= v) return m * pow;
  }
  return 10 * pow;
}

/** Axis domain hugging the data (not forced to 0) with 5 even, rounded steps. */
function niceDomain(min: number, max: number, minSpan: number): { lo: number; hi: number } {
  const span = Math.max(max - min, minSpan);
  const step = niceStep(span / 5);
  const lo = Math.max(0, Math.floor(min / step) * step);
  return { lo, hi: Math.max(lo + 5 * step, Math.ceil(max / step) * step) };
}

const PAGE_SIZE = 50;
/** Largest page the keyword-calls procedure serves; used when exporting. */
const EXPORT_PAGE_SIZE = 200;
const MAX_BUBBLES = 60;
// Must match the mobile breakpoint in sentimeter.scss.
const MOBILE_QUERY = '(max-width: 768px)';

@Component({
  selector: 'app-sentimeter',
  imports: [
    FormsModule, ButtonModule, CheckboxModule, DatePickerModule, DialogModule, InputTextModule,
    MultiSelectModule, TableModule, DatePipe, DecimalPipe, NgTemplateOutlet, SentimeterColumnFilter
  ],
  templateUrl: './sentimeter.html',
  styleUrl: './sentimeter.scss'
})
export class Sentimeter implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef);
  private readonly base = `${API_BASE_URL}/support/sentimeter`;

  readonly moodColor = moodColor;

  // ---- Global filters ----
  readonly softwareOptions = signal<string[]>([]);
  readonly moodOptions = signal<string[]>([]);
  dateFrom: Date | null = null;
  dateTo: Date | null = null;
  customer = '';
  executive = '';
  software: string[] = [];
  moods: string[] = [];
  /** Comma-separated complete keywords (OR), matched as whole tokens. */
  keywordText = '';
  /** Filters as last applied — drill-down/expand/summary calls reuse these,
   * so editing a field without clicking Apply never mixes two filter states. */
  private applied = this.currentFilters();

  // ---- Keyword chart ----
  readonly keywords = signal<KeywordItem[]>([]);
  readonly chartLoading = signal(false);
  readonly chartError = signal<string | null>(null);
  // Scatter plot geometry (SVG user units): X = distinct customers,
  // Y = average call duration, bubble size = call count.
  readonly SVG_W = 1000;
  readonly SVG_H = 620;
  readonly PLOT = { left: 78, right: 980, top: 24, bottom: 560 };
  /** Bubble under the pointer / keyboard focus — drives the HTML tooltip. */
  readonly hovered = signal<Bubble | null>(null);

  // ---- Drill-down for the selected keyword ----
  readonly selected = signal<KeywordItem | null>(null);
  readonly localMood = signal<string | null>(null);
  readonly calls = signal<KeywordCallsPage | null>(null);
  readonly callsLoading = signal(false);
  readonly callsError = signal<string | null>(null);
  callsPage = 1;
  private callsRequest = 0;

  // ---- Expanded list ----
  expandedVisible = false;
  readonly expanded = signal<KeywordCallsPage | null>(null);
  readonly expandedLoading = signal(false);
  readonly expandedError = signal<string | null>(null);
  expandedFirst = 0;
  private expandedRequest = 0;

  // ---- Content viewer ----
  contentVisible = false;
  readonly contentTicket = signal<number | null>(null);
  readonly contentType = signal<ContentType>('shortSummary');
  readonly content = signal<string | null>(null);
  readonly contentLoading = signal(false);
  readonly contentError = signal<string | null>(null);
  readonly copied = signal(false);
  readonly contentLabels: Record<ContentType, string> = {
    shortSummary: 'Short summary',
    longSummary: 'Long summary',
    transcript: 'Transcript'
  };

  // ---- Summary panels (GET /data) ----
  readonly rows = signal<CallRow[]>([]);
  readonly rowsTruncated = signal(false);
  readonly rowsLoading = signal(false);

  // ---- Keyword exclusions admin ----
  exclusionsVisible = false;
  readonly exclusions = signal<KeywordExclusion[]>([]);
  readonly exclusionsLoading = signal(false);
  readonly exclusionsMessage = signal<{ ok: boolean; text: string } | null>(null);
  readonly canManageExclusions = signal(false);
  exclusionSearch = '';
  exclusionForm: { id: number | null; keyword: string; reason: string } = { id: null, keyword: '', reason: '' };

  ngOnInit(): void {
    this.setDefaultDates();
    this.applied = this.currentFilters();
    this.http.get<{ softwareNames: string[]; moods: string[] }>(`${this.base}/options`).subscribe({
      next: (d) => {
        this.softwareOptions.set(d.softwareNames);
        this.moodOptions.set(d.moods);
        this.cdr.markForCheck();
      },
      error: (err) => this.chartError.set(this.errorText(err, 'Failed to load filter options.'))
    });
    this.http.get<{ canManageExclusions: boolean }>(`${this.base}/admin/me`).subscribe({
      next: (d) => this.canManageExclusions.set(d.canManageExclusions)
    });
    this.apply();
  }

  // =========================================================================
  // Filters
  // =========================================================================

  private setDefaultDates(): void {
    const now = new Date();
    const prior = new Date();
    prior.setDate(now.getDate() - 90);
    this.dateFrom = prior;
    this.dateTo = now;
  }

  private currentFilters() {
    return {
      dateFrom: this.dateFrom ? this.toDateStr(this.dateFrom) : null,
      dateTo: this.dateTo ? this.toDateStr(this.dateTo) : null,
      customerName: this.customer.trim(),
      executiveName: this.executive.trim(),
      softwareNames: [...this.software],
      moods: [...this.moods],
      keywords: this.keywordText.split(',').map((k) => k.trim()).filter((k) => k)
    };
  }

  /** Apply Filters: refresh the chart + summary panels and drop any stale
   * selected keyword / local mood / expanded view. */
  apply(): void {
    this.applied = this.currentFilters();
    this.clearSelection();
    this.loadKeywords();
    this.loadRows();
  }

  reset(): void {
    this.setDefaultDates();
    this.customer = '';
    this.executive = '';
    this.software = [];
    this.moods = [];
    this.keywordText = '';
    this.apply();
  }

  private loadKeywords(): void {
    this.chartLoading.set(true);
    this.chartError.set(null);
    this.http.post<{ items: KeywordItem[] }>(`${this.base}/analytics/keywords`, this.applied).subscribe({
      next: (d) => {
        this.keywords.set(d.items);
        this.chartLoading.set(false);
      },
      error: (err) => {
        this.keywords.set([]);
        this.chartError.set(this.errorText(err, 'Failed to load keywords.'));
        this.chartLoading.set(false);
      }
    });
  }

  private loadRows(): void {
    this.rowsLoading.set(true);
    const f = this.applied;
    let params = new HttpParams();
    if (f.dateFrom) params = params.set('date_from', f.dateFrom);
    if (f.dateTo) params = params.set('date_to', f.dateTo);
    if (f.customerName) params = params.set('customer', f.customerName);
    if (f.executiveName) params = params.set('executive', f.executiveName);
    f.softwareNames.forEach((s) => (params = params.append('software', s)));
    f.moods.forEach((m) => (params = params.append('mood', m)));
    f.keywords.forEach((k) => (params = params.append('keyword', k)));
    this.http.get<{ rows: CallRow[]; truncated: boolean }>(`${this.base}/data`, { params }).subscribe({
      next: (d) => {
        this.rows.set(d.rows);
        this.rowsTruncated.set(d.truncated);
        this.rowsLoading.set(false);
      },
      error: () => {
        this.rows.set([]);
        this.rowsLoading.set(false);
      }
    });
  }

  // =========================================================================
  // Keyword chart
  // =========================================================================

  readonly totalMentions = computed(() => this.keywords().reduce((s, k) => s + k.callCount, 0));

  /** Moods present in the current chart data, in option order, for the legend. */
  readonly legendMoods = computed(() => {
    const seen = new Set<string>();
    for (const k of this.keywords()) Object.keys(k.moodCounts).forEach((m) => seen.add(m));
    const ordered = this.moodOptions().filter((m) => seen.has(m));
    return [...ordered, ...[...seen].filter((m) => !ordered.includes(m))];
  });

  /** Keywords that can be plotted (need an average duration for Y), top N by call count. */
  private readonly plotted = computed(() =>
    this.keywords().filter((k) => k.averageDurationSeconds != null).slice(0, MAX_BUBBLES)
  );

  readonly unplottedCount = computed(() => this.keywords().filter((k) => k.averageDurationSeconds == null).length);

  private readonly xDomain = computed(() => {
    const v = this.plotted().map((k) => k.distinctCustomers);
    return niceDomain(Math.min(...v), Math.max(...v), 5);
  });
  private readonly yDomain = computed(() => {
    const v = this.plotted().map((k) => k.averageDurationSeconds ?? 0);
    return niceDomain(Math.min(...v), Math.max(...v), 60);
  });

  private ticks(d: { lo: number; hi: number }, pos: (v: number) => number, fmt: (v: number) => string): Tick[] {
    return [0, 1, 2, 3, 4, 5].map((i) => {
      const v = d.lo + ((d.hi - d.lo) * i) / 5;
      return { pos: pos(v), text: fmt(v) };
    });
  }

  readonly xTicks = computed<Tick[]>(() =>
    this.ticks(this.xDomain(), (v) => this.xPos(v), (v) => (Number.isInteger(v) ? String(v) : v.toFixed(1)))
  );

  readonly yTicks = computed<Tick[]>(() => this.ticks(this.yDomain(), (v) => this.yPos(v), (v) => toMmss(Math.round(v))));

  private xPos(v: number): number {
    const { lo, hi } = this.xDomain();
    return this.PLOT.left + ((v - lo) / (hi - lo)) * (this.PLOT.right - this.PLOT.left);
  }

  private yPos(v: number): number {
    const { lo, hi } = this.yDomain();
    return this.PLOT.bottom - ((v - lo) / (hi - lo)) * (this.PLOT.bottom - this.PLOT.top);
  }

  readonly bubbles = computed<Bubble[]>(() => {
    const data = this.plotted();
    if (!data.length) return [];
    const maxCalls = Math.max(1, ...data.map((d) => d.callCount));
    // Restrained sqrt scale so a huge keyword can't hide the X/Y positions.
    const all = data.map((d) => {
      const x = this.xPos(d.distinctCustomers);
      const y = this.yPos(d.averageDurationSeconds!);
      const r = 5 + Math.sqrt(d.callCount / maxCalls) * 28;
      return { ...d, x, y, r, slices: this.pieSlices(d.moodCounts, x, y, r), label: null as LabelChip | null };
    });

    // Label chips, biggest keywords first; skip any that would overlap a
    // placed chip (the tooltip and the metrics table still name them).
    const placed: { x1: number; y1: number; x2: number; y2: number }[] = [];
    for (const b of [...all].sort((a, c) => c.callCount - a.callCount)) {
      const text = this.truncate(b.keyword, 22);
      const w = text.length * 7 + 14;
      const cx = Math.min(Math.max(b.x, this.PLOT.left + w / 2), this.PLOT.right - w / 2);
      const cy = Math.max(b.y - b.r - 13, this.PLOT.top + 10);
      const box = { x1: cx - w / 2, y1: cy - 10, x2: cx + w / 2, y2: cy + 10 };
      if (placed.some((p) => box.x1 < p.x2 && box.x2 > p.x1 && box.y1 < p.y2 && box.y2 > p.y1)) continue;
      placed.push(box);
      b.label = { x: cx, y: cy, w, text };
    }
    // Draw large bubbles first so small ones stay clickable on top.
    return all.sort((a, c) => c.r - a.r);
  });

  /** Tooltip position as % of the chart box (the SVG scales with its width). */
  tooltipLeft(b: Bubble): number {
    return (b.x / this.SVG_W) * 100;
  }

  tooltipTop(b: Bubble): number {
    return (b.y / this.SVG_H) * 100;
  }

  /** Bubble fill as a pie of its mood shares (fixed mood order, so the same
   * mood sits in the same place on every bubble), starting at 12 o'clock. */
  private pieSlices(moodCounts: Record<string, number>, cx: number, cy: number, r: number): BubbleSlice[] {
    const order = this.legendMoods();
    const entries = Object.entries(moodCounts)
      .filter(([, n]) => n > 0)
      .sort((a, b) => order.indexOf(a[0]) - order.indexOf(b[0]));
    const total = entries.reduce((s, [, n]) => s + n, 0);
    if (entries.length <= 1 || !total) {
      const [mood, count] = entries[0] ?? ['Unknown', 0];
      return [{ mood, count, color: moodColor(mood), path: null }];
    }
    let angle = -Math.PI / 2;
    return entries.map(([mood, count]) => {
      const sweep = (count / total) * 2 * Math.PI;
      const x1 = cx + r * Math.cos(angle), y1 = cy + r * Math.sin(angle);
      angle += sweep;
      const x2 = cx + r * Math.cos(angle), y2 = cy + r * Math.sin(angle);
      const large = sweep > Math.PI ? 1 : 0;
      const path = `M${cx},${cy} L${x1.toFixed(2)},${y1.toFixed(2)} A${r},${r} 0 ${large} 1 ${x2.toFixed(2)},${y2.toFixed(2)} Z`;
      return { mood, count, color: moodColor(mood), path };
    });
  }

  bubbleTooltip(b: KeywordItem): string {
    const moods = this.moodEntries(b.moodCounts).map((m) => `${m.key}: ${m.val}`).join(', ');
    return `${b.keyword} — ${b.distinctCustomers} distinct customers, ${b.callCount} calls, ` +
      `average duration ${b.averageDurationDisplay ?? '—'} (${moods})`;
  }

  // =========================================================================
  // Drill-down
  // =========================================================================

  selectBubble(b: KeywordItem): void {
    this.selected.set(b);
    this.localMood.set(null);
    this.columnFilters.set({});
    this.expandedFirst = 0;
    this.callsPage = 1;
    this.loadCalls();
    // On phones the detail panel stacks below the chart, off-screen.
    if (window.matchMedia(MOBILE_QUERY).matches) {
      setTimeout(() => this.scrollToEl('.detail-panel'));
    }
  }

  private clearSelection(): void {
    this.selected.set(null);
    this.localMood.set(null);
    this.calls.set(null);
    this.callsError.set(null);
    this.columnFilters.set({});
    this.expandedFirst = 0;
    this.expandedVisible = false;
    this.contentVisible = false;
  }

  closeDetail(): void {
    this.clearSelection();
  }

  /** Clicking the active pill again (or All moods) clears the local filter. */
  toggleMood(mood: string | null): void {
    this.localMood.set(mood === null || this.localMood() === mood ? null : mood);
    this.callsPage = 1;
    this.loadCalls();
    // The same pills sit in the expanded panel; refresh it in place.
    if (this.expandedVisible) this.reloadExpandedFromStart();
  }

  goToPage(page: number): void {
    this.callsPage = page;
    this.loadCalls();
  }

  /** Column filters apply only to the expanded list (and its export). */
  private callsBody(page: number, viewMode: 'compact' | 'expanded') {
    return {
      keyword: this.selected()!.keyword,
      filters: this.applied,
      localMood: this.localMood(),
      page,
      pageSize: PAGE_SIZE,
      viewMode,
      ...(viewMode === 'expanded' ? { columnFilters: this.columnFiltersApi() } : {})
    };
  }

  // =========================================================================
  // Expanded-list column filters (Excel-style, server-side)
  // =========================================================================

  readonly columnFilters = signal<Partial<Record<ColumnField, ColumnFilterValue>>>({});
  readonly activeColumnFilterCount = computed(() => Object.values(this.columnFilters()).filter((v) => isActive(v)).length);

  readonly expandedColumns: { field: ColumnField; label: string; kind: 'ticket' | 'category' | 'text' | 'date' | 'duration' }[] = [
    { field: 'ticketNo', label: 'Tkt No', kind: 'ticket' },
    { field: 'callDate', label: 'Date', kind: 'date' },
    { field: 'customerName', label: 'Customer', kind: 'text' },
    { field: 'executiveName', label: 'Executive', kind: 'text' },
    { field: 'customerMood', label: 'Mood', kind: 'category' },
    { field: 'softwareName', label: 'Software', kind: 'text' },
    { field: 'callDurationSeconds', label: 'Duration', kind: 'duration' }
  ];

  /** One stable loader per column (header menus fetch distinct values for the
   * selected keyword + applied global filters, searchable and bounded). */
  readonly optionLoaders: Partial<Record<ColumnField, (search: string) => Observable<FilterOptionsResult>>> =
    Object.fromEntries(
      (['ticketNo', 'callDate', 'customerName', 'executiveName', 'customerMood', 'softwareName'] as ColumnField[]).map((field) => [
        field,
        (search: string) =>
          this.http.post<FilterOptionsResult>(`${this.base}/analytics/keyword-calls/filter-options`, {
            keyword: this.selected()?.keyword ?? '',
            filters: this.applied,
            field,
            search: search || null,
            maxValues: 200
          })
      ])
    );

  onColumnFilter(field: ColumnField, value: ColumnFilterValue | null): void {
    const next = { ...this.columnFilters() };
    if (value) next[field] = value;
    else delete next[field];
    this.columnFilters.set(next);
    this.reloadExpandedFromStart();
  }

  clearColumnFilters(): void {
    this.columnFilters.set({});
    this.reloadExpandedFromStart();
  }

  private reloadExpandedFromStart(): void {
    this.expandedFirst = 0;
    this.loadExpanded(1);
  }

  /** UI filter state → the backend's allow-listed columnFilters shape. */
  private columnFiltersApi(): Record<string, unknown> {
    const f = this.columnFilters();
    const out: Record<string, unknown> = {};
    if (f.ticketNo?.values?.length) out['ticketNo'] = f.ticketNo.values.map(Number);
    if (f.callDate) {
      out['callDate'] = {
        selectedDates: f.callDate.values ?? [],
        ...(f.callDate.from ? { from: f.callDate.from } : {}),
        ...(f.callDate.to ? { to: f.callDate.to } : {})
      };
    }
    for (const k of ['customerName', 'executiveName', 'softwareName'] as const) {
      const v = f[k];
      if (v) out[k] = { values: v.values ?? [], ...(v.contains ? { contains: v.contains } : {}) };
    }
    if (f.customerMood?.values?.length) out['customerMood'] = { values: f.customerMood.values };
    const d = f.callDurationSeconds;
    if (d?.operator && d.value != null) {
      out['callDurationSeconds'] = { operator: d.operator, value: d.value, ...(d.operator === 'between' ? { valueTo: d.valueTo } : {}) };
    }
    return out;
  }

  private loadCalls(): void {
    if (!this.selected()) return;
    const req = ++this.callsRequest;
    this.callsLoading.set(true);
    this.callsError.set(null);
    this.http.post<KeywordCallsPage>(`${this.base}/analytics/keyword-calls`, this.callsBody(this.callsPage, 'compact')).subscribe({
      next: (d) => {
        if (req !== this.callsRequest) return; // a newer pill/page click won
        this.calls.set(d);
        this.callsLoading.set(false);
      },
      error: (err) => {
        if (req !== this.callsRequest) return;
        this.callsError.set(this.errorText(err, 'Failed to load calls.'));
        this.callsLoading.set(false);
      }
    });
  }

  /** Mood pills keep the counts from before the local mood selection. */
  readonly moodPills = computed(() =>
    Object.entries(this.calls()?.moodCounts ?? this.selected()?.moodCounts ?? {})
      .map(([mood, count]) => ({ mood, count }))
      .sort((a, b) => b.count - a.count)
  );

  // =========================================================================
  // Expanded list
  // =========================================================================

  /** Opens on the same page as the compact list; the lazy table's initial
   * onLazyLoad (fired when the dialog renders it) does the first fetch. */
  openExpanded(): void {
    this.expanded.set(null);
    this.expandedFirst = (this.callsPage - 1) * PAGE_SIZE;
    this.expandedVisible = true;
  }

  onExpandedLazyLoad(e: TableLazyLoadEvent): void {
    const rows = e.rows ?? PAGE_SIZE;
    this.expandedFirst = e.first ?? 0;
    this.loadExpanded(Math.floor(this.expandedFirst / rows) + 1);
  }

  private loadExpanded(page: number): void {
    if (!this.selected()) return;
    const req = ++this.expandedRequest;
    this.expandedLoading.set(true);
    this.expandedError.set(null);
    this.http.post<KeywordCallsPage>(`${this.base}/analytics/keyword-calls`, this.callsBody(page, 'expanded')).subscribe({
      next: (d) => {
        if (req !== this.expandedRequest) return;
        this.expanded.set(d);
        this.expandedLoading.set(false);
      },
      error: (err) => {
        if (req !== this.expandedRequest) return;
        this.expandedError.set(this.errorText(err, 'Failed to load calls.'));
        this.expandedLoading.set(false);
      }
    });
  }

  readonly pageSize = PAGE_SIZE;
  readonly exporting = signal(false);

  /** Exports EVERY call in the expanded list (same keyword, filters and local
   * mood), not just the visible page — fetched page by page. Metadata only:
   * summaries/transcripts stay on-demand per ticket. */
  async exportExpanded(): Promise<void> {
    const kw = this.selected();
    if (!kw || this.exporting()) return;
    this.exporting.set(true);
    this.expandedError.set(null);
    try {
      const all: KeywordCall[] = [];
      for (let page = 1; ; page++) {
        const body = { ...this.callsBody(page, 'expanded'), pageSize: EXPORT_PAGE_SIZE };
        const d = await firstValueFrom(this.http.post<KeywordCallsPage>(`${this.base}/analytics/keyword-calls`, body));
        all.push(...d.items);
        if (page >= d.totalPages || !d.items.length) break;
      }
      const cols: ExcelColumn<KeywordCall>[] = [
        { header: 'Tkt No', value: (r) => r.ticketNo },
        { header: 'Date', value: (r) => r.callDate },
        { header: 'Customer', value: (r) => r.customerName ?? '' },
        { header: 'Executive', value: (r) => r.executiveName ?? '' },
        { header: 'Mood', value: (r) => r.customerMood },
        { header: 'Software', value: (r) => r.softwareName ?? '' },
        { header: 'Duration (MM:SS)', value: (r) => r.callDurationDisplay ?? '' },
        { header: 'Duration (sec)', value: (r) => r.callDurationSeconds }
      ];
      const safe = kw.keyword.replace(/[^\w-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'keyword';
      exportToExcel(`sentimeter-${safe}${this.localMood() ? '-' + this.localMood()!.replace(/\W+/g, '-') : ''}`, all, cols);
    } catch (err) {
      this.expandedError.set(this.errorText(err as HttpErrorResponse, 'Export failed.'));
    } finally {
      this.exporting.set(false);
    }
  }

  // =========================================================================
  // Content viewer (fetched on demand, rendered as plain text)
  // =========================================================================

  openContent(ticketNo: number, type: ContentType): void {
    this.contentTicket.set(ticketNo);
    this.contentType.set(type);
    this.content.set(null);
    this.contentError.set(null);
    this.copied.set(false);
    this.contentLoading.set(true);
    this.contentVisible = true;
    this.http.post<{ content: string | null }>(`${this.base}/calls/content`, { ticketNo, contentType: type }).subscribe({
      next: (d) => {
        if (this.contentTicket() !== ticketNo || this.contentType() !== type) return;
        this.content.set(d.content);
        this.contentLoading.set(false);
      },
      error: (err) => {
        this.contentError.set(err.status === 404 ? 'Ticket not found.' : this.errorText(err, 'Failed to load content.'));
        this.contentLoading.set(false);
      }
    });
  }

  copyContent(): void {
    const text = this.content();
    if (!text) return;
    navigator.clipboard?.writeText(text).then(() => this.copied.set(true));
  }

  // =========================================================================
  // Keyword exclusions admin
  // =========================================================================

  openExclusions(): void {
    this.exclusionsVisible = true;
    this.exclusionsMessage.set(null);
    this.resetExclusionForm();
    this.loadExclusions();
  }

  private loadExclusions(): void {
    this.exclusionsLoading.set(true);
    this.http.get<KeywordExclusion[]>(`${this.base}/admin/keyword-exclusions`).subscribe({
      next: (d) => {
        this.exclusions.set(d);
        this.exclusionsLoading.set(false);
      },
      error: (err) => {
        this.exclusionsMessage.set({ ok: false, text: this.errorText(err, 'Failed to load exclusions.') });
        this.exclusionsLoading.set(false);
      }
    });
  }

  exclusionMatches(e: KeywordExclusion): boolean {
    const q = this.exclusionSearch.trim().toLowerCase();
    return !q || e.keyword.toLowerCase().includes(q) || (e.reason ?? '').toLowerCase().includes(q);
  }

  editExclusion(e: KeywordExclusion): void {
    this.exclusionForm = { id: e.exclusionId, keyword: e.keyword, reason: e.reason ?? '' };
  }

  resetExclusionForm(): void {
    this.exclusionForm = { id: null, keyword: '', reason: '' };
  }

  saveExclusion(): void {
    const keyword = this.exclusionForm.keyword.trim();
    if (!keyword) {
      this.exclusionsMessage.set({ ok: false, text: 'Keyword is required.' });
      return;
    }
    const duplicate = this.exclusions().some(
      (e) => e.exclusionId !== this.exclusionForm.id && e.keyword.trim().toLowerCase() === keyword.toLowerCase()
    );
    if (duplicate) {
      this.exclusionsMessage.set({ ok: false, text: 'An exclusion with this keyword already exists.' });
      return;
    }
    const body = { keyword, reason: this.exclusionForm.reason.trim() || null };
    const req = this.exclusionForm.id
      ? this.http.put(`${this.base}/admin/keyword-exclusions/${this.exclusionForm.id}`, body)
      : this.http.post(`${this.base}/admin/keyword-exclusions`, body);
    req.subscribe({
      next: () => {
        this.exclusionsMessage.set({ ok: true, text: 'Saved. It applies from the next Apply Filters.' });
        this.resetExclusionForm();
        this.loadExclusions();
      },
      error: (err) => this.exclusionsMessage.set({ ok: false, text: this.errorText(err, 'Save failed.') })
    });
  }

  toggleExclusion(e: KeywordExclusion): void {
    const verb = e.isActive ? 'Deactivate' : 'Activate';
    if (!confirm(`${verb} the exclusion "${e.keyword}"?`)) return;
    this.http.patch(`${this.base}/admin/keyword-exclusions/${e.exclusionId}/status`, { isActive: !e.isActive }).subscribe({
      next: () => {
        this.exclusionsMessage.set({ ok: true, text: `${verb}d. It applies from the next Apply Filters.` });
        this.loadExclusions();
      },
      error: (err) => this.exclusionsMessage.set({ ok: false, text: this.errorText(err, 'Update failed.') })
    });
  }

  // =========================================================================
  // Summary panels
  // =========================================================================

  private breakdownBy(field: 'customer_name' | 'executive_name'): MoodBreakdown[] {
    const map = new Map<string, { calls: number; moods: Record<string, number> }>();
    for (const r of this.rows()) {
      const name = r[field]?.trim() || '(Unknown)';
      const e = map.get(name) ?? { calls: 0, moods: {} };
      e.calls++;
      const m = r.customer_mood || 'Unknown';
      e.moods[m] = (e.moods[m] ?? 0) + 1;
      map.set(name, e);
    }
    return [...map.entries()]
      .sort((a, b) => b[1].calls - a[1].calls)
      .map(([name, { calls, moods }]) => ({
        name,
        calls,
        moods,
        segments: Object.entries(moods)
          .sort((a, b) => b[1] - a[1])
          .map(([mood, count]) => ({ mood, count, pct: (count / calls) * 100, color: moodColor(mood) }))
      }));
  }

  readonly customerMoodBreakdown = computed(() => this.breakdownBy('customer_name'));
  readonly executiveMoodBreakdown = computed(() => this.breakdownBy('executive_name'));

  /** Distinct moods in the summary rows — used for the breakdown legend and export columns. */
  readonly rowMoods = computed(() => [...new Set(this.rows().map((r) => r.customer_mood || 'Unknown'))].sort());

  readonly executiveSummary = computed<ExecutiveSummary[]>(() => {
    const map = new Map<string, ExecutiveSummary>();
    for (const r of this.rows()) {
      const name = r.executive_name?.trim() || '(Unknown)';
      const e = map.get(name) ?? { name, calls: 0, totalSeconds: 0 };
      e.calls++;
      e.totalSeconds += r.call_duration ?? 0;
      map.set(name, e);
    }
    return [...map.values()].sort((a, b) => b.totalSeconds - a.totalSeconds);
  });

  private exportBreakdown(file: string, label: string, data: MoodBreakdown[]): void {
    const moods = this.rowMoods();
    const cols: ExcelColumn<MoodBreakdown>[] = [
      { header: label, value: (r) => r.name },
      { header: 'Total Calls', value: (r) => r.calls },
      ...moods.map((m) => ({ header: m, value: (r: MoodBreakdown) => r.moods[m] ?? 0 })),
      ...moods.map((m) => ({ header: `${m} %`, value: (r: MoodBreakdown) => +(((r.moods[m] ?? 0) / r.calls) * 100).toFixed(1) }))
    ];
    exportToExcel(file, data, cols);
  }

  exportCustomerMoodBreakdown(): void {
    this.exportBreakdown('mood-breakdown-per-customer', 'Customer', this.customerMoodBreakdown());
  }

  exportMoodBreakdown(): void {
    this.exportBreakdown('mood-breakdown-per-executive', 'Executive', this.executiveMoodBreakdown());
  }

  exportExecutiveSummary(): void {
    const cols: ExcelColumn<ExecutiveSummary>[] = [
      { header: 'Executive', value: (r) => r.name },
      { header: 'Calls', value: (r) => r.calls },
      { header: 'Total Time', value: (r) => this.fmtDuration(r.totalSeconds) },
      { header: 'Total Seconds', value: (r) => r.totalSeconds }
    ];
    exportToExcel('time-spent-per-executive', this.executiveSummary(), cols);
  }

  exportCalls(): void {
    const cols: ExcelColumn<CallRow>[] = [
      { header: 'Tkt No', value: (r) => r.id },
      { header: 'Date', value: (r) => r.call_date?.slice(0, 10) ?? '' },
      { header: 'Customer', value: (r) => r.customer_name ?? '' },
      { header: 'Executive', value: (r) => r.executive_name ?? '' },
      { header: 'Mood', value: (r) => r.customer_mood ?? '' },
      { header: 'Mood Reason', value: (r) => r.mood_reason ?? '' },
      { header: 'Duration (sec)', value: (r) => r.call_duration ?? '' },
      { header: 'Software', value: (r) => r.software_name ?? '' },
      { header: 'Keywords', value: (r) => r.keywords ?? '' }
    ];
    exportToExcel('call-summaries', this.rows(), cols);
  }

  // =========================================================================
  // Helpers
  // =========================================================================

  fmtDuration(seconds: number): string {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) return `${h}h ${m}m`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
  }

  scrollToChart(): void {
    this.scrollToEl('.chart-panel');
  }

  private scrollToEl(selector: string): void {
    this.host.nativeElement.querySelector(selector)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  private toDateStr(d: Date): string {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  private errorText(err: HttpErrorResponse, fallback: string): string {
    return typeof err.error?.detail === 'string' ? err.error.detail : fallback;
  }

  labelFontSize(r: number): number {
    return Math.max(11, Math.min(16, r / 3));
  }

  truncate(s: string, max: number): string {
    return s.length > max ? s.slice(0, max - 1) + '…' : s;
  }

  moodEntries(moods: Record<string, number>): { key: string; val: number }[] {
    return Object.entries(moods).map(([key, val]) => ({ key, val }));
  }
}
