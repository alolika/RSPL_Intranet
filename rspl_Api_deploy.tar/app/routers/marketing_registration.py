"""Mirrors Section_Marketing/CustRegistration.aspx.vb (class
Section_Marketing_CustRegistration) — flagged in the source as the most
complex form in the app. The Angular rebuild already simplified two things
before this backend was written: the per-campaign "inform" checkbox loop
(which called webProc_AddCustomer/webProc_ModifyCustomer once per checked
campaign in the source — a real legacy quirk, not replicated) collapses to
a single MultiSelect whose first selection is sent as one @Campaign value;
and the GSTIN auto-fill button originally called an external LicenseInfo COM
API (GSTIN_TaxPayerSearch, hardcoded creds) via a WinForms-style web
reference that has no direct equivalent in this stack.

Update (2026-07-28): verify_gstin() was hardcoded to always return
{"verified": False} regardless of input — every GSTIN, valid or not, showed
"Invalid GST No", which is what was actually reported as a bug. At the time,
the real government lookup was still unavailable, so what COULD be verified
locally was just the GSTIN's own structure: the standard 15-char format
(2-digit state code + 10-char PAN + entity code + literal 'Z' + a checksum
digit) and its checksum, a published, standard MOD-36 algorithm (verified
against a real, widely-published example GSTIN, 27AAPFU0939F1ZV, used across
Indian GST documentation).

Update (2026-08-18): real business-detail auto-fill wired up after all —
the "external LicenseInfo COM API" mentioned above turned out to just be a
plain SOAP web service (http://myretailware.com/service/license.asmx,
GSTIN_TaxPayerSearch), reachable from this stack via a raw HTTP+XML POST
(see _gstin_taxpayer_search()/_parse_taxpayer_result() below) — no COM
interop needed, that was purely a legacy VB/.NET calling convention. It's
Retailware's own internal license server (presumably itself proxying the
government GST system), not a third-party API, using the same shared
service account (ajit/ajit99/SoftwareID 1/ClientID 11110) the legacy source
already had hardcoded — confirmed live and reachable. verify_gstin() now
does local checksum validation first (cheap reject for malformed input),
then calls this service and maps its pipe-delimited response (see
_parse_taxpayer_result()'s docstring for the exact index layout, copied
from CustRegistration.aspx.vb) to business name / address / pincode / area,
plus resolves state/district NAME strings the service returns to this app's
own geo_StateMaster/Geo_DistrictMaster IDs via a plain exact-match lookup
(same convention already used by /lookup-pincode below). If the external
call itself fails (network/timeout), verified still reports true (checksum
passed) but a separate gstApiError explains why no details came back —
kept distinct from a genuine "not a registered GSTIN" response, which still
reports verified=False like before.

webProc_AddCustomer and webProc_ModifyCustomer are both 40-param procs;
verified the source's call sites supply exactly 40 for both — unlike
CustEnquiry's Add call and the AMC/CustEnquiryAction procs, these two were
NOT short-by-N (worth checking every proc call this way; two of four found
in this project so far were actually broken).

Update (2026-08-04): fixed a real bug — right param COUNT, wrong VALUE.
@ReferredCustID (the actual FK both procs gate their referral-card
validation on: `If @ReferredCustID=0 and @ReferralCardNo<>'' -> 'Referral
card generated but referral customer not selected.'`) was hardcoded to
literal 0 in both add_customer_registration()/modify_customer_registration()
below, regardless of what the frontend's Referred By Customer picker
actually had selected — only the display-name string (@ReferredBy) was ever
sent, and neither CustRegistrationDetail nor the Angular form even carried
the numeric ID at all. Both procs only treat a referral as real when
@ReferredCustID>0 (and then re-derive @ReferredBy themselves from
CustomerMaster.displayName, ignoring whatever string was passed) — so any
customer with a Referral Card No filled in would hit that exact message and
silently fail to save, no matter what was picked. Fixed by adding
referred_by_customer_id to the request/response contract and threading the
real ID through to both proc calls; see also the Angular fix for a second,
independent bug in the same feature (referredByCustomerLabel in
cust-registration.ts) where the display name itself could go stale.
"""

import re
from datetime import date, datetime

import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

import requests
from fastapi import APIRouter, Depends
from pydantic import BaseModel

from app.db import get_cursor, rows_to_dicts
from app.deps import CurrentUser, get_current_user

router = APIRouter(prefix="/marketing/registration", tags=["marketing-registration"])

# Web_Enquiry.sourceDate is NOT NULL (confirmed live — an attempted NULL
# write throws a real 23000 IntegrityError and aborts the whole add/modify
# request even though the main proc already succeeded). The column's own
# established "unset" convention, from WebProc_AddCustEnquiry's own
# `@sourcedate datetime=''` default, is this sentinel — reused here instead
# of NULL whenever Enquiry Source 2 Date is left blank, and already what
# get_cust_registration_detail() below treats as "no date" on the way back out.
_NO_SOURCE_DATE = date(1900, 1, 1)


class LookupOption(BaseModel):
    label: str
    value: int


class CustRegistrationLookups(BaseModel):
    groups: list[LookupOption]
    case_types: list[LookupOption]
    business_natures: list[LookupOption]
    enquiry_sources: list[LookupOption]
    received_by_users: list[LookupOption]
    segments: list[LookupOption]
    providers: list[LookupOption]
    campaigns: list[LookupOption]
    continents: list[LookupOption]
    zones: list[LookupOption]
    countries: list[LookupOption]
    states: list[LookupOption]
    districts: list[LookupOption]
    cities: list[LookupOption]


class CustRegistrationDetail(BaseModel):
    cust_id: int = 0
    group_id: int = 0
    name: str = ""
    last_name: str = ""
    mobile_no: str = ""
    telephone_no: str = ""
    email: str = ""
    address1: str = ""
    address2: str = ""
    area: str = ""
    pin_code: str = ""
    contact_person: str = ""
    gstin: str = ""
    arn: str = ""
    case_type: str = ""
    hardware_partner: str = ""
    narration: str = ""
    continent_id: int = 1
    country_id: int = 91
    state_id: int = 15
    district_id: int = 0
    city_id: int = 0
    zone_id: int = 0
    enquiry_date: date
    received_by: int = 0
    enquiry_source: int = 0
    # Web_Enquiry.sourcetype2/sourceDate — a second Enquiry Source + its own
    # date, same EnquirySourceType master as enquiry_source above. Neither
    # webProc_AddCustomer/webProc_ModifyCustomer nor the WebProc_AddCustEnquiry
    # call embedded in webProc_AddCustomer's own body ever pass these through
    # (confirmed via OBJECT_DEFINITION — webProc_AddCustomer hardcodes its
    # inner EXEC WebProc_AddCustEnquiry call's args and stops one short of the
    # proc's own @sourcetype2/@sourcedate params, which is why they've always
    # defaulted to 0/''), so both are threaded through here via a follow-up
    # UPDATE Web_Enquiry after the main proc call succeeds — same established
    # pattern as this endpoint's own Proc_AssignCampaignToCust follow-up below.
    enquiry_source_2: int = 0
    enquiry_source_2_date: date | None = None
    source_detail: str = ""
    business_nature: int = 0
    segment: int = 0
    provider: int = 0
    referral_card_no: str = ""
    hardware: str = ""
    campaign_id: int = 0
    referred_by_name: str = ""
    # The actual FK the stored procs gate their referral-card validation on
    # (@ReferredCustID) — see add_customer_registration()/
    # modify_customer_registration() below. referred_by_name alone is not
    # enough: both procs only treat a referral as "selected" when this ID is
    # > 0, and (when it is) re-derive referred_by_name themselves from
    # CustomerMaster.displayName, ignoring whatever string was sent.
    referred_by_customer_id: int = 0
    assigned_to_name: str = ""


# GroupID for the fixed "CUSTOMERS" group used as the initial referral card generator context;
# not otherwise special-cased here.


def _little_master(cursor, master_name: str) -> list[LookupOption]:
    cursor.execute("EXEC Webproc_LittleMaster ?", master_name)
    return [LookupOption(label=r["MasterValue"], value=r["ID"]) for r in rows_to_dicts(cursor)]


@router.get("/lookups", response_model=CustRegistrationLookups)
def get_cust_registration_lookups() -> CustRegistrationLookups:
    with get_cursor() as cursor:
        cursor.execute("SELECT GroupID, Name FROM CustomerGroupMaster WHERE GroupType = 1 ORDER BY Name")
        groups = [LookupOption(label=r["Name"], value=r["GroupID"]) for r in rows_to_dicts(cursor)]

        cursor.execute("SELECT MasterValue FROM Web_LittleMaster WHERE MasterName = 'Case Type'")
        case_types = [LookupOption(label=r["MasterValue"], value=i) for i, r in enumerate(rows_to_dicts(cursor))]

        business_natures = _little_master(cursor, "BusinessNature")
        enquiry_sources = _little_master(cursor, "EnquirySourceType")
        segments = _little_master(cursor, "SegmentMaster")
        providers = _little_master(cursor, "Providers")

        cursor.execute(
            "SELECT UserID, name FROM usermaster WHERE enabled = 1 AND (UserType IN (1,6,3,5) OR userId IN (119,120)) ORDER BY name"
        )
        received_by_users = [LookupOption(label=r["name"], value=r["UserID"]) for r in rows_to_dicts(cursor)]

        cursor.execute("SELECT Name, CampaignID FROM CampaignMaster WHERE Disabled = 0 ORDER BY Name")
        campaigns = [LookupOption(label=r["Name"], value=r["CampaignID"]) for r in rows_to_dicts(cursor)]

        cursor.execute("SELECT ContinentID, ContinentName FROM geo_ContinentMaster WHERE Disabled = 0")
        continents = [LookupOption(label=r["ContinentName"], value=r["ContinentID"]) for r in rows_to_dicts(cursor)]

        cursor.execute("SELECT ZoneID, ZoneName FROM geo_ZoneMaster WHERE Disabled = 0")
        zones = [LookupOption(label=r["ZoneName"], value=r["ZoneID"]) for r in rows_to_dicts(cursor)]

        cursor.execute("SELECT CountryID, CountryName FROM geo_CountryMaster WHERE Disabled = 0 ORDER BY CountryName")
        countries = [LookupOption(label=r["CountryName"], value=r["CountryID"]) for r in rows_to_dicts(cursor)]

        cursor.execute("SELECT StateID, StateName FROM geo_StateMaster WHERE Disabled = 0 ORDER BY StateName")
        states = [LookupOption(label=r["StateName"], value=r["StateID"]) for r in rows_to_dicts(cursor)]

        cursor.execute(
            "SELECT DistrictID, DistrictName FROM Geo_DistrictMaster WHERE Disabled = 0 AND StateID IN (0, 15) ORDER BY DistrictName"
        )
        districts = [LookupOption(label=r["DistrictName"], value=r["DistrictID"]) for r in rows_to_dicts(cursor)]

        cursor.execute(
            "SELECT CityID, CityName FROM geo_CityMaster WHERE Disabled = 0 AND StateID IN (0, 15) ORDER BY CityName"
        )
        cities = [LookupOption(label=r["CityName"], value=r["CityID"]) for r in rows_to_dicts(cursor)]

    return CustRegistrationLookups(
        groups=groups, case_types=case_types, business_natures=business_natures, enquiry_sources=enquiry_sources,
        received_by_users=received_by_users, segments=segments, providers=providers, campaigns=campaigns,
        continents=continents, zones=zones, countries=countries, states=states, districts=districts, cities=cities,
    )


# Mirrors ComboFill.asmx's FillCustomerWithGroupID1 (rcbRefferedBy, shown when "Potential
# Customer" is unchecked) and FillPotentialCustomer (rcbrefcust, shown when it's checked) —
# both were genuinely load-on-demand RadComboBoxes in the source (EnableLoadOnDemand="True"),
# capped to a fixed TOP-N and re-queried by DisplayName as the user types, never a full
# CustomerMaster list. The earlier Angular port had stubbed both to a permanently empty list.
@router.get("/referred-by-customers", response_model=list[LookupOption])
def get_referred_by_customers(search: str = "") -> list[LookupOption]:
    with get_cursor() as cursor:
        if search.strip():
            # Smart keyword search — see marketing_enquiry.get_customers_for_search.
            keywords = search.split()
            where_clause = " AND ".join(["CM.DisplayName LIKE ?"] * len(keywords))
            params = [f"%{kw}%" for kw in keywords]
            cursor.execute(
                "SELECT TOP 100 CM.CustID, CM.DisplayName FROM CustomerMaster CM "
                "INNER JOIN CustomerGroupMaster G ON CM.GroupID = G.GroupID "
                f"WHERE G.GroupID = 1 AND {where_clause} ORDER BY CM.DisplayName",
                *params,
            )
        else:
            cursor.execute(
                "SELECT TOP 100 CM.CustID, CM.DisplayName FROM CustomerMaster CM "
                "INNER JOIN CustomerGroupMaster G ON CM.GroupID = G.GroupID "
                "WHERE G.GroupID = 1 ORDER BY CM.DisplayName"
            )
        return [LookupOption(label=r["DisplayName"] or "", value=r["CustID"]) for r in rows_to_dicts(cursor)]


@router.get("/potential-customers", response_model=list[LookupOption])
def get_potential_customers(search: str = "") -> list[LookupOption]:
    with get_cursor() as cursor:
        if search.strip():
            # Smart keyword search — see marketing_enquiry.get_customers_for_search.
            keywords = search.split()
            where_clause = " AND ".join(["DisplayName LIKE ?"] * len(keywords))
            params = [f"%{kw}%" for kw in keywords]
            cursor.execute(
                f"SELECT TOP 100 CustID, DisplayName FROM CustomerMaster WHERE GroupId <> 1 AND {where_clause} ORDER BY DisplayName",
                *params,
            )
        else:
            cursor.execute(
                "SELECT TOP 100 CustID, DisplayName FROM CustomerMaster WHERE GroupId <> 1 ORDER BY DisplayName"
            )
        return [LookupOption(label=r["DisplayName"] or "", value=r["CustID"]) for r in rows_to_dicts(cursor)]


# Mirrors ComboFill.asmx's FillCustomerWithGroupType1 (cmbCustomerName, the Modify-mode
# "Customer Name" search box) — same load-on-demand shape as referred-by-customers /
# potential-customers above (TOP 100, re-queried by DisplayName as the user types), scoped
# to GroupType=1 (the real "customer" groups, as opposed to Employees/Relatives/Business).
# The source additionally restricts results to the logged-in user's own customers when
# Session("usertype")=101 — a restricted sales-rep role; replicated via CurrentUser.user_type.
@router.get("/customer-name-search", response_model=list[LookupOption])
def search_customer_name(search: str = "", current_user: CurrentUser = Depends(get_current_user)) -> list[LookupOption]:
    with get_cursor() as cursor:
        own_only = current_user.user_type == "101"
        sql = (
            "SELECT TOP 100 CM.CustID, CM.DisplayName FROM CustomerMaster CM "
            "INNER JOIN CustomerGroupMaster G ON CM.GroupID = G.GroupID "
            "WHERE G.GroupType = 1"
        )
        params: list = []
        if own_only:
            sql += " AND CM.userID = ?"
            params.append(current_user.user_id)
        if search.strip():
            # Smart keyword search — see marketing_enquiry.get_customers_for_search.
            keywords = search.split()
            sql += " AND " + " AND ".join(["CM.DisplayName LIKE ?"] * len(keywords))
            params.extend(f"%{kw}%" for kw in keywords)
        sql += " ORDER BY CM.DisplayName"
        cursor.execute(sql, *params)
        return [LookupOption(label=r["DisplayName"] or "", value=r["CustID"]) for r in rows_to_dicts(cursor)]


@router.get("/cities-districts")
def get_cities_and_districts(state_id: int) -> dict:
    with get_cursor() as cursor:
        cursor.execute(
            "SELECT CityID, CityName FROM geo_CityMaster WHERE Disabled = 0 AND StateID IN (0, ?) ORDER BY CityName",
            state_id,
        )
        cities = [{"label": r["CityName"], "value": r["CityID"]} for r in rows_to_dicts(cursor)]
        cursor.execute(
            "SELECT DistrictID, DistrictName FROM Geo_DistrictMaster WHERE Disabled = 0 AND StateID IN (0, ?) ORDER BY DistrictName",
            state_id,
        )
        districts = [{"label": r["DistrictName"], "value": r["DistrictID"]} for r in rows_to_dicts(cursor)]
    return {"cities": cities, "districts": districts}


@router.get("/detail/{cust_id}")
def get_cust_registration_detail(cust_id: int) -> dict | None:
    with get_cursor() as cursor:
        cursor.execute(
            "SELECT C.GroupId, C.Name, C.Lastname, C.MobileNo, C.PhNo, C.Email, C.BldgName, C.Road, C.Area, "
            "C.Pincode, C.LandMark, C.GSTIN, C.ARN, C.Referance, C.ContinentID, C.CountryID, C.StateID, "
            "C.DistrictID, C.CityID, C.ZoneID FROM CustomerMaster C "
            "INNER JOIN CustomerGroupMaster G ON C.GroupId = G.GroupID WHERE C.CustID = ?",
            cust_id,
        )
        row = cursor.fetchone()
        if not row:
            return None
        c = dict(zip([col[0] for col in cursor.description], row))

        cursor.execute("EXEC Webproc_ViewEnquiry ?", cust_id)
        enq_rows = rows_to_dicts(cursor)
        e = enq_rows[0] if enq_rows else {}

    return {
        "cust_id": cust_id,
        "group_id": c.get("GroupId") or 0,
        "name": c.get("Name") or "",
        "last_name": c.get("Lastname") or "",
        "mobile_no": c.get("MobileNo") or "",
        "telephone_no": c.get("PhNo") or "",
        "email": c.get("Email") or "",
        "address1": c.get("BldgName") or "",
        "address2": c.get("Road") or "",
        "area": c.get("Area") or "",
        "pin_code": c.get("Pincode") or "",
        "contact_person": c.get("LandMark") or "",
        "gstin": c.get("GSTIN") or "",
        "arn": c.get("ARN") or "",
        "case_type": c.get("Referance") or "",
        "hardware_partner": "",
        "narration": e.get("Narration") or "",
        "continent_id": c.get("ContinentID") or 1,
        "country_id": c.get("CountryID") or 91,
        "state_id": c.get("StateID") or 15,
        "district_id": c.get("DistrictID") or 0,
        "city_id": c.get("CityID") or 0,
        "zone_id": c.get("ZoneID") or 0,
        "enquiry_date": e["EnquiryDate"].date().isoformat() if e.get("EnquiryDate") else datetime.now().date().isoformat(),
        "received_by": int(e.get("ReceivedBy") or 0),
        "enquiry_source": int(e.get("Sourcetype") or 0),
        # Webproc_ViewEnquiry's result has both a resolved-name "SourceType2"
        # (from an explicit isnull(...) subquery alias) and the raw numeric
        # "sourcetype2" (from its trailing E.* expansion) — same duplicate-ish
        # shape as the already-known Providers/Providers1 case, except here
        # the two only differ by case, which pyodbc's dict(zip(...)) keeps as
        # two distinct keys rather than collapsing them. The raw ID is what
        # this form's <p-select> needs (matches enquiry_source above).
        "enquiry_source_2": int(e.get("sourcetype2") or 0),
        # sourceDate's column default (@sourcedate datetime='' on
        # WebProc_AddCustEnquiry — an empty string implicitly converts to SQL
        # Server's epoch, 1900-01-01) means every pre-existing row has this
        # exact value even though the field was never actually set/used
        # before this feature — treated the same as "no date" rather than a
        # real saved date.
        "enquiry_source_2_date": (
            e["sourceDate"].date().isoformat()
            if e.get("sourceDate") and e["sourceDate"].date() != date(1900, 1, 1)
            else None
        ),
        "source_detail": e.get("SourceNarration") or "",
        "business_nature": int(e.get("NatureOfBusiness") or 0),
        "segment": int(e.get("Segment") or 0),
        "provider": int(e.get("Providers") or 0),
        "referral_card_no": e.get("ReferralCardNo") or "",
        "hardware": e.get("HardwarePatner") or "",
        "campaign_id": int(e.get("Campaign") or 0),
        "referred_by_name": e.get("ReferredByName") or "",
        "referred_by_customer_id": int(e.get("ReferredCustID") or 0),
        "assigned_to_name": e.get("AssignedToName") or "",
    }


def _city_name(cursor, city_id: int) -> str:
    if not city_id:
        return ""
    cursor.execute("SELECT CityName FROM geo_CityMaster WHERE CityID = ?", city_id)
    row = cursor.fetchone()
    return row[0] if row else ""


@router.post("/add")
def add_customer_registration(
    body: CustRegistrationDetail, current_user: CurrentUser = Depends(get_current_user)
) -> dict:
    with get_cursor() as cursor:
        city_name = _city_name(cursor, body.city_id)
        params = [
            body.name, body.group_id, body.mobile_no, body.email, body.address1, body.address2,
            city_name, body.contact_person, body.narration, body.last_name, body.telephone_no,
            body.area, body.pin_code, body.case_type, body.narration, current_user.user_id,
            body.received_by, body.enquiry_source, body.source_detail, body.business_nature, body.segment,
            0, "", 1, body.referral_card_no, body.continent_id, body.country_id, body.state_id,
            body.district_id, body.city_id, body.zone_id, 1, body.referred_by_customer_id, body.referred_by_name, 0,
            body.gstin, body.arn, body.provider, body.campaign_id, body.hardware,
        ]
        placeholders = ", ".join("?" for _ in params)
        cursor.execute(f"EXEC webProc_AddCustomer {placeholders}", *params)
        rows = rows_to_dicts(cursor)
    if not rows:
        return {"success": False, "custId": 0, "message": "Customer registration failed."}
    r = rows[0]
    if r.get("Campaign") and int(r.get("Campaign") or 0) > 0:
        with get_cursor() as cursor:
            cursor.execute("EXEC Proc_AssignCampaignToCust ?, ?", r["Campaign"], r["CustID"])
    if r.get("Success") and r.get("CustID"):
        # webProc_AddCustomer's own internal WebProc_AddCustEnquiry call never
        # passes @sourcetype2/@sourcedate (see CustRegistrationDetail's
        # enquiry_source_2 comment) — set here directly on the row it just
        # created, same follow-up-after-the-proc shape as the campaign
        # assignment above.
        with get_cursor() as cursor:
            cursor.execute(
                "UPDATE Web_Enquiry SET sourcetype2 = ?, sourceDate = ? WHERE CustID = ?",
                body.enquiry_source_2, body.enquiry_source_2_date or _NO_SOURCE_DATE, r["CustID"],
            )
    return {"success": bool(r.get("Success")), "custId": r.get("CustID") or 0, "message": r.get("ResultMessage") or ""}


@router.post("/modify")
def modify_customer_registration(
    body: CustRegistrationDetail, current_user: CurrentUser = Depends(get_current_user)
) -> dict:
    with get_cursor() as cursor:
        city_name = _city_name(cursor, body.city_id)
        params = [
            body.cust_id, body.name, body.group_id, body.mobile_no, body.email, body.address1, body.address2,
            city_name, body.contact_person, body.narration, body.last_name, body.telephone_no,
            body.area, body.pin_code, body.case_type, body.narration, current_user.user_id,
            body.received_by, body.enquiry_source, body.source_detail, body.business_nature, body.segment,
            0, "", body.referral_card_no, body.continent_id, body.country_id, body.state_id,
            body.district_id, body.city_id, body.zone_id, body.enquiry_date, body.referred_by_customer_id, body.referred_by_name, 0,
            body.gstin, body.arn, body.provider, body.campaign_id, body.hardware,
        ]
        placeholders = ", ".join("?" for _ in params)
        cursor.execute(f"EXEC webProc_ModifyCustomer {placeholders}", *params)
        rows = rows_to_dicts(cursor)
    if not rows:
        return {"success": False, "message": "Customer update failed."}
    r = rows[0]
    if r.get("Campaign") and int(r.get("Campaign") or 0) > 0:
        with get_cursor() as cursor:
            cursor.execute("EXEC Proc_AssignCampaignToCust ?, ?", r["Campaign"], r["CustID"])
    if r.get("Success"):
        # webProc_ModifyCustomer's own UPDATE Web_Enquiry statements never
        # touch sourcetype2/sourceDate either (see enquiry_source_2's
        # comment on CustRegistrationDetail) — same follow-up fix as add
        # above, keyed on the customer id the request already carries.
        with get_cursor() as cursor:
            cursor.execute(
                "UPDATE Web_Enquiry SET sourcetype2 = ?, sourceDate = ? WHERE CustID = ?",
                body.enquiry_source_2, body.enquiry_source_2_date or _NO_SOURCE_DATE, body.cust_id,
            )
    return {"success": bool(r.get("Success")), "message": r.get("ResultMessage") or ""}


@router.get("/check-mobile")
def check_mobile_availability(mobile_no: str) -> dict:
    with get_cursor() as cursor:
        cursor.execute(
            "SELECT TOP 1 CustID, Name FROM Customermaster WHERE RIGHT(MobileNo, 10) = RIGHT(?, 10)", mobile_no
        )
        row = cursor.fetchone()
    if row:
        return {"available": False, "custId": row[0]}
    return {"available": True}


_GSTIN_CODE_POINTS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
_GSTIN_FORMAT_RE = re.compile(r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$")


def _gstin_checksum(gstin_14: str) -> str:
    """Standard published GSTIN check-digit algorithm (MOD-36, alternating
    1x/2x factor over the first 14 characters). Verified against a real,
    widely-published example GSTIN — see module docstring."""
    factor = 1
    total = 0
    for ch in gstin_14:
        addend = factor * _GSTIN_CODE_POINTS.index(ch)
        factor = 2 if factor == 1 else 1
        total += (addend // 36) + (addend % 36)
    return _GSTIN_CODE_POINTS[(36 - (total % 36)) % 36]


def _is_valid_gstin(gstin: str) -> bool:
    gstin = gstin.strip().upper()
    return bool(_GSTIN_FORMAT_RE.match(gstin)) and _gstin_checksum(gstin[:14]) == gstin[14]


_LICENSE_SOAP_URL = "http://myretailware.com/service/license.asmx"
_LICENSE_SOAP_ACTION = "http://www.retailware.in/GSTIN_TaxPayerSearch"
# Retailware's own internal license-server service account, used verbatim
# from the legacy source (Section_Marketing/CustRegistration.aspx.vb,
# lnkbtnCheckGSTVarification_Click) — not a per-deployment secret, this is
# the one shared account the original ASP.NET app always used for this call.
_LICENSE_LOGIN_USER = "ajit"
_LICENSE_LOGIN_PASSWORD = "ajit99"
_LICENSE_SOFTWARE_ID = "1"
_LICENSE_CLIENT_ID = "11110"


def _gstin_taxpayer_search(gstin: str, username: str) -> str:
    """Calls the same internal SOAP endpoint the legacy app used for GST
    business-detail lookup (there is no government/third-party API involved
    — this proxies through Retailware's own license server). Raises on any
    transport/HTTP failure; returns "" if the service responds with no
    result element."""
    envelope = (
        '<?xml version="1.0" encoding="utf-8"?>'
        '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
        'xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
        "<soap:Body>"
        '<GSTIN_TaxPayerSearch xmlns="http://www.retailware.in/">'
        f"<LoginUserName>{_LICENSE_LOGIN_USER}</LoginUserName>"
        f"<LoginPassword>{_LICENSE_LOGIN_PASSWORD}</LoginPassword>"
        f"<SoftwareID>{_LICENSE_SOFTWARE_ID}</SoftwareID>"
        f"<ClientID>{_LICENSE_CLIENT_ID}</ClientID>"
        "<HDNumber></HDNumber>"
        "<MachineName>SERVER</MachineName>"
        f"<UserName>{escape(username)}</UserName>"
        f"<GSTIN>{escape(gstin)}</GSTIN>"
        "<IsPipeResponse>1</IsPipeResponse>"
        "</GSTIN_TaxPayerSearch>"
        "</soap:Body>"
        "</soap:Envelope>"
    )
    resp = requests.post(
        _LICENSE_SOAP_URL,
        data=envelope.encode("utf-8"),
        headers={"Content-Type": "text/xml; charset=utf-8", "SOAPAction": _LICENSE_SOAP_ACTION},
        timeout=15,
    )
    resp.raise_for_status()
    root = ET.fromstring(resp.content)
    for el in root.iter():
        if el.tag.endswith("GSTIN_TaxPayerSearchResult"):
            return el.text or ""
    return ""


def _parse_taxpayer_result(raw: str) -> dict:
    # Mirrors the legacy VB parsing exactly (CustRegistration.aspx.vb,
    # lnkbtnCheckGSTVarification_Click): pipe-delimited, index 0 = success
    # flag ("1"), 4 = business name, 9-17 = address fragments (joined with
    # ",", blanks skipped), 16 = pincode, 17 = area, 18 = state name,
    # 12 = district name. Indices 16/17 are deliberately reused (they land
    # inside the address join AND are pulled out as their own fields) —
    # that's the original app's own behavior, not a bug introduced here.
    parts = raw.split("|")
    if len(parts) < 19 or parts[0] != "1":
        return {"success": False}
    address_parts = [parts[i].strip() for i in range(9, 18) if parts[i].strip()]
    return {
        "success": True,
        "name": parts[4].strip(),
        "address1": ",".join(address_parts),
        "pin_code": parts[16].strip(),
        "area": parts[17].strip(),
        "state_name": parts[18].strip(),
        "district_name": parts[12].strip(),
    }


@router.get("/verify-gstin")
def verify_gstin(gstin: str, current_user: CurrentUser = Depends(get_current_user)) -> dict:
    # First confirms the GSTIN is well-formed (correct 15-char structure +
    # checksum) purely locally — cheap, and avoids spending an external call
    # on obviously-malformed input. Only a checksum-valid GSTIN goes on to
    # the real business-detail lookup below.
    if not _is_valid_gstin(gstin):
        return {"verified": False}

    gstin_clean = gstin.strip().upper()
    try:
        raw = _gstin_taxpayer_search(gstin_clean, current_user.username)
    except Exception as exc:
        # Format is valid but the external lookup itself failed (network,
        # timeout, malformed SOAP response) — report the format-check as
        # still good rather than falsely saying "Invalid", but surface the
        # lookup failure separately so the UI can tell the two apart.
        return {"verified": True, "gstApiError": f"Business-details lookup failed: {exc}"}

    parsed = _parse_taxpayer_result(raw)
    if not parsed["success"]:
        # The external service itself says this GSTIN isn't a real
        # registered business — matches the legacy app's "Invalid GSTN No"
        # for this exact case (StrResult(0) <> 1).
        return {"verified": False}

    state_id = 0
    district_id = 0
    with get_cursor() as cursor:
        if parsed["state_name"]:
            cursor.execute("SELECT StateID FROM geo_StateMaster WHERE StateName = ?", parsed["state_name"])
            row = cursor.fetchone()
            state_id = row[0] if row else 0
        if parsed["district_name"] and state_id:
            cursor.execute(
                "SELECT DistrictID FROM Geo_DistrictMaster WHERE DistrictName = ? AND StateID = ?",
                parsed["district_name"], state_id,
            )
            row = cursor.fetchone()
            district_id = row[0] if row else 0

    return {
        "verified": True,
        "name": parsed["name"],
        "address1": parsed["address1"],
        "pinCode": parsed["pin_code"],
        "area": parsed["area"],
        "stateId": state_id or None,
        "districtId": district_id or None,
    }


@router.get("/lookup-pincode")
def lookup_pincode(pin_code: str) -> dict | None:
    with get_cursor() as cursor:
        cursor.execute("SELECT TOP 1 Tehsil, District, State FROM PinCodeCityMaster WHERE Pincode = ?", pin_code)
        row = cursor.fetchone()
        if not row:
            return None
        district_name, state_name = row[1], row[2]
        cursor.execute("SELECT StateID FROM geo_StateMaster WHERE StateName = ?", state_name)
        state_row = cursor.fetchone()
        state_id = state_row[0] if state_row else 0
        cursor.execute("SELECT DistrictID FROM Geo_DistrictMaster WHERE DistrictName = ? AND StateID = ?", district_name, state_id)
        district_row = cursor.fetchone()
        district_id = district_row[0] if district_row else 0
    return {"stateId": state_id, "districtId": district_id}


@router.post("/create-city")
def create_city(state_id: int, city_name: str) -> dict:
    with get_cursor() as cursor:
        cursor.execute("EXEC WebProc_CreateCity ?, ?", state_id, city_name)
        rows = rows_to_dicts(cursor)
    if not rows:
        return {"cityId": 0, "message": "City creation failed."}
    r = rows[0]
    return {"cityId": r.get("CityID") or 0, "message": r.get("ResultMessage") or ""}
