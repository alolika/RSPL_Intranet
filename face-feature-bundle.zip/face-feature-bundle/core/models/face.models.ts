/**
 * Face-feature TypeScript interfaces, extracted from the BNI app's
 * `apps/web/src/app/core/models/index.ts`.
 *
 * Drop these somewhere in your `core/models` (or merge into your existing
 * `index.ts`). The two page components and `face.service.ts` import these
 * types; without them the lift won't compile.
 */

export interface EnrolledFace {
  memberId: string;
  memberName: string;
  firstName: string;
  /** Template set — one or more 128-float descriptors captured at enrolment.
   * Attendance matching takes the max cosine similarity across the set. */
  embeddings: number[][];
  photoUrl: string;
  faceRegisteredAt: string;
}

export interface FaceEmbeddingsResponse {
  faces: EnrolledFace[];
  etag: string;
}

export interface FaceEnrolResponse {
  memberId: string;
  faceRegisteredAt: string;
  photoUrl: string;
}

/**
 * Attendance-mark response.
 *
 * In the BNI app this carries a `state: MeetingState` field with the full
 * meeting roster + counters so the attendance screen can refresh its UI from
 * the same response. For the sister project, replace `AttendanceState` below
 * with whatever "current roster / today's state" shape your API returns, or
 * drop the `state` field entirely and refetch via a separate endpoint.
 *
 * The geolocation fields are additions required by the sister project —
 * they aren't on the BNI response. Make sure your server returns them.
 */
export interface FaceArrival {
  state: AttendanceState;        // replace with your tenant's state shape
  memberId: string;              // rename to employeeId if your domain prefers
  memberName: string;
  firstName: string;
  alreadyMarked: boolean;
  arrivalTime: string;           // server-clock ISO 8601
  confidence: number;
  // --- Added for the sister project (not in the BNI response) ---
  lat?: number;
  lng?: number;
  accuracyM?: number;
  city?: string;
  state_?: string;               // underscored to avoid clashing with .state above
  country?: string;
}

/** Placeholder — replace with your project's own aggregated state shape. */
export interface AttendanceState {
  summary: { arrived: number };
  arrivals: Array<{ memberId: string; arrivalTime: string }>;
}
