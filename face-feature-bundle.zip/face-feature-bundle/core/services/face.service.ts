import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { API_BASE } from '../constants/api';
import { FaceArrival, FaceEmbeddingsResponse, FaceEnrolResponse } from '../models';

/** HTTP client for the Phase 2 face endpoints. See /api/routers/face.py. */
@Injectable({ providedIn: 'root' })
export class FaceService {
  private readonly http = inject(HttpClient);

  /** Enrol or re-enrol a member. Admin only (server also enforces).
   *
   * `embeddings` is the full template set captured during enrolment. The server
   * stores it as-is so attendance matching can take the best per-template score.
   */
  register(memberId: string, embeddings: number[][], photo: Blob): Promise<FaceEnrolResponse> {
    const form = new FormData();
    form.append('embedding', JSON.stringify(embeddings));
    form.append('photo', photo, `${memberId}-face.jpg`);
    return firstValueFrom(
      this.http.post<FaceEnrolResponse>(`${API_BASE}/members/${encodeURIComponent(memberId)}/face`, form),
    );
  }

  clear(memberId: string): Promise<void> {
    return firstValueFrom(this.http.delete<void>(`${API_BASE}/members/${encodeURIComponent(memberId)}/face`));
  }

  /**
   * Fetch the full set of enrolled embeddings. Pass the previous ETag to let the
   * server return 304 — the caller gets ``null`` in that case and reuses its
   * cached copy.
   */
  async embeddings(ifNoneMatch?: string): Promise<FaceEmbeddingsResponse | null> {
    const headers = ifNoneMatch ? new HttpHeaders({ 'If-None-Match': ifNoneMatch }) : undefined;
    const response = await firstValueFrom(
      this.http.get<FaceEmbeddingsResponse>(`${API_BASE}/face-embeddings`, { headers, observe: 'response' }),
    );
    if (response.status === 304) {
      return null;
    }
    return response.body;
  }

  markByFace(meetingId: string, memberId: string, confidence: number): Promise<FaceArrival> {
    return firstValueFrom(
      this.http.post<FaceArrival>(`${API_BASE}/meetings/${encodeURIComponent(meetingId)}/attendance/face`, {
        memberId,
        confidence,
      }),
    );
  }
}
