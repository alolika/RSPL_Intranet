import { Component, ElementRef, OnDestroy, computed, inject, signal, viewChild } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import {
  IonBadge,
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonSpinner,
  IonTitle,
  IonToolbar,
  ViewWillEnter,
  ViewWillLeave,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  arrowBackOutline,
  checkmarkCircle,
  helpCircleOutline,
  refreshOutline,
  warningOutline,
} from 'ionicons/icons';

import { EnrolledFace, FaceEmbeddingsResponse, FaceArrival } from '../../../core/models';
import { FaceService } from '../../../core/services/face.service';
import { MeetingService } from '../../../core/services/meeting.service';
import { NotifyService } from '../../../core/services/notify.service';
import { SettingsService } from '../../../core/services/settings.service';
import { FaceApiService } from '../../../shared/face/face-api.service';
import { bestMatch, topMatch } from '../../../shared/face/matching';
import { greeting, primeSpeech, speakGreeting } from '../../../shared/face/voice';
import { toAppError } from '../../../shared/utils/error-message';

type Phase = 'preparing' | 'scanning' | 'blink' | 'matching' | 'success' | 'alreadyMarked' | 'unknown' | 'error';
type Guidance = 'position' | 'noFace' | 'multiple' | 'tooSmall' | 'tooLarge' | 'offCenter' | 'ok';

/** Cosine threshold mirroring FACE_MATCH_THRESHOLD on the backend. */
const MATCH_THRESHOLD = 0.45;
const DETECTION_INTERVAL_MS = 180;
const BLINK_PROMPT_TIMEOUT_MS = 4500;
const BLINK_EAR_CLOSED = 0.22;
const BLINK_EAR_OPEN = 0.23;
/** Face briefly disappears during a natural blink; tolerate up to this many
 * consecutive bad frames before dropping back to scanning. */
const BLINK_GRACE_FRAMES = 8;
/** When blink is NOT required, require this many consecutive well-framed
 * detections before auto-marking. Prevents a single noisy frame from firing. */
const STABLE_FRAMES_TO_MARK = 5;
const RESULT_DISPLAY_MS = 2200;
const SUPPRESSION_WINDOW_MS = 2500;
const COUNTER_POLL_MS = 5000;
const EMBEDDINGS_REFRESH_MS = 120_000;

interface Toast {
  phase: Phase;
  firstName: string;
  memberName: string;
  photoUrl: string;
  arrivalTime: string;
  /** Diagnostic — top candidate's name on an "unknown" result ("" when no templates enrolled). */
  closestName: string;
  /** Diagnostic — top cosine similarity on an "unknown" result (NaN when empty). */
  closestScore: number;
}

@Component({
  selector: 'app-attendance-face',
  standalone: true,
  imports: [
    RouterLink,
    IonHeader,
    IonToolbar,
    IonButtons,
    IonButton,
    IonTitle,
    IonContent,
    IonIcon,
    IonBadge,
    IonSpinner,
  ],
  template: `
    <ion-header>
      <ion-toolbar color="primary">
        <ion-buttons slot="start">
          <ion-button [routerLink]="['/meeting']" aria-label="Back">
            <ion-icon slot="icon-only" name="arrow-back-outline" />
          </ion-button>
        </ion-buttons>
        <ion-title>Attendance (Face)</ion-title>
        <ion-buttons slot="end">
          <ion-button (click)="refresh()" aria-label="Refresh members">
            <ion-icon slot="icon-only" name="refresh-outline" />
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>
    <ion-content>
      <div class="face-page">
        <div class="viewfinder">
          <video #video playsinline autoplay muted></video>
          <canvas #overlay class="overlay"></canvas>
          @if (toast(); as t) {
            @if (t.phase === 'success' || t.phase === 'alreadyMarked') {
              <div class="splash" [class.alreadyMarked]="t.phase === 'alreadyMarked'" role="status" aria-live="polite">
                @if (t.photoUrl) {
                  <img class="splash-photo" [src]="t.photoUrl" alt="" />
                } @else {
                  <ion-icon class="splash-icon" name="checkmark-circle" aria-hidden="true" />
                }
                <div class="splash-name">{{ t.memberName }}</div>
                @if (t.phase === 'success') {
                  <div class="splash-greeting">{{ greetingFor(t.firstName) }}</div>
                  <div class="splash-time">Marked at {{ t.arrivalTime }}</div>
                } @else {
                  <div class="splash-greeting">Already marked</div>
                  <div class="splash-time">at {{ t.arrivalTime }}</div>
                }
              </div>
            } @else {
              <div class="result warn" role="alert">
                <ion-icon name="help-circle-outline" aria-hidden="true" />
                <div class="result-text">
                  <strong>Not recognised</strong>
                  @if (t.closestName) {
                    <span>Closest: {{ t.closestName }} ({{ t.closestScore.toFixed(2) }}, need ≥ {{ matchThresholdDisplay }})</span>
                  } @else {
                    <span>Try again or mark manually</span>
                  }
                </div>
              </div>
            }
          }
        </div>

        <div class="status-bar">
          <ion-badge color="primary">{{ arrivedCount() }} marked</ion-badge>
          <ion-badge color="medium" [attr.title]="'Enrolled members'">{{ enrolledCount() }} enrolled</ion-badge>
        </div>

        <div class="status">
          @switch (phase()) {
            @case ('preparing') {
              <p><ion-spinner name="crescent" /> Starting camera…</p>
            }
            @case ('scanning') {
              <p [class]="guidance() === 'ok' ? 'ok' : 'guide'">{{ guideMessage() }}</p>
            }
            @case ('blink') {
              <p class="prompt">Please blink</p>
            }
            @case ('matching') {
              <p><ion-spinner name="dots" /> Checking…</p>
            }
            @case ('error') {
              <p class="error-list" role="alert">
                <ion-icon name="warning-outline" aria-hidden="true" /> {{ errorMessage() }}
              </p>
            }
          }
        </div>

        <div class="actions">
          @if (meetingId()) {
            <ion-button fill="outline" [routerLink]="['/meeting', meetingId(), 'attendance']">
              Mark manually
            </ion-button>
          }
        </div>
      </div>
    </ion-content>
  `,
  styles: `
    .face-page {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 10px;
      padding: 12px;
    }
    .viewfinder {
      position: relative;
      width: min(360px, 100%);
      aspect-ratio: 3 / 4;
      background: #000;
      border-radius: 18px;
      overflow: hidden;
      box-shadow: 0 10px 24px rgba(0, 0, 0, 0.22);
    }
    .viewfinder video {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transform: scaleX(-1);
    }
    .overlay {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .result {
      position: absolute;
      inset: auto 8px 8px 8px;
      padding: 10px 12px;
      border-radius: 12px;
      background: rgba(178, 106, 0, 0.92);
      color: #fff;
      display: flex;
      align-items: center;
      gap: 10px;
      box-shadow: 0 6px 16px rgba(0, 0, 0, 0.28);
    }
    .result ion-icon { font-size: 44px; }
    .result-text { display: flex; flex-direction: column; }
    .result-text strong { font-size: 1rem; }
    .result-text span { font-size: 0.82rem; opacity: 0.9; }

    /* Full-viewfinder splash shown on successful match / already-marked.
     * Covers the live video so the attendee gets an unmissable confirmation. */
    .splash {
      position: absolute;
      inset: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 10px;
      padding: 20px;
      text-align: center;
      color: #fff;
      background: linear-gradient(145deg, #0ea80e 0%, #0a7a0a 100%);
      animation: splash-in 180ms ease-out;
    }
    .splash.alreadyMarked {
      background: linear-gradient(145deg, #585858 0%, #3a3a3a 100%);
    }
    .splash-photo {
      width: 140px;
      height: 140px;
      border-radius: 50%;
      object-fit: cover;
      border: 4px solid rgba(255, 255, 255, 0.85);
      box-shadow: 0 10px 24px rgba(0, 0, 0, 0.35);
    }
    .splash-icon {
      font-size: 128px;
      color: #fff;
      filter: drop-shadow(0 4px 10px rgba(0, 0, 0, 0.3));
    }
    .splash-name {
      font-size: 1.9rem;
      font-weight: 800;
      line-height: 1.15;
      margin-top: 4px;
      letter-spacing: 0.3px;
      text-shadow: 0 2px 6px rgba(0, 0, 0, 0.25);
    }
    .splash-greeting {
      font-size: 1.05rem;
      font-weight: 600;
      opacity: 0.95;
    }
    .splash-time {
      font-size: 0.85rem;
      opacity: 0.8;
    }
    @keyframes splash-in {
      from { opacity: 0; transform: scale(0.94); }
      to { opacity: 1; transform: scale(1); }
    }

    .status-bar {
      display: flex;
      gap: 8px;
    }
    .status p { margin: 4px 0; text-align: center; }
    .status .guide { color: var(--ion-color-warning-shade, #b26a00); }
    .status .ok { color: var(--ion-color-success-shade, #0e7c0e); font-weight: 600; }
    .status .prompt { font-size: 1.1rem; font-weight: 700; color: var(--ion-color-primary); }

    .actions { margin-top: 4px; }
  `,
})
export class AttendanceFacePage implements ViewWillEnter, ViewWillLeave, OnDestroy {
  protected readonly matchThresholdDisplay = MATCH_THRESHOLD.toFixed(2);

  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly meetingsApi = inject(MeetingService);
  private readonly faces = inject(FaceService);
  private readonly faceApi = inject(FaceApiService);
  private readonly notify = inject(NotifyService);
  private readonly settingsApi = inject(SettingsService);

  private readonly videoRef = viewChild<ElementRef<HTMLVideoElement>>('video');
  private readonly overlayRef = viewChild<ElementRef<HTMLCanvasElement>>('overlay');

  protected readonly meetingId = signal<string>('');
  protected readonly phase = signal<Phase>('preparing');
  protected readonly guidance = signal<Guidance>('position');
  protected readonly toast = signal<Toast | null>(null);
  protected readonly errorMessage = signal('');
  protected readonly arrivedCount = signal(0);
  protected readonly enrolled = signal<EnrolledFace[]>([]);
  protected readonly enrolledCount = computed(() => this.enrolled().length);

  protected greetingFor(firstName: string): string {
    return greeting(firstName);
  }

  protected readonly guideMessage = computed(() => {
    switch (this.guidance()) {
      case 'noFace': return 'Position your face in the oval.';
      case 'multiple': return 'One person at a time, please.';
      case 'tooSmall': return 'Move a little closer.';
      case 'tooLarge': return 'Move a little further back.';
      case 'offCenter': return 'Center your face in the oval.';
      case 'ok': return this.requireBlink ? 'Hold steady — blink to confirm.' : 'Hold steady…';
      case 'position':
      default:
        return 'Position your face in the oval.';
    }
  });

  private stream: MediaStream | null = null;
  private detectTimer: ReturnType<typeof setInterval> | null = null;
  private counterTimer: ReturnType<typeof setInterval> | null = null;
  private embeddingsTimer: ReturnType<typeof setInterval> | null = null;
  private resultTimeout: ReturnType<typeof setTimeout> | null = null;
  private embeddingsEtag: string | null = null;
  private arrivedIds = new Set<string>();
  private suppressedUntil = new Map<string, number>();
  private blinkStartedAt = 0;
  private earHistory: number[] = [];
  private seenClosed = false;
  private missedBlinkFrames = 0;
  private stableFrames = 0;
  private requireBlink = false;
  private disposed = false;

  constructor() {
    addIcons({ arrowBackOutline, checkmarkCircle, helpCircleOutline, refreshOutline, warningOutline });
  }

  ionViewWillEnter(): void {
    const id = this.route.snapshot.paramMap.get('meetingId') ?? '';
    this.meetingId.set(id);
    if (!id) {
      this.showError('No meeting selected.');
      return;
    }
    void this.start();
  }

  ionViewWillLeave(): void {
    this.stopAll();
  }

  ngOnDestroy(): void {
    this.disposed = true;
    this.stopAll();
  }

  async start(): Promise<void> {
    this.phase.set('preparing');
    try {
      await this.faceApi.ensureReady();
      const [, , chapterSettings] = await Promise.all([
        this.loadEmbeddings(true),
        this.pollCounter(),
        this.settingsApi.get(),
      ]);
      this.requireBlink = chapterSettings.faceAttendanceRequireBlink;
      // Warm up TTS so the first greeting plays reliably on browsers that
      // defer voice loading or require a silent prime after the user gesture.
      primeSpeech();
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 720 }, height: { ideal: 960 } },
        audio: false,
      });
      const video = this.videoRef()?.nativeElement;
      if (!video) throw new Error('Camera surface not ready.');
      video.srcObject = this.stream;
      await video.play();
      const overlay = this.overlayRef()?.nativeElement;
      if (overlay) {
        overlay.width = video.videoWidth;
        overlay.height = video.videoHeight;
      }
      this.drawOverlay();
      this.phase.set('scanning');
      this.detectTimer = setInterval(() => void this.tick(), DETECTION_INTERVAL_MS);
      this.counterTimer = setInterval(() => void this.pollCounter(), COUNTER_POLL_MS);
      this.embeddingsTimer = setInterval(() => void this.loadEmbeddings(false), EMBEDDINGS_REFRESH_MS);
    } catch (err) {
      this.showError(err instanceof Error ? err.message : 'Could not start the camera.');
    }
  }

  async refresh(): Promise<void> {
    try {
      await this.loadEmbeddings(true);
      await this.pollCounter();
      await this.notify.success('Members refreshed.');
    } catch (err) {
      await this.notify.error(err);
    }
  }

  // --------------------------------------------------------- main loop
  private async tick(): Promise<void> {
    if (this.disposed) return;
    const current = this.phase();
    if (current !== 'scanning' && current !== 'blink') {
      return;
    }
    const video = this.videoRef()?.nativeElement;
    if (!video || video.readyState < 2 || !video.videoWidth) {
      return;
    }
    let result;
    try {
      result = await this.faceApi.detect(video);
    } catch {
      return;
    }
    if (!result) {
      // Face briefly disappears during a natural blink. Preserve the blink
      // state unless we've seen many consecutive bad frames in a row.
      if (current === 'blink' && this.missedBlinkFrames < BLINK_GRACE_FRAMES) {
        this.missedBlinkFrames += 1;
        return;
      }
      this.stableFrames = 0;
      this.handleGuidance('noFace');
      if (current === 'blink') {
        this.returnToScanning();
      }
      return;
    }
    const framing = this.framingCheck(result.box, video);
    if (framing !== 'ok') {
      if (current === 'blink' && this.missedBlinkFrames < BLINK_GRACE_FRAMES) {
        this.missedBlinkFrames += 1;
        return;
      }
      this.stableFrames = 0;
      this.handleGuidance(framing);
      if (current === 'blink') {
        this.returnToScanning();
      }
      return;
    }
    this.missedBlinkFrames = 0;
    this.handleGuidance('ok');

    if (current === 'scanning') {
      if (!this.requireBlink) {
        // No blink required: wait for a few stable frames, then match directly.
        this.stableFrames += 1;
        if (this.stableFrames >= STABLE_FRAMES_TO_MARK) {
          this.stableFrames = 0;
          this.phase.set('matching');
          void this.matchAndMark(result.descriptor);
        }
        return;
      }
      this.phase.set('blink');
      this.blinkStartedAt = performance.now();
      this.earHistory = [];
      this.seenClosed = false;
      this.missedBlinkFrames = 0;
      return;
    }
    // Blink detection path
    const ear = this.faceApi.eyeAspectRatio(result.landmarks);
    this.earHistory.push(ear);
    if (this.earHistory.length > 20) this.earHistory.shift();
    if (!this.seenClosed && ear < BLINK_EAR_CLOSED) {
      this.seenClosed = true;
    }
    if (this.seenClosed && ear > BLINK_EAR_OPEN) {
      // Blink confirmed → match + mark
      this.phase.set('matching');
      void this.matchAndMark(result.descriptor);
      return;
    }
    if (performance.now() - this.blinkStartedAt > BLINK_PROMPT_TIMEOUT_MS) {
      // Reset the blink window without bouncing out — the user just needs more time.
      this.blinkStartedAt = performance.now();
      this.earHistory = [];
      this.seenClosed = false;
    }
  }

  private returnToScanning(): void {
    this.phase.set('scanning');
    this.earHistory = [];
    this.seenClosed = false;
    this.missedBlinkFrames = 0;
  }

  private framingCheck(box: { x: number; y: number; width: number; height: number }, video: HTMLVideoElement): Guidance {
    const ratio = box.width / video.videoWidth;
    if (ratio < 0.15) return 'tooSmall';
    if (ratio > 0.85) return 'tooLarge';
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;
    // Oval axes slightly larger than the drawn guide so a face hugging the
    // edge of the oval doesn't bounce out.
    const dx = (cx - video.videoWidth / 2) / (video.videoWidth * 0.42);
    const dy = (cy - video.videoHeight / 2) / (video.videoHeight * 0.48);
    if (dx * dx + dy * dy > 1) return 'offCenter';
    return 'ok';
  }

  private handleGuidance(g: Guidance): void {
    if (this.phase() === 'scanning') {
      this.guidance.set(g);
    }
  }

  // --------------------------------------------------------- match + mark
  private async matchAndMark(descriptor: Float32Array): Promise<void> {
    const match = bestMatch(descriptor, this.enrolled(), MATCH_THRESHOLD);
    if (!match) {
      const top = topMatch(descriptor, this.enrolled());
      this.showToast({
        phase: 'unknown',
        memberName: '',
        firstName: '',
        photoUrl: '',
        arrivalTime: '',
        closestName: top?.face.memberName ?? '',
        closestScore: top?.similarity ?? NaN,
      });
      return;
    }
    const now = performance.now();
    const suppressed = (this.suppressedUntil.get(match.face.memberId) ?? 0) > now;
    if (suppressed) {
      this.phase.set('scanning');
      return;
    }
    this.suppressedUntil.set(match.face.memberId, now + SUPPRESSION_WINDOW_MS);
    try {
      const arrival = await this.faces.markByFace(this.meetingId(), match.face.memberId, match.similarity);
      this.applyArrival(arrival);
    } catch (err) {
      this.phase.set('scanning');
      await this.notify.error(err);
    }
  }

  private applyArrival(arrival: FaceArrival): void {
    this.arrivedCount.set(arrival.state.summary.arrived);
    this.arrivedIds = new Set(arrival.state.arrivals.map((a) => a.memberId));
    if (arrival.alreadyMarked) {
      this.showToast({
        phase: 'alreadyMarked',
        memberName: arrival.memberName,
        firstName: arrival.firstName,
        photoUrl: this.photoFor(arrival.memberId),
        arrivalTime: arrival.arrivalTime,
        closestName: '',
        closestScore: NaN,
      });
      return;
    }
    speakGreeting(arrival.firstName);
    this.showToast({
      phase: 'success',
      memberName: arrival.memberName,
      firstName: arrival.firstName,
      photoUrl: this.photoFor(arrival.memberId),
      arrivalTime: arrival.arrivalTime,
      closestName: '',
      closestScore: NaN,
    });
  }

  private photoFor(memberId: string): string {
    return this.enrolled().find((f) => f.memberId === memberId)?.photoUrl ?? '';
  }

  private showToast(toast: Toast): void {
    this.toast.set(toast);
    this.phase.set(toast.phase);
    if (this.resultTimeout !== null) clearTimeout(this.resultTimeout);
    this.resultTimeout = setTimeout(() => {
      this.toast.set(null);
      this.phase.set('scanning');
    }, RESULT_DISPLAY_MS);
  }

  // --------------------------------------------------------- data pulls
  private async loadEmbeddings(force: boolean): Promise<void> {
    try {
      const response: FaceEmbeddingsResponse | null = await this.faces.embeddings(
        force ? undefined : this.embeddingsEtag ?? undefined,
      );
      if (response) {
        this.enrolled.set(response.faces);
        this.embeddingsEtag = response.etag;
      }
    } catch (err) {
      // Non-fatal: keep whatever we already have.
      console.warn('Failed to refresh face embeddings', err);
    }
  }

  private async pollCounter(): Promise<void> {
    const id = this.meetingId();
    if (!id) return;
    try {
      const state = await this.meetingsApi.state(id);
      this.arrivedCount.set(state.summary.arrived);
      this.arrivedIds = new Set(state.arrivals.map((a) => a.memberId));
    } catch (err) {
      console.warn('Failed to refresh attendance counter', err);
    }
  }

  // --------------------------------------------------------- overlay
  private drawOverlay(): void {
    const canvas = this.overlayRef()?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const { width, height } = canvas;
    ctx.clearRect(0, 0, width, height);
    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
    ctx.fillRect(0, 0, width, height);
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.ellipse(width / 2, height / 2, width * 0.35, height * 0.4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(width / 2, height / 2, width * 0.35, height * 0.4, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  // --------------------------------------------------------- cleanup
  private stopAll(): void {
    this.clearTimer('detectTimer');
    this.clearTimer('counterTimer');
    this.clearTimer('embeddingsTimer');
    if (this.resultTimeout !== null) {
      clearTimeout(this.resultTimeout);
      this.resultTimeout = null;
    }
    const video = this.videoRef()?.nativeElement;
    if (video) {
      video.pause();
      video.srcObject = null;
    }
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }

  private clearTimer(name: 'detectTimer' | 'counterTimer' | 'embeddingsTimer'): void {
    const t = this[name];
    if (t !== null) {
      clearInterval(t);
      this[name] = null;
    }
  }

  private showError(message: string): void {
    this.errorMessage.set(message);
    this.phase.set('error');
    this.stopAll();
  }
}
