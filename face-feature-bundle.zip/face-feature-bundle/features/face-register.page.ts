import { Component, ElementRef, OnDestroy, computed, inject, signal, viewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import type * as faceapi from '@vladmandic/face-api';
import {
  IonAvatar,
  IonBadge,
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonItem,
  IonLabel,
  IonList,
  IonMenuButton,
  IonSearchbar,
  IonSpinner,
  IonTitle,
  IonToolbar,
  ViewWillEnter,
  ViewWillLeave,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  checkmarkCircle,
  closeOutline,
  personCircleOutline,
  refreshOutline,
  scanCircleOutline,
} from 'ionicons/icons';

import { Member } from '../../../core/models';
import { FaceService } from '../../../core/services/face.service';
import { MemberService } from '../../../core/services/member.service';
import { NotifyService } from '../../../core/services/notify.service';
import { FaceApiService, FACE_DESCRIPTOR_LENGTH } from '../../../shared/face/face-api.service';
import { toAppError } from '../../../shared/utils/error-message';
import { normalise } from '../../../shared/utils/search';

type Phase = 'picker' | 'preparing' | 'guiding' | 'capturing' | 'uploading' | 'done' | 'error';
type Guidance = 'position' | 'noFace' | 'multiple' | 'tooSmall' | 'tooLarge' | 'offCenter' | 'ok';

const SHOT_COUNT = 15;
const CAPTURE_INTERVAL_MS = 400;
const STABLE_FRAMES_REQUIRED = 10;
const DETECTION_INTERVAL_MS = 150;
const REFERENCE_IMAGE_SIDE = 320;
/** Minimum detector score for a captured frame to be kept. Keeps noisy frames
 * (motion blur, half-turn, odd angles) out of the averaged template. */
const MIN_CAPTURE_SCORE = 0.75;
/** Split the 15 captures into 3 pose phases of 5 each so the stored template
 * reflects a small range of head angles instead of one frozen pose. */
const CAPTURES_PER_POSE = 5;
const POSE_PROMPTS = [
  'Look straight at the camera',
  'Turn your head slightly left',
  'Turn your head slightly right',
] as const;

@Component({
  selector: 'app-face-register',
  standalone: true,
  imports: [
    FormsModule,
    IonHeader,
    IonToolbar,
    IonButtons,
    IonMenuButton,
    IonTitle,
    IonContent,
    IonSearchbar,
    IonList,
    IonItem,
    IonLabel,
    IonAvatar,
    IonBadge,
    IonButton,
    IonIcon,
    IonSpinner,
  ],
  template: `
    <ion-header>
      <ion-toolbar color="primary">
        <ion-buttons slot="start">
          @if (phase() === 'picker') {
            <ion-menu-button />
          } @else {
            <ion-button (click)="backToPicker()" aria-label="Back to member list">
              <ion-icon slot="icon-only" name="close-outline" />
            </ion-button>
          }
        </ion-buttons>
        <ion-title>{{ phase() === 'picker' ? 'Face registration' : selected()?.memberName }}</ion-title>
      </ion-toolbar>
    </ion-header>
    <ion-content>
      @if (phase() === 'picker') {
        <div class="page-container">
          <div class="toolbar ion-padding-horizontal">
            <ion-searchbar placeholder="Filter by name" [(ngModel)]="filter" (ionInput)="filter = $any($event).detail.value ?? ''" />
          </div>
          @if (loadingMembers()) {
            <p class="ion-padding"><ion-spinner name="crescent" /> Loading members…</p>
          } @else if (membersError()) {
            <p class="ion-padding error-list" role="alert">{{ membersError() }}</p>
          } @else {
            <p class="ion-padding-horizontal muted">{{ visible().length }} of {{ members().length }} members</p>
            <ion-list>
              @for (m of visible(); track m.memberId) {
                <ion-item button detail (click)="startCapture(m)">
                  <ion-avatar slot="start">
                    @if (m.photoUrl) {
                      <img [src]="m.photoUrl" alt="" [style.object-position]="m.photoCropX + '% ' + m.photoCropY + '%'" />
                    } @else {
                      <ion-icon name="person-circle-outline" class="placeholder" aria-hidden="true" />
                    }
                  </ion-avatar>
                  <ion-label>
                    <h2>{{ m.memberName }}</h2>
                    <p>{{ m.businessName }}{{ m.category ? ' · ' + m.category : '' }}</p>
                  </ion-label>
                  @if (m.faceRegisteredAt) {
                    <ion-badge slot="end" color="success">
                      <ion-icon name="checkmark-circle" aria-hidden="true" /> Enrolled
                    </ion-badge>
                  }
                </ion-item>
              } @empty {
                <ion-item lines="none"><ion-label class="muted">No members found.</ion-label></ion-item>
              }
            </ion-list>
          }
        </div>
      } @else {
        <div class="camera-container">
          <div class="viewfinder">
            <video #video playsinline autoplay muted></video>
            <canvas #overlay class="overlay"></canvas>
            @if (phase() === 'uploading') {
              <div class="scrim">
                <ion-spinner name="crescent" />
                <p>Saving…</p>
              </div>
            }
            @if (phase() === 'done') {
              <div class="scrim success">
                <ion-icon name="checkmark-circle" />
                <p>Enrolled</p>
              </div>
            }
          </div>

          <div class="status">
            @if (phase() === 'preparing') {
              <p><ion-spinner name="crescent" /> Starting camera…</p>
            } @else if (phase() === 'guiding') {
              <p [class]="guidance() === 'ok' ? 'ok' : 'guide'">{{ guideMessage() }}</p>
            } @else if (phase() === 'capturing') {
              <p class="ok">{{ posePrompt() }}</p>
              <p class="muted">Captured {{ shotsTaken() }} of {{ shotCount }}</p>
            } @else if (phase() === 'uploading') {
              <p>Averaging and saving your face…</p>
            } @else if (phase() === 'done') {
              <p>{{ selected()?.memberName }} is enrolled.</p>
              <div class="actions">
                <ion-button fill="outline" (click)="backToPicker()">
                  <ion-icon slot="start" name="refresh-outline" /> Register another
                </ion-button>
              </div>
            } @else if (phase() === 'error') {
              <p class="error-list" role="alert">{{ errorMessage() }}</p>
              <div class="actions">
                <ion-button fill="outline" (click)="backToPicker()">
                  <ion-icon slot="start" name="close-outline" /> Back to members
                </ion-button>
              </div>
            }
          </div>
        </div>
      }
    </ion-content>
  `,
  styles: `
    .toolbar {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }
    .toolbar ion-searchbar { flex: 1 1 260px; }
    ion-avatar img { object-fit: cover; }
    .placeholder { width: 100%; height: 100%; color: var(--app-muted); }

    .camera-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 12px;
      padding: 12px;
    }
    .viewfinder {
      position: relative;
      width: min(360px, 100%);
      aspect-ratio: 3 / 4;
      background: #000;
      border-radius: 18px;
      overflow: hidden;
      box-shadow: 0 10px 24px rgba(0, 0, 0, 0.22);
    }
    .viewfinder video {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transform: scaleX(-1); /* Mirror the selfie view so the user's left is on screen left. */
    }
    .overlay {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
    }
    .scrim {
      position: absolute;
      inset: 0;
      background: rgba(0, 0, 0, 0.55);
      color: #fff;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }
    .scrim.success { background: rgba(16, 124, 16, 0.72); }
    .scrim ion-icon { font-size: 72px; }

    .status p { margin: 4px 0; text-align: center; }
    .status .guide { color: var(--ion-color-warning-shade, #b26a00); }
    .status .ok { color: var(--ion-color-success-shade, #0e7c0e); font-weight: 600; }
    .actions { display: flex; justify-content: center; margin-top: 12px; }
  `,
})
export class FaceRegisterPage implements ViewWillEnter, ViewWillLeave, OnDestroy {
  protected readonly shotCount = SHOT_COUNT;

  private readonly api = inject(MemberService);
  private readonly faces = inject(FaceService);
  private readonly faceApi = inject(FaceApiService);
  private readonly notify = inject(NotifyService);

  private readonly videoRef = viewChild<ElementRef<HTMLVideoElement>>('video');
  private readonly overlayRef = viewChild<ElementRef<HTMLCanvasElement>>('overlay');

  // ----- Picker state --------------------------------------------------
  protected readonly members = signal<Member[]>([]);
  protected readonly loadingMembers = signal(true);
  protected readonly membersError = signal('');
  private readonly filterText = signal('');

  protected readonly visible = computed(() => {
    const q = normalise(this.filterText());
    return this.members()
      .filter((m) => m.active && (!q || normalise(m.memberName).includes(q)))
      .sort((a, b) => a.memberName.localeCompare(b.memberName));
  });

  get filter(): string { return this.filterText(); }
  set filter(value: string) { this.filterText.set(value); }

  // ----- Capture state -------------------------------------------------
  protected readonly phase = signal<Phase>('picker');
  protected readonly selected = signal<Member | null>(null);
  protected readonly guidance = signal<Guidance>('position');
  protected readonly shotsTaken = signal(0);
  protected readonly errorMessage = signal('');

  protected readonly guideMessage = computed(() => {
    switch (this.guidance()) {
      case 'noFace': return 'Looking for a face…';
      case 'multiple': return 'One person at a time, please.';
      case 'tooSmall': return 'Move a little closer.';
      case 'tooLarge': return 'Move a little further back.';
      case 'offCenter': return 'Center your face in the oval.';
      case 'ok': return 'Hold steady — capturing in a moment.';
      case 'position':
      default:
        return 'Position your face in the oval.';
    }
  });

  protected readonly posePrompt = computed(() => {
    const idx = Math.min(POSE_PROMPTS.length - 1, Math.floor(this.shotsTaken() / CAPTURES_PER_POSE));
    return POSE_PROMPTS[idx];
  });

  private stableFrames = 0;
  private descriptors: Float32Array[] = [];
  private bestShot: { score: number; descriptor: Float32Array } | null = null;
  private stream: MediaStream | null = null;
  private detectTimer: ReturnType<typeof setInterval> | null = null;
  private captureTimer: ReturnType<typeof setInterval> | null = null;
  private disposed = false;

  constructor() {
    addIcons({ checkmarkCircle, closeOutline, personCircleOutline, refreshOutline, scanCircleOutline });
  }

  ionViewWillEnter(): void {
    void this.loadMembers();
  }

  ionViewWillLeave(): void {
    this.stopCamera();
  }

  ngOnDestroy(): void {
    this.disposed = true;
    this.stopCamera();
  }

  async loadMembers(): Promise<void> {
    this.loadingMembers.set(true);
    try {
      this.members.set(await this.api.list());
      this.membersError.set('');
    } catch (err) {
      this.membersError.set(toAppError(err).supportMessage);
    } finally {
      this.loadingMembers.set(false);
    }
  }

  async startCapture(member: Member): Promise<void> {
    this.selected.set(member);
    this.phase.set('preparing');
    this.descriptors = [];
    this.bestShot = null;
    this.stableFrames = 0;
    this.shotsTaken.set(0);
    this.guidance.set('position');
    this.errorMessage.set('');

    try {
      await this.faceApi.ensureReady();
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 720 }, height: { ideal: 960 } },
        audio: false,
      });
      const video = this.videoRef()?.nativeElement;
      if (!video) {
        throw new Error('Camera surface is not ready yet.');
      }
      video.srcObject = this.stream;
      await video.play();
      // Sync the overlay to the video's intrinsic size so detection boxes
      // and the oval guide are in the same coordinate space.
      const overlay = this.overlayRef()?.nativeElement;
      if (overlay) {
        overlay.width = video.videoWidth;
        overlay.height = video.videoHeight;
      }
      this.drawOverlay();
      this.phase.set('guiding');
      this.startDetectionLoop();
    } catch (err) {
      this.showError(err instanceof Error ? err.message : 'Could not start the camera.');
    }
  }

  backToPicker(): void {
    this.stopCamera();
    this.selected.set(null);
    this.phase.set('picker');
  }

  // ----- Capture loop --------------------------------------------------
  private startDetectionLoop(): void {
    this.detectTimer = setInterval(() => void this.tick(), DETECTION_INTERVAL_MS);
  }

  private async tick(): Promise<void> {
    if (this.disposed || !(this.phase() === 'guiding' || this.phase() === 'capturing')) {
      return;
    }
    const video = this.videoRef()?.nativeElement;
    if (!video || video.readyState < 2 || !video.videoWidth) {
      return;
    }
    try {
      const result = await this.faceApi.detect(video);
      if (!result) {
        this.handleGuidance('noFace');
        return;
      }
      // Face size and centeredness checks are evaluated in the video's
      // intrinsic coordinate system, matching the detector output.
      const ratio = result.box.width / video.videoWidth;
      if (ratio < 0.25) {
        this.handleGuidance('tooSmall');
        return;
      }
      if (ratio > 0.75) {
        this.handleGuidance('tooLarge');
        return;
      }
      const cx = result.box.x + result.box.width / 2;
      const cy = result.box.y + result.box.height / 2;
      const ovalCx = video.videoWidth / 2;
      const ovalCy = video.videoHeight / 2;
      const rx = video.videoWidth * 0.35;
      const ry = video.videoHeight * 0.4;
      const d = ((cx - ovalCx) / rx) ** 2 + ((cy - ovalCy) / ry) ** 2;
      if (d > 1) {
        this.handleGuidance('offCenter');
        return;
      }
      this.handleGuidance('ok');
      if (this.phase() === 'guiding') {
        this.stableFrames += 1;
        if (this.stableFrames >= STABLE_FRAMES_REQUIRED) {
          this.beginCapture();
        }
      }
      if (this.phase() === 'capturing' && this.descriptors.length < SHOT_COUNT) {
        // Drop low-quality frames (motion blur, half-turn, odd angles) so the
        // averaged template is built from clean detections only.
        if (result.score < MIN_CAPTURE_SCORE) {
          return;
        }
        this.descriptors.push(result.descriptor);
        this.shotsTaken.set(this.descriptors.length);
        if (!this.bestShot || result.score > this.bestShot.score) {
          this.bestShot = { score: result.score, descriptor: result.descriptor };
          // Snapshot the best frame right now while the pixels are still fresh.
          this.snapshotPending = { video, box: result.box };
        }
      }
      if (this.phase() === 'capturing' && this.descriptors.length >= SHOT_COUNT) {
        await this.finishCapture();
      }
    } catch (err) {
      this.showError(err instanceof Error ? err.message : 'Face detection failed.');
    }
  }

  private snapshotPending: { video: HTMLVideoElement; box: faceapi.Box } | null = null;

  private handleGuidance(next: Guidance): void {
    if (this.phase() === 'guiding') {
      this.guidance.set(next);
      if (next !== 'ok') {
        this.stableFrames = 0;
      }
    }
  }

  private beginCapture(): void {
    this.phase.set('capturing');
    this.descriptors = [];
    this.shotsTaken.set(0);
    // The detection loop keeps running; this timer just paces the UI expectation.
    this.captureTimer = setInterval(() => {
      // No-op pacing marker — descriptors are collected in tick() as they arrive.
      if (this.descriptors.length >= SHOT_COUNT) {
        this.clearCaptureTimer();
      }
    }, CAPTURE_INTERVAL_MS);
  }

  private async finishCapture(): Promise<void> {
    this.clearCaptureTimer();
    this.clearDetectionTimer();
    this.phase.set('uploading');
    try {
      // Send the full template set so attendance can match against the best
      // per-template similarity instead of a pose-averaged compromise vector.
      const templates = this.descriptors.map((d) => Array.from(d));
      if (!templates.length || templates.some((t) => t.length !== FACE_DESCRIPTOR_LENGTH)) {
        throw new Error('Face descriptors had an unexpected shape.');
      }
      const snapshot = this.snapshotPending;
      if (!snapshot) {
        throw new Error('No reference frame captured.');
      }
      const blob = await this.faceApi.cropToJpeg(snapshot.video, snapshot.box, REFERENCE_IMAGE_SIDE);
      const member = this.selected();
      if (!member) {
        throw new Error('No member selected.');
      }
      await this.faces.register(member.memberId, templates, blob);
      // Reflect enrolment in the picker without a full round-trip.
      this.members.update((list) =>
        list.map((m) =>
          m.memberId === member.memberId ? { ...m, faceRegisteredAt: new Date().toISOString() } : m,
        ),
      );
      this.phase.set('done');
      await this.notify.success(`${member.memberName} enrolled.`);
      this.stopCamera();
    } catch (err) {
      this.showError(toAppError(err).supportMessage);
    }
  }

  // ----- Rendering ------------------------------------------------------
  private drawOverlay(): void {
    const canvas = this.overlayRef()?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const { width, height } = canvas;
    ctx.clearRect(0, 0, width, height);
    ctx.save();
    // Full dim, cut out the oval
    ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
    ctx.fillRect(0, 0, width, height);
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.ellipse(width / 2, height / 2, width * 0.35, height * 0.4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    // Oval outline
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(width / 2, height / 2, width * 0.35, height * 0.4, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  // ----- Cleanup --------------------------------------------------------
  private stopCamera(): void {
    this.clearDetectionTimer();
    this.clearCaptureTimer();
    const video = this.videoRef()?.nativeElement;
    if (video) {
      video.pause();
      video.srcObject = null;
    }
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
  }

  private clearDetectionTimer(): void {
    if (this.detectTimer !== null) {
      clearInterval(this.detectTimer);
      this.detectTimer = null;
    }
  }

  private clearCaptureTimer(): void {
    if (this.captureTimer !== null) {
      clearInterval(this.captureTimer);
      this.captureTimer = null;
    }
  }

  private showError(message: string): void {
    this.errorMessage.set(message);
    this.phase.set('error');
    this.stopCamera();
  }
}


