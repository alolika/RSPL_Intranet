/** Time-of-day aware greeting used after a successful face match. */
export function greeting(firstName: string, at: Date = new Date()): string {
  const hour = at.getHours();
  const period = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening';
  const name = firstName.trim();
  return name ? `Good ${period}, ${name}` : `Good ${period}`;
}

function hasSpeech(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window && typeof SpeechSynthesisUtterance === 'function';
}

/**
 * Nudge the browser to load voices and (on iOS Safari / older Chrome) unlock
 * the speech channel inside the current user-gesture call stack. Safe to call
 * repeatedly — the primed utterance is zero-length and inaudible.
 */
export function primeSpeech(): void {
  if (!hasSpeech()) return;
  try {
    window.speechSynthesis.getVoices();
    const silent = new SpeechSynthesisUtterance(' ');
    silent.volume = 0;
    silent.rate = 1;
    window.speechSynthesis.speak(silent);
  } catch {
    // Non-fatal — speech is a nicety, visuals carry the confirmation.
  }
}

/**
 * Speak the greeting via the Web Speech API. Silently no-ops when the device
 * has muted speech synthesis or doesn't support it. The visual splash is the
 * reliable channel; audio is a nicety.
 */
export function speakGreeting(firstName: string, at: Date = new Date()): void {
  if (!hasSpeech()) return;
  const utterance = new SpeechSynthesisUtterance(greeting(firstName, at));
  utterance.rate = 1;
  utterance.pitch = 1;
  utterance.volume = 1;
  // Don't preemptively cancel: Chrome has a long-standing bug where speak()
  // issued immediately after cancel() silently drops the utterance.
  window.speechSynthesis.speak(utterance);
}
