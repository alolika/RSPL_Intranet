import { Injectable } from '@angular/core';
import * as faceapi from '@vladmandic/face-api';

const MODEL_URL = '/assets/face-models';
/** Face-api descriptor length. Mirrors FACE_DESCRIPTOR_LENGTH on the backend. */
export const FACE_DESCRIPTOR_LENGTH = 128;

export interface FaceDetectionResult {
  score: number;
  box: faceapi.Box;
  landmarks: faceapi.FaceLandmarks68;
  descriptor: Float32Array;
}

/**
 * Thin wrapper around face-api.js. Lazy-loads model weights the first time
 * ensureReady() is called; subsequent calls are cheap.
 *
 * Face recognition runs entirely in the browser — the server never sees a
 * frame, only the 128-float descriptor the model produces.
 */
@Injectable({ providedIn: 'root' })
export class FaceApiService {
  private loader: Promise<void> | null = null;

  async ensureReady(): Promise<void> {
    if (!this.loader) {
      this.loader = Promise.all([
        faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
        faceapi.nets.faceLandmark68TinyNet.loadFromUri(MODEL_URL),
        faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
      ]).then(() => undefined);
    }
    await this.loader;
  }

  /**
   * Detect the single most prominent face in `source`, with landmarks + 128-d
   * descriptor. Returns null when no face passes the detector threshold.
   */
  async detect(source: HTMLVideoElement | HTMLCanvasElement | HTMLImageElement): Promise<FaceDetectionResult | null> {
    const options = new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 });
    const result = await faceapi.detectSingleFace(source, options).withFaceLandmarks(true).withFaceDescriptor();
    if (!result) {
      return null;
    }
    return {
      score: result.detection.score,
      box: result.detection.box,
      landmarks: result.landmarks,
      descriptor: result.descriptor,
    };
  }

  /**
   * Eye Aspect Ratio averaged across both eyes. Open eye ≈ 0.3; closed eye ≈
   * 0.1. A sharp drop + recovery over consecutive frames is a blink.
   *
   * Uses the 68-point landmark layout: left eye indices 36..41, right 42..47.
   */
  eyeAspectRatio(landmarks: faceapi.FaceLandmarks68): number {
    const points = landmarks.positions;
    const left = ear(points.slice(36, 42));
    const right = ear(points.slice(42, 48));
    return (left + right) / 2;
  }

  /**
   * Crop the detected face from the source frame, resize to a square side, and
   * encode as JPEG. Used for the reference photo uploaded at enrolment.
   */
  async cropToJpeg(source: HTMLVideoElement, box: faceapi.Box, side: number, quality = 0.9): Promise<Blob> {
    const pad = 0.3; // widen the crop a little so hair/chin are included
    const sx = Math.max(0, box.x - box.width * pad);
    const sy = Math.max(0, box.y - box.height * pad);
    const sw = Math.min(source.videoWidth - sx, box.width * (1 + 2 * pad));
    const sh = Math.min(source.videoHeight - sy, box.height * (1 + 2 * pad));
    const canvas = document.createElement('canvas');
    canvas.width = side;
    canvas.height = side;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Canvas 2D context unavailable');
    }
    ctx.drawImage(source, sx, sy, sw, sh, 0, 0, side, side);
    return await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob(
        (blob) => (blob ? resolve(blob) : reject(new Error('Canvas toBlob returned null'))),
        'image/jpeg',
        quality,
      );
    });
  }
}

function ear(eye: faceapi.Point[]): number {
  // Eye aspect ratio: (|p1-p5| + |p2-p4|) / (2 * |p0-p3|)
  // Indices here are 0..5 inside the sliced eye array.
  const v1 = dist(eye[1], eye[5]);
  const v2 = dist(eye[2], eye[4]);
  const h = dist(eye[0], eye[3]) * 2;
  return h === 0 ? 0 : (v1 + v2) / h;
}

function dist(a: faceapi.Point, b: faceapi.Point): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}
