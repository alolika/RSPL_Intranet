import { EnrolledFace } from '../../core/models';

export interface FaceMatch {
  face: EnrolledFace;
  similarity: number;
}

/**
 * Cosine similarity of two numeric vectors.
 *
 * face-api.js FaceRecognitionNet descriptors are not L2-normalised, so we
 * divide by the magnitudes rather than taking a plain dot product. Same-person
 * pairs typically score ~0.75-0.95; different people ~0.3-0.6.
 */
export function cosineSimilarity(a: ArrayLike<number>, b: ArrayLike<number>): number {
  if (a.length !== b.length || a.length === 0) {
    return 0;
  }
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  if (normA === 0 || normB === 0) {
    return 0;
  }
  return dot / Math.sqrt(normA * normB);
}

/**
 * Return the enrolled face with the highest per-template cosine similarity to
 * `descriptor`, regardless of threshold. Null only when the enrolled set is empty.
 *
 * Each enrolled face carries a template set (one or more descriptors captured at
 * different poses during enrolment); we score against the best-matching template
 * in the set, which is far more robust than matching a muddy pose-averaged vector.
 */
export function topMatch(
  descriptor: ArrayLike<number>,
  enrolled: Iterable<EnrolledFace>,
): FaceMatch | null {
  let best: FaceMatch | null = null;
  for (const face of enrolled) {
    let perFace = -Infinity;
    for (const template of face.embeddings) {
      const similarity = cosineSimilarity(descriptor, template);
      if (similarity > perFace) {
        perFace = similarity;
      }
    }
    if (perFace > (best?.similarity ?? -Infinity)) {
      best = { face, similarity: perFace };
    }
  }
  return best;
}

/**
 * Pick the enrolled face whose top-template similarity clears `threshold`.
 * Returns null when nobody clears the bar.
 */
export function bestMatch(
  descriptor: ArrayLike<number>,
  enrolled: Iterable<EnrolledFace>,
  threshold: number,
): FaceMatch | null {
  const top = topMatch(descriptor, enrolled);
  return top && top.similarity >= threshold ? top : null;
}
