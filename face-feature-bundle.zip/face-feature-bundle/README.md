# Face Feature Bundle — Source Lift

Companion to `FACE_RECOGNITION_HANDOFF.md`. These are the actual TypeScript
source files to copy into the sister Angular/Ionic project. The handoff doc
explains **why**; this bundle gives you **what**.

## What's in here

```
face-feature-bundle/
├── README.md                        ← this file
├── shared/face/
│   ├── face-api.service.ts          ← face-api.js wrapper (ensureReady, detect, EAR, cropToJpeg)
│   ├── matching.ts                  ← cosineSimilarity, topMatch, bestMatch (pure, zero deps)
│   └── voice.ts                     ← greeting + primeSpeech + speakGreeting
├── core/
│   ├── models/
│   │   └── face.models.ts           ← TypeScript interfaces (EnrolledFace, FaceArrival, etc.)
│   └── services/
│       └── face.service.ts          ← HttpClient wrapper for the three API endpoints
└── features/
    ├── face-register.page.ts        ← admin enrol page (standalone component)
    └── attendance-face.page.ts      ← employee self-mark page (standalone component)
```

## Where each file goes in the receiving project

Assuming the sister project uses the standard Angular/Ionic layout
(`src/app/...`), copy each file to the matching path:

| From this bundle | To (in the sister project) |
|---|---|
| `shared/face/face-api.service.ts` | `src/app/shared/face/face-api.service.ts` |
| `shared/face/matching.ts` | `src/app/shared/face/matching.ts` |
| `shared/face/voice.ts` | `src/app/shared/face/voice.ts` |
| `core/models/face.models.ts` | `src/app/core/models/face.models.ts` *(or merge into existing `models/index.ts`)* |
| `core/services/face.service.ts` | `src/app/core/services/face.service.ts` |
| `features/face-register.page.ts` | `src/app/features/<admin-area>/face-register.page.ts` |
| `features/attendance-face.page.ts` | `src/app/features/<attendance-area>/attendance-face.page.ts` |

## What each file needs on the receiving side

### `shared/face/face-api.service.ts` — copy verbatim
- No changes needed.
- Requires: `npm install @vladmandic/face-api`.
- Requires: the six model files in `src/assets/face-models/` (see §2 of the
  handoff doc — copy from `node_modules/@vladmandic/face-api/model/`).

### `shared/face/matching.ts` — copy verbatim
- Fix the one import path: `'../../core/models'` → `'../../core/models/face.models'`
  (or wherever you placed `EnrolledFace`).

### `shared/face/voice.ts` — copy verbatim
- No imports; adjust the time-of-day cutoffs if your locale wants different
  morning/afternoon/evening breakpoints.

### `core/models/face.models.ts` — adapt
- Replace the `AttendanceState` placeholder at the bottom with the sister
  project's own "today's roster / counters" shape, or remove `FaceArrival.state`
  entirely if the attendance page refetches state via a separate endpoint.
- The `memberId` naming can be renamed to `employeeId` throughout — if you do,
  rename in all four files below as well.

### `core/services/face.service.ts` — adapt
- Point `API_BASE` at the sister project's API prefix (it's imported from
  `'../constants/api'` in BNI — just inline the string, e.g.
  `const API_BASE = '/api';`).
- Change the URLs to match the sister project's endpoints:
  - BNI: `POST /members/{id}/face` → sister: whatever your "enrol employee face" route is
  - BNI: `GET /face-embeddings` → whatever "list enrolled" route is
  - BNI: `POST /meetings/{meetingId}/attendance/face` → sister: `POST /attendance/face`
    (your route won't have a meeting ID; it marks "today" for the authenticated employee)
- Add the geolocation fields to the `markByFace` body:
  ```ts
  markByFace(employeeId: string, confidence: number, geo: {
    lat?: number; lng?: number; accuracyM?: number;
    city?: string; state?: string; country?: string;
  }): Promise<FaceArrival> {
    return firstValueFrom(
      this.http.post<FaceArrival>(`${API_BASE}/attendance/face`, {
        employeeId, confidence, ...geo,
      }),
    );
  }
  ```

### `features/face-register.page.ts` — adapt
- Rename `Member` / `MemberService` imports to the sister project's directory
  types (`Employee` / `EmployeeService` or similar).
- Drop fields the sister project doesn't have on its directory rows:
  `businessName`, `category` — remove from the `ion-label` block in the picker.
- Replace `NotifyService` / `toAppError` / `normalise` with the sister project's
  equivalents (toast + error-to-string + search-normalise helpers).
- Everything in the capture loop, camera plumbing, overlay drawing, and upload
  flow — keep verbatim.

### `features/attendance-face.page.ts` — adapt (biggest changes)
- **Drop the meeting-id dependency.** Remove `meetingId` route param, the
  `MeetingService.state()` polling, and `meetingsApi` injection. Attendance marks
  "today" for the authenticated employee; no meeting selector.
- **Replace `SettingsService.get().faceAttendanceRequireBlink`** with however
  the sister project configures tenant settings (or hard-code `requireBlink = true/false`
  initially and plumb the setting later).
- **Insert the geolocation + reverse-geocode block** in `matchAndMark()` right
  before the `faces.markByFace(...)` call. The exact code is in §7a-7c of the
  handoff doc; the key policy question (what to do when location is denied) is
  §7d — flag that choice to the user before coding.
- Replace `NotifyService` with the sister project's toast equivalent.
- Everything in the detection loop, blink EAR math, suppression window,
  template-matching, and splash UI — keep verbatim.

## npm dependency to add

```bash
npm install @vladmandic/face-api
```

Then copy from `node_modules/@vladmandic/face-api/model/` into
`src/assets/face-models/`:

- `tiny_face_detector_model-weights_manifest.json`
- `tiny_face_detector_model.bin`
- `face_landmark_68_tiny_model-weights_manifest.json`
- `face_landmark_68_tiny_model.bin`
- `face_recognition_model-weights_manifest.json`
- `face_recognition_model.bin`

## Checking the lift worked

1. `npm run build` succeeds — all imports resolve.
2. Open the enrol page, pick an employee, verify the camera starts and the
   oval guide draws.
3. Hold still through the 15 captures → upload succeeds, response includes
   `photoUrl` and `faceRegisteredAt`.
4. Open the attendance page on a different device → `GET /face-embeddings` returns
   the enrolled employee → scan their face → match + mark succeeds, server
   receives `{employeeId, confidence, lat, lng, city, ...}`.
5. Deny location permission in the browser → attendance behaves per the §7d
   policy decision (hard-block or mark-with-no-location).

## When to re-read the handoff

- Choosing the match threshold → handoff §4.
- Reverse-geocoding provider / rate limits → handoff §7b.
- Policy decisions (denial / accuracy / geofence) → handoff §7d.
- Non-negotiables (server clock, server-side threshold, HTTPS) → handoff §8.
- Gotchas (iOS Safari speech, canvas sizing, blink grace frames) → handoff §10.
