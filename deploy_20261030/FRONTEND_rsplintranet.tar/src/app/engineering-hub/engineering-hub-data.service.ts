import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../shared/api-config';

/**
 * Single service for the whole Engineering Hub module, matching the
 * established "one big data service per top-level portal" convention
 * (agile-data.service.ts, support-data.service.ts, etc.) rather than
 * pre-splitting into per-entity services.
 */

export interface LookupOption {
  label: string;
  value: number;
}

export interface StatusOption extends LookupOption {
  isTerminal: boolean;
}

// ---- Masters admin (raw CRUD shapes — distinct from the *Option lookup
// shapes above, which drop id/enabled/etc. that the Masters console needs
// to actually edit a row). ----

// Each also carries a string index signature — MasterCrudConfig (the
// shared/master-crud scaffold's config contract) is generic over
// Record<string, unknown> so one component can drive all master shapes, and
// these rows need to satisfy that structurally.

export interface SimpleMasterCrudRow {
  [key: string]: unknown;
  id: number;
  name: string;
  enabled: boolean;
}

export interface ProductCrudRow {
  [key: string]: unknown;
  productId: number;
  name: string;
  description: string;
  enabled: boolean;
}

export interface ModuleCrudRow {
  [key: string]: unknown;
  moduleId: number;
  productId: number;
  name: string;
  description: string;
  enabled: boolean;
}

export interface StatusCrudRow {
  [key: string]: unknown;
  statusId: number;
  entityType: string;
  name: string;
  color: string | null;
  sortOrder: number;
  isTerminal: boolean;
  enabled: boolean;
}

export interface FeatureRow {
  featureId: number;
  moduleId: number;
  moduleName: string;
  productId: number;
  productName: string;
  name: string;
  description: string;
  featureOwnerUserId: number | null;
  featureOwnerName: string | null;
  technicalOwnerUserId: number | null;
  technicalOwnerName: string | null;
  enabled: boolean;
  /** Rollup of every duration-carrying Activity anywhere under this Feature
   * (directly, via a Dev Item, or via one of those Dev Items' Tasks) — same
   * three-level scope as the Feature Timeline. Format for display with
   * formatTimeSpent() from shared/time-spent.ts. */
  actualMinutes: number;
}

export interface FeatureForm {
  featureId: number;
  moduleId: number;
  name: string;
  description: string;
  enabled: boolean;
}

export interface DevItemRow {
  devItemId: number;
  featureId: number;
  featureName: string;
  moduleId: number;
  productId: number;
  devItemTypeId: number;
  devItemTypeName: string;
  title: string;
  description: string;
  originTypeId: number | null;
  originTypeName: string | null;
  originTicketVoucherNo: number | null;
  customerId: number | null;
  customerName: string | null;
  priorityId: number | null;
  priorityName: string | null;
  statusId: number;
  statusName: string;
  isTerminal: boolean;
  closedAt: string | null;
  /** Total minutes across every duration-carrying Activity attached to this
   * Dev Item, directly or via one of its Tasks — same rollup Timeline uses,
   * summed server-side. Format for display with formatTimeSpent() below. */
  actualMinutes: number;
}

export interface DevItemForm {
  devItemId: number;
  featureId: number;
  devItemTypeId: number;
  title: string;
  description: string;
  originTypeId: number | null;
  originTicketVoucherNo: number | null;
  customerId: number | null;
  priorityId: number | null;
  statusId: number;
}

export interface TaskRow {
  taskId: number;
  devItemId: number;
  devItemTitle: string;
  featureId: number;
  featureName: string;
  moduleId: number;
  productId: number;
  taskTypeId: number;
  taskTypeName: string;
  title: string;
  description: string;
  statusId: number;
  statusName: string;
  isTerminal: boolean;
  priorityId: number | null;
  priorityName: string | null;
  estimatedHours: number | null;
  actualHours: number;
  /** Same value as actualHours, in whole minutes — format for display with
   * formatTimeSpent() from shared/time-spent.ts. */
  actualMinutes: number;
  developerUserId: number | null;
  developerName: string | null;
  closedAt: string | null;
  /** Optional "YYYY-MM-DD" calendar date. */
  expectedDeadline: string | null;
}

export interface TaskForm {
  taskId: number;
  devItemId: number;
  taskTypeId: number;
  title: string;
  description: string;
  statusId: number;
  priorityId: number | null;
  estimatedHours: number | null;
  /** Optional "YYYY-MM-DD" calendar date; null = no deadline. */
  expectedDeadline: string | null;
}

export interface CustomerOption {
  custId: number;
  displayName: string;
}

export interface TicketOption {
  voucherNo: number;
  date: string | null;
  customerName: string | null;
}

export interface AssignmentHistoryRow {
  assignmentHistoryId: number;
  roleType: string;
  userId: number;
  userName: string;
  assignedByUserId: number;
  assignedByName: string;
  assignedAt: string;
  unassignedAt: string | null;
  comments: string | null;
}

export interface FeatureTicketRow {
  featureTicketId: number;
  ticketVoucherNo: number;
  ticketDate: string | null;
  ticketCustomerName: string | null;
  addedByUserId: number;
  addedByName: string;
  addedAt: string;
}

export interface TaskTicketRow {
  taskTicketId: number;
  ticketVoucherNo: number;
  ticketDate: string | null;
  ticketCustomerName: string | null;
  addedByUserId: number;
  addedByName: string;
  addedAt: string;
}

export interface ActivityRow {
  activityId: number;
  activityTypeId: number;
  activityTypeName: string;
  featureId: number | null;
  devItemId: number | null;
  taskId: number | null;
  description: string | null;
  durationMinutes: number | null;
  oldStatusId: number | null;
  oldStatusName: string | null;
  newStatusId: number | null;
  newStatusName: string | null;
  occurredAt: string;
  loggedByUserId: number;
  loggedByName: string;
}

export interface ActivityBrowseRow extends ActivityRow {
  featureName: string | null;
  devItemTitle: string | null;
  taskTitle: string | null;
}

export interface ParticipantRow {
  activityParticipantId: number;
  userId: number;
  userName: string;
  participationStatus: string;
  addedByUserId: number;
  addedByName: string;
  respondedAt: string | null;
}

export interface CurrentTask {
  taskId: number | null;
  taskTitle: string | null;
}

export interface DecisionRow {
  decisionId: number;
  featureId: number | null;
  featureName: string | null;
  devItemId: number | null;
  devItemTitle: string | null;
  taskId: number | null;
  taskTitle: string | null;
  decisionTypeId: number;
  decisionTypeName: string;
  description: string;
  approverUserId: number | null;
  approverName: string | null;
  approverExternalName: string | null;
  reason: string;
  riskLevel: string;
  reviewDate: string | null;
  statusId: number;
  statusName: string;
  customerId: number | null;
  customerName: string | null;
  createdByUserId: number;
  createdByName: string;
  createdAt: string;
}

export interface DecisionForm {
  decisionId: number;
  featureId: number | null;
  devItemId: number | null;
  taskId: number | null;
  decisionTypeId: number;
  description: string;
  approverUserId: number | null;
  approverExternalName: string | null;
  reason: string;
  riskLevel: string;
  reviewDate: string | null;
  statusId: number;
  customerId: number | null;
}

/** A merged, chronologically-sortable Timeline entry — the PRD's "Feature
 * Timeline" is a UNION of Activities and Decisions for a given scope, per
 * the approved design (§4). Built client-side from two already-scoped
 * fetches rather than a combined backend endpoint, since the two entity
 * types stay independently queryable (e.g. Decision Log's own filters). */
export interface TimelineEntry {
  kind: 'activity' | 'decision';
  occurredAt: string;
  activity?: ActivityRow;
  decision?: DecisionRow;
}

export interface ReleaseRow {
  releaseId: number;
  name: string;
  releaseDate: string | null;
  description: string | null;
  productId: number | null;
  productName: string | null;
  statusId: number;
  statusName: string;
  createdByUserId: number;
  createdByName: string;
  createdAt: string;
}

export interface ReleaseForm {
  releaseId: number;
  name: string;
  releaseDate: string | null;
  description: string | null;
  productId: number | null;
  statusId: number;
}

export interface ReleaseMappingRow {
  releaseMappingId: number;
  releaseId: number;
  featureId: number | null;
  featureName: string | null;
  devItemId: number | null;
  devItemTitle: string | null;
  mappedByUserId: number;
  mappedByName: string;
  mappedAt: string;
}

export interface ReleaseNoteItem {
  kind: 'Feature' | 'DevelopmentItem';
  title: string;
  description: string;
}

export interface EngineeringEffortRow {
  moduleName: string | null;
  taskTypeName: string | null;
  activityTypeName: string;
  totalMinutes: number;
  entryCount: number;
}

export interface ModuleEffortRow {
  moduleId: number | null;
  moduleName: string | null;
  productName: string | null;
  totalMinutes: number;
  entryCount: number;
}

export interface FeatureEffortRow {
  featureId: number | null;
  featureName: string | null;
  moduleName: string | null;
  totalMinutes: number;
  entryCount: number;
}

export interface FeatureEffortEntryRow {
  activityId: number;
  occurredAt: string;
  taskTitle: string | null;
  activityTypeName: string;
  durationMinutes: number;
  loggedByName: string | null;
}

export interface InterruptionReportRow {
  activityId: number;
  occurredAt: string;
  reasonName: string;
  interruptedTaskTitle: string;
  newTaskTitle: string;
  requestedByName: string;
  comments: string | null;
  durationMinutes: number | null;
}

export interface PendingAgeingRow {
  devItemId: number;
  title: string;
  featureName: string;
  statusName: string;
  ageDays: number;
  createdAt: string;
  /** One row per pending Task of the Dev Item; null when it has none. */
  taskId: number | null;
  taskTitle: string | null;
  taskStatusName: string | null;
  /** Task's Expected Deadline, "YYYY-MM-DD". */
  expectedDeadline: string | null;
  /** null = no deadline, 0 = not overdue, N = N days past the deadline. */
  overdueDays: number | null;
}

export interface ReleaseProgressRow {
  releaseId: number;
  releaseName: string;
  statusName: string;
  mappedFeatureCount: number;
  mappedDevItemCount: number;
  devItemsDoneCount: number;
  devItemsPendingCount: number;
}

export interface SupportDrivenWorkRow {
  devItemId: number;
  title: string;
  featureName: string;
  ticketVoucherNo: number | null;
  customerName: string | null;
  statusName: string;
  totalMinutes: number;
}

export interface DashboardSummary {
  openDevItems: number;
  openTasks: number;
  minutesLoggedLast7Days: number;
  pendingDecisionReviews: number;
}

// ---- Per-developer dashboard (GET /developer-dashboard) ----

export interface DevDashNamedMinutes {
  name: string;
  minutes: number;
}

export interface DevDashDateMinutes {
  /** "YYYY-MM-DD" local calendar date. */
  date: string;
  minutes: number;
}

export interface DevDashModuleMinutes {
  productName: string;
  moduleName: string;
  minutes: number;
}

export interface DevDashSwitchReason {
  reason: string;
  count: number;
  minutes: number;
}

export interface DevDashSwitch {
  occurredAt: string;
  fromTask: string;
  toTask: string;
  reason: string;
  requestedBy: string;
  minutes: number | null;
  comments: string | null;
}

export interface DevDashOpenTask {
  taskId: number;
  title: string;
  devItemTitle: string;
  statusName: string;
  priorityName: string | null;
  estimatedHours: number | null;
  spentMinutes: number;
  expectedDeadline: string | null;
  /** null = no deadline, 0 = not overdue, N = N days late. */
  overdueDays: number | null;
}

export interface DevDashEstimate {
  taskId: number;
  title: string;
  statusName: string;
  isTerminal: boolean;
  estimatedHours: number | null;
  /** This user's time on the task within the selected range. */
  minutesInRange: number;
  /** All-time, everyone. */
  totalMinutes: number;
}

export interface DevDashWorkLog {
  activityId: number;
  occurredAt: string;
  activityType: string;
  taskTitle: string | null;
  devItemTitle: string | null;
  moduleName: string | null;
  minutes: number | null;
  description: string | null;
}

export interface DeveloperDashboard {
  userId: number;
  userName: string;
  dateFrom: string;
  dateTo: string;
  totalMinutes: number;
  daysWorked: number;
  tasksWorked: number;
  openTasks: number;
  overdueTasks: number;
  tasksClosed: number;
  switchCount: number;
  switchMinutes: number;
  byDate: DevDashDateMinutes[];
  byModule: DevDashModuleMinutes[];
  byDevItemType: DevDashNamedMinutes[];
  byTaskType: DevDashNamedMinutes[];
  switchReasons: DevDashSwitchReason[];
  switches: DevDashSwitch[];
  openTaskList: DevDashOpenTask[];
  estimates: DevDashEstimate[];
  workLog: DevDashWorkLog[];
}

/** Recursively converts snake_case object keys to camelCase. */
function camelizeKeys(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map(camelizeKeys);
  }
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(([k, v]) => [
        k.replace(/_([a-z])/g, (_, c: string) => c.toUpperCase()),
        camelizeKeys(v)
      ])
    );
  }
  return value;
}

export interface RecentActivityRow {
  activityId: number;
  activityTypeName: string;
  description: string | null;
  durationMinutes: number | null;
  occurredAt: string;
  loggedByName: string;
  taskName: string | null;
}

export interface AttachmentRow {
  attachmentId: number;
  entityType: string;
  entityId: number;
  fileName: string;
  fileSizeBytes: number;
  contentType: string | null;
  uploadedByUserId: number;
  uploadedByName: string;
  uploadedAt: string;
}

export function mergeTimelineEntries(activities: ActivityRow[], decisions: DecisionRow[]): TimelineEntry[] {
  const entries: TimelineEntry[] = [
    ...activities.map((a) => ({ kind: 'activity' as const, occurredAt: a.occurredAt, activity: a })),
    ...decisions.map((d) => ({ kind: 'decision' as const, occurredAt: d.createdAt, decision: d }))
  ];
  return entries.sort((a, b) => (a.occurredAt < b.occurredAt ? 1 : -1));
}

interface ApiSimpleMasterRow {
  id: number;
  name: string;
  enabled: boolean;
}

interface ApiStatusRow {
  status_id: number;
  entity_type: string;
  name: string;
  color: string | null;
  sort_order: number;
  is_terminal: boolean;
  enabled: boolean;
}

interface ApiProductCrudRow {
  product_id: number;
  name: string;
  description: string;
  enabled: boolean;
}

interface ApiModuleCrudRow {
  module_id: number;
  product_id: number;
  name: string;
  description: string;
  enabled: boolean;
}

function toProductCrudRow(r: ApiProductCrudRow): ProductCrudRow {
  return { productId: r.product_id, name: r.name, description: r.description, enabled: r.enabled };
}

function toModuleCrudRow(r: ApiModuleCrudRow): ModuleCrudRow {
  return { moduleId: r.module_id, productId: r.product_id, name: r.name, description: r.description, enabled: r.enabled };
}

function toStatusCrudRow(r: ApiStatusRow): StatusCrudRow {
  return {
    statusId: r.status_id, entityType: r.entity_type, name: r.name, color: r.color,
    sortOrder: r.sort_order, isTerminal: r.is_terminal, enabled: r.enabled
  };
}

interface ApiFeatureRow {
  feature_id: number;
  module_id: number;
  module_name: string;
  product_id: number;
  product_name: string;
  name: string;
  description: string;
  feature_owner_user_id: number | null;
  feature_owner_name: string | null;
  technical_owner_user_id: number | null;
  technical_owner_name: string | null;
  enabled: boolean;
  actual_minutes: number;
}

interface ApiDevItemRow {
  dev_item_id: number;
  feature_id: number;
  feature_name: string;
  module_id: number;
  product_id: number;
  dev_item_type_id: number;
  dev_item_type_name: string;
  title: string;
  description: string;
  origin_type_id: number | null;
  origin_type_name: string | null;
  origin_ticket_voucher_no: number | null;
  customer_id: number | null;
  customer_name: string | null;
  priority_id: number | null;
  priority_name: string | null;
  status_id: number;
  status_name: string;
  is_terminal: boolean;
  closed_at: string | null;
  actual_minutes: number;
}

interface ApiTaskRow {
  task_id: number;
  dev_item_id: number;
  dev_item_title: string;
  feature_id: number;
  feature_name: string;
  module_id: number;
  product_id: number;
  task_type_id: number;
  task_type_name: string;
  title: string;
  description: string;
  status_id: number;
  status_name: string;
  is_terminal: boolean;
  priority_id: number | null;
  priority_name: string | null;
  estimated_hours: number | null;
  actual_hours: number;
  actual_minutes: number;
  developer_user_id: number | null;
  developer_name: string | null;
  closed_at: string | null;
  expected_deadline: string | null;
}

interface ApiCustomerRow {
  cust_id: number;
  display_name: string;
}

interface ApiTicketRow {
  voucher_no: number;
  date: string | null;
  customer_name: string | null;
}

interface ApiFeatureTicketRow {
  feature_ticket_id: number;
  ticket_voucher_no: number;
  ticket_date: string | null;
  ticket_customer_name: string | null;
  added_by_user_id: number;
  added_by_name: string;
  added_at: string;
}

interface ApiTaskTicketRow {
  task_ticket_id: number;
  ticket_voucher_no: number;
  ticket_date: string | null;
  ticket_customer_name: string | null;
  added_by_user_id: number;
  added_by_name: string;
  added_at: string;
}

interface ApiAssignmentHistoryRow {
  assignment_history_id: number;
  role_type: string;
  user_id: number;
  user_name: string;
  assigned_by_user_id: number;
  assigned_by_name: string;
  assigned_at: string;
  unassigned_at: string | null;
  comments: string | null;
}

interface ApiActivityRow {
  activity_id: number;
  activity_type_id: number;
  activity_type_name: string;
  feature_id: number | null;
  dev_item_id: number | null;
  task_id: number | null;
  description: string | null;
  duration_minutes: number | null;
  old_status_id: number | null;
  old_status_name: string | null;
  new_status_id: number | null;
  new_status_name: string | null;
  occurred_at: string;
  logged_by_user_id: number;
  logged_by_name: string;
}

interface ApiActivityBrowseRow extends ApiActivityRow {
  feature_name: string | null;
  dev_item_title: string | null;
  task_title: string | null;
}

interface ApiParticipantRow {
  activity_participant_id: number;
  user_id: number;
  user_name: string;
  participation_status: string;
  added_by_user_id: number;
  added_by_name: string;
  responded_at: string | null;
}

interface ApiCurrentTask {
  task_id: number | null;
  task_title: string | null;
}

interface ApiDecisionRow {
  decision_id: number;
  feature_id: number | null;
  feature_name: string | null;
  dev_item_id: number | null;
  dev_item_title: string | null;
  task_id: number | null;
  task_title: string | null;
  decision_type_id: number;
  decision_type_name: string;
  description: string;
  approver_user_id: number | null;
  approver_name: string | null;
  approver_external_name: string | null;
  reason: string;
  risk_level: string;
  review_date: string | null;
  status_id: number;
  status_name: string;
  customer_id: number | null;
  customer_name: string | null;
  created_by_user_id: number;
  created_by_name: string;
  created_at: string;
}

function toFeatureRow(r: ApiFeatureRow): FeatureRow {
  return {
    featureId: r.feature_id, moduleId: r.module_id, moduleName: r.module_name,
    productId: r.product_id, productName: r.product_name, name: r.name, description: r.description,
    featureOwnerUserId: r.feature_owner_user_id, featureOwnerName: r.feature_owner_name,
    technicalOwnerUserId: r.technical_owner_user_id, technicalOwnerName: r.technical_owner_name,
    enabled: r.enabled, actualMinutes: r.actual_minutes
  };
}

function toDevItemRow(r: ApiDevItemRow): DevItemRow {
  return {
    devItemId: r.dev_item_id, featureId: r.feature_id, featureName: r.feature_name,
    moduleId: r.module_id, productId: r.product_id,
    devItemTypeId: r.dev_item_type_id, devItemTypeName: r.dev_item_type_name,
    title: r.title, description: r.description,
    originTypeId: r.origin_type_id, originTypeName: r.origin_type_name,
    originTicketVoucherNo: r.origin_ticket_voucher_no,
    customerId: r.customer_id, customerName: r.customer_name,
    priorityId: r.priority_id, priorityName: r.priority_name,
    statusId: r.status_id, statusName: r.status_name, isTerminal: r.is_terminal,
    closedAt: r.closed_at, actualMinutes: r.actual_minutes
  };
}

function toTaskRow(r: ApiTaskRow): TaskRow {
  return {
    taskId: r.task_id, devItemId: r.dev_item_id, devItemTitle: r.dev_item_title,
    featureId: r.feature_id, featureName: r.feature_name,
    moduleId: r.module_id, productId: r.product_id,
    taskTypeId: r.task_type_id, taskTypeName: r.task_type_name,
    title: r.title, description: r.description,
    statusId: r.status_id, statusName: r.status_name, isTerminal: r.is_terminal,
    priorityId: r.priority_id, priorityName: r.priority_name,
    estimatedHours: r.estimated_hours, actualHours: r.actual_hours, actualMinutes: r.actual_minutes,
    developerUserId: r.developer_user_id, developerName: r.developer_name,
    closedAt: r.closed_at,
    expectedDeadline: r.expected_deadline
  };
}

function toActivityRow(r: ApiActivityRow): ActivityRow {
  return {
    activityId: r.activity_id, activityTypeId: r.activity_type_id, activityTypeName: r.activity_type_name,
    featureId: r.feature_id, devItemId: r.dev_item_id, taskId: r.task_id,
    description: r.description, durationMinutes: r.duration_minutes,
    oldStatusId: r.old_status_id, oldStatusName: r.old_status_name,
    newStatusId: r.new_status_id, newStatusName: r.new_status_name,
    occurredAt: r.occurred_at, loggedByUserId: r.logged_by_user_id, loggedByName: r.logged_by_name
  };
}

function toActivityBrowseRow(r: ApiActivityBrowseRow): ActivityBrowseRow {
  return { ...toActivityRow(r), featureName: r.feature_name, devItemTitle: r.dev_item_title, taskTitle: r.task_title };
}

function toParticipantRow(r: ApiParticipantRow): ParticipantRow {
  return {
    activityParticipantId: r.activity_participant_id, userId: r.user_id, userName: r.user_name,
    participationStatus: r.participation_status, addedByUserId: r.added_by_user_id,
    addedByName: r.added_by_name, respondedAt: r.responded_at
  };
}

interface ApiReleaseRow {
  release_id: number;
  name: string;
  release_date: string | null;
  description: string | null;
  product_id: number | null;
  product_name: string | null;
  status_id: number;
  status_name: string;
  created_by_user_id: number;
  created_by_name: string;
  created_at: string;
}

interface ApiReleaseMappingRow {
  release_mapping_id: number;
  release_id: number;
  feature_id: number | null;
  feature_name: string | null;
  dev_item_id: number | null;
  dev_item_title: string | null;
  mapped_by_user_id: number;
  mapped_by_name: string;
  mapped_at: string;
}

interface ApiReleaseNoteItem {
  kind: string;
  title: string;
  description: string;
}

function toReleaseRow(r: ApiReleaseRow): ReleaseRow {
  return {
    releaseId: r.release_id, name: r.name, releaseDate: r.release_date, description: r.description,
    productId: r.product_id, productName: r.product_name, statusId: r.status_id, statusName: r.status_name,
    createdByUserId: r.created_by_user_id, createdByName: r.created_by_name, createdAt: r.created_at
  };
}

function toReleaseMappingRow(r: ApiReleaseMappingRow): ReleaseMappingRow {
  return {
    releaseMappingId: r.release_mapping_id, releaseId: r.release_id,
    featureId: r.feature_id, featureName: r.feature_name, devItemId: r.dev_item_id, devItemTitle: r.dev_item_title,
    mappedByUserId: r.mapped_by_user_id, mappedByName: r.mapped_by_name, mappedAt: r.mapped_at
  };
}

interface ApiEngineeringEffortRow {
  module_name: string | null;
  task_type_name: string | null;
  activity_type_name: string;
  total_minutes: number;
  entry_count: number;
}

interface ApiModuleEffortRow {
  module_id: number | null;
  module_name: string | null;
  product_name: string | null;
  total_minutes: number;
  entry_count: number;
}

interface ApiFeatureEffortRow {
  feature_id: number | null;
  feature_name: string | null;
  module_name: string | null;
  total_minutes: number;
  entry_count: number;
}

interface ApiFeatureEffortEntryRow {
  activity_id: number;
  occurred_at: string;
  task_title: string | null;
  activity_type_name: string;
  duration_minutes: number;
  logged_by_name: string | null;
}

interface ApiInterruptionReportRow {
  activity_id: number;
  occurred_at: string;
  reason_name: string;
  interrupted_task_title: string;
  new_task_title: string;
  requested_by_name: string;
  comments: string | null;
  duration_minutes: number | null;
}

interface ApiPendingAgeingRow {
  dev_item_id: number;
  title: string;
  feature_name: string;
  status_name: string;
  age_days: number;
  created_at: string;
  task_id: number | null;
  task_title: string | null;
  task_status_name: string | null;
  expected_deadline: string | null;
  overdue_days: number | null;
}

interface ApiReleaseProgressRow {
  release_id: number;
  release_name: string;
  status_name: string;
  mapped_feature_count: number;
  mapped_dev_item_count: number;
  dev_items_done_count: number;
  dev_items_pending_count: number;
}

interface ApiSupportDrivenWorkRow {
  dev_item_id: number;
  title: string;
  feature_name: string;
  ticket_voucher_no: number | null;
  customer_name: string | null;
  status_name: string;
  total_minutes: number;
}

interface ApiDashboardSummary {
  open_dev_items: number;
  open_tasks: number;
  minutes_logged_last_7_days: number;
  pending_decision_reviews: number;
}

interface ApiRecentActivityRow {
  activity_id: number;
  activity_type_name: string;
  description: string | null;
  duration_minutes: number | null;
  occurred_at: string;
  logged_by_name: string;
  task_name: string | null;
}

interface ApiAttachmentRow {
  attachment_id: number;
  entity_type: string;
  entity_id: number;
  file_name: string;
  file_size_bytes: number;
  content_type: string | null;
  uploaded_by_user_id: number;
  uploaded_by_name: string;
  uploaded_at: string;
}

function toEngineeringEffortRow(r: ApiEngineeringEffortRow): EngineeringEffortRow {
  return {
    moduleName: r.module_name, taskTypeName: r.task_type_name, activityTypeName: r.activity_type_name,
    totalMinutes: r.total_minutes, entryCount: r.entry_count
  };
}

function toModuleEffortRow(r: ApiModuleEffortRow): ModuleEffortRow {
  return { moduleId: r.module_id, moduleName: r.module_name, productName: r.product_name, totalMinutes: r.total_minutes, entryCount: r.entry_count };
}

function toFeatureEffortRow(r: ApiFeatureEffortRow): FeatureEffortRow {
  return { featureId: r.feature_id, featureName: r.feature_name, moduleName: r.module_name, totalMinutes: r.total_minutes, entryCount: r.entry_count };
}

function toFeatureEffortEntryRow(r: ApiFeatureEffortEntryRow): FeatureEffortEntryRow {
  return {
    activityId: r.activity_id, occurredAt: r.occurred_at, taskTitle: r.task_title,
    activityTypeName: r.activity_type_name, durationMinutes: r.duration_minutes, loggedByName: r.logged_by_name
  };
}

function toInterruptionReportRow(r: ApiInterruptionReportRow): InterruptionReportRow {
  return {
    activityId: r.activity_id, occurredAt: r.occurred_at, reasonName: r.reason_name,
    interruptedTaskTitle: r.interrupted_task_title, newTaskTitle: r.new_task_title,
    requestedByName: r.requested_by_name, comments: r.comments, durationMinutes: r.duration_minutes
  };
}

function toPendingAgeingRow(r: ApiPendingAgeingRow): PendingAgeingRow {
  return {
    devItemId: r.dev_item_id, title: r.title, featureName: r.feature_name, statusName: r.status_name,
    ageDays: r.age_days, createdAt: r.created_at,
    taskId: r.task_id, taskTitle: r.task_title, taskStatusName: r.task_status_name,
    expectedDeadline: r.expected_deadline, overdueDays: r.overdue_days
  };
}

function toReleaseProgressRow(r: ApiReleaseProgressRow): ReleaseProgressRow {
  return {
    releaseId: r.release_id, releaseName: r.release_name, statusName: r.status_name,
    mappedFeatureCount: r.mapped_feature_count, mappedDevItemCount: r.mapped_dev_item_count,
    devItemsDoneCount: r.dev_items_done_count, devItemsPendingCount: r.dev_items_pending_count
  };
}

function toSupportDrivenWorkRow(r: ApiSupportDrivenWorkRow): SupportDrivenWorkRow {
  return {
    devItemId: r.dev_item_id, title: r.title, featureName: r.feature_name, ticketVoucherNo: r.ticket_voucher_no,
    customerName: r.customer_name, statusName: r.status_name, totalMinutes: r.total_minutes
  };
}

function toRecentActivityRow(r: ApiRecentActivityRow): RecentActivityRow {
  return {
    activityId: r.activity_id, activityTypeName: r.activity_type_name, description: r.description,
    durationMinutes: r.duration_minutes, occurredAt: r.occurred_at, loggedByName: r.logged_by_name,
    taskName: r.task_name
  };
}

function toAttachmentRow(r: ApiAttachmentRow): AttachmentRow {
  return {
    attachmentId: r.attachment_id, entityType: r.entity_type, entityId: r.entity_id,
    fileName: r.file_name, fileSizeBytes: r.file_size_bytes, contentType: r.content_type,
    uploadedByUserId: r.uploaded_by_user_id, uploadedByName: r.uploaded_by_name, uploadedAt: r.uploaded_at
  };
}

function toDecisionRow(r: ApiDecisionRow): DecisionRow {
  return {
    decisionId: r.decision_id, featureId: r.feature_id, featureName: r.feature_name,
    devItemId: r.dev_item_id, devItemTitle: r.dev_item_title, taskId: r.task_id, taskTitle: r.task_title,
    decisionTypeId: r.decision_type_id, decisionTypeName: r.decision_type_name, description: r.description,
    approverUserId: r.approver_user_id, approverName: r.approver_name, approverExternalName: r.approver_external_name,
    reason: r.reason, riskLevel: r.risk_level, reviewDate: r.review_date,
    statusId: r.status_id, statusName: r.status_name, customerId: r.customer_id, customerName: r.customer_name,
    createdByUserId: r.created_by_user_id, createdByName: r.created_by_name, createdAt: r.created_at
  };
}

function toFeatureTicketRow(r: ApiFeatureTicketRow): FeatureTicketRow {
  return {
    featureTicketId: r.feature_ticket_id, ticketVoucherNo: r.ticket_voucher_no,
    ticketDate: r.ticket_date, ticketCustomerName: r.ticket_customer_name,
    addedByUserId: r.added_by_user_id, addedByName: r.added_by_name, addedAt: r.added_at
  };
}

function toTaskTicketRow(r: ApiTaskTicketRow): TaskTicketRow {
  return {
    taskTicketId: r.task_ticket_id, ticketVoucherNo: r.ticket_voucher_no,
    ticketDate: r.ticket_date, ticketCustomerName: r.ticket_customer_name,
    addedByUserId: r.added_by_user_id, addedByName: r.added_by_name, addedAt: r.added_at
  };
}

function toAssignmentHistoryRow(r: ApiAssignmentHistoryRow): AssignmentHistoryRow {
  return {
    assignmentHistoryId: r.assignment_history_id, roleType: r.role_type,
    userId: r.user_id, userName: r.user_name,
    assignedByUserId: r.assigned_by_user_id, assignedByName: r.assigned_by_name,
    assignedAt: r.assigned_at, unassignedAt: r.unassigned_at, comments: r.comments
  };
}

@Injectable({ providedIn: 'root' })
export class EngineeringHubDataService {
  private readonly http = inject(HttpClient);
  private readonly base = `${API_BASE_URL}/engineering-hub`;

  // ---- Cascading hierarchy lookups ----

  getProducts(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${this.base}/products/lookup`);
  }

  /** productId omitted -> every module across all products (used by the
   * Tasks page's unscoped multi-select filter, not a cascading picker there). */
  getModules(productId?: number): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${this.base}/modules/lookup`, { params: productId ? { product_id: productId } : {} });
  }

  /** moduleId omitted -> every feature across all modules (same unscoped-filter use case as getModules). */
  getFeaturesLookup(moduleId?: number): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${this.base}/features/lookup`, { params: moduleId ? { module_id: moduleId } : {} });
  }

  /** featureId omitted -> every development item across all features (same unscoped-filter use case). */
  getDevItemsLookup(featureId?: number): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${this.base}/development-items/lookup`, { params: featureId ? { feature_id: featureId } : {} });
  }

  /** devItemId omitted -> every task across all development items (same unscoped-filter use case, for report Task filters). */
  getTasksLookup(devItemId?: number): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${this.base}/tasks/lookup`, { params: devItemId ? { dev_item_id: devItemId } : {} });
  }

  // ---- Global master lookups ----

  private simpleMasterLookup(path: string): Observable<LookupOption[]> {
    return this.http
      .get<ApiSimpleMasterRow[]>(`${this.base}/${path}`)
      .pipe(map((rows) => rows.filter((r) => r.enabled).map((r) => ({ label: r.name, value: r.id }))));
  }

  getTaskTypes(): Observable<LookupOption[]> {
    return this.simpleMasterLookup('task-types');
  }

  getDevItemTypes(): Observable<LookupOption[]> {
    return this.simpleMasterLookup('dev-item-types');
  }

  getPriorities(): Observable<LookupOption[]> {
    return this.simpleMasterLookup('priorities');
  }

  getOriginTypes(): Observable<LookupOption[]> {
    return this.simpleMasterLookup('origin-types');
  }

  getDecisionTypes(): Observable<LookupOption[]> {
    return this.simpleMasterLookup('decision-types');
  }

  getActivityTypes(): Observable<LookupOption[]> {
    return this.simpleMasterLookup('activity-types');
  }

  getStatuses(entityType: 'Feature' | 'DevelopmentItem' | 'Task' | 'Decision' | 'Release'): Observable<StatusOption[]> {
    return this.http
      .get<ApiStatusRow[]>(`${this.base}/statuses`, { params: { entity_type: entityType } })
      .pipe(map((rows) => rows.filter((r) => r.enabled).map((r) => ({ label: r.name, value: r.status_id, isTerminal: r.is_terminal }))));
  }

  getUsers(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${this.base}/users`);
  }

  getCustomers(search = ''): Observable<CustomerOption[]> {
    return this.http
      .get<ApiCustomerRow[]>(`${this.base}/customers`, { params: { search } })
      .pipe(map((rows) => rows.map((r) => ({ custId: r.cust_id, displayName: r.display_name }))));
  }

  getTickets(search = ''): Observable<TicketOption[]> {
    return this.http
      .get<ApiTicketRow[]>(`${this.base}/tickets`, { params: { search } })
      .pipe(map((rows) => rows.map((r) => ({ voucherNo: r.voucher_no, date: r.date, customerName: r.customer_name }))));
  }

  // ---- Features ----

  getFeatures(moduleId?: number, includeDisabled = false, productId?: number): Observable<FeatureRow[]> {
    let params = new HttpParams().set('include_disabled', includeDisabled);
    if (moduleId) {
      params = params.set('module_id', moduleId);
    }
    if (productId) {
      params = params.set('product_id', productId);
    }
    return this.http.get<ApiFeatureRow[]>(`${this.base}/features`, { params }).pipe(map((rows) => rows.map(toFeatureRow)));
  }

  getFeature(featureId: number): Observable<FeatureRow> {
    return this.http.get<ApiFeatureRow>(`${this.base}/features/${featureId}`).pipe(map(toFeatureRow));
  }

  saveFeature(form: FeatureForm): Observable<{ success: boolean; featureId: number }> {
    return this.http
      .post<{ success: boolean; feature_id: number }>(`${this.base}/features`, {
        feature_id: form.featureId, module_id: form.moduleId, name: form.name,
        description: form.description, enabled: form.enabled
      })
      .pipe(map((r) => ({ success: r.success, featureId: r.feature_id })));
  }

  // userId=null unassigns the role — closes the current EngHub_AssignmentHistory
  // row (if any) without opening a replacement and clears the denormalized
  // FeatureOwnerUserId/TechnicalOwnerUserId column server-side.
  assignFeatureRole(featureId: number, roleType: string, userId: number | null): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${this.base}/features/${featureId}/assign`, { role_type: roleType, user_id: userId });
  }

  getFeatureAssignmentHistory(featureId: number): Observable<AssignmentHistoryRow[]> {
    return this.http
      .get<ApiAssignmentHistoryRow[]>(`${this.base}/features/${featureId}/assignment-history`)
      .pipe(map((rows) => rows.map(toAssignmentHistoryRow)));
  }

  /** A Feature links to at most one Trouble Ticket at a time (not a list). */
  getFeatureTicket(featureId: number): Observable<FeatureTicketRow | null> {
    return this.http
      .get<ApiFeatureTicketRow | null>(`${this.base}/features/${featureId}/ticket`)
      .pipe(map((row) => (row ? toFeatureTicketRow(row) : null)));
  }

  /** Replaces whatever ticket is currently linked; pass null to clear it. */
  setFeatureTicket(featureId: number, ticketVoucherNo: number | null): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${this.base}/features/${featureId}/ticket`, { ticket_voucher_no: ticketVoucherNo });
  }

  // ---- Development Items ----

  getDevelopmentItems(
    featureId?: number, statusId?: number, includeClosed = false, productId?: number, moduleId?: number
  ): Observable<DevItemRow[]> {
    let params = new HttpParams().set('include_closed', includeClosed);
    if (productId) {
      params = params.set('product_id', productId);
    }
    if (moduleId) {
      params = params.set('module_id', moduleId);
    }
    if (featureId) {
      params = params.set('feature_id', featureId);
    }
    if (statusId) {
      params = params.set('status_id', statusId);
    }
    return this.http.get<ApiDevItemRow[]>(`${this.base}/development-items`, { params }).pipe(map((rows) => rows.map(toDevItemRow)));
  }

  getDevelopmentItem(devItemId: number): Observable<DevItemRow> {
    return this.http.get<ApiDevItemRow>(`${this.base}/development-items/${devItemId}`).pipe(map(toDevItemRow));
  }

  saveDevelopmentItem(form: DevItemForm): Observable<{ success: boolean; devItemId: number }> {
    return this.http
      .post<{ success: boolean; dev_item_id: number }>(`${this.base}/development-items`, {
        dev_item_id: form.devItemId, feature_id: form.featureId, dev_item_type_id: form.devItemTypeId,
        title: form.title, description: form.description, origin_type_id: form.originTypeId,
        origin_ticket_voucher_no: form.originTicketVoucherNo, customer_id: form.customerId,
        priority_id: form.priorityId, status_id: form.statusId
      })
      .pipe(map((r) => ({ success: r.success, devItemId: r.dev_item_id })));
  }

  // ---- Tasks ----

  getTasks(
    devItemId?: number,
    assignedToUserId?: number,
    includeClosed = false,
    unassignedOnly = false,
    multiFilters?: {
      productIds?: number[];
      moduleIds?: number[];
      featureIds?: number[];
      devItemIds?: number[];
      taskTypeIds?: number[];
      statusIds?: number[];
      developerUserIds?: number[];
      dateFrom?: string;
      dateTo?: string;
    }
  ): Observable<TaskRow[]> {
    let params = new HttpParams().set('include_closed', includeClosed);
    if (devItemId) {
      params = params.set('dev_item_id', devItemId);
    }
    if (assignedToUserId) {
      params = params.set('assigned_to_user_id', assignedToUserId);
    }
    if (unassignedOnly) {
      params = params.set('unassigned_only', true);
    }
    const appendAll = (key: string, values?: number[]) => {
      for (const v of values ?? []) {
        params = params.append(key, v);
      }
    };
    appendAll('product_ids', multiFilters?.productIds);
    appendAll('module_ids', multiFilters?.moduleIds);
    appendAll('feature_ids', multiFilters?.featureIds);
    appendAll('dev_item_ids', multiFilters?.devItemIds);
    appendAll('task_type_ids', multiFilters?.taskTypeIds);
    appendAll('status_ids', multiFilters?.statusIds);
    appendAll('developer_user_ids', multiFilters?.developerUserIds);
    if (multiFilters?.dateFrom) {
      params = params.set('date_from', multiFilters.dateFrom);
    }
    if (multiFilters?.dateTo) {
      params = params.set('date_to', multiFilters.dateTo);
    }
    return this.http.get<ApiTaskRow[]>(`${this.base}/tasks`, { params }).pipe(map((rows) => rows.map(toTaskRow)));
  }

  getTask(taskId: number): Observable<TaskRow> {
    return this.http.get<ApiTaskRow>(`${this.base}/tasks/${taskId}`).pipe(map(toTaskRow));
  }

  saveTask(form: TaskForm): Observable<{ success: boolean; taskId: number }> {
    return this.http
      .post<{ success: boolean; task_id: number }>(`${this.base}/tasks`, {
        task_id: form.taskId, dev_item_id: form.devItemId, task_type_id: form.taskTypeId,
        title: form.title, description: form.description, status_id: form.statusId,
        priority_id: form.priorityId,
        estimated_hours: form.estimatedHours,
        expected_deadline: form.expectedDeadline
      })
      .pipe(map((r) => ({ success: r.success, taskId: r.task_id })));
  }

  // userId=null unassigns the role (same as assignFeatureRole).
  assignTaskRole(taskId: number, roleType: string, userId: number | null): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${this.base}/tasks/${taskId}/assign`, { role_type: roleType, user_id: userId });
  }

  /** Status-only change from the grid's inline "Change status" dropdown —
   * distinct from logWork()'s new_status_id, which only applies alongside a
   * work-log entry. This lets a status change be saved on its own, with no
   * duration required, and without creating a spurious 0-minute Activity row. */
  changeTaskStatus(taskId: number, statusId: number): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${this.base}/tasks/${taskId}/status`, { status_id: statusId });
  }

  getTaskAssignmentHistory(taskId: number): Observable<AssignmentHistoryRow[]> {
    return this.http
      .get<ApiAssignmentHistoryRow[]>(`${this.base}/tasks/${taskId}/assignment-history`)
      .pipe(map((rows) => rows.map(toAssignmentHistoryRow)));
  }

  /** A Task links to at most one Trouble Ticket at a time (not a list) — same model as getFeatureTicket. */
  getTaskTicket(taskId: number): Observable<TaskTicketRow | null> {
    return this.http
      .get<ApiTaskTicketRow | null>(`${this.base}/tasks/${taskId}/ticket`)
      .pipe(map((row) => (row ? toTaskTicketRow(row) : null)));
  }

  /** Replaces whatever ticket is currently linked; pass null to clear it. */
  setTaskTicket(taskId: number, ticketVoucherNo: number | null): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${this.base}/tasks/${taskId}/ticket`, { ticket_voucher_no: ticketVoucherNo });
  }

  // ---- Activities / Timeline ----

  getInterruptionReasons(): Observable<LookupOption[]> {
    return this.simpleMasterLookup('interruption-reasons');
  }

  /** Exactly one of featureId/devItemId/taskId — rolls up child-entity
   * activities too (e.g. a Feature's timeline includes its Dev Items' and
   * Tasks' activities), matching the backend's rollup query. */
  getActivities(scope: { featureId?: number; devItemId?: number; taskId?: number }): Observable<ActivityRow[]> {
    let params = new HttpParams();
    if (scope.featureId) {
      params = params.set('feature_id', scope.featureId);
    } else if (scope.devItemId) {
      params = params.set('dev_item_id', scope.devItemId);
    } else if (scope.taskId) {
      params = params.set('task_id', scope.taskId);
    }
    return this.http.get<ApiActivityRow[]>(`${this.base}/activities`, { params }).pipe(map((rows) => rows.map(toActivityRow)));
  }

  /** Standalone "every activity ever logged" list (top-level Activities nav
   * item) — unlike getActivities() above, no scope is required; all filters
   * optional and combine as AND, same as Tasks' getTasks() multiFilters. */
  browseActivities(filters: {
    activityTypeIds?: number[];
    loggedByUserIds?: number[];
    productIds?: number[];
    moduleIds?: number[];
    featureIds?: number[];
    devItemIds?: number[];
    taskTypeIds?: number[];
    statusIds?: number[];
    developerUserIds?: number[];
    dateFrom?: string;
    dateTo?: string;
  }): Observable<ActivityBrowseRow[]> {
    let params = new HttpParams();
    const appendAll = (key: string, values?: number[]) => {
      for (const v of values ?? []) {
        params = params.append(key, v);
      }
    };
    appendAll('activity_type_ids', filters.activityTypeIds);
    appendAll('logged_by_user_ids', filters.loggedByUserIds);
    appendAll('product_ids', filters.productIds);
    appendAll('module_ids', filters.moduleIds);
    appendAll('feature_ids', filters.featureIds);
    appendAll('dev_item_ids', filters.devItemIds);
    appendAll('task_type_ids', filters.taskTypeIds);
    appendAll('status_ids', filters.statusIds);
    appendAll('developer_user_ids', filters.developerUserIds);
    if (filters.dateFrom) params = params.set('date_from', filters.dateFrom);
    if (filters.dateTo) params = params.set('date_to', filters.dateTo);
    return this.http
      .get<ApiActivityBrowseRow[]>(`${this.base}/activities/browse`, { params })
      .pipe(map((rows) => rows.map(toActivityBrowseRow)));
  }

  /** workDate: 'YYYY-MM-DD' local date the work was done (omitted = today). */
  logWork(
    taskId: number, durationMinutes: number, newStatusId?: number | null, description?: string, workDate?: string
  ): Observable<{ success: boolean; activityId: number }> {
    return this.http
      .post<{ success: boolean; activity_id: number }>(`${this.base}/activities/work-log`, {
        task_id: taskId, duration_minutes: durationMinutes, new_status_id: newStatusId ?? null, description: description ?? null,
        work_date: workDate ?? null
      })
      .pipe(map((r) => ({ success: r.success, activityId: r.activity_id })));
  }

  logDiscussion(
    scope: { featureId?: number; devItemId?: number; taskId?: number },
    description: string,
    durationMinutes: number | null,
    participantUserIds: number[]
  ): Observable<{ success: boolean; activityId: number }> {
    return this.http
      .post<{ success: boolean; activity_id: number }>(`${this.base}/activities/discussion`, {
        feature_id: scope.featureId ?? null, dev_item_id: scope.devItemId ?? null, task_id: scope.taskId ?? null,
        duration_minutes: durationMinutes, description, participant_user_ids: participantUserIds
      })
      .pipe(map((r) => ({ success: r.success, activityId: r.activity_id })));
  }

  logComment(scope: { featureId?: number; devItemId?: number; taskId?: number }, description: string): Observable<{ success: boolean; activityId: number }> {
    return this.http
      .post<{ success: boolean; activity_id: number }>(`${this.base}/activities/comment`, {
        feature_id: scope.featureId ?? null, dev_item_id: scope.devItemId ?? null, task_id: scope.taskId ?? null, description
      })
      .pipe(map((r) => ({ success: r.success, activityId: r.activity_id })));
  }

  getParticipants(activityId: number): Observable<ParticipantRow[]> {
    return this.http
      .get<ApiParticipantRow[]>(`${this.base}/activities/${activityId}/participants`)
      .pipe(map((rows) => rows.map(toParticipantRow)));
  }

  respondToParticipation(activityId: number, status: 'Accepted' | 'Rejected'): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${this.base}/activities/${activityId}/participants/respond`, { status });
  }

  selfAddParticipant(activityId: number): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${this.base}/activities/${activityId}/participants/self-add`, {});
  }

  getCurrentTask(): Observable<CurrentTask> {
    return this.http.get<ApiCurrentTask>(`${this.base}/user-current-task`).pipe(map((r) => ({ taskId: r.task_id, taskTitle: r.task_title })));
  }

  setCurrentTask(taskId: number): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${this.base}/user-current-task`, { task_id: taskId });
  }

  logInterruption(
    newTaskId: number,
    interruptionReasonId: number,
    requestedByUserId: number,
    comments?: string,
    durationMinutes?: number | null
  ): Observable<{ success: boolean; activityId: number }> {
    return this.http
      .post<{ success: boolean; activity_id: number }>(`${this.base}/activities/interruption`, {
        new_task_id: newTaskId, interruption_reason_id: interruptionReasonId,
        requested_by_user_id: requestedByUserId, comments: comments ?? null,
        duration_minutes: durationMinutes ?? null
      })
      .pipe(map((r) => ({ success: r.success, activityId: r.activity_id })));
  }

  // ---- Decisions ----

  getDecisions(filter: {
    featureId?: number;
    devItemId?: number;
    taskId?: number;
    decisionTypeId?: number;
    statusId?: number;
    customerId?: number;
  } = {}): Observable<DecisionRow[]> {
    let params = new HttpParams();
    if (filter.featureId) {
      params = params.set('feature_id', filter.featureId);
    }
    if (filter.devItemId) {
      params = params.set('dev_item_id', filter.devItemId);
    }
    if (filter.taskId) {
      params = params.set('task_id', filter.taskId);
    }
    if (filter.decisionTypeId) {
      params = params.set('decision_type_id', filter.decisionTypeId);
    }
    if (filter.statusId) {
      params = params.set('status_id', filter.statusId);
    }
    if (filter.customerId) {
      params = params.set('customer_id', filter.customerId);
    }
    return this.http.get<ApiDecisionRow[]>(`${this.base}/decisions`, { params }).pipe(map((rows) => rows.map(toDecisionRow)));
  }

  getDecision(decisionId: number): Observable<DecisionRow> {
    return this.http.get<ApiDecisionRow>(`${this.base}/decisions/${decisionId}`).pipe(map(toDecisionRow));
  }

  saveDecision(form: DecisionForm): Observable<{ success: boolean; decisionId: number }> {
    return this.http
      .post<{ success: boolean; decision_id: number }>(`${this.base}/decisions`, {
        decision_id: form.decisionId, feature_id: form.featureId, dev_item_id: form.devItemId, task_id: form.taskId,
        decision_type_id: form.decisionTypeId, description: form.description, approver_user_id: form.approverUserId,
        approver_external_name: form.approverExternalName, reason: form.reason, risk_level: form.riskLevel,
        review_date: form.reviewDate, status_id: form.statusId, customer_id: form.customerId
      })
      .pipe(map((r) => ({ success: r.success, decisionId: r.decision_id })));
  }

  // ---- Releases ----

  getReleases(filter: { productId?: number; statusId?: number } = {}): Observable<ReleaseRow[]> {
    let params = new HttpParams();
    if (filter.productId) {
      params = params.set('product_id', filter.productId);
    }
    if (filter.statusId) {
      params = params.set('status_id', filter.statusId);
    }
    return this.http.get<ApiReleaseRow[]>(`${this.base}/releases`, { params }).pipe(map((rows) => rows.map(toReleaseRow)));
  }

  getRelease(releaseId: number): Observable<ReleaseRow> {
    return this.http.get<ApiReleaseRow>(`${this.base}/releases/${releaseId}`).pipe(map(toReleaseRow));
  }

  saveRelease(form: ReleaseForm): Observable<{ success: boolean; releaseId: number }> {
    return this.http
      .post<{ success: boolean; release_id: number }>(`${this.base}/releases`, {
        release_id: form.releaseId, name: form.name, release_date: form.releaseDate,
        description: form.description, product_id: form.productId, status_id: form.statusId
      })
      .pipe(map((r) => ({ success: r.success, releaseId: r.release_id })));
  }

  getReleasesForEntity(target: { featureId?: number; devItemId?: number }): Observable<ReleaseRow[]> {
    let params = new HttpParams();
    if (target.featureId) {
      params = params.set('feature_id', target.featureId);
    } else if (target.devItemId) {
      params = params.set('dev_item_id', target.devItemId);
    }
    return this.http.get<ApiReleaseRow[]>(`${this.base}/releases/for-entity`, { params }).pipe(map((rows) => rows.map(toReleaseRow)));
  }

  getReleaseMappings(releaseId: number): Observable<ReleaseMappingRow[]> {
    return this.http
      .get<ApiReleaseMappingRow[]>(`${this.base}/releases/${releaseId}/mappings`)
      .pipe(map((rows) => rows.map(toReleaseMappingRow)));
  }

  mapToRelease(releaseId: number, target: { featureId?: number; devItemId?: number }): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${this.base}/releases/${releaseId}/map`, {
      feature_id: target.featureId ?? null, dev_item_id: target.devItemId ?? null
    });
  }

  unmapFromRelease(releaseId: number, mappingId: number): Observable<{ success: boolean }> {
    return this.http.delete<{ success: boolean }>(`${this.base}/releases/${releaseId}/mappings/${mappingId}`);
  }

  getReleaseNotes(releaseId: number): Observable<ReleaseNoteItem[]> {
    return this.http
      .get<ApiReleaseNoteItem[]>(`${this.base}/releases/${releaseId}/notes`)
      .pipe(map((rows) => rows.map((r) => ({ kind: r.kind as 'Feature' | 'DevelopmentItem', title: r.title, description: r.description }))));
  }

  // ---- Attachments ----

  getAttachments(entityType: string, entityId: number): Observable<AttachmentRow[]> {
    const params = new HttpParams().set('entity_type', entityType).set('entity_id', entityId);
    return this.http.get<ApiAttachmentRow[]>(`${this.base}/attachments`, { params }).pipe(map((rows) => rows.map(toAttachmentRow)));
  }

  uploadAttachments(entityType: string, entityId: number, files: File[]): Observable<AttachmentRow[]> {
    const formData = new FormData();
    files.forEach((f) => formData.append('files', f, f.name));
    const params = new HttpParams().set('entity_type', entityType).set('entity_id', entityId);
    return this.http.post<ApiAttachmentRow[]>(`${this.base}/attachments`, formData, { params }).pipe(map((rows) => rows.map(toAttachmentRow)));
  }

  deleteAttachment(attachmentId: number): Observable<{ success: boolean }> {
    return this.http.delete<{ success: boolean }>(`${this.base}/attachments/${attachmentId}`);
  }

  getAttachmentDownloadUrl(attachmentId: number): string {
    return `${this.base}/attachments/${attachmentId}/download`;
  }

  // ---- Reports ----

  private reportParams(filter: {
    moduleId?: number;
    productId?: number;
    featureId?: number;
    devItemId?: number;
    taskId?: number;
    overdueDaysGt?: number;
    ttNo?: number;
    userId?: number;
    dateFrom?: string;
    dateTo?: string;
  }): HttpParams {
    let params = new HttpParams();
    if (filter.productId) {
      params = params.set('product_id', filter.productId);
    }
    if (filter.moduleId) {
      params = params.set('module_id', filter.moduleId);
    }
    if (filter.featureId) {
      params = params.set('feature_id', filter.featureId);
    }
    if (filter.devItemId) {
      params = params.set('dev_item_id', filter.devItemId);
    }
    if (filter.taskId) {
      params = params.set('task_id', filter.taskId);
    }
    if (filter.overdueDaysGt !== undefined && filter.overdueDaysGt !== null) {
      params = params.set('overdue_days_gt', filter.overdueDaysGt);
    }
    if (filter.ttNo) {
      params = params.set('tt_no', filter.ttNo);
    }
    if (filter.userId) {
      params = params.set('user_id', filter.userId);
    }
    if (filter.dateFrom) {
      params = params.set('date_from', filter.dateFrom);
    }
    if (filter.dateTo) {
      params = params.set('date_to', filter.dateTo);
    }
    return params;
  }

  getEngineeringEffort(
    filter: { productId?: number; moduleId?: number; dateFrom?: string; dateTo?: string } = {}
  ): Observable<EngineeringEffortRow[]> {
    return this.http
      .get<ApiEngineeringEffortRow[]>(`${this.base}/reports/engineering-effort`, { params: this.reportParams(filter) })
      .pipe(map((rows) => rows.map(toEngineeringEffortRow)));
  }

  getModuleEffort(filter: { productId?: number; dateFrom?: string; dateTo?: string } = {}): Observable<ModuleEffortRow[]> {
    return this.http
      .get<ApiModuleEffortRow[]>(`${this.base}/reports/module-effort`, { params: this.reportParams(filter) })
      .pipe(map((rows) => rows.map(toModuleEffortRow)));
  }

  getFeatureEffort(
    filter: { productId?: number; moduleId?: number; featureId?: number; dateFrom?: string; dateTo?: string } = {}
  ): Observable<FeatureEffortRow[]> {
    return this.http
      .get<ApiFeatureEffortRow[]>(`${this.base}/reports/feature-effort`, { params: this.reportParams(filter) })
      .pipe(map((rows) => rows.map(toFeatureEffortRow)));
  }

  /** Row-level entries behind one Feature Effort row's Entries count — a
   * drill-down for that single row, not a report of its own. */
  getFeatureEffortEntries(featureId: number, filter: { dateFrom?: string; dateTo?: string } = {}): Observable<FeatureEffortEntryRow[]> {
    return this.http
      .get<ApiFeatureEffortEntryRow[]>(`${this.base}/reports/feature-effort/${featureId}/entries`, { params: this.reportParams(filter) })
      .pipe(map((rows) => rows.map(toFeatureEffortEntryRow)));
  }

  getInterruptionsReport(filter: { dateFrom?: string; dateTo?: string } = {}): Observable<InterruptionReportRow[]> {
    return this.http
      .get<ApiInterruptionReportRow[]>(`${this.base}/reports/interruptions`, { params: this.reportParams(filter) })
      .pipe(map((rows) => rows.map(toInterruptionReportRow)));
  }

  getTestingEffort(
    filter: { productId?: number; moduleId?: number; featureId?: number; devItemId?: number; taskId?: number; dateFrom?: string; dateTo?: string } = {}
  ): Observable<FeatureEffortRow[]> {
    return this.http
      .get<ApiFeatureEffortRow[]>(`${this.base}/reports/testing-effort`, { params: this.reportParams(filter) })
      .pipe(map((rows) => rows.map(toFeatureEffortRow)));
  }

  /** Row-level entries behind one Testing Effort row's Entries count — a
   * drill-down for that single row, not a report of its own. Accepts the
   * same filters as getTestingEffort (minus featureId, fixed to the row)
   * so the returned entries always match whatever combination of filters
   * produced that row's entryCount. */
  getTestingEffortEntries(
    featureId: number,
    filter: { productId?: number; moduleId?: number; devItemId?: number; taskId?: number; dateFrom?: string; dateTo?: string } = {}
  ): Observable<FeatureEffortEntryRow[]> {
    return this.http
      .get<ApiFeatureEffortEntryRow[]>(`${this.base}/reports/testing-effort/${featureId}/entries`, { params: this.reportParams(filter) })
      .pipe(map((rows) => rows.map(toFeatureEffortEntryRow)));
  }

  getPendingAgeing(
    filter: { productId?: number; moduleId?: number; featureId?: number; devItemId?: number; overdueDaysGt?: number } = {}
  ): Observable<PendingAgeingRow[]> {
    return this.http
      .get<ApiPendingAgeingRow[]>(`${this.base}/reports/pending-ageing`, { params: this.reportParams(filter) })
      .pipe(map((rows) => rows.map(toPendingAgeingRow)));
  }

  getReleaseProgress(filter: { productId?: number } = {}): Observable<ReleaseProgressRow[]> {
    return this.http
      .get<ApiReleaseProgressRow[]>(`${this.base}/reports/release-progress`, { params: this.reportParams(filter) })
      .pipe(map((rows) => rows.map(toReleaseProgressRow)));
  }

  getSupportDrivenWork(
    filter: {
      productId?: number;
      featureId?: number;
      devItemId?: number;
      taskId?: number;
      ttNo?: number;
      userId?: number;
      dateFrom?: string;
      dateTo?: string;
    } = {}
  ): Observable<SupportDrivenWorkRow[]> {
    return this.http
      .get<ApiSupportDrivenWorkRow[]>(`${this.base}/reports/support-driven-work`, { params: this.reportParams(filter) })
      .pipe(map((rows) => rows.map(toSupportDrivenWorkRow)));
  }

  // ---- Dashboard ----

  getDashboardSummary(): Observable<DashboardSummary> {
    return this.http.get<ApiDashboardSummary>(`${this.base}/dashboard/summary`).pipe(
      map((r) => ({
        openDevItems: r.open_dev_items, openTasks: r.open_tasks,
        minutesLoggedLast7Days: r.minutes_logged_last_7_days, pendingDecisionReviews: r.pending_decision_reviews
      }))
    );
  }

  getRecentActivity(): Observable<RecentActivityRow[]> {
    return this.http
      .get<ApiRecentActivityRow[]>(`${this.base}/dashboard/recent-activity`)
      .pipe(map((rows) => rows.map(toRecentActivityRow)));
  }

  /** Per-developer dashboard for one user + date range ("YYYY-MM-DD" local
   * dates). userId omitted = the logged-in user; another user's id is only
   * allowed for Menu Rights admins (403 otherwise). The response is a wide,
   * nested, read-only shape, so its snake_case keys are camelized generically
   * rather than with a hand-written mapper per row type. */
  getDeveloperDashboard(filter: { userId?: number | null; dateFrom?: string | null; dateTo?: string | null }): Observable<DeveloperDashboard> {
    let params = new HttpParams();
    if (filter.userId) {
      params = params.set('user_id', filter.userId);
    }
    if (filter.dateFrom) {
      params = params.set('date_from', filter.dateFrom);
    }
    if (filter.dateTo) {
      params = params.set('date_to', filter.dateTo);
    }
    return this.http
      .get<unknown>(`${this.base}/developer-dashboard`, { params })
      .pipe(map((r) => camelizeKeys(r) as DeveloperDashboard));
  }

  // ---- Masters admin (raw CRUD) ----
  //
  // One generic pair covers all 7 simple id/name/enabled masters (mirrors
  // enghub_masters.py's own _get_simple_master()/_save_simple_master()
  // helper — the table/path is always a hardcoded literal the caller
  // chooses, never taken from user input, so this isn't the "generic table
  // name as a parameter" pattern the design proposal ruled out). Product,
  // Module and Status each have their own pair since their shapes genuinely
  // differ (parent scoping, extra fields).

  getSimpleMasterCrud(path: string): Observable<SimpleMasterCrudRow[]> {
    return this.http.get<SimpleMasterCrudRow[]>(`${this.base}/${path}`);
  }

  saveSimpleMasterCrud(path: string, row: SimpleMasterCrudRow): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${this.base}/${path}`, row);
  }

  getProductsCrud(): Observable<ProductCrudRow[]> {
    return this.http.get<ApiProductCrudRow[]>(`${this.base}/products`).pipe(map((rows) => rows.map(toProductCrudRow)));
  }

  saveProductCrud(row: ProductCrudRow): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${this.base}/products`, {
      product_id: row.productId, name: row.name, description: row.description, enabled: row.enabled
    });
  }

  getModulesCrud(productId: number): Observable<ModuleCrudRow[]> {
    return this.http
      .get<ApiModuleCrudRow[]>(`${this.base}/modules`, { params: { product_id: productId } })
      .pipe(map((rows) => rows.map(toModuleCrudRow)));
  }

  saveModuleCrud(row: ModuleCrudRow): Observable<{ success: boolean; moduleId: number }> {
    return this.http
      .post<{ success: boolean; module_id: number }>(`${this.base}/modules`, {
        module_id: row.moduleId, product_id: row.productId, name: row.name, description: row.description, enabled: row.enabled
      })
      .pipe(map((r) => ({ success: r.success, moduleId: r.module_id })));
  }

  getStatusesCrud(entityType: string): Observable<StatusCrudRow[]> {
    return this.http
      .get<ApiStatusRow[]>(`${this.base}/statuses`, { params: { entity_type: entityType } })
      .pipe(map((rows) => rows.map(toStatusCrudRow)));
  }

  saveStatusCrud(row: StatusCrudRow): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${this.base}/statuses`, {
      status_id: row.statusId, entity_type: row.entityType, name: row.name, color: row.color,
      sort_order: row.sortOrder, is_terminal: row.isTerminal, enabled: row.enabled
    });
  }
}
