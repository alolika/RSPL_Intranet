import { DatePipe, DecimalPipe, Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, ViewChild, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { DialogModule } from 'primeng/dialog';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelect, MultiSelectModule } from 'primeng/multiselect';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { PortalAuthService } from '../../core/auth/portal-auth.service';
import { DecisionForm, EngineeringHubDataService, LookupOption, ReleaseRow, StatusOption, TaskRow, TimelineEntry, mergeTimelineEntries } from '../engineering-hub-data.service';
import { EngHubTimeline } from '../shared/eng-hub-timeline';
import { QUICK_RANGE_OPTIONS, QuickRangeOption, computeQuickRange } from '../shared/quick-range';
import { formatTimeSpent } from '../shared/time-spent';

interface TaskRowUi extends TaskRow {
  customMinutes: number | null;
  logStatusId: number | null;
  /** Unsaved text in the remark strip under the row — sent as the work-log
   * entry's description when ✓ is clicked, then cleared. */
  remarkDraft: string;
  /** Date the logged work was done — defaults to today, may go back up to
   * WORK_LOG_MAX_DAYS_BACK days (the backend enforces the same limit). */
  workDate: Date;
}

const QUICK_DURATIONS = [15, 30, 45, 60];
const WORK_LOG_MAX_DAYS_BACK = 15;

function startOfToday(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

/** Tasks — defaults to "My Tasks" (current user's current Developer
 * assignment, tracked via EngHub_AssignmentHistory, not a static column).
 * Each row has inline quick work-log buttons (15/30/45/60/custom minutes,
 * PRD target: under 10 seconds) plus an optional status change. Switching
 * to a Task that differs from the caller's EngHub_UserCurrentTask pointer
 * prompts "Have you been interrupted?" before the log is written. */
@Component({
  selector: 'app-tasks',
  imports: [FormsModule, ButtonModule, CheckboxModule, DatePickerModule, DatePipe, DialogModule, EngHubTimeline, InputNumberModule, InputTextModule, MultiSelectModule, SelectModule, TableModule, TextareaModule, DecimalPipe],
  templateUrl: './tasks.html',
  styleUrl: './tasks.scss'
})
export class Tasks implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly location = inject(Location);
  private readonly auth = inject(PortalAuthService);
  // No zone.js — plain properties mutated inside subscribe callbacks need an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly rows = signal<TaskRowUi[]>([]);
  readonly users = signal<LookupOption[]>([]);
  readonly taskStatuses = signal<StatusOption[]>([]);
  readonly interruptionReasons = signal<LookupOption[]>([]);
  readonly loading = signal(false);
  // Reflects what the grid is ACTUALLY showing right now, set inside load()
  // rather than computed live from showAllTasks/filters — same deferred-until-
  // Show model as every other filter, so the header doesn't flip to "All
  // Tasks" the instant a checkbox is ticked, only once Show is clicked.
  readonly isMyTasksView = signal(true);

  // Filter panel is collapsed by default so the grid gets full page width/
  // height on load; the panel only occupies space once the user opens it,
  // and everything inside keeps working exactly as before (Show still stages
  // -> applies, Quick Range still applies immediately, etc.) regardless of
  // whether the panel is open or closed at the time.
  readonly filtersExpanded = signal(false);

  toggleFilters(): void {
    this.filtersExpanded.update((v) => !v);
  }

  // Top-of-page filters — each an independent multi-select (not a cascading
  // Product->Module->Feature picker like the add-forms use), since these
  // narrow an already-small task list rather than build one record; every
  // option list is unscoped/global, per-filter "Select All" comes for free
  // from p-multiSelect's own showToggleAll.
  readonly filterProducts = signal<LookupOption[]>([]);
  readonly filterModules = signal<LookupOption[]>([]);
  readonly filterFeatures = signal<LookupOption[]>([]);
  readonly filterDevItems = signal<LookupOption[]>([]);
  readonly filterTaskTypes = signal<LookupOption[]>([]);
  // Status filter reuses taskStatuses() (same Task-status master already
  // loaded for the inline "Change status" dropdown) rather than a duplicate signal.

  filterProductIds: number[] = [];
  filterModuleIds: number[] = [];
  filterFeatureIds: number[] = [];
  filterDevItemIds: number[] = [];
  filterTaskTypeIds: number[] = [];
  filterStatusIds: number[] = [];
  filterDeveloperUserIds: number[] = [];

  // Created-date range filter, plus a Quick Range dropdown that fills both
  // dates at once. Unlike every other filter in this bar, picking a Quick
  // Range option refreshes the grid immediately (see onQuickRangeChange())
  // rather than waiting for "Show" — manual From/To date edits still wait,
  // same as the rest of the filter bar.
  filterDateFrom: Date | null = null;
  filterDateTo: Date | null = null;
  quickRangeOption: QuickRangeOption | null = null;
  readonly quickRangeOptions = QUICK_RANGE_OPTIONS;

  readonly quickDurations = QUICK_DURATIONS;
  readonly formatTimeSpent = formatTimeSpent;

  /** Log Work column is only usable by the Task's currently assigned
   * Developer — everyone else sees it disabled. Backend re-checks this on
   * every mutating call (log_work / set_task_status) too, since a disabled
   * button is UI-only and doesn't stop a direct API call. */
  canLogWork(row: TaskRowUi): boolean {
    const myUserId = this.auth.currentUser()?.userId;
    return myUserId != null && row.developerUserId === myUserId;
  }

  showAllTasks = false;
  unassignedOnly = false;
  includeClosed = false;

  // Text search over the already-loaded grid — filters as you type, no Show
  // click needed. Closed tasks are excluded from the load unless Include
  // Closed is ticked, so by default this searches pending tasks only.
  readonly searchText = signal('');
  readonly filteredRows = computed(() => {
    const q = this.searchText().trim().toLowerCase();
    if (!q) return this.rows();
    return this.rows().filter((r) =>
      [r.title, r.devItemTitle, r.featureName, r.taskTypeName, r.statusName, r.developerName]
        .some((v) => (v ?? '').toString().toLowerCase().includes(q))
    );
  });

  currentTaskId: number | null = null;

  assignDialogVisible = false;
  assignTask: TaskRow | null = null;
  assignRoleType: 'Developer' | 'Tester' = 'Developer';
  assignUserId: number | null = null;

  // Interruption prompt state — shown when a quick-log is fired against a
  // Task different from currentTaskId.
  interruptionDialogVisible = false;
  interruptionStep: 'ask' | 'details' = 'ask';
  private pendingLog: { row: TaskRowUi; minutes: number } | null = null;
  interruptionReasonId: number | null = null;
  interruptionRequestedByUserId: number | null = null;
  interruptionComments = '';
  interruptionDurationMinutes: number | null = null;

  // Task-scoped Timeline dialog, opened from clicking a row's Time Spent
  // value — deliberately a different view from the grid's own "Timeline"
  // action link (which opens the shared Development Item detail page's
  // Timeline, rolled up across every Task under that Dev Item). This one
  // scopes strictly to a single Task's own TaskId, via the same
  // getActivities/getDecisions({taskId}) + mergeTimelineEntries() pattern
  // Feature/Dev Item detail already use for their own scopes.
  taskTimelineDialogVisible = false;
  taskTimelineTaskTitle = '';
  readonly taskTimelineEntries = signal<TimelineEntry[]>([]);

  viewTaskTimeline(row: TaskRowUi): void {
    this.taskTimelineTaskTitle = row.title;
    this.taskTimelineEntries.set([]);
    this.taskTimelineDialogVisible = true;
    this.data.getActivities({ taskId: row.taskId }).subscribe((activities) => {
      this.data.getDecisions({ taskId: row.taskId }).subscribe((decisions) => {
        this.taskTimelineEntries.set(mergeTimelineEntries(activities, decisions));
        this.cdr.markForCheck();
      });
    });
  }

  closeTaskTimeline(): void {
    this.taskTimelineDialogVisible = false;
  }

  // Header quick actions (Log Discussion / Log Decision / Map to Release) —
  // the same three actions the Development Item detail page offers, so they
  // can be fired straight from this grid without opening that page. Each one
  // asks which Task first, defaulting to the user's current Task. Discussion
  // and Decision are logged at Task level (they still roll up into the Dev
  // Item's Timeline); releases only map Features/Dev Items, so Map to Release
  // maps the chosen Task's Development Item.
  quickAction: 'Discussion' | 'Decision' | 'Release' | null = null;
  quickDialogVisible = false;
  quickTaskId: number | null = null;
  discussionDescription = '';
  discussionMinutes: number | null = null;
  discussionParticipantIds: number[] = [];
  @ViewChild('participantsMs') participantsMs?: MultiSelect;
  mapReleaseId: number | null = null;
  // All releases for the task's product, newest first. The dropdown shows the
  // latest 5 until the user types; a search then covers every release.
  private readonly allReleases = signal<ReleaseRow[]>([]);
  private readonly releaseSearch = signal('');
  readonly availableReleases = computed(() => {
    const q = this.releaseSearch().trim().toLowerCase();
    const all = this.allReleases();
    return q ? all.filter((r) => r.name.toLowerCase().includes(q)) : all.slice(0, 5);
  });

  onReleaseFilter(text: string): void {
    this.releaseSearch.set(text ?? '');
  }

  // Log Decision popup — same fields/validation as the Add Decision page,
  // linked to the chosen Task, saved without leaving this grid.
  readonly decisionTypes = signal<LookupOption[]>([]);
  readonly decisionStatuses = signal<StatusOption[]>([]);
  readonly customers = signal<LookupOption[]>([]);
  readonly riskLevels = ['Low', 'Medium', 'High'];
  decisionForm: DecisionForm = this.blankDecisionForm();
  decisionApproverIsExternal = false;
  decisionReviewDate: Date | null = null;
  decisionSaving = false;
  private decisionLookupsLoaded = false;
  private readonly customerFilter$ = new Subject<string>();

  private blankDecisionForm(): DecisionForm {
    return {
      decisionId: 0, featureId: null, devItemId: null, taskId: null, decisionTypeId: 0,
      description: '', approverUserId: null, approverExternalName: null, reason: '',
      riskLevel: 'Low', reviewDate: null, statusId: this.decisionStatuses()[0]?.value ?? 0, customerId: null
    };
  }

  private loadDecisionLookups(): void {
    if (this.decisionLookupsLoaded) {
      return;
    }
    this.decisionLookupsLoaded = true;
    this.data.getDecisionTypes().subscribe((t) => {
      this.decisionTypes.set(t);
      this.cdr.markForCheck();
    });
    this.data.getStatuses('Decision').subscribe((statuses) => {
      this.decisionStatuses.set(statuses);
      if (!this.decisionForm.statusId) {
        this.decisionForm.statusId = statuses[0]?.value ?? 0;
      }
      this.cdr.markForCheck();
    });
    this.customerFilter$
      .pipe(debounceTime(300), distinctUntilChanged(), switchMap((q) => this.data.getCustomers(q)))
      .subscribe((rows) => {
        this.customers.set(rows.map((r) => ({ label: r.displayName, value: r.custId })));
        this.cdr.markForCheck();
      });
  }

  onCustomerFilter(query: string): void {
    this.customerFilter$.next(query);
  }

  private validateDecision(): boolean {
    const f = this.decisionForm;
    if (!f.decisionTypeId) {
      alert('Please select a decision type.');
      return false;
    }
    if (!f.description.trim()) {
      alert('Enter a description.');
      return false;
    }
    if (!f.reason.trim()) {
      alert('Enter a reason.');
      return false;
    }
    if (this.decisionApproverIsExternal && !f.approverExternalName?.trim()) {
      alert('Enter the external approver name.');
      return false;
    }
    if (!this.decisionApproverIsExternal && !f.approverUserId) {
      alert('Please select an approver, or check "External approver".');
      return false;
    }
    return true;
  }

  quickTaskOptions(): LookupOption[] {
    return this.rows().map((r) => ({ label: `${r.title} — ${r.devItemTitle}`, value: r.taskId }));
  }

  private quickTask(): TaskRowUi | undefined {
    return this.rows().find((r) => r.taskId === this.quickTaskId);
  }

  openQuickAction(action: 'Discussion' | 'Decision' | 'Release'): void {
    const rows = this.rows();
    this.quickAction = action;
    this.quickTaskId = rows.some((r) => r.taskId === this.currentTaskId) ? this.currentTaskId : rows.length === 1 ? rows[0].taskId : null;
    this.discussionDescription = '';
    this.discussionMinutes = null;
    this.discussionParticipantIds = [];
    this.mapReleaseId = null;
    this.allReleases.set([]);
    this.releaseSearch.set('');
    if (action === 'Decision') {
      this.loadDecisionLookups();
      this.decisionForm = this.blankDecisionForm();
      this.decisionApproverIsExternal = false;
      this.decisionReviewDate = null;
      this.decisionSaving = false;
    }
    if (action === 'Release') {
      this.loadReleasesForQuickTask();
    }
    this.quickDialogVisible = true;
  }

  onQuickTaskChange(): void {
    if (this.quickAction === 'Release') {
      this.mapReleaseId = null;
      this.loadReleasesForQuickTask();
    }
  }

  private loadReleasesForQuickTask(): void {
    const t = this.quickTask();
    this.releaseSearch.set('');
    if (!t) {
      this.allReleases.set([]);
      return;
    }
    this.data.getReleases(t.productId ? { productId: t.productId } : {}).subscribe((rows) => {
      this.allReleases.set(
        [...rows].sort((a, b) => (b.releaseDate ?? '').localeCompare(a.releaseDate ?? '') || b.releaseId - a.releaseId),
      );
      this.cdr.markForCheck();
    });
  }

  saveQuickAction(): void {
    const t = this.quickTask();
    if (!t) {
      alert('Please select a task.');
      return;
    }
    if (this.quickAction === 'Decision') {
      if (!this.validateDecision()) {
        return;
      }
      const form: DecisionForm = {
        ...this.decisionForm,
        featureId: null,
        devItemId: null,
        taskId: t.taskId,
        approverUserId: this.decisionApproverIsExternal ? null : this.decisionForm.approverUserId,
        approverExternalName: this.decisionApproverIsExternal ? this.decisionForm.approverExternalName : null,
        reviewDate: this.decisionReviewDate ? this.decisionReviewDate.toISOString().slice(0, 10) : null
      };
      this.decisionSaving = true;
      this.data.saveDecision(form).subscribe({
        next: (res) => {
          this.decisionSaving = false;
          if (!res.success) {
            alert('Failed to save decision.');
          } else {
            this.quickDialogVisible = false;
          }
          this.cdr.markForCheck();
        },
        error: (err) => {
          this.decisionSaving = false;
          alert(err.error?.detail ?? 'Failed to save decision.');
          this.cdr.markForCheck();
        }
      });
    } else if (this.quickAction === 'Discussion') {
      if (!this.discussionDescription.trim()) {
        alert('Enter a description.');
        return;
      }
      this.data
        .logDiscussion({ taskId: t.taskId }, this.discussionDescription, this.discussionMinutes, this.discussionParticipantIds)
        .subscribe(() => {
          this.quickDialogVisible = false;
          this.load();
        });
    } else if (this.quickAction === 'Release') {
      if (!this.mapReleaseId) {
        alert('Please select a release.');
        return;
      }
      this.data.mapToRelease(this.mapReleaseId, { devItemId: t.devItemId }).subscribe(() => {
        this.quickDialogVisible = false;
        this.cdr.markForCheck();
      });
    }
  }

  onParticipantSelect(): void {
    if (this.participantsMs) {
      this.participantsMs.filterValue = '';
    }
  }

  ngOnInit(): void {
    this.data.getUsers().subscribe((users) => this.users.set(users));
    this.data.getStatuses('Task').subscribe((s) => this.taskStatuses.set(s));
    this.data.getInterruptionReasons().subscribe((r) => this.interruptionReasons.set(r));
    this.data.getProducts().subscribe((p) => this.filterProducts.set(p));
    this.data.getModules().subscribe((m) => this.filterModules.set(m));
    this.data.getFeaturesLookup().subscribe((f) => this.filterFeatures.set(f));
    this.data.getDevItemsLookup().subscribe((d) => this.filterDevItems.set(d));
    this.data.getTaskTypes().subscribe((t) => this.filterTaskTypes.set(t));
    // Developer filter opens pre-selected to the logged-in user — the same
    // scope as the default "My Tasks" view (both filter on the assigned
    // Developer), just made visible in the filter bar.
    const myUserId = this.auth.currentUser()?.userId;
    if (myUserId != null) {
      this.filterDeveloperUserIds = [myUserId];
    }
    this.refreshCurrentTask();
    this.load();
  }

  private refreshCurrentTask(): void {
    this.data.getCurrentTask().subscribe((c) => {
      this.currentTaskId = c.taskId;
      this.cdr.markForCheck();
    });
  }

  /** True once the user has staged any of the top filter-bar controls
   * (the 7 multi-selects or the date range) — used below to decide whether
   * the implicit "My Tasks" scope should still apply. */
  private hasActiveFilters(): boolean {
    return (
      this.hasActiveNonDeveloperFilters() ||
      (this.filterDeveloperUserIds.length > 0 && !this.isDeveloperFilterJustMe())
    );
  }

  private hasActiveNonDeveloperFilters(): boolean {
    return (
      this.filterProductIds.length > 0 ||
      this.filterModuleIds.length > 0 ||
      this.filterFeatureIds.length > 0 ||
      this.filterDevItemIds.length > 0 ||
      this.filterTaskTypeIds.length > 0 ||
      this.filterStatusIds.length > 0 ||
      !!this.filterDateFrom ||
      !!this.filterDateTo
    );
  }

  /** The default pre-selection (only the logged-in user) is "My Tasks",
   * not an explicit filter — keeps the header reading "My Tasks". */
  private isDeveloperFilterJustMe(): boolean {
    const myUserId = this.auth.currentUser()?.userId;
    return myUserId != null && this.filterDeveloperUserIds.length === 1 && this.filterDeveloperUserIds[0] === myUserId;
  }

  /** "Show All Tasks" and the default Developer = me pre-selection would
   * contradict each other, so ticking it clears that default (a Developer
   * selection the user picked themselves is left alone) and unticking it
   * with no Developer selected restores it. Still applies only on Show. */
  onShowAllTasksChange(): void {
    const myUserId = this.auth.currentUser()?.userId;
    if (this.showAllTasks && this.isDeveloperFilterJustMe()) {
      this.filterDeveloperUserIds = [];
    } else if (!this.showAllTasks && !this.filterDeveloperUserIds.length && myUserId != null) {
      this.filterDeveloperUserIds = [myUserId];
    }
    this.load();
  }

  load(): void {
    this.loading.set(true);
    const myUserId = this.auth.currentUser()?.userId;
    // "My Tasks" (assignedToUserId set) is the bare default view with no
    // other filters active. The moment the user stages any filter bar
    // control and clicks Show, that's an explicit request to search beyond
    // just their own tasks — silently ANDing it with "assigned to me" too
    // was the actual bug: e.g. picking a Developer filter for someone else
    // while "Show All Tasks" was still unchecked always returned zero rows,
    // which looked identical to "the filters don't work" from the outside.
    const assignedToUserId = this.showAllTasks || this.unassignedOnly || this.hasActiveFilters() ? undefined : myUserId;
    this.isMyTasksView.set(assignedToUserId !== undefined);
    this.data
      .getTasks(undefined, assignedToUserId, this.includeClosed, this.unassignedOnly, {
        productIds: this.filterProductIds,
        moduleIds: this.filterModuleIds,
        featureIds: this.filterFeatureIds,
        devItemIds: this.filterDevItemIds,
        taskTypeIds: this.filterTaskTypeIds,
        statusIds: this.filterStatusIds,
        developerUserIds: this.filterDeveloperUserIds,
        dateFrom: this.filterDateFrom ? this.toDateOnlyString(this.filterDateFrom) : undefined,
        dateTo: this.filterDateTo ? this.toDateOnlyString(this.filterDateTo) : undefined
      })
      .subscribe((rows) => {
        // Keep any unsaved remark/selected minutes on other rows across a
        // reload (a status change or another row's log reloads the grid).
        const drafts = new Map(this.rows().map((r) => [r.taskId, r]));
        this.minWorkDateValue = this.minWorkDate();
        this.rows.set(
          rows.map((r) => ({
            ...r,
            customMinutes: drafts.get(r.taskId)?.customMinutes ?? null,
            logStatusId: null,
            remarkDraft: drafts.get(r.taskId)?.remarkDraft ?? '',
            workDate: drafts.get(r.taskId)?.workDate ?? startOfToday()
          }))
        );
        this.loading.set(false);
      });
  }

  // ---- Filter bar: every control below only stages a change; nothing
  // re-queries the grid until the user clicks "Show" (showFiltered()). ----

  /** Bound to the "Show" button — the one place that actually re-fetches
   * the grid using whatever the filter bar currently has staged. */
  showFiltered(): void {
    this.load();
  }

  /** Sends a plain "YYYY-MM-DD" calendar date, deliberately not
   * date.toISOString() — that converts through UTC, which shifts a
   * locally-picked date onto the wrong day for any user ahead of UTC (e.g.
   * IST, +5:30) and was the actual cause of "To Date returns no data": a
   * local-midnight Date for e.g. 8-Aug in IST becomes 7-Aug 18:30 UTC once
   * converted, landing the whole comparison a full day early. The backend
   * treats both bounds as calendar dates and makes date_to inclusive of its
   * entire day, so only the Y/M/D parts need to survive the trip here. */
  private toDateOnlyString(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  /** Fills From/To from the selected Quick Range option and refreshes the
   * grid immediately — the one filter in this bar that doesn't wait for
   * "Show", since picking a preset is itself the "I want to see this" action.
   * Only the calendar date (Y/M/D) of these ever reaches the server (see
   * toDateOnlyString), so no start/end-of-day time handling is needed here. */
  onQuickRangeChange(): void {
    const { from, to } = computeQuickRange(this.quickRangeOption);
    this.filterDateFrom = from;
    this.filterDateTo = to;
    this.load();
  }

  clearDateRange(): void {
    this.filterDateFrom = null;
    this.filterDateTo = null;
    this.quickRangeOption = null;
  }

  onDateRangeManualChange(): void {
    this.quickRangeOption = null;
  }

  back(): void {
    this.location.back();
  }

  addTask(): void {
    this.router.navigate(['/engineering-hub/add-task']);
  }

  editTask(row: TaskRowUi): void {
    // UI-only gate here (mirrors the [class.disabled] link below); the real
    // enforcement for the actual edit-save is server-side in save_task().
    if (!this.canLogWork(row)) {
      return;
    }
    this.router.navigate(['/engineering-hub/add-task'], { queryParams: { id: row.taskId } });
  }

  /** Opens this Task's own timeline in a popup on this page (same dialog as
   * clicking Time Spent) instead of navigating away. */
  viewTimeline(row: TaskRowUi): void {
    this.viewTaskTimeline(row);
  }

  // ---- Inline status change (independent of logging work) ----

  /** The "Change status" dropdown previously only took effect if the user
   * also logged minutes via the quick-log buttons/checkmark — picking a
   * status alone did nothing. This saves it immediately on its own and
   * refreshes the grid, no duration required. */
  onStatusChange(row: TaskRowUi): void {
    // Current status is shown as text above the dropdown; the dropdown stays
    // on its "Change status" placeholder and picking a status saves it.
    if (!row.logStatusId || row.logStatusId === row.statusId || !this.canLogWork(row)) {
      row.logStatusId = null;
      return;
    }
    this.data.changeTaskStatus(row.taskId, row.logStatusId).subscribe({
      next: () => this.load(),
      error: (err) => {
        row.logStatusId = null;
        this.cdr.markForCheck();
        alert(err.error?.detail ?? 'Only the assigned developer can change this task\'s status.');
      }
    });
  }

  // ---- Quick work log ----

  /** Quick-duration pills only SELECT the minutes (into the same box as a
   * custom value) — nothing is saved until ✓, so a remark can be typed in
   * the strip under the row first and saved together with the time. */
  logQuick(row: TaskRowUi, minutes: number): void {
    if (!this.canLogWork(row)) {
      return;
    }
    row.customMinutes = minutes;
  }

  logCustom(row: TaskRowUi): void {
    if (!this.canLogWork(row)) {
      return;
    }
    if (!row.customMinutes || row.customMinutes <= 0) {
      alert('Select or enter minutes.');
      return;
    }
    if (!row.workDate) {
      alert('Select the work date.');
      return;
    }
    if (row.workDate < this.minWorkDate()) {
      alert(`Work date can be at most ${WORK_LOG_MAX_DAYS_BACK} days in the past.`);
      return;
    }
    this.startLog(row, row.customMinutes);
  }

  /** Bound to the row datepickers' [minDate]; a stable object (refreshed on
   * every grid load) so change detection doesn't rebuild every calendar. */
  minWorkDateValue: Date = this.minWorkDate();

  /** Earliest selectable work date — recomputed on save/load so the limit
   * stays right if the page is left open past midnight. */
  minWorkDate(): Date {
    const d = startOfToday();
    d.setDate(d.getDate() - WORK_LOG_MAX_DAYS_BACK);
    return d;
  }

  private startLog(row: TaskRowUi, minutes: number): void {
    if (this.currentTaskId && this.currentTaskId !== row.taskId) {
      this.pendingLog = { row, minutes };
      this.interruptionStep = 'ask';
      this.interruptionReasonId = null;
      this.interruptionRequestedByUserId = null;
      this.interruptionComments = '';
      this.interruptionDurationMinutes = null;
      this.interruptionDialogVisible = true;
      return;
    }
    this.doLogWork(row, minutes);
  }

  private doLogWork(row: TaskRowUi, minutes: number): void {
    const remark = row.remarkDraft.trim() || undefined;
    const workDate = this.toDateOnlyString(row.workDate ?? startOfToday());
    this.data.logWork(row.taskId, minutes, row.logStatusId !== row.statusId ? row.logStatusId : null, remark, workDate).subscribe({
      next: () => {
        // Saved to the timeline — clear the strip and minutes for the next
        // entry, and put the date back to today so nothing is backdated by accident.
        row.remarkDraft = '';
        row.customMinutes = null;
        row.workDate = startOfToday();
        this.currentTaskId = row.taskId;
        this.load();
        this.cdr.markForCheck();
      },
      error: (err) => alert(err.error?.detail ?? 'Only the assigned developer can log work for this task.')
    });
  }

  interruptionYes(): void {
    this.interruptionStep = 'details';
  }

  interruptionNo(): void {
    if (this.pendingLog) {
      this.doLogWork(this.pendingLog.row, this.pendingLog.minutes);
    }
    this.closeInterruptionDialog();
  }

  confirmInterruption(): void {
    if (!this.pendingLog) {
      return;
    }
    if (!this.interruptionReasonId || !this.interruptionRequestedByUserId) {
      alert('Please select a reason and who requested the switch.');
      return;
    }
    const { row, minutes } = this.pendingLog;
    this.data
      .logInterruption(
        row.taskId,
        this.interruptionReasonId,
        this.interruptionRequestedByUserId,
        this.interruptionComments,
        this.interruptionDurationMinutes
      )
      .subscribe(() => {
        this.doLogWork(row, minutes);
        this.closeInterruptionDialog();
      });
  }

  closeInterruptionDialog(): void {
    this.interruptionDialogVisible = false;
    this.pendingLog = null;
  }

  // ---- Assignment ----

  openAssign(row: TaskRow, roleType: 'Developer' | 'Tester'): void {
    this.assignTask = row;
    this.assignRoleType = roleType;
    this.assignUserId = roleType === 'Developer' ? row.developerUserId : null;
    this.assignDialogVisible = true;
  }

  assignToMe(row: TaskRow): void {
    const myUserId = this.auth.currentUser()?.userId;
    if (!myUserId) {
      return;
    }
    this.data.assignTaskRole(row.taskId, 'Developer', myUserId).subscribe(() => this.load());
  }

  saveAssign(): void {
    if (!this.assignTask || !this.assignUserId) {
      alert('Please select a user.');
      return;
    }
    this.data.assignTaskRole(this.assignTask.taskId, this.assignRoleType, this.assignUserId).subscribe(() => {
      this.assignDialogVisible = false;
      this.load();
    });
  }
}
