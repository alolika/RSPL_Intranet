export const environment = {
  production: false,
  apiBaseUrl: '/proxy',
};
