export const environment = {
  production: true,
  apiBaseUrl: 'https://rsplintranet-backend.apps.retailware.in',
};
