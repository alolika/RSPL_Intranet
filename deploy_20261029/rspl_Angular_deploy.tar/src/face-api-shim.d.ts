// Type shim for @vladmandic/face-api.
// The package's own types/face-api.d.ts uses a triple-slash reference that
// breaks Angular's bundler-mode module resolution. This re-exports the same
// declarations without that reference so the import resolves cleanly.
declare module '@vladmandic/face-api' {
  export * from '../node_modules/@vladmandic/face-api/types/face-api';
}
