import { ApplicationConfig, inject, provideAppInitializer, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { RouteReuseStrategy, provideRouter } from '@angular/router';
import { FilterService } from 'primeng/api';
import { providePrimeNG } from 'primeng/config';

import { routes } from './app.routes';
import { authInterceptor } from './core/auth/auth.interceptor';
import { sessionExpiryInterceptor } from './core/auth/session-expiry.interceptor';
import { transientRetryInterceptor } from './core/http/transient-retry.interceptor';
import { PreserveCustEnquiryRegisterRouteReuseStrategy } from './core/routing/preserve-cust-enquiry-register-route-reuse-strategy';
import { IciciPreset } from './core/theme/icici-preset';
import { registerKeywordAllFilter } from './shared/keyword-filter';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    { provide: RouteReuseStrategy, useClass: PreserveCustEnquiryRegisterRouteReuseStrategy },
    provideHttpClient(withInterceptors([authInterceptor, sessionExpiryInterceptor, transientRetryInterceptor])),
    provideAnimationsAsync(),
    providePrimeNG({
      theme: {
        preset: IciciPreset,
        options: {
          darkModeSelector: false
        }
      }
    }),
    provideAppInitializer(() => registerKeywordAllFilter(inject(FilterService)))
  ]
};
