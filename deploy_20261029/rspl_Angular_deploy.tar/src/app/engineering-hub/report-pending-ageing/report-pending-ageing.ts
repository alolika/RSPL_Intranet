import { DatePipe, Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { InputNumberModule } from 'primeng/inputnumber';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToCsv } from '../../shared/export-csv';
import { exportToPdf } from '../../shared/export-pdf';
import { EngineeringHubDataService, LookupOption, PendingAgeingRow } from '../engineering-hub-data.service';

/** Pending Ageing — open Development Items with one row per pending Task
 * (a Dev Item with 3 pending Tasks shows on 3 rows). "Overdue By" is days
 * past the Task's Expected Deadline as of today; most overdue first.
 * Product > Module > Feature > Development Item is an optional cascading
 * filter, plus an "Overdue By (Days) Greater Than" numeric filter. */
@Component({
  selector: 'app-report-pending-ageing',
  imports: [FormsModule, ButtonModule, InputNumberModule, SelectModule, TableModule, DatePipe],
  templateUrl: './report-pending-ageing.html',
  styleUrl: './report-pending-ageing.scss'
})
export class ReportPendingAgeing implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly location = inject(Location);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly rows = signal<PendingAgeingRow[]>([]);
  readonly loading = signal(false);

  readonly products = signal<LookupOption[]>([]);
  readonly modules = signal<LookupOption[]>([]);
  readonly features = signal<LookupOption[]>([]);
  readonly devItems = signal<LookupOption[]>([]);

  productId: number | null = null;
  moduleId: number | null = null;
  featureId: number | null = null;
  devItemId: number | null = null;
  overdueDaysGt: number | null = null;

  ngOnInit(): void {
    this.data.getProducts().subscribe((products) => {
      this.products.set(products);
      this.cdr.markForCheck();
    });
    this.load();
  }

  onProductChange(): void {
    this.moduleId = null;
    this.featureId = null;
    this.devItemId = null;
    this.modules.set([]);
    this.features.set([]);
    this.devItems.set([]);
    if (this.productId) {
      this.data.getModules(this.productId).subscribe((modules) => {
        this.modules.set(modules);
        this.cdr.markForCheck();
      });
    }
    this.load();
  }

  onModuleChange(): void {
    this.featureId = null;
    this.devItemId = null;
    this.features.set([]);
    this.devItems.set([]);
    if (this.moduleId) {
      this.data.getFeaturesLookup(this.moduleId).subscribe((features) => {
        this.features.set(features);
        this.cdr.markForCheck();
      });
    }
    this.load();
  }

  onFeatureChange(): void {
    this.devItemId = null;
    this.devItems.set([]);
    if (this.featureId) {
      this.data.getDevItemsLookup(this.featureId).subscribe((devItems) => {
        this.devItems.set(devItems);
        this.cdr.markForCheck();
      });
    }
    this.load();
  }

  onDevItemChange(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.data
      .getPendingAgeing({
        productId: this.productId ?? undefined,
        moduleId: this.moduleId ?? undefined,
        featureId: this.featureId ?? undefined,
        devItemId: this.devItemId ?? undefined,
        overdueDaysGt: this.overdueDaysGt ?? undefined
      })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
        this.cdr.markForCheck();
      });
  }

  /** "No deadline" / "Not overdue" / "N day(s)" — same text on screen and in exports. */
  overdueLabel(row: PendingAgeingRow): string {
    if (!row.taskId) {
      return '';
    }
    if (row.overdueDays === null) {
      return 'No deadline';
    }
    if (row.overdueDays <= 0) {
      return 'Not overdue';
    }
    return `${row.overdueDays} day${row.overdueDays === 1 ? '' : 's'}`;
  }

  /** Export what the grid shows (readable columns), not the raw API fields. */
  private exportRows(): Record<string, unknown>[] {
    return this.rows().map((r) => ({
      'Development Item': r.title,
      Feature: r.featureName,
      Status: r.statusName,
      Task: r.taskTitle ?? '(no pending task)',
      'Task Status': r.taskStatusName ?? '',
      'Expected Deadline': r.expectedDeadline ?? '',
      'Overdue By': this.overdueLabel(r),
      Created: r.createdAt ? r.createdAt.slice(0, 10) : ''
    }));
  }

  exportCsv(): void {
    exportToCsv('pending-ageing', this.exportRows());
  }

  exportPdf(): void {
    exportToPdf('pending-ageing', 'Pending Ageing', this.exportRows());
  }

  back(): void {
    this.location.back();
  }
}
