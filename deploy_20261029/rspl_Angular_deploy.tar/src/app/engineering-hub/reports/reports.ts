import { Location } from '@angular/common';
import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';

interface ReportTile {
  label: string;
  description: string;
  route: string;
}

/** Reports landing — 8 tiles per the PRD, each routes to its own filterable
 * grid page. */
@Component({
  selector: 'app-reports',
  imports: [ButtonModule],
  templateUrl: './reports.html',
  styleUrl: './reports.scss'
})
export class Reports {
  private readonly router = inject(Router);
  private readonly location = inject(Location);

  readonly tiles: ReportTile[] = [
    { label: 'Engineering Effort', description: 'Time logged, sliced by Module / Task Type / Activity Type', route: 'engineering-effort' },
    { label: 'Module Effort', description: 'Which modules need the most engineering effort', route: 'module-effort' },
    { label: 'Feature Effort', description: 'Time logged per Feature', route: 'feature-effort' },
    { label: 'Interruptions', description: 'Who got interrupted, why, and what they switched to', route: 'interruptions' },
    { label: 'Testing Effort', description: 'Time logged on Testing-type Tasks', route: 'testing-effort' },
    { label: 'Pending Ageing', description: 'Open Development Items and their pending Tasks, most overdue first', route: 'pending-ageing' },
    { label: 'Release Progress', description: 'Mapped Features/Dev Items per Release and how many are done', route: 'release-progress' },
    { label: 'Support-Driven Work', description: 'Development Items that originated from a Support ticket', route: 'support-driven-work' }
  ];

  open(tile: ReportTile): void {
    this.router.navigate(['/engineering-hub/reports', tile.route]);
  }

  back(): void {
    this.location.back();
  }
}
