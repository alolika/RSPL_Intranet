import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { EngineeringHubDataService, FeatureForm, LookupOption } from '../engineering-hub-data.service';
import { EngHubMenuRightsService } from '../menu-rights.service';
import { QuickAddModuleDialog } from '../shared/quick-add-module-dialog';
import { QuickCreatePrefill, QuickCreated } from '../shared/quick-create';

/** Add/Edit Feature — Product picker cascades the Module picker; a Feature
 * always belongs to exactly one Module (Product > Module > Feature).
 * Trouble Ticket is a single-value field (a Feature links to at most one
 * ticket, not a list) — selectedTicketVoucherNo is staged locally like the
 * rest of the form and committed via one PUT in save(), same moment the
 * Feature itself saves. */
@Component({
  selector: 'app-add-feature',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, SelectModule, TextareaModule, QuickAddModuleDialog],
  templateUrl: './add-feature.html',
  styleUrl: './add-feature.scss'
})
export class AddFeature implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  // Inline "+" create buttons show only for menus this user has been granted.
  readonly menuRights = inject(EngHubMenuRightsService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly location = inject(Location);
  // No zone.js — `form`/`productId` (plain) mutated inside subscribe
  // callbacks need an explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  /** Embedded = hosted in the Add Task page's "+" dialog: prefilled from
   * `prefill` (route query params ignored), and Save/Close emit
   * saved/cancelled instead of navigating. */
  readonly embedded = input(false);
  readonly prefill = input<QuickCreatePrefill | null>(null);
  readonly saved = output<QuickCreated>();
  readonly cancelled = output<void>();

  readonly products = signal<LookupOption[]>([]);
  readonly modules = signal<LookupOption[]>([]);
  readonly saving = signal(false);

  readonly ticketOptions = signal<LookupOption[]>([]);
  selectedTicketVoucherNo: number | null = null;
  private readonly ticketFilter$ = new Subject<string>();

  productId: number | null = null;
  form: FeatureForm = this.blankForm();
  moduleDialogVisible = false;

  private blankForm(): FeatureForm {
    return { featureId: 0, moduleId: 0, name: '', description: '', enabled: true };
  }

  ngOnInit(): void {
    this.data.getProducts().subscribe((products) => {
      this.products.set(products);
      const prefill = this.embedded() ? this.prefill() : null;
      if (prefill?.productId) {
        this.productId = prefill.productId;
        this.onProductChange();
        this.form.moduleId = prefill.moduleId ?? 0;
      }
      this.cdr.markForCheck();
    });

    this.ticketFilter$
      .pipe(debounceTime(300), distinctUntilChanged(), switchMap((q) => this.data.getTickets(q)))
      .subscribe((rows) => {
        this.ticketOptions.set(rows.map((r) => ({ label: this.ticketLabel(r.voucherNo, r.customerName, r.date), value: r.voucherNo })));
        this.cdr.markForCheck();
      });
    this.ticketFilter$.next('');

    const id = this.embedded() ? 0 : Number(this.route.snapshot.queryParamMap.get('id') ?? 0);
    if (id) {
      this.data.getFeature(id).subscribe((feature) => {
        this.form = {
          featureId: feature.featureId, moduleId: feature.moduleId,
          name: feature.name, description: feature.description, enabled: feature.enabled
        };
        this.productId = feature.productId;
        this.onProductChange();
        this.cdr.markForCheck();
      });
      this.data.getFeatureTicket(id).subscribe((ticket) => {
        if (!ticket) {
          return;
        }
        this.selectedTicketVoucherNo = ticket.ticketVoucherNo;
        const label = this.ticketLabel(ticket.ticketVoucherNo, ticket.ticketCustomerName, ticket.ticketDate);
        // Ensure the already-linked ticket has an option to render against —
        // it may not be among the initial unfiltered search results above.
        this.ticketOptions.update((opts) =>
          opts.some((o) => o.value === ticket.ticketVoucherNo) ? opts : [{ label, value: ticket.ticketVoucherNo }, ...opts]
        );
        this.cdr.markForCheck();
      });
    }
  }

  onTicketFilter(query: string): void {
    this.ticketFilter$.next(query);
  }

  // "#VoucherNo — Customer Name (dd-MM-yy)" — same format for search
  // results and the already-linked ticket, so switching between them (e.g.
  // re-opening the search after a ticket is already selected) never
  // flickers to a plainer label.
  private ticketLabel(voucherNo: number, customerName: string | null, date: string | null): string {
    let label = `#${voucherNo}`;
    if (customerName) {
      label += ` — ${customerName}`;
    }
    if (date) {
      label += ` (${date.slice(0, 10)})`;
    }
    return label;
  }

  onProductChange(): void {
    this.modules.set([]);
    if (this.productId) {
      this.data.getModules(this.productId).subscribe((modules) => {
        this.modules.set(modules);
        this.cdr.markForCheck();
      });
    }
  }

  /** "+" next to Module: select the Module just created (its Product may
   * differ if changed in the dialog), leaving the rest of the form as is. */
  onModuleCreated(c: QuickCreated): void {
    this.productId = c.productId;
    this.form.moduleId = c.id;
    this.data.getModules(c.productId).subscribe((modules) => {
      this.modules.set(modules.some((m) => m.value === c.id) ? modules : [...modules, { label: c.label, value: c.id }]);
      this.cdr.markForCheck();
    });
    this.cdr.markForCheck();
  }

  private validate(): boolean {
    if (!this.productId) {
      alert('Please select a product.');
      return false;
    }
    if (!this.form.moduleId) {
      alert('Please select a module.');
      return false;
    }
    if (!this.form.name.trim()) {
      alert('Enter a feature name.');
      return false;
    }
    return true;
  }

  save(): void {
    if (!this.validate()) {
      return;
    }
    this.saving.set(true);
    this.data.saveFeature(this.form).subscribe((res) => {
      if (!res.success) {
        this.saving.set(false);
        alert('Failed to save feature.');
        return;
      }
      // Only now does a real FeatureId exist (for a brand-new Feature) to
      // link the selected ticket against.
      this.data.setFeatureTicket(res.featureId, this.selectedTicketVoucherNo).subscribe(() => {
        this.saving.set(false);
        if (this.embedded()) {
          this.saved.emit({ id: res.featureId, label: this.form.name.trim(), productId: this.productId!, moduleId: this.form.moduleId });
          return;
        }
        this.router.navigate(['/engineering-hub/features']);
      });
    });
  }

  close(): void {
    if (this.embedded()) {
      this.cancelled.emit();
      return;
    }
    this.location.back();
  }
}
