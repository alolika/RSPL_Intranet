import { DecimalPipe, Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToCsv } from '../../shared/export-csv';
import { exportToPdf } from '../../shared/export-pdf';
import { EngineeringEffortRow, EngineeringHubDataService, LookupOption } from '../engineering-hub-data.service';
import { QUICK_RANGE_OPTIONS, QuickRangeOption, computeQuickRange } from '../shared/quick-range';

/** Engineering Effort — "Where is engineering time being spent?", sliced by
 * Module / Task Type / Activity Type. Product > Module is an optional
 * cascading filter, same pattern as the Development Items list page. */
@Component({
  selector: 'app-report-engineering-effort',
  imports: [FormsModule, ButtonModule, DatePickerModule, SelectModule, TableModule, DecimalPipe],
  templateUrl: './report-engineering-effort.html',
  styleUrl: './report-engineering-effort.scss'
})
export class ReportEngineeringEffort implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly location = inject(Location);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly rows = signal<EngineeringEffortRow[]>([]);
  readonly loading = signal(false);

  readonly products = signal<LookupOption[]>([]);
  readonly modules = signal<LookupOption[]>([]);

  productId: number | null = null;
  moduleId: number | null = null;

  dateFrom: Date | null = null;
  dateTo: Date | null = null;
  quickRangeOption: QuickRangeOption | null = null;
  readonly quickRangeOptions = QUICK_RANGE_OPTIONS;

  ngOnInit(): void {
    this.data.getProducts().subscribe((products) => {
      this.products.set(products);
      this.cdr.markForCheck();
    });
    this.load();
  }

  onProductChange(): void {
    this.moduleId = null;
    this.modules.set([]);
    if (this.productId) {
      this.data.getModules(this.productId).subscribe((modules) => {
        this.modules.set(modules);
        this.cdr.markForCheck();
      });
    }
    this.load();
  }

  onModuleChange(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.data
      .getEngineeringEffort({
        productId: this.productId ?? undefined,
        moduleId: this.moduleId ?? undefined,
        dateFrom: this.dateFrom ? this.dateFrom.toISOString() : undefined,
        dateTo: this.dateTo ? this.dateTo.toISOString() : undefined
      })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
        this.cdr.markForCheck();
      });
  }

  /** Fills From/To from the selected Quick Range option and refreshes the
   * grid immediately, same as My Tasks. */
  onQuickRangeChange(): void {
    const { from, to } = computeQuickRange(this.quickRangeOption);
    this.dateFrom = from;
    this.dateTo = to;
    this.load();
  }

  clearDateRange(): void {
    this.dateFrom = null;
    this.dateTo = null;
    this.quickRangeOption = null;
    this.load();
  }

  onDateRangeManualChange(): void {
    this.quickRangeOption = null;
    this.load();
  }

  hoursOf(minutes: number): number {
    return Math.round((minutes / 60) * 100) / 100;
  }

  exportCsv(): void {
    exportToCsv('engineering-effort', this.rows());
  }

  exportPdf(): void {
    exportToPdf('engineering-effort', 'Engineering Effort', this.rows());
  }

  back(): void {
    this.location.back();
  }
}
