import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DialogModule } from 'primeng/dialog';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { EngineeringHubDataService, FeatureRow, LookupOption } from '../engineering-hub-data.service';
import { formatTimeSpent } from '../shared/time-spent';

/** Features list — Product/Module filter (optional), Add routes to the
 * add-feature form. Owner/Technical Owner assignment is a small inline
 * dialog that writes to EngHub_AssignmentHistory (never overwritten) rather
 * than a plain field edit. */
@Component({
  selector: 'app-features',
  imports: [FormsModule, ButtonModule, CheckboxModule, DialogModule, SelectModule, TableModule],
  templateUrl: './features.html',
  styleUrl: './features.scss'
})
export class Features implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly location = inject(Location);
  // No zone.js — plain properties mutated inside subscribe callbacks need an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly products = signal<LookupOption[]>([]);
  readonly modules = signal<LookupOption[]>([]);
  readonly rows = signal<FeatureRow[]>([]);
  readonly users = signal<LookupOption[]>([]);
  readonly loading = signal(false);

  productId: number | null = null;
  moduleId: number | null = null;
  includeDisabled = false;

  // Set only when arriving via the Feature/Dev Item detail breadcrumb's
  // "Product Name" link (a Product-wide view, not yet narrowed to a
  // specific Module) — independent of the filter bar's own productId above,
  // so the filter bar's existing behavior is untouched either way.
  private headerProductId: number | null = null;

  get headerSuffix(): string {
    if (!this.headerProductId) {
      return '';
    }
    const match = this.products().find((p) => p.value === this.headerProductId);
    return match ? ` — ${match.label}` : '';
  }

  // Backs the header's "Add Development Item" button — bound via p-table's
  // [(selection)] (selectionMode="single"), so clicking a row selects it and
  // clicking it again (or a reload) can clear it, same as PrimeNG's own
  // single-select semantics elsewhere.
  selectedFeature: FeatureRow | null = null;

  readonly formatTimeSpent = formatTimeSpent;

  assignDialogVisible = false;
  assignFeature: FeatureRow | null = null;
  assignRoleType: 'FeatureOwner' | 'TechnicalOwner' = 'FeatureOwner';
  assignUserId: number | null = null;

  ngOnInit(): void {
    this.data.getProducts().subscribe((products) => {
      this.products.set(products);
      this.cdr.markForCheck();
    });
    this.data.getUsers().subscribe((users) => this.users.set(users));

    // Optional prefill when navigated here from the Feature/Dev Item detail
    // breadcrumb's "Product Name" link, which only knows a Product (not yet
    // a specific Module). Deliberately a separate path from the filter
    // bar's own productId/load() below, rather than routing through it, so
    // the filter bar's existing module_id-only filtering is unaffected.
    const prefillProductId = Number(this.route.snapshot.queryParamMap.get('productId') ?? 0) || null;
    if (prefillProductId) {
      this.headerProductId = prefillProductId;
      this.loading.set(true);
      this.data.getFeatures(undefined, this.includeDisabled, prefillProductId).subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      });
      return;
    }
    this.load();
  }

  onProductChange(): void {
    this.moduleId = null;
    this.modules.set([]);
    if (this.productId) {
      this.data.getModules(this.productId).subscribe((modules) => {
        this.modules.set(modules);
        this.cdr.markForCheck();
      });
    }
    this.load();
  }

  onModuleChange(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    // A reload can change/narrow which rows exist (filters, Include Retired)
    // — clear any prior selection rather than leaving "Add Development Item"
    // enabled for a row that may no longer be in the grid.
    this.selectedFeature = null;
    this.data.getFeatures(this.moduleId ?? undefined, this.includeDisabled).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }

  back(): void {
    this.location.back();
  }

  addFeature(): void {
    this.router.navigate(['/engineering-hub/add-feature']);
  }

  editFeature(row: FeatureRow): void {
    this.router.navigate(['/engineering-hub/add-feature'], { queryParams: { id: row.featureId } });
  }

  /** Same productId/moduleId/featureId prefill contract as Feature detail's
   * own "Add Development Item" button (add-development-item.ts reads these
   * three query params to preselect its Product > Module > Feature cascade
   * and set form.featureId, so the new Development Item saves against
   * exactly the Feature that was selected in the grid). */
  addDevelopmentItem(): void {
    if (!this.selectedFeature) {
      return;
    }
    const f = this.selectedFeature;
    this.router.navigate(['/engineering-hub/add-development-item'], {
      queryParams: { productId: f.productId, moduleId: f.moduleId, featureId: f.featureId }
    });
  }

  viewFeature(row: FeatureRow): void {
    this.router.navigate(['/engineering-hub/feature-detail'], { queryParams: { id: row.featureId } });
  }

  openAssign(row: FeatureRow, roleType: 'FeatureOwner' | 'TechnicalOwner'): void {
    this.assignFeature = row;
    this.assignRoleType = roleType;
    this.assignUserId = roleType === 'FeatureOwner' ? row.featureOwnerUserId : row.technicalOwnerUserId;
    this.assignDialogVisible = true;
  }

  /** True when the role being assigned in the dialog currently has someone
   * holding it (captured from the row at openAssign() time, independent of
   * whatever the user has since picked in the dropdown) — used to enable/
   * disable the Unassign button. */
  get canUnassign(): boolean {
    if (!this.assignFeature) {
      return false;
    }
    return (this.assignRoleType === 'FeatureOwner' ? this.assignFeature.featureOwnerUserId : this.assignFeature.technicalOwnerUserId) != null;
  }

  saveAssign(): void {
    if (!this.assignFeature || !this.assignUserId) {
      alert('Please select a user.');
      return;
    }
    this.data.assignFeatureRole(this.assignFeature.featureId, this.assignRoleType, this.assignUserId).subscribe(() => {
      this.assignDialogVisible = false;
      this.load();
    });
  }

  /** Clears whoever currently holds this role (Feature Owner or Technical
   * Owner, independently — assignRoleType scopes it to whichever one the
   * dialog was opened for). Works identically for both roles since both go
   * through the same assign_role()/user_id=null backend path. */
  unassign(): void {
    if (!this.assignFeature) {
      return;
    }
    this.data.assignFeatureRole(this.assignFeature.featureId, this.assignRoleType, null).subscribe(() => {
      this.assignDialogVisible = false;
      this.load();
    });
  }
}
