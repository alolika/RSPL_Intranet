import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, ViewChild, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelect, MultiSelectModule } from 'primeng/multiselect';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { EngHubAttachments } from '../shared/eng-hub-attachments';
import { EngHubTimeline } from '../shared/eng-hub-timeline';
import {
  DecisionRow,
  DevItemRow,
  EngineeringHubDataService,
  FeatureRow,
  LookupOption,
  ReleaseRow,
  TaskRow,
  TimelineEntry,
  mergeTimelineEntries
} from '../engineering-hub-data.service';

/** Development Item detail — breadcrumb, Tasks sub-grid with inline "Add
 * Task" (prefilled with the full Product > Module > Feature > Dev Item
 * chain), Decisions sub-list, Release mapping badge, Attachments panel, and
 * the rolled-up Timeline (Activities + Decisions, this Dev Item and every
 * Task beneath it). */
@Component({
  selector: 'app-development-item-detail',
  imports: [
    FormsModule,
    ButtonModule,
    DialogModule,
    InputTextModule,
    MultiSelectModule,
    SelectModule,
    TableModule,
    TextareaModule,
    EngHubTimeline,
    EngHubAttachments
  ],
  templateUrl: './development-item-detail.html',
  styleUrl: './development-item-detail.scss'
})
export class DevelopmentItemDetail implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly location = inject(Location);
  // No zone.js — plain properties mutated inside subscribe callbacks need an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly devItem = signal<DevItemRow | null>(null);
  readonly feature = signal<FeatureRow | null>(null);
  readonly tasks = signal<TaskRow[]>([]);
  readonly decisions = signal<DecisionRow[]>([]);
  readonly timelineEntries = signal<TimelineEntry[]>([]);
  readonly users = signal<LookupOption[]>([]);
  readonly mappedReleases = signal<ReleaseRow[]>([]);
  readonly availableReleases = signal<ReleaseRow[]>([]);

  private devItemId = 0;

  discussionDialogVisible = false;
  discussionDescription = '';
  discussionMinutes: number | null = null;
  discussionParticipantIds: number[] = [];
  @ViewChild('participantsMs') participantsMs?: MultiSelect;

  onParticipantSelect(): void {
    if (this.participantsMs) {
      this.participantsMs.filterValue = '';
    }
  }

  mapDialogVisible = false;
  mapReleaseId: number | null = null;

  ngOnInit(): void {
    this.devItemId = Number(this.route.snapshot.queryParamMap.get('id') ?? 0);
    this.data.getUsers().subscribe((users) => this.users.set(users));
    this.load();
  }

  private load(): void {
    this.data.getDevelopmentItem(this.devItemId).subscribe((item) => {
      this.devItem.set(item);
      this.data.getFeature(item.featureId).subscribe((feature) => {
        this.feature.set(feature);
        this.cdr.markForCheck();
      });
      this.cdr.markForCheck();
    });
    this.data.getTasks(this.devItemId, undefined, true).subscribe((rows) => this.tasks.set(rows));
    this.data.getReleasesForEntity({ devItemId: this.devItemId }).subscribe((rows) => this.mappedReleases.set(rows));
    this.loadTimeline();
  }

  private loadTimeline(): void {
    this.data.getActivities({ devItemId: this.devItemId }).subscribe((activities) => {
      this.data.getDecisions({ devItemId: this.devItemId }).subscribe((decisions) => {
        this.decisions.set(decisions);
        this.timelineEntries.set(mergeTimelineEntries(activities, decisions));
        this.cdr.markForCheck();
      });
    });
  }

  addTask(): void {
    const f = this.feature();
    const d = this.devItem();
    if (!f || !d) {
      return;
    }
    this.router.navigate(['/engineering-hub/add-task'], {
      queryParams: { productId: f.productId, moduleId: f.moduleId, featureId: f.featureId, devItemId: d.devItemId }
    });
  }

  editTask(row: TaskRow): void {
    this.router.navigate(['/engineering-hub/add-task'], { queryParams: { id: row.taskId } });
  }

  editDevItem(): void {
    this.router.navigate(['/engineering-hub/add-development-item'], { queryParams: { id: this.devItemId } });
  }

  /** Breadcrumb's "Product Name" — lands on the Features grid pre-filtered
   * to every Feature under this Product (all Modules), not yet narrowed to
   * a specific Module. */
  goToProduct(productId: number): void {
    this.router.navigate(['/engineering-hub/features'], { queryParams: { productId } });
  }

  goToFeature(featureId: number): void {
    this.router.navigate(['/engineering-hub/feature-detail'], { queryParams: { id: featureId } });
  }

  back(): void {
    this.location.back();
  }

  openMapDialog(): void {
    const f = this.feature();
    this.mapReleaseId = null;
    this.data.getReleases(f?.productId ? { productId: f.productId } : {}).subscribe((rows) => {
      this.availableReleases.set(rows);
      this.cdr.markForCheck();
    });
    this.mapDialogVisible = true;
  }

  saveMap(): void {
    if (!this.mapReleaseId) {
      alert('Please select a release.');
      return;
    }
    this.data.mapToRelease(this.mapReleaseId, { devItemId: this.devItemId }).subscribe(() => {
      this.mapDialogVisible = false;
      this.load();
    });
  }

  logDecision(): void {
    const d = this.devItem();
    if (!d) {
      return;
    }
    this.router.navigate(['/engineering-hub/add-decision'], { queryParams: { devItemId: d.devItemId, label: `Development Item: ${d.title}` } });
  }

  editDecision(row: DecisionRow): void {
    this.router.navigate(['/engineering-hub/add-decision'], { queryParams: { id: row.decisionId } });
  }

  openDiscussion(): void {
    this.discussionDescription = '';
    this.discussionMinutes = null;
    this.discussionParticipantIds = [];
    this.discussionDialogVisible = true;
  }

  saveDiscussion(): void {
    if (!this.discussionDescription.trim()) {
      alert('Enter a description.');
      return;
    }
    this.data
      .logDiscussion({ devItemId: this.devItemId }, this.discussionDescription, this.discussionMinutes, this.discussionParticipantIds)
      .subscribe(() => {
        this.discussionDialogVisible = false;
        this.load();
      });
  }
}
