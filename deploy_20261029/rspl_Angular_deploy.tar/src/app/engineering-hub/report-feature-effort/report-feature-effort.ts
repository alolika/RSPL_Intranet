import { DatePipe, DecimalPipe, Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { DialogModule } from 'primeng/dialog';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToCsv } from '../../shared/export-csv';
import { exportToPdf } from '../../shared/export-pdf';
import { EngineeringHubDataService, FeatureEffortEntryRow, FeatureEffortRow, LookupOption } from '../engineering-hub-data.service';
import { QUICK_RANGE_OPTIONS, QuickRangeOption, computeQuickRange } from '../shared/quick-range';

/** Feature Effort — time logged per Feature. Product > Module > Feature is
 * an optional cascading filter (same pattern as the Development Items list
 * page / other effort reports), not a required drill-down. Clicking a row's
 * Entries count opens a Details dialog listing every individual Activity
 * entry summed into that row — a per-row drill-down, not a separate report
 * page, so it always reflects whatever filters currently produced the row. */
@Component({
  selector: 'app-report-feature-effort',
  imports: [FormsModule, ButtonModule, DatePickerModule, DialogModule, SelectModule, TableModule, DecimalPipe, DatePipe],
  templateUrl: './report-feature-effort.html',
  styleUrl: './report-feature-effort.scss'
})
export class ReportFeatureEffort implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly location = inject(Location);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly rows = signal<FeatureEffortRow[]>([]);
  readonly loading = signal(false);

  // Entries drill-down dialog — scoped to whichever row's Entries count was
  // clicked, using the same date range currently applied to the grid so the
  // listed entries always add up to that row's Hours/Entries figures.
  entriesDialogVisible = false;
  entriesFeatureName = '';
  readonly entriesRows = signal<FeatureEffortEntryRow[]>([]);
  readonly entriesLoading = signal(false);

  readonly products = signal<LookupOption[]>([]);
  readonly modules = signal<LookupOption[]>([]);
  readonly features = signal<LookupOption[]>([]);

  productId: number | null = null;
  moduleId: number | null = null;
  featureId: number | null = null;

  dateFrom: Date | null = null;
  dateTo: Date | null = null;
  quickRangeOption: QuickRangeOption | null = null;
  readonly quickRangeOptions = QUICK_RANGE_OPTIONS;

  ngOnInit(): void {
    this.data.getProducts().subscribe((products) => {
      this.products.set(products);
      this.cdr.markForCheck();
    });
    this.load();
  }

  onProductChange(): void {
    this.moduleId = null;
    this.featureId = null;
    this.modules.set([]);
    this.features.set([]);
    if (this.productId) {
      this.data.getModules(this.productId).subscribe((modules) => {
        this.modules.set(modules);
        this.cdr.markForCheck();
      });
    }
    this.load();
  }

  onModuleChange(): void {
    this.featureId = null;
    this.features.set([]);
    if (this.moduleId) {
      this.data.getFeaturesLookup(this.moduleId).subscribe((features) => {
        this.features.set(features);
        this.cdr.markForCheck();
      });
    }
    this.load();
  }

  onFeatureChange(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.data
      .getFeatureEffort({
        productId: this.productId ?? undefined,
        moduleId: this.moduleId ?? undefined,
        featureId: this.featureId ?? undefined,
        dateFrom: this.dateFrom ? this.dateFrom.toISOString() : undefined,
        dateTo: this.dateTo ? this.dateTo.toISOString() : undefined
      })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
        this.cdr.markForCheck();
      });
  }

  /** Fills From/To from the selected Quick Range option and refreshes the
   * grid immediately, same as My Tasks. */
  onQuickRangeChange(): void {
    const { from, to } = computeQuickRange(this.quickRangeOption);
    this.dateFrom = from;
    this.dateTo = to;
    this.load();
  }

  clearDateRange(): void {
    this.dateFrom = null;
    this.dateTo = null;
    this.quickRangeOption = null;
    this.load();
  }

  onDateRangeManualChange(): void {
    this.quickRangeOption = null;
    this.load();
  }

  hoursOf(minutes: number): number {
    return Math.round((minutes / 60) * 100) / 100;
  }

  viewEntries(row: FeatureEffortRow): void {
    if (!row.featureId) {
      return;
    }
    this.entriesFeatureName = row.featureName ?? 'Feature';
    this.entriesDialogVisible = true;
    this.entriesLoading.set(true);
    this.entriesRows.set([]);
    this.data
      .getFeatureEffortEntries(row.featureId, {
        dateFrom: this.dateFrom ? this.dateFrom.toISOString() : undefined,
        dateTo: this.dateTo ? this.dateTo.toISOString() : undefined
      })
      .subscribe((entries) => {
        this.entriesRows.set(entries);
        this.entriesLoading.set(false);
        this.cdr.markForCheck();
      });
  }

  closeEntries(): void {
    this.entriesDialogVisible = false;
  }

  exportCsv(): void {
    exportToCsv('feature-effort', this.rows());
  }

  exportPdf(): void {
    exportToPdf('feature-effort', 'Feature Effort', this.rows());
  }

  back(): void {
    this.location.back();
  }
}
