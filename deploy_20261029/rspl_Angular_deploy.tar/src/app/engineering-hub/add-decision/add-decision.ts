import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { DecisionForm, EngineeringHubDataService, LookupOption, StatusOption } from '../engineering-hub-data.service';
import { EngHubMenuRightsService } from '../menu-rights.service';
import { QuickAddDevItemDialog } from '../shared/quick-add-dev-item-dialog';
import { QuickAddFeatureDialog } from '../shared/quick-add-feature-dialog';
import { QuickAddModuleDialog } from '../shared/quick-add-module-dialog';
import { QuickCreated } from '../shared/quick-create';

/** Add/Edit Decision — the link target (Feature/Development Item/Task) is
 * chosen once via an interactive Product > Module > Feature[ > Dev Item[ >
 * Task]] cascade when adding fresh from the Decision Log, or arrives
 * pre-set (shown read-only) when navigated here from a detail page's "Log
 * Decision" button, or when editing an existing decision — re-linking an
 * existing decision isn't a PRD requirement, only its content fields are
 * editable then. */
@Component({
  selector: 'app-add-decision',
  imports: [
    FormsModule, ButtonModule, CheckboxModule, DatePickerModule, InputTextModule, SelectModule, TextareaModule,
    QuickAddModuleDialog, QuickAddFeatureDialog, QuickAddDevItemDialog
  ],
  templateUrl: './add-decision.html',
  styleUrl: './add-decision.scss'
})
export class AddDecision implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  // Inline "+" create buttons show only for menus this user has been granted.
  readonly menuRights = inject(EngHubMenuRightsService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly location = inject(Location);
  // No zone.js — plain properties mutated inside subscribe callbacks need an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly decisionTypes = signal<LookupOption[]>([]);
  readonly statuses = signal<StatusOption[]>([]);
  readonly users = signal<LookupOption[]>([]);
  readonly customers = signal<LookupOption[]>([]);
  readonly saving = signal(false);

  readonly riskLevels = ['Low', 'Medium', 'High'];

  // Interactive link picker — only shown when adding fresh with no
  // pre-supplied scope.
  readonly products = signal<LookupOption[]>([]);
  readonly modules = signal<LookupOption[]>([]);
  readonly features = signal<LookupOption[]>([]);
  readonly devItems = signal<LookupOption[]>([]);
  readonly tasksForLink = signal<LookupOption[]>([]);
  productId: number | null = null;
  moduleId: number | null = null;
  linkFeatureId: number | null = null;
  linkDevItemId: number | null = null;
  linkTaskId: number | null = null;
  linkLevel: 'Feature' | 'DevelopmentItem' | 'Task' = 'Feature';

  // Inline "+" create dialogs next to Module / Feature / Dev Item.
  moduleDialogVisible = false;
  featureDialogVisible = false;
  devItemDialogVisible = false;

  linkIsReadonly = false;
  linkLabel = '';

  approverIsExternal = false;
  reviewDate: Date | null = null;
  customerSearchLabel: LookupOption | null = null;

  form: DecisionForm = this.blankForm();

  private readonly customerFilter$ = new Subject<string>();

  private blankForm(): DecisionForm {
    return {
      decisionId: 0, featureId: null, devItemId: null, taskId: null, decisionTypeId: 0,
      description: '', approverUserId: null, approverExternalName: null, reason: '',
      riskLevel: 'Low', reviewDate: null, statusId: 0, customerId: null
    };
  }

  ngOnInit(): void {
    this.data.getUsers().subscribe((u) => this.users.set(u));
    this.data.getDecisionTypes().subscribe((t) => this.decisionTypes.set(t));
    this.data.getStatuses('Decision').subscribe((statuses) => {
      this.statuses.set(statuses);
      if (!this.form.statusId) {
        this.form.statusId = statuses[0]?.value ?? 0;
      }
      this.cdr.markForCheck();
    });
    this.customerFilter$
      .pipe(debounceTime(300), distinctUntilChanged(), switchMap((q) => this.data.getCustomers(q)))
      .subscribe((rows) => {
        this.customers.set(rows.map((r) => ({ label: r.displayName, value: r.custId })));
        this.cdr.markForCheck();
      });

    const id = Number(this.route.snapshot.queryParamMap.get('id') ?? 0);
    if (id) {
      this.data.getDecision(id).subscribe((d) => {
        this.form = {
          decisionId: d.decisionId, featureId: d.featureId, devItemId: d.devItemId, taskId: d.taskId,
          decisionTypeId: d.decisionTypeId, description: d.description, approverUserId: d.approverUserId,
          approverExternalName: d.approverExternalName, reason: d.reason, riskLevel: d.riskLevel,
          reviewDate: d.reviewDate, statusId: d.statusId, customerId: d.customerId
        };
        this.approverIsExternal = !!d.approverExternalName;
        this.reviewDate = d.reviewDate ? new Date(d.reviewDate) : null;
        this.linkIsReadonly = true;
        this.linkLabel = d.taskId ? `Task: ${d.taskTitle}` : d.devItemId ? `Development Item: ${d.devItemTitle}` : `Feature: ${d.featureName}`;
        if (d.customerId && d.customerName) {
          this.customers.set([{ label: d.customerName, value: d.customerId }]);
        }
        this.cdr.markForCheck();
      });
      return;
    }

    const prefillFeatureId = Number(this.route.snapshot.queryParamMap.get('featureId') ?? 0) || null;
    const prefillDevItemId = Number(this.route.snapshot.queryParamMap.get('devItemId') ?? 0) || null;
    const prefillTaskId = Number(this.route.snapshot.queryParamMap.get('taskId') ?? 0) || null;
    const prefillLabel = this.route.snapshot.queryParamMap.get('label');
    if (prefillFeatureId || prefillDevItemId || prefillTaskId) {
      this.form.featureId = prefillFeatureId;
      this.form.devItemId = prefillDevItemId;
      this.form.taskId = prefillTaskId;
      this.linkIsReadonly = true;
      this.linkLabel = prefillLabel ?? '';
      return;
    }

    // Fresh add from the Decision Log — interactive link cascade.
    this.data.getProducts().subscribe((products) => {
      this.products.set(products);
      this.cdr.markForCheck();
    });
  }

  onProductChange(): void {
    this.moduleId = null;
    this.linkFeatureId = null;
    this.modules.set([]);
    this.features.set([]);
    if (this.productId) {
      this.data.getModules(this.productId).subscribe((modules) => {
        this.modules.set(modules);
        this.cdr.markForCheck();
      });
    }
  }

  onModuleChange(): void {
    this.linkFeatureId = null;
    this.features.set([]);
    if (this.moduleId) {
      this.data.getFeaturesLookup(this.moduleId).subscribe((features) => {
        this.features.set(features);
        this.cdr.markForCheck();
      });
    }
  }

  onLinkFeatureChange(): void {
    this.linkDevItemId = null;
    this.devItems.set([]);
    if (this.linkFeatureId && this.linkLevel !== 'Feature') {
      this.data.getDevItemsLookup(this.linkFeatureId).subscribe((devItems) => {
        this.devItems.set(devItems);
        this.cdr.markForCheck();
      });
    }
  }

  onLinkDevItemChange(): void {
    this.linkTaskId = null;
    this.tasksForLink.set([]);
    if (this.linkDevItemId && this.linkLevel === 'Task') {
      this.data.getTasks(this.linkDevItemId).subscribe((tasks) => {
        this.tasksForLink.set(tasks.map((t) => ({ label: t.title, value: t.taskId })));
        this.cdr.markForCheck();
      });
    }
  }

  onLinkLevelChange(): void {
    if (this.linkLevel !== 'Feature' && this.linkFeatureId) {
      this.onLinkFeatureChange();
    }
    if (this.linkLevel === 'Task' && this.linkDevItemId) {
      this.onLinkDevItemChange();
    }
  }

  /** "+" next to Module / Feature / Dev Item: point the link cascade at
   * what was just created (parents may differ if changed in the dialog) and
   * select it. Levels below it are cleared; content fields are untouched. */
  onCreated(level: 'module' | 'feature' | 'devItem', c: QuickCreated): void {
    const withCreated = (opts: LookupOption[]) =>
      opts.some((o) => o.value === c.id) ? opts : [...opts, { label: c.label, value: c.id }];
    this.productId = c.productId;
    this.moduleId = c.moduleId;
    this.linkFeatureId = level === 'module' ? null : level === 'feature' ? c.id : (c.featureId ?? null);
    this.linkDevItemId = level === 'devItem' ? c.id : null;
    this.linkTaskId = null;
    this.tasksForLink.set([]);

    this.data.getModules(c.productId).subscribe((modules) => {
      this.modules.set(level === 'module' ? withCreated(modules) : modules);
      this.cdr.markForCheck();
    });
    this.data.getFeaturesLookup(c.moduleId).subscribe((features) => {
      this.features.set(level === 'feature' ? withCreated(features) : features);
      this.cdr.markForCheck();
    });
    this.devItems.set([]);
    if (this.linkFeatureId && this.linkLevel !== 'Feature') {
      this.data.getDevItemsLookup(this.linkFeatureId).subscribe((devItems) => {
        this.devItems.set(level === 'devItem' ? withCreated(devItems) : devItems);
        this.cdr.markForCheck();
      });
    }
    // A brand-new Dev Item has no Tasks yet, so the Task list stays empty.
    this.cdr.markForCheck();
  }

  onCustomerFilter(query: string): void {
    this.customerFilter$.next(query);
  }

  private validate(): boolean {
    if (!this.linkIsReadonly && !this.linkFeatureId) {
      alert('Please select a Feature to link this decision to.');
      return false;
    }
    if (!this.linkIsReadonly && this.linkLevel === 'DevelopmentItem' && !this.linkDevItemId) {
      alert('Please select a Development Item.');
      return false;
    }
    if (!this.linkIsReadonly && this.linkLevel === 'Task' && !this.linkTaskId) {
      alert('Please select a Task.');
      return false;
    }
    if (!this.form.decisionTypeId) {
      alert('Please select a decision type.');
      return false;
    }
    if (!this.form.description.trim()) {
      alert('Enter a description.');
      return false;
    }
    if (!this.form.reason.trim()) {
      alert('Enter a reason.');
      return false;
    }
    if (this.approverIsExternal && !this.form.approverExternalName?.trim()) {
      alert('Enter the external approver name.');
      return false;
    }
    if (!this.approverIsExternal && !this.form.approverUserId) {
      alert('Please select an approver, or check "External approver".');
      return false;
    }
    return true;
  }

  save(): void {
    if (!this.validate()) {
      return;
    }
    if (!this.linkIsReadonly) {
      // Only the most specific selected level is sent — the rollup query on
      // the backend infers ancestry via the Feature -> DevItem -> Task
      // hierarchy, so a Task-level decision doesn't need FeatureId/DevItemId
      // set too.
      this.form.featureId = this.linkLevel === 'Feature' ? this.linkFeatureId : null;
      this.form.devItemId = this.linkLevel === 'DevelopmentItem' ? this.linkDevItemId : null;
      this.form.taskId = this.linkLevel === 'Task' ? this.linkTaskId : null;
    }
    if (this.approverIsExternal) {
      this.form.approverUserId = null;
    } else {
      this.form.approverExternalName = null;
    }
    this.form.reviewDate = this.reviewDate ? this.reviewDate.toISOString().slice(0, 10) : null;

    this.saving.set(true);
    this.data.saveDecision(this.form).subscribe((res) => {
      this.saving.set(false);
      if (!res.success) {
        alert('Failed to save decision.');
        return;
      }
      this.router.navigate(['/engineering-hub/decisions']);
    });
  }

  close(): void {
    this.location.back();
  }
}
