import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { DecisionRow, EngineeringHubDataService, LookupOption, StatusOption } from '../engineering-hub-data.service';

/** Decision Log — top-level filterable list (type/status/customer). Each
 * row's link target (Feature/Development Item/Task) is shown as a single
 * column, whichever level it was attached at. */
@Component({
  selector: 'app-decisions',
  imports: [FormsModule, ButtonModule, SelectModule, TableModule],
  templateUrl: './decisions.html',
  styleUrl: './decisions.scss'
})
export class Decisions implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly location = inject(Location);
  // No zone.js — plain properties mutated inside subscribe callbacks need an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly decisionTypes = signal<LookupOption[]>([]);
  readonly statuses = signal<StatusOption[]>([]);
  readonly customers = signal<LookupOption[]>([]);
  readonly rows = signal<DecisionRow[]>([]);
  readonly loading = signal(false);

  decisionTypeId: number | null = null;
  statusId: number | null = null;
  customerId: number | null = null;

  private readonly customerFilter$ = new Subject<string>();

  ngOnInit(): void {
    this.data.getDecisionTypes().subscribe((t) => this.decisionTypes.set(t));
    this.data.getStatuses('Decision').subscribe((s) => this.statuses.set(s));
    this.customerFilter$
      .pipe(debounceTime(300), distinctUntilChanged(), switchMap((q) => this.data.getCustomers(q)))
      .subscribe((rows) => {
        this.customers.set(rows.map((r) => ({ label: r.displayName, value: r.custId })));
        this.cdr.markForCheck();
      });
    this.customerFilter$.next('');
    this.load();
  }

  onCustomerFilter(query: string): void {
    this.customerFilter$.next(query);
  }

  load(): void {
    this.loading.set(true);
    this.data
      .getDecisions({
        decisionTypeId: this.decisionTypeId ?? undefined,
        statusId: this.statusId ?? undefined,
        customerId: this.customerId ?? undefined
      })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      });
  }

  linkLabel(row: DecisionRow): string {
    if (row.taskId) {
      return `Task: ${row.taskTitle}`;
    }
    if (row.devItemId) {
      return `Dev Item: ${row.devItemTitle}`;
    }
    return `Feature: ${row.featureName}`;
  }

  back(): void {
    this.location.back();
  }

  addDecision(): void {
    this.router.navigate(['/engineering-hub/add-decision']);
  }

  editDecision(row: DecisionRow): void {
    this.router.navigate(['/engineering-hub/add-decision'], { queryParams: { id: row.decisionId } });
  }
}
