import { Location } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { map, of } from 'rxjs';

import {
  EngineeringHubDataService,
  ModuleCrudRow,
  ProductCrudRow,
  SimpleMasterCrudRow,
  StatusCrudRow
} from '../engineering-hub-data.service';
import { EngHubMasterCrud } from '../shared/eng-hub-master-crud';
import { MasterCrudConfig } from '../shared/master-crud.config';

/** Names referenced by exact string in backend code — renaming these via
 * this UI would silently break the feature/report that matches on them. */
const NAME_COUPLED_WARNINGS: Record<string, string> = {
  'activity-types':
    'The names "Work Logged", "Discussion", "Comment", "Interruption" and "Release Mapping" are matched by exact string in the backend (quick work-log, interruption capture, release mapping). Renaming or disabling one of these will silently break that feature.',
  'task-types': 'The name "Testing" is matched by exact string in the Testing Effort report. Renaming it will silently break that report.',
  'origin-types': 'The name "Support" is matched by exact string in the Support-Driven Work report. Renaming it will silently break that report.'
};

@Component({
  selector: 'app-masters',
  imports: [EngHubMasterCrud, ButtonModule],
  templateUrl: './masters.html',
  styleUrl: './masters.scss'
})
export class Masters {
  private readonly data = inject(EngineeringHubDataService);
  private readonly location = inject(Location);

  private simpleConfig(key: string, title: string, path: string): MasterCrudConfig {
    return {
      key,
      title,
      idField: 'id',
      fields: [
        { key: 'name', label: 'Name', type: 'text' },
        { key: 'enabled', label: 'Enabled', type: 'checkbox' }
      ],
      load: () => this.data.getSimpleMasterCrud(path),
      save: (row) => this.data.saveSimpleMasterCrud(path, row as unknown as SimpleMasterCrudRow),
      blankRow: () => ({ id: 0, name: '', enabled: true })
    };
  }

  readonly configs: MasterCrudConfig[] = [
    {
      key: 'products',
      title: 'Products',
      idField: 'productId',
      fields: [
        { key: 'name', label: 'Name', type: 'text' },
        { key: 'description', label: 'Description', type: 'textarea' },
        { key: 'enabled', label: 'Enabled', type: 'checkbox' }
      ],
      load: () => this.data.getProductsCrud(),
      save: (row) => this.data.saveProductCrud(row as unknown as ProductCrudRow),
      blankRow: () => ({ productId: 0, name: '', description: '', enabled: true })
    },
    {
      key: 'modules',
      title: 'Modules',
      idField: 'moduleId',
      parentLabel: 'Product',
      parentOptions: () => this.data.getProductsCrud().pipe(map((rows) => rows.map((r) => ({ label: r.name, value: r.productId })))),
      fields: [
        { key: 'name', label: 'Name', type: 'text' },
        { key: 'description', label: 'Description', type: 'textarea' },
        { key: 'enabled', label: 'Enabled', type: 'checkbox' }
      ],
      load: (productId) => this.data.getModulesCrud(Number(productId) || 0),
      save: (row) => this.data.saveModuleCrud(row as unknown as ModuleCrudRow),
      blankRow: (productId) => ({ moduleId: 0, productId: Number(productId) || 0, name: '', description: '', enabled: true })
    },
    this.simpleConfig('task-types', 'Task Types', 'task-types'),
    this.simpleConfig('dev-item-types', 'Development Item Types', 'dev-item-types'),
    this.simpleConfig('activity-types', 'Activity Types', 'activity-types'),
    this.simpleConfig('decision-types', 'Decision Types', 'decision-types'),
    this.simpleConfig('interruption-reasons', 'Interruption Reasons', 'interruption-reasons'),
    this.simpleConfig('priorities', 'Priorities', 'priorities'),
    this.simpleConfig('origin-types', 'Origin Types', 'origin-types'),
    {
      key: 'statuses',
      title: 'Statuses',
      idField: 'statusId',
      parentLabel: 'Entity Type',
      parentOptions: () =>
        of([
          { label: 'Feature', value: 'Feature' },
          { label: 'Development Item', value: 'DevelopmentItem' },
          { label: 'Task', value: 'Task' },
          { label: 'Decision', value: 'Decision' },
          { label: 'Release', value: 'Release' }
        ]),
      fields: [
        { key: 'name', label: 'Name', type: 'text' },
        { key: 'color', label: 'Color', type: 'color' },
        { key: 'sortOrder', label: 'Sort Order', type: 'number' },
        { key: 'isTerminal', label: 'Terminal', type: 'checkbox' },
        { key: 'enabled', label: 'Enabled', type: 'checkbox' }
      ],
      load: (entityType) => this.data.getStatusesCrud(String(entityType ?? '')),
      save: (row) => this.data.saveStatusCrud(row as unknown as StatusCrudRow),
      blankRow: (entityType) => ({
        statusId: 0,
        entityType: String(entityType ?? ''),
        name: '',
        color: null,
        sortOrder: 0,
        isTerminal: false,
        enabled: true
      })
    }
  ];

  readonly selectedKey = signal(this.configs[0].key);
  readonly selectedConfig = computed(() => this.configs.find((c) => c.key === this.selectedKey())!);
  readonly warning = computed(() => NAME_COUPLED_WARNINGS[this.selectedKey()] ?? null);

  select(key: string): void {
    this.selectedKey.set(key);
  }

  back(): void {
    this.location.back();
  }
}
