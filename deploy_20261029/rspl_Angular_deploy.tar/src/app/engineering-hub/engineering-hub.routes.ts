import { Routes } from '@angular/router';

import { portalAuthGuard } from '../core/auth/portal-auth.guard';
import { engHubHomeGuard, engHubMenuAdminGuard, engHubMenuGuard } from './menu-rights.guard';

export const engineeringHubRoutes: Routes = [
  {
    path: '',
    loadComponent: () => import('./layout/engineering-hub-layout').then((m) => m.EngineeringHubLayout),
    canActivate: [portalAuthGuard],
    children: [
      // Lands on the first menu this user has been granted.
      { path: '', pathMatch: 'full', canActivate: [engHubHomeGuard], children: [] },
      {
        path: 'menu-rights',
        canActivate: [engHubMenuAdminGuard],
        loadComponent: () => import('./menu-rights/menu-rights').then((m) => m.MenuRights)
      },
      {
        path: 'no-access',
        loadComponent: () => import('./no-access/no-access').then((m) => m.NoAccess)
      },
      {
        path: 'dashboard',
        canActivate: [engHubMenuGuard('DASHBOARD')],
        loadComponent: () => import('./dashboard/eng-hub-dashboard').then((m) => m.EngHubDashboard)
      },
      {
        path: 'features',
        canActivate: [engHubMenuGuard('FEATURES')],
        loadComponent: () => import('./features/features').then((m) => m.Features)
      },
      {
        path: 'add-feature',
        canActivate: [engHubMenuGuard('FEATURES')],
        loadComponent: () => import('./add-feature/add-feature').then((m) => m.AddFeature)
      },
      {
        path: 'feature-detail',
        canActivate: [engHubMenuGuard('FEATURES')],
        loadComponent: () => import('./feature-detail/feature-detail').then((m) => m.FeatureDetail)
      },
      {
        path: 'development-items',
        canActivate: [engHubMenuGuard('DEV_ITEMS')],
        loadComponent: () => import('./development-items/development-items').then((m) => m.DevelopmentItems)
      },
      {
        path: 'add-development-item',
        canActivate: [engHubMenuGuard('DEV_ITEMS')],
        loadComponent: () => import('./add-development-item/add-development-item').then((m) => m.AddDevelopmentItem)
      },
      {
        path: 'development-item-detail',
        canActivate: [engHubMenuGuard('DEV_ITEMS')],
        loadComponent: () => import('./development-item-detail/development-item-detail').then((m) => m.DevelopmentItemDetail)
      },
      {
        path: 'tasks',
        canActivate: [engHubMenuGuard('TASKS')],
        loadComponent: () => import('./tasks/tasks').then((m) => m.Tasks)
      },
      {
        path: 'add-task',
        canActivate: [engHubMenuGuard('TASKS')],
        loadComponent: () => import('./add-task/add-task').then((m) => m.AddTask)
      },
      {
        path: 'activities',
        canActivate: [engHubMenuGuard('ACTIVITIES')],
        loadComponent: () => import('./activities/activities').then((m) => m.Activities)
      },
      {
        path: 'decisions',
        canActivate: [engHubMenuGuard('DECISIONS')],
        loadComponent: () => import('./decisions/decisions').then((m) => m.Decisions)
      },
      {
        path: 'add-decision',
        canActivate: [engHubMenuGuard('DECISIONS')],
        loadComponent: () => import('./add-decision/add-decision').then((m) => m.AddDecision)
      },
      {
        path: 'releases',
        canActivate: [engHubMenuGuard('RELEASES')],
        loadComponent: () => import('./releases/releases').then((m) => m.Releases)
      },
      {
        path: 'add-release',
        canActivate: [engHubMenuGuard('RELEASES')],
        loadComponent: () => import('./add-release/add-release').then((m) => m.AddRelease)
      },
      {
        path: 'release-detail',
        canActivate: [engHubMenuGuard('RELEASES')],
        loadComponent: () => import('./release-detail/release-detail').then((m) => m.ReleaseDetail)
      },
      {
        path: 'reports',
        canActivate: [engHubMenuGuard('REPORTS')],
        loadComponent: () => import('./reports/reports').then((m) => m.Reports)
      },
      {
        path: 'reports/engineering-effort',
        canActivate: [engHubMenuGuard('REPORTS')],
        loadComponent: () => import('./report-engineering-effort/report-engineering-effort').then((m) => m.ReportEngineeringEffort)
      },
      {
        path: 'reports/module-effort',
        canActivate: [engHubMenuGuard('REPORTS')],
        loadComponent: () => import('./report-module-effort/report-module-effort').then((m) => m.ReportModuleEffort)
      },
      {
        path: 'reports/feature-effort',
        canActivate: [engHubMenuGuard('REPORTS')],
        loadComponent: () => import('./report-feature-effort/report-feature-effort').then((m) => m.ReportFeatureEffort)
      },
      {
        path: 'reports/interruptions',
        canActivate: [engHubMenuGuard('REPORTS')],
        loadComponent: () => import('./report-interruptions/report-interruptions').then((m) => m.ReportInterruptions)
      },
      {
        path: 'reports/testing-effort',
        canActivate: [engHubMenuGuard('REPORTS')],
        loadComponent: () => import('./report-testing-effort/report-testing-effort').then((m) => m.ReportTestingEffort)
      },
      {
        path: 'reports/pending-ageing',
        canActivate: [engHubMenuGuard('REPORTS')],
        loadComponent: () => import('./report-pending-ageing/report-pending-ageing').then((m) => m.ReportPendingAgeing)
      },
      {
        path: 'reports/release-progress',
        canActivate: [engHubMenuGuard('REPORTS')],
        loadComponent: () => import('./report-release-progress/report-release-progress').then((m) => m.ReportReleaseProgress)
      },
      {
        path: 'reports/support-driven-work',
        canActivate: [engHubMenuGuard('REPORTS')],
        loadComponent: () =>
          import('./report-support-driven-work/report-support-driven-work').then((m) => m.ReportSupportDrivenWork)
      },
      {
        path: 'masters',
        canActivate: [engHubMenuGuard('MASTERS')],
        loadComponent: () => import('./masters/masters').then((m) => m.Masters)
      }
    ]
  }
];
