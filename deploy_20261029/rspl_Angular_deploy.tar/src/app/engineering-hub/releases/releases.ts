import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { EngineeringHubDataService, LookupOption, ReleaseRow, StatusOption } from '../engineering-hub-data.service';

/** Releases list — Product/Status filter, Add routes to the add-release
 * form, row click routes to the release detail (mapped items + release
 * notes). */
@Component({
  selector: 'app-releases',
  imports: [FormsModule, ButtonModule, SelectModule, TableModule],
  templateUrl: './releases.html',
  styleUrl: './releases.scss'
})
export class Releases implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly location = inject(Location);
  // No zone.js — plain properties mutated inside subscribe callbacks need an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly products = signal<LookupOption[]>([]);
  readonly statuses = signal<StatusOption[]>([]);
  readonly rows = signal<ReleaseRow[]>([]);
  readonly loading = signal(false);

  productId: number | null = null;
  statusId: number | null = null;

  ngOnInit(): void {
    this.data.getProducts().subscribe((products) => {
      this.products.set(products);
      this.cdr.markForCheck();
    });
    this.data.getStatuses('Release').subscribe((s) => this.statuses.set(s));
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.data.getReleases({ productId: this.productId ?? undefined, statusId: this.statusId ?? undefined }).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }

  back(): void {
    this.location.back();
  }

  addRelease(): void {
    this.router.navigate(['/engineering-hub/add-release']);
  }

  viewRelease(row: ReleaseRow): void {
    this.router.navigate(['/engineering-hub/release-detail'], { queryParams: { id: row.releaseId } });
  }
}
