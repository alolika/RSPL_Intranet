import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';
import { Subject, forkJoin, of } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { PortalAuthService } from '../../core/auth/portal-auth.service';
import { QuickAddDevItemDialog } from '../shared/quick-add-dev-item-dialog';
import { QuickAddFeatureDialog } from '../shared/quick-add-feature-dialog';
import { QuickAddModuleDialog } from '../shared/quick-add-module-dialog';
import { EngineeringHubDataService, LookupOption, StatusOption, TaskForm } from '../engineering-hub-data.service';
import { EngHubMenuRightsService } from '../menu-rights.service';
import { QuickCreated } from '../shared/quick-create';

/** Add/Edit Task — Product > Module > Feature > Development Item cascade.
 * Trouble Ticket is a single-value field (a Task links to at most one
 * ticket, not a list), same model/UI as the Feature form's Trouble Ticket
 * field — search TTMaster, pick one, commit via one PUT in save() right
 * after the Task itself saves (a brand-new Task has no id yet to link
 * against until then). */
@Component({
  selector: 'app-add-task',
  imports: [
    FormsModule, ButtonModule, DatePickerModule, InputNumberModule, InputTextModule, SelectModule, TextareaModule,
    QuickAddModuleDialog, QuickAddFeatureDialog, QuickAddDevItemDialog
  ],
  templateUrl: './add-task.html',
  styleUrl: './add-task.scss'
})
export class AddTask implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  // Inline "+" create buttons show only for menus this user has been granted.
  readonly menuRights = inject(EngHubMenuRightsService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly location = inject(Location);
  private readonly auth = inject(PortalAuthService);
  // No zone.js — plain properties mutated inside subscribe callbacks need an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  /** Optional Expected Deadline, bound to the date picker. Sent to the API
   * as a plain "YYYY-MM-DD" (see toDateOnlyString) — never toISOString(),
   * which converts through UTC and lands an IST-picked date on the previous
   * day. */
  expectedDeadlineDate: Date | null = null;

  private toDateOnlyString(d: Date | null): string | null {
    if (!d) {
      return null;
    }
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${d.getFullYear()}-${mm}-${dd}`;
  }

  private fromDateOnlyString(s: string | null): Date | null {
    if (!s) {
      return null;
    }
    const [y, m, d] = s.slice(0, 10).split('-').map(Number);
    return new Date(y, m - 1, d);
  }

  readonly products = signal<LookupOption[]>([]);
  readonly modules = signal<LookupOption[]>([]);
  readonly features = signal<LookupOption[]>([]);
  readonly devItems = signal<LookupOption[]>([]);
  readonly taskTypes = signal<LookupOption[]>([]);
  readonly priorities = signal<LookupOption[]>([]);
  readonly statuses = signal<StatusOption[]>([]);
  readonly saving = signal(false);

  // "Assigned To" = the Task's Developer (EngHub_AssignmentHistory
  // RoleType='Developer'). Defaults to the logged-in user on Add; on Edit it
  // shows the current Developer. Applied via assignTaskRole() after the Task
  // itself saves — only when it actually changed, so re-saving an unchanged
  // task doesn't churn a new history row. Optional: the "Unassigned" option
  // (value NA_USER_ID) — or the dropdown's ✕ clear button, which resets to
  // it — means no Developer; picking it on Edit unassigns the current one.
  readonly NA_USER_ID = 0;
  readonly users = signal<LookupOption[]>([]);
  assignedToUserId: number | null = null;
  private originalAssignedToUserId: number | null = null;

  readonly ticketOptions = signal<LookupOption[]>([]);
  selectedTicketVoucherNo: number | null = null;
  private readonly ticketFilter$ = new Subject<string>();

  productId: number | null = null;
  moduleId: number | null = null;
  featureId: number | null = null;
  form: TaskForm = this.blankForm();

  // Inline "+" create dialogs next to Module / Feature / Dev Item.
  moduleDialogVisible = false;
  featureDialogVisible = false;
  devItemDialogVisible = false;

  private blankForm(): TaskForm {
    return { taskId: 0, devItemId: 0, taskTypeId: 0, title: '', description: '', statusId: 0, priorityId: null, estimatedHours: null, expectedDeadline: null };
  }

  ngOnInit(): void {
    // Optional prefill when navigated here from a Development Item detail
    // page's "Add Task" button, which already knows the full Product >
    // Module > Feature > Dev Item chain.
    const prefillProductId = Number(this.route.snapshot.queryParamMap.get('productId') ?? 0) || null;
    const prefillModuleId = Number(this.route.snapshot.queryParamMap.get('moduleId') ?? 0) || null;
    const prefillFeatureId = Number(this.route.snapshot.queryParamMap.get('featureId') ?? 0) || null;
    const prefillDevItemId = Number(this.route.snapshot.queryParamMap.get('devItemId') ?? 0) || null;

    this.data.getProducts().subscribe((products) => {
      this.products.set(products);
      if (prefillProductId) {
        this.productId = prefillProductId;
        this.onProductChange();
        if (prefillModuleId) {
          this.moduleId = prefillModuleId;
          this.onModuleChange();
          if (prefillFeatureId) {
            this.featureId = prefillFeatureId;
            this.onFeatureChange();
            if (prefillDevItemId) {
              this.form.devItemId = prefillDevItemId;
            }
          }
        }
      }
      this.cdr.markForCheck();
    });
    this.data.getTaskTypes().subscribe((t) => this.taskTypes.set(t));
    this.data.getPriorities().subscribe((p) => { this.priorities.set([{ label: 'None', value: 0 }, ...p]); this.cdr.markForCheck(); });
    const me = this.auth.currentUser();
    this.data.getUsers().subscribe((users) => {
      // Guarantee the logged-in user has an option to render against even if
      // the users lookup somehow omits them.
      const withMe = me && !users.some((u) => u.value === me.userId) ? [{ label: me.userName, value: me.userId }, ...users] : users;
      this.users.update((prev) => {
        // Keep an Edit-mode current Developer option that may have landed first.
        const extra = prev.filter((p) => p.value !== this.NA_USER_ID && !withMe.some((u) => u.value === p.value));
        return [{ label: 'Unassigned', value: this.NA_USER_ID }, ...extra, ...withMe];
      });
      this.cdr.markForCheck();
    });
    this.data.getStatuses('Task').subscribe((statuses) => {
      this.statuses.set(statuses);
      if (!this.form.statusId) {
        this.form.statusId = statuses[0]?.value ?? 0;
      }
      this.cdr.markForCheck();
    });

    this.ticketFilter$
      .pipe(debounceTime(300), distinctUntilChanged(), switchMap((q) => this.data.getTickets(q)))
      .subscribe((rows) => {
        this.ticketOptions.set(rows.map((r) => ({ label: this.ticketLabel(r.voucherNo, r.customerName, r.date), value: r.voucherNo })));
        this.cdr.markForCheck();
      });
    this.ticketFilter$.next('');

    const id = Number(this.route.snapshot.queryParamMap.get('id') ?? 0);
    if (!id) {
      this.assignedToUserId = me?.userId ?? null;
    }
    if (id) {
      this.data.getTask(id).subscribe((task) => {
        // Edit mode: prefill the Product > Module > Feature cascade from the
        // saved task itself (there's no productId/moduleId/featureId query
        // param here, unlike the "Add Task" prefill above) — previously this
        // was skipped entirely, so Product/Module/Feature showed blank on
        // Edit and, worse, touching any of those dropdowns would silently
        // reset form.devItemId to 0 via onProductChange()/onModuleChange()/
        // onFeatureChange()'s own reset logic before the user had picked a
        // real replacement. Reusing those same methods here (for their
        // "fetch the dependent lookup list" side effect) is safe because the
        // full this.form reassignment below runs right after, in the same
        // synchronous callback, overwriting whatever devItemId they reset to
        // 0 with the task's real value. Dev Item itself still gets its own
        // single-option prefill (below) since getDevItemsLookup(featureId)
        // wouldn't otherwise include a Dev Item outside that Feature's
        // current lookup ordering/paging.
        this.productId = task.productId;
        this.onProductChange();
        this.moduleId = task.moduleId;
        this.onModuleChange();
        this.featureId = task.featureId;
        this.onFeatureChange();
        this.form = {
          taskId: task.taskId, devItemId: task.devItemId, taskTypeId: task.taskTypeId,
          title: task.title, description: task.description, statusId: task.statusId,
          priorityId: task.priorityId,
          estimatedHours: task.estimatedHours,
          expectedDeadline: task.expectedDeadline
        };
        this.expectedDeadlineDate = this.fromDateOnlyString(task.expectedDeadline);
        this.devItems.set([{ label: task.devItemTitle, value: task.devItemId }]);
        this.assignedToUserId = task.developerUserId ?? this.NA_USER_ID;
        this.originalAssignedToUserId = task.developerUserId;
        if (task.developerUserId && task.developerName) {
          const dev: LookupOption = { label: task.developerName, value: task.developerUserId };
          this.users.update((opts) => (opts.some((o) => o.value === dev.value) ? opts : [dev, ...opts]));
        }
        this.cdr.markForCheck();
      });
      this.data.getTaskTicket(id).subscribe((ticket) => {
        if (!ticket) {
          return;
        }
        this.selectedTicketVoucherNo = ticket.ticketVoucherNo;
        const label = this.ticketLabel(ticket.ticketVoucherNo, ticket.ticketCustomerName, ticket.ticketDate);
        // Ensure the already-linked ticket has an option to render against —
        // it may not be among the initial unfiltered search results above.
        this.ticketOptions.update((opts) =>
          opts.some((o) => o.value === ticket.ticketVoucherNo) ? opts : [{ label, value: ticket.ticketVoucherNo }, ...opts]
        );
        this.cdr.markForCheck();
      });
    }
  }

  onTicketFilter(query: string): void {
    this.ticketFilter$.next(query);
  }

  // "#VoucherNo — Customer Name (dd-MM-yy)" — same format used by the
  // Feature form's Trouble Ticket field.
  private ticketLabel(voucherNo: number, customerName: string | null, date: string | null): string {
    let label = `#${voucherNo}`;
    if (customerName) {
      label += ` — ${customerName}`;
    }
    if (date) {
      label += ` (${date.slice(0, 10)})`;
    }
    return label;
  }

  onProductChange(): void {
    this.moduleId = null;
    this.featureId = null;
    this.form.devItemId = 0;
    this.modules.set([]);
    this.features.set([]);
    this.devItems.set([]);
    if (this.productId) {
      this.data.getModules(this.productId).subscribe((modules) => {
        this.modules.set(modules);
        this.cdr.markForCheck();
      });
    }
  }

  onModuleChange(): void {
    this.featureId = null;
    this.form.devItemId = 0;
    this.features.set([]);
    this.devItems.set([]);
    if (this.moduleId) {
      this.data.getFeaturesLookup(this.moduleId).subscribe((features) => {
        this.features.set(features);
        this.cdr.markForCheck();
      });
    }
  }

  onFeatureChange(): void {
    this.form.devItemId = 0;
    this.devItems.set([]);
    if (this.featureId) {
      this.data.getDevItemsLookup(this.featureId).subscribe((devItems) => {
        this.devItems.set(devItems);
        this.cdr.markForCheck();
      });
    }
  }

  private validate(): boolean {
    if (!this.form.devItemId) {
      alert('Please select a development item.');
      return false;
    }
    if (!this.form.taskTypeId) {
      alert('Please select a task type.');
      return false;
    }
    if (!this.form.title.trim()) {
      alert('Enter a title.');
      return false;
    }
    if (!this.form.statusId) {
      alert('Please select a status.');
      return false;
    }
    return true;
  }

  save(): void {
    if (!this.validate()) {
      return;
    }
    this.saving.set(true);
    this.form.expectedDeadline = this.toDateOnlyString(this.expectedDeadlineDate);
    this.data.saveTask(this.form).subscribe({
      next: (res) => {
        if (!res.success) {
          this.saving.set(false);
          alert('Failed to save task.');
          return;
        }
        // Only now does a real TaskId exist (for a brand-new Task) to link
        // the selected ticket against.
        const assignedTo = this.assignedToUserId || null; // Unassigned / blank -> no Developer
        const assign$ =
          assignedTo !== this.originalAssignedToUserId
            ? this.data.assignTaskRole(res.taskId, 'Developer', assignedTo)
            : of(null);
        forkJoin([this.data.setTaskTicket(res.taskId, this.selectedTicketVoucherNo), assign$]).subscribe({
          next: () => {
            this.saving.set(false);
            this.router.navigate(['/engineering-hub/tasks']);
          },
          error: () => {
            this.saving.set(false);
            alert('Task saved, but linking the ticket / assigning the developer failed.');
          }
        });
      },
      // Covers a stale/bookmarked edit URL reached outside the All Tasks
      // grid's own disabled-button gating — save_task() 403s server-side for
      // anyone who isn't the task's current assigned Developer.
      error: (err) => {
        this.saving.set(false);
        alert(err.error?.detail ?? 'Only the assigned developer can edit this task.');
      }
    });
  }

  close(): void {
    this.location.back();
  }

  // ---- Inline "+" create ----

  /** Points the Product > Module > Feature > Dev Item cascade at the item
   * just created in a "+" dialog (its parents may differ from what was
   * selected, since the dialog lets the user change them) and selects it.
   * Levels below the created one are cleared; every other Task field
   * (title, description, type, status, hours, ticket) is left untouched. */
  selectCreated(level: 'module' | 'feature' | 'devItem', c: QuickCreated): void {
    const created: LookupOption = { label: c.label, value: c.id };
    // Lookup endpoints only return enabled rows — guarantee the created
    // option is present so the selection always renders.
    const withCreated = (opts: LookupOption[]) => (opts.some((o) => o.value === c.id) ? opts : [...opts, created]);

    this.productId = c.productId;
    this.moduleId = c.moduleId;
    this.featureId = level === 'module' ? null : level === 'feature' ? c.id : (c.featureId ?? null);
    this.form.devItemId = level === 'devItem' ? c.id : 0;

    this.data.getModules(c.productId).subscribe((modules) => {
      this.modules.set(level === 'module' ? withCreated(modules) : modules);
      this.cdr.markForCheck();
    });
    this.data.getFeaturesLookup(c.moduleId).subscribe((features) => {
      this.features.set(level === 'feature' ? withCreated(features) : features);
      this.cdr.markForCheck();
    });
    this.devItems.set([]);
    if (this.featureId) {
      this.data.getDevItemsLookup(this.featureId).subscribe((devItems) => {
        this.devItems.set(level === 'devItem' ? withCreated(devItems) : devItems);
        this.cdr.markForCheck();
      });
    }
    this.cdr.markForCheck();
  }
}
