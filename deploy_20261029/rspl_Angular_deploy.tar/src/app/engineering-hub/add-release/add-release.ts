import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';

import { EngineeringHubDataService, LookupOption, ReleaseForm, StatusOption } from '../engineering-hub-data.service';

/** Add/Edit Release. */
@Component({
  selector: 'app-add-release',
  imports: [FormsModule, ButtonModule, DatePickerModule, InputTextModule, SelectModule, TextareaModule],
  templateUrl: './add-release.html',
  styleUrl: './add-release.scss'
})
export class AddRelease implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly location = inject(Location);
  // No zone.js — plain properties mutated inside subscribe callbacks need an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly products = signal<LookupOption[]>([]);
  readonly statuses = signal<StatusOption[]>([]);
  readonly saving = signal(false);

  releaseDate: Date | null = null;
  form: ReleaseForm = this.blankForm();

  private blankForm(): ReleaseForm {
    return { releaseId: 0, name: '', releaseDate: null, description: '', productId: null, statusId: 0 };
  }

  ngOnInit(): void {
    this.data.getProducts().subscribe((p) => this.products.set(p));
    this.data.getStatuses('Release').subscribe((statuses) => {
      this.statuses.set(statuses);
      if (!this.form.statusId) {
        this.form.statusId = statuses[0]?.value ?? 0;
      }
      this.cdr.markForCheck();
    });

    const id = Number(this.route.snapshot.queryParamMap.get('id') ?? 0);
    if (id) {
      this.data.getRelease(id).subscribe((r) => {
        this.form = {
          releaseId: r.releaseId, name: r.name, releaseDate: r.releaseDate,
          description: r.description, productId: r.productId, statusId: r.statusId
        };
        this.releaseDate = r.releaseDate ? new Date(r.releaseDate) : null;
        this.cdr.markForCheck();
      });
    }
  }

  private validate(): boolean {
    if (!this.form.name.trim()) {
      alert('Enter a release name.');
      return false;
    }
    if (!this.form.statusId) {
      alert('Please select a status.');
      return false;
    }
    return true;
  }

  save(): void {
    if (!this.validate()) {
      return;
    }
    this.form.releaseDate = this.releaseDate ? this.releaseDate.toISOString().slice(0, 10) : null;
    this.saving.set(true);
    this.data.saveRelease(this.form).subscribe((res) => {
      this.saving.set(false);
      if (!res.success) {
        alert('Failed to save release.');
        return;
      }
      this.router.navigate(['/engineering-hub/releases']);
    });
  }

  close(): void {
    this.location.back();
  }
}
