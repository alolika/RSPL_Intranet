import { HttpClient } from '@angular/common/http';
import { Injectable, computed, effect, inject, signal } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Observable, catchError, filter, map, of, tap } from 'rxjs';

import { PortalAuthService } from '../core/auth/portal-auth.service';
import { API_BASE_URL } from '../shared/api-config';

// Must match MENU_LABELS keys in rspl_Api app/routers/enghub_menu_rights.py.
export type EngHubMenuCode =
  | 'DASHBOARD'
  | 'FEATURES'
  | 'DEV_ITEMS'
  | 'TASKS'
  | 'ACTIVITIES'
  | 'DECISIONS'
  | 'RELEASES'
  | 'REPORTS'
  | 'MASTERS'
  // Not a menu: lets the user pick any developer on the Dashboard.
  | 'DASHBOARD_ALL_USERS';

export interface MyEngHubMenus {
  isAdmin: boolean;
  menus: EngHubMenuCode[];
}

export interface EngHubMenuOption {
  code: EngHubMenuCode;
  label: string;
}

export interface EngHubUserMenus {
  userId: number;
  name: string;
  // "238 - Parthamesh Gaikwad" — same reasoning as UserRightsService's
  // displayLabel: near-identical names need the UserID to tell apart.
  displayLabel: string;
  menus: EngHubMenuCode[];
}

interface ApiMyMenus {
  is_admin: boolean;
  menus: EngHubMenuCode[];
}

interface ApiUserMenus {
  user_id: number;
  name: string;
  menus: EngHubMenuCode[];
}

/**
 * Engineering Hub per-user menu rights. Unlike the portal-wide
 * UserRightsService (no row = full access), here a user sees ONLY the menus
 * an admin has granted — so until /me has loaded, `menus` is empty and
 * nothing is shown (no flash of menus the user doesn't have).
 *
 * The cached signal only drives what the sidebar/links show; the route
 * guards below always fetch fresh via fetchMine() at navigation time, so a
 * right removed while the user's session is open takes effect on their next
 * navigation.
 */
@Injectable({ providedIn: 'root' })
export class EngHubMenuRightsService {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(PortalAuthService);
  private readonly router = inject(Router);

  private readonly state = signal<MyEngHubMenus | null>(null);

  /** Raw state, null until /me has loaded. */
  readonly mine = this.state.asReadonly();
  readonly loaded = computed(() => this.state() !== null);
  readonly isAdmin = computed(() => this.state()?.isAdmin ?? false);
  readonly menus = computed(() => new Set<EngHubMenuCode>(this.state()?.menus ?? []));

  constructor() {
    effect(() => {
      if (this.auth.isLoggedIn()) {
        this.fetchMine().subscribe();
      } else {
        this.state.set(null);
      }
    });
    // Keep the sidebar in step with rights changed while this session is
    // open. Only inside Engineering Hub — the rest of the portal doesn't
    // need this call on every navigation.
    this.router.events
      .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd && e.urlAfterRedirects.startsWith('/engineering-hub')))
      .subscribe(() => {
        if (this.auth.isLoggedIn()) {
          this.fetchMine().subscribe();
        }
      });
  }

  has(code: EngHubMenuCode): boolean {
    return this.menus().has(code);
  }

  /** Always hits the server, updating the cache. On a failed call falls back
   * to whatever is cached (nothing, if never loaded — i.e. deny). */
  fetchMine(): Observable<MyEngHubMenus> {
    return this.http.get<ApiMyMenus>(`${API_BASE_URL}/engineering-hub/menu-rights/me`).pipe(
      map((r) => ({ isAdmin: r.is_admin, menus: r.menus })),
      tap((s) => this.state.set(s)),
      catchError(() => of(this.state() ?? { isAdmin: false, menus: [] }))
    );
  }

  // ---------- admin only (backend 403s anyone not allow-listed) ----------

  getAdminMenus(): Observable<EngHubMenuOption[]> {
    return this.http.get<EngHubMenuOption[]>(`${API_BASE_URL}/engineering-hub/menu-rights/admin/menus`);
  }

  getAdminUsers(): Observable<EngHubUserMenus[]> {
    return this.http
      .get<ApiUserMenus[]>(`${API_BASE_URL}/engineering-hub/menu-rights/admin/users`)
      .pipe(map((rows) => rows.map((r) => ({ userId: r.user_id, name: r.name, displayLabel: `${r.user_id} - ${r.name}`, menus: r.menus }))));
  }

  setUserMenus(userId: number, menus: EngHubMenuCode[]): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${API_BASE_URL}/engineering-hub/menu-rights/admin/${userId}`, { menus });
  }
}
