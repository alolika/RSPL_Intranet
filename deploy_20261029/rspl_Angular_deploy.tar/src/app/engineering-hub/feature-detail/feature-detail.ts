import { DatePipe, Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, ViewChild, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelect, MultiSelectModule } from 'primeng/multiselect';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { EngHubAttachments } from '../shared/eng-hub-attachments';
import { EngHubTimeline } from '../shared/eng-hub-timeline';
import {
  AssignmentHistoryRow,
  DecisionRow,
  DevItemRow,
  EngineeringHubDataService,
  FeatureRow,
  LookupOption,
  ReleaseRow,
  TimelineEntry,
  mergeTimelineEntries
} from '../engineering-hub-data.service';

/** Feature detail — Product > Module breadcrumb, current owners with an
 * Assign action (writes to EngHub_AssignmentHistory), Development Items
 * sub-grid, rolled-up Timeline (this Feature + every Dev Item and Task
 * beneath it), and the full Assignment History trail. */
@Component({
  selector: 'app-feature-detail',
  imports: [
    FormsModule,
    ButtonModule,
    DialogModule,
    InputTextModule,
    MultiSelectModule,
    SelectModule,
    TableModule,
    TextareaModule,
    EngHubTimeline,
    EngHubAttachments,
    DatePipe
  ],
  templateUrl: './feature-detail.html',
  styleUrl: './feature-detail.scss'
})
export class FeatureDetail implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly location = inject(Location);
  // No zone.js — plain properties mutated inside subscribe callbacks need an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly feature = signal<FeatureRow | null>(null);
  readonly devItems = signal<DevItemRow[]>([]);
  readonly decisions = signal<DecisionRow[]>([]);
  readonly timelineEntries = signal<TimelineEntry[]>([]);
  readonly assignmentHistory = signal<AssignmentHistoryRow[]>([]);
  readonly users = signal<LookupOption[]>([]);
  readonly mappedReleases = signal<ReleaseRow[]>([]);
  readonly availableReleases = signal<ReleaseRow[]>([]);

  private featureId = 0;

  assignDialogVisible = false;
  assignRoleType: 'FeatureOwner' | 'TechnicalOwner' = 'FeatureOwner';
  assignUserId: number | null = null;

  discussionDialogVisible = false;
  discussionDescription = '';
  discussionMinutes: number | null = null;
  discussionParticipantIds: number[] = [];
  @ViewChild('participantsMs') participantsMs?: MultiSelect;

  onParticipantSelect(): void {
    if (this.participantsMs) {
      this.participantsMs.filterValue = '';
    }
  }

  mapDialogVisible = false;
  mapReleaseId: number | null = null;

  ngOnInit(): void {
    this.featureId = Number(this.route.snapshot.queryParamMap.get('id') ?? 0);
    this.data.getUsers().subscribe((users) => this.users.set(users));
    this.load();
  }

  private load(): void {
    this.data.getFeature(this.featureId).subscribe((feature) => {
      this.feature.set(feature);
      this.cdr.markForCheck();
    });
    this.data.getDevelopmentItems(this.featureId, undefined, true).subscribe((rows) => this.devItems.set(rows));
    this.data.getFeatureAssignmentHistory(this.featureId).subscribe((rows) => this.assignmentHistory.set(rows));
    this.data.getReleasesForEntity({ featureId: this.featureId }).subscribe((rows) => this.mappedReleases.set(rows));
    this.loadTimeline();
  }

  private loadTimeline(): void {
    this.data.getActivities({ featureId: this.featureId }).subscribe((activities) => {
      this.data.getDecisions({ featureId: this.featureId }).subscribe((decisions) => {
        this.decisions.set(decisions);
        this.timelineEntries.set(mergeTimelineEntries(activities, decisions));
        this.cdr.markForCheck();
      });
    });
  }

  addDevelopmentItem(): void {
    const f = this.feature();
    if (!f) {
      return;
    }
    this.router.navigate(['/engineering-hub/add-development-item'], {
      queryParams: { productId: f.productId, moduleId: f.moduleId, featureId: f.featureId }
    });
  }

  editDevelopmentItem(row: DevItemRow): void {
    this.router.navigate(['/engineering-hub/add-development-item'], { queryParams: { id: row.devItemId } });
  }

  viewDevelopmentItem(row: DevItemRow): void {
    this.router.navigate(['/engineering-hub/development-item-detail'], { queryParams: { id: row.devItemId } });
  }

  /** Breadcrumb's "Product Name" — lands on the Features grid pre-filtered
   * to every Feature under this Product (all Modules), not yet narrowed to
   * a specific Module. */
  goToProduct(productId: number): void {
    this.router.navigate(['/engineering-hub/features'], { queryParams: { productId } });
  }

  editFeature(): void {
    this.router.navigate(['/engineering-hub/add-feature'], { queryParams: { id: this.featureId } });
  }

  logDecision(): void {
    const f = this.feature();
    if (!f) {
      return;
    }
    this.router.navigate(['/engineering-hub/add-decision'], { queryParams: { featureId: f.featureId, label: `Feature: ${f.name}` } });
  }

  editDecision(row: DecisionRow): void {
    this.router.navigate(['/engineering-hub/add-decision'], { queryParams: { id: row.decisionId } });
  }

  back(): void {
    this.location.back();
  }

  openMapDialog(): void {
    const f = this.feature();
    this.mapReleaseId = null;
    this.data.getReleases(f?.productId ? { productId: f.productId } : {}).subscribe((rows) => {
      this.availableReleases.set(rows);
      this.cdr.markForCheck();
    });
    this.mapDialogVisible = true;
  }

  saveMap(): void {
    if (!this.mapReleaseId) {
      alert('Please select a release.');
      return;
    }
    this.data.mapToRelease(this.mapReleaseId, { featureId: this.featureId }).subscribe(() => {
      this.mapDialogVisible = false;
      this.load();
    });
  }

  openAssign(roleType: 'FeatureOwner' | 'TechnicalOwner'): void {
    const f = this.feature();
    this.assignRoleType = roleType;
    this.assignUserId = roleType === 'FeatureOwner' ? (f?.featureOwnerUserId ?? null) : (f?.technicalOwnerUserId ?? null);
    this.assignDialogVisible = true;
  }

  saveAssign(): void {
    if (!this.assignUserId) {
      alert('Please select a user.');
      return;
    }
    this.data.assignFeatureRole(this.featureId, this.assignRoleType, this.assignUserId).subscribe(() => {
      this.assignDialogVisible = false;
      this.load();
    });
  }

  openDiscussion(): void {
    this.discussionDescription = '';
    this.discussionMinutes = null;
    this.discussionParticipantIds = [];
    this.discussionDialogVisible = true;
  }

  saveDiscussion(): void {
    if (!this.discussionDescription.trim()) {
      alert('Enter a description.');
      return;
    }
    this.data
      .logDiscussion({ featureId: this.featureId }, this.discussionDescription, this.discussionMinutes, this.discussionParticipantIds)
      .subscribe(() => {
        this.discussionDialogVisible = false;
        this.load();
      });
  }
}
