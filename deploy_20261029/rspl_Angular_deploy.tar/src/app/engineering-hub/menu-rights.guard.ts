import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { map } from 'rxjs';

import { buildEngineeringHubNav } from './layout/engineering-hub-nav';
import { EngHubMenuCode, EngHubMenuRightsService } from './menu-rights.service';

/** Blocks an Engineering Hub page unless the user has been granted the menu
 * it belongs to — typing the URL directly or following a link from another
 * page doesn't get around the hidden menu. Denied → the No Access page. */
export function engHubMenuGuard(code: EngHubMenuCode): CanActivateFn {
  return () => {
    const rights = inject(EngHubMenuRightsService);
    const router = inject(Router);
    return rights
      .fetchMine()
      .pipe(map((s) => (s.menus.includes(code) ? true : router.createUrlTree(['/engineering-hub/no-access'], { queryParams: { menu: code } }))));
  };
}

/** Menu Rights page — rights admins only. */
export const engHubMenuAdminGuard: CanActivateFn = () => {
  const rights = inject(EngHubMenuRightsService);
  const router = inject(Router);
  return rights.fetchMine().pipe(map((s) => (s.isAdmin ? true : router.createUrlTree(['/engineering-hub/no-access']))));
};

/** Bare /engineering-hub lands on the first menu this user may open, instead
 * of always Dashboard (which they may not have). An admin with no menus of
 * their own lands on Menu Rights. */
export const engHubHomeGuard: CanActivateFn = () => {
  const rights = inject(EngHubMenuRightsService);
  const router = inject(Router);
  return rights.fetchMine().pipe(
    map((s) => {
      const first = buildEngineeringHubNav().find((item) => s.menus.includes(item.code));
      if (first) {
        return router.createUrlTree([first.link]);
      }
      return router.createUrlTree([s.isAdmin ? '/engineering-hub/menu-rights' : '/engineering-hub/no-access']);
    })
  );
};
