import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { DevItemForm, EngineeringHubDataService, LookupOption, StatusOption } from '../engineering-hub-data.service';
import { EngHubMenuRightsService } from '../menu-rights.service';
import { QuickAddFeatureDialog } from '../shared/quick-add-feature-dialog';
import { QuickAddModuleDialog } from '../shared/quick-add-module-dialog';
import { QuickCreatePrefill, QuickCreated } from '../shared/quick-create';

/** Add/Edit Development Item — Product > Module > Feature cascade. Origin
 * selecting "Customer" reveals a debounced customer search; the Ticket #
 * search (also debounced, into TTMaster) is always available regardless of
 * Origin. Both follow the approved design's "reference, don't duplicate"
 * pattern into CustomerMaster/TTMaster. */
@Component({
  selector: 'app-add-development-item',
  imports: [FormsModule, ButtonModule, InputTextModule, SelectModule, TextareaModule, QuickAddModuleDialog, QuickAddFeatureDialog],
  templateUrl: './add-development-item.html',
  styleUrl: './add-development-item.scss'
})
export class AddDevelopmentItem implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  // Inline "+" create buttons show only for menus this user has been granted.
  readonly menuRights = inject(EngHubMenuRightsService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly location = inject(Location);
  // No zone.js — plain properties mutated inside subscribe callbacks need an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  /** Embedded = hosted in the Add Task page's "+" dialog: prefilled from
   * `prefill` (route query params ignored), and Save/Close emit
   * saved/cancelled instead of navigating. */
  readonly embedded = input(false);
  readonly prefill = input<QuickCreatePrefill | null>(null);
  readonly saved = output<QuickCreated>();
  readonly cancelled = output<void>();

  readonly products = signal<LookupOption[]>([]);
  readonly modules = signal<LookupOption[]>([]);
  readonly features = signal<LookupOption[]>([]);
  readonly devItemTypes = signal<LookupOption[]>([]);
  readonly originTypes = signal<LookupOption[]>([]);
  readonly priorities = signal<LookupOption[]>([]);
  readonly statuses = signal<StatusOption[]>([]);
  readonly customers = signal<LookupOption[]>([]);
  readonly tickets = signal<LookupOption[]>([]);
  readonly saving = signal(false);

  productId: number | null = null;
  moduleId: number | null = null;
  form: DevItemForm = this.blankForm();
  moduleDialogVisible = false;
  featureDialogVisible = false;

  private readonly customerFilter$ = new Subject<string>();
  private readonly ticketFilter$ = new Subject<string>();

  private blankForm(): DevItemForm {
    return {
      devItemId: 0, featureId: 0, devItemTypeId: 0, title: '', description: '',
      originTypeId: null, originTicketVoucherNo: null, customerId: null, priorityId: null, statusId: 0
    };
  }

  get originTypeName(): string {
    return this.originTypes().find((o) => o.value === this.form.originTypeId)?.label ?? '';
  }

  ngOnInit(): void {
    // Optional prefill when navigated here from a Feature detail page's "Add
    // Development Item" button, which already knows the full Product > Module
    // > Feature chain — saves re-picking it from scratch.
    const q = this.route.snapshot.queryParamMap;
    const embeddedPrefill = this.embedded() ? this.prefill() : null;
    const prefillProductId = this.embedded() ? embeddedPrefill?.productId ?? null : Number(q.get('productId') ?? 0) || null;
    const prefillModuleId = this.embedded() ? embeddedPrefill?.moduleId ?? null : Number(q.get('moduleId') ?? 0) || null;
    const prefillFeatureId = this.embedded() ? embeddedPrefill?.featureId ?? null : Number(q.get('featureId') ?? 0) || null;

    this.data.getProducts().subscribe((products) => {
      this.products.set(products);
      if (prefillProductId) {
        this.productId = prefillProductId;
        this.onProductChange();
        if (prefillModuleId) {
          this.moduleId = prefillModuleId;
          this.onModuleChange();
          if (prefillFeatureId) {
            this.form.featureId = prefillFeatureId;
          }
        }
      }
      this.cdr.markForCheck();
    });
    this.data.getDevItemTypes().subscribe((t) => this.devItemTypes.set(t));
    this.data.getOriginTypes().subscribe((t) => this.originTypes.set(t));
    this.data.getPriorities().subscribe((t) => this.priorities.set(t));
    this.data.getStatuses('DevelopmentItem').subscribe((statuses) => {
      this.statuses.set(statuses);
      if (!this.form.statusId) {
        this.form.statusId = statuses[0]?.value ?? 0;
      }
      this.cdr.markForCheck();
    });

    this.customerFilter$
      .pipe(debounceTime(300), distinctUntilChanged(), switchMap((q) => this.data.getCustomers(q)))
      .subscribe((rows) => {
        this.customers.set(rows.map((r) => ({ label: r.displayName, value: r.custId })));
        this.cdr.markForCheck();
      });

    this.ticketFilter$
      .pipe(debounceTime(300), distinctUntilChanged(), switchMap((q) => this.data.getTickets(q)))
      .subscribe((rows) => {
        this.tickets.set(rows.map((r) => ({ label: this.ticketLabel(r.voucherNo, r.customerName, r.date), value: r.voucherNo })));
        this.cdr.markForCheck();
      });

    const id = this.embedded() ? 0 : Number(this.route.snapshot.queryParamMap.get('id') ?? 0);
    if (id) {
      this.data.getDevelopmentItem(id).subscribe((item) => {
        // Edit mode: prefill the Product > Module > Feature cascade from the
        // saved item itself (there's no productId/moduleId query param here,
        // unlike the "Add Development Item" prefill above) — previously this
        // was skipped entirely, so Product/Module showed blank on Edit and,
        // worse, touching either dropdown would silently reset featureId to 0
        // via onProductChange()/onModuleChange()'s own reset logic before the
        // user had picked a real replacement. Reusing those same two methods
        // here (for their "fetch the dependent lookup list" side effect) is
        // safe because the full this.form reassignment below runs right
        // after, in the same synchronous callback, overwriting whatever
        // featureId they reset to 0 with the item's real value.
        this.productId = item.productId;
        this.onProductChange();
        this.moduleId = item.moduleId;
        this.onModuleChange();
        this.form = {
          devItemId: item.devItemId, featureId: item.featureId, devItemTypeId: item.devItemTypeId,
          title: item.title, description: item.description, originTypeId: item.originTypeId,
          originTicketVoucherNo: item.originTicketVoucherNo, customerId: item.customerId,
          priorityId: item.priorityId, statusId: item.statusId
        };
        if (item.customerId && item.customerName) {
          this.customers.set([{ label: item.customerName, value: item.customerId }]);
        }
        if (item.originTicketVoucherNo) {
          const voucherNo = item.originTicketVoucherNo;
          // Placeholder shown immediately so the field isn't blank while the
          // real lookup (with customer name) below resolves.
          this.tickets.set([{ label: `#${voucherNo}`, value: voucherNo }]);
          this.data.getTickets(String(voucherNo)).subscribe((rows) => {
            const match = rows.find((r) => r.voucherNo === voucherNo);
            if (match) {
              this.tickets.set([{ label: this.ticketLabel(match.voucherNo, match.customerName, match.date), value: match.voucherNo }]);
              this.cdr.markForCheck();
            }
          });
        }
        this.cdr.markForCheck();
      });
    } else {
      this.customerFilter$.next('');
      this.ticketFilter$.next('');
    }
  }

  onProductChange(): void {
    this.moduleId = null;
    this.form.featureId = 0;
    this.modules.set([]);
    this.features.set([]);
    if (this.productId) {
      this.data.getModules(this.productId).subscribe((modules) => {
        this.modules.set(modules);
        this.cdr.markForCheck();
      });
    }
  }

  onModuleChange(): void {
    this.form.featureId = 0;
    this.features.set([]);
    if (this.moduleId) {
      this.data.getFeaturesLookup(this.moduleId).subscribe((features) => {
        this.features.set(features);
        this.cdr.markForCheck();
      });
    }
  }

  /** "+" next to Module / Feature: point the cascade at what was just
   * created (parents may differ if changed in the dialog) and select it,
   * leaving the rest of the form as is. */
  onCreated(level: 'module' | 'feature', c: QuickCreated): void {
    const withCreated = (opts: LookupOption[]) =>
      opts.some((o) => o.value === c.id) ? opts : [...opts, { label: c.label, value: c.id }];
    this.productId = c.productId;
    this.moduleId = c.moduleId;
    this.form.featureId = level === 'feature' ? c.id : 0;
    this.data.getModules(c.productId).subscribe((modules) => {
      this.modules.set(level === 'module' ? withCreated(modules) : modules);
      this.cdr.markForCheck();
    });
    this.data.getFeaturesLookup(c.moduleId).subscribe((features) => {
      this.features.set(level === 'feature' ? withCreated(features) : features);
      this.cdr.markForCheck();
    });
    this.cdr.markForCheck();
  }

  onCustomerFilter(query: string): void {
    this.customerFilter$.next(query);
  }

  onTicketFilter(query: string): void {
    this.ticketFilter$.next(query);
  }

  // "#VoucherNo — Customer Name (dd-MM-yy)" — same format used by the
  // Feature form's Trouble Ticket field, so a ticket reads identically
  // wherever it's picked in Engineering Hub.
  private ticketLabel(voucherNo: number, customerName: string | null, date: string | null): string {
    let label = `#${voucherNo}`;
    if (customerName) {
      label += ` — ${customerName}`;
    }
    if (date) {
      label += ` (${date.slice(0, 10)})`;
    }
    return label;
  }

  private validate(): boolean {
    if (!this.form.featureId) {
      alert('Please select a feature.');
      return false;
    }
    if (!this.form.devItemTypeId) {
      alert('Please select a type.');
      return false;
    }
    if (!this.form.title.trim()) {
      alert('Enter a title.');
      return false;
    }
    if (!this.form.statusId) {
      alert('Please select a status.');
      return false;
    }
    return true;
  }

  save(): void {
    if (!this.validate()) {
      return;
    }
    this.saving.set(true);
    this.data.saveDevelopmentItem(this.form).subscribe((res) => {
      this.saving.set(false);
      if (!res.success) {
        alert('Failed to save development item.');
        return;
      }
      if (this.embedded()) {
        this.saved.emit({
          id: res.devItemId, label: this.form.title.trim(),
          productId: this.productId!, moduleId: this.moduleId!, featureId: this.form.featureId
        });
        return;
      }
      // Return to whichever screen opened this form (Features, Feature detail,
      // Dev Item detail, ...); only fall back to the list when the page was
      // opened directly with no in-app screen to go back to.
      if (this.router.lastSuccessfulNavigation()?.previousNavigation) {
        this.location.back();
      } else {
        this.router.navigate(['/engineering-hub/development-items']);
      }
    });
  }

  close(): void {
    if (this.embedded()) {
      this.cancelled.emit();
      return;
    }
    this.location.back();
  }
}
