import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, HostListener, OnInit, computed, inject, input, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';

import { AttachmentRow, EngineeringHubDataService } from '../engineering-hub-data.service';

const IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg'];

/**
 * Extracts trouble-ticket.ts's proven label+hidden-input file-picker pattern
 * (a visible <label> wraps a hidden native <input type=file> — clicking the
 * label triggers the native picker; programmatic .click() on the input
 * itself is blocked in this app's Ionic WebView, per a confirmed past
 * finding) into a reusable component. Unlike trouble-ticket.ts, there's no
 * "stage until the parent record is saved" step here — this component only
 * ever appears on detail pages for entities that already have a real id, so
 * uploads go straight to the server.
 */
@Component({
  selector: 'app-eng-hub-attachments',
  imports: [DatePipe, ButtonModule, DialogModule],
  template: `
    <div class="attachments">
      <label class="attach-btn">
        <i class="pi pi-paperclip"></i> Add Attachment
        <input type="file" multiple (change)="onFilesSelected($event)" hidden />
      </label>
      @if (uploading()) {
        <span class="uploading">Uploading…</span>
      }

      <ul class="attachment-list">
        @for (a of attachments(); track a.attachmentId) {
          <li>
            <a href="javascript:void(0)" (click)="download(a)">{{ a.fileName }}</a>
            @if (isImage(a)) {
              <a href="javascript:void(0)" class="view-link" (click)="viewImage(a)"><i class="pi pi-eye"></i> View</a>
            }
            <span class="meta">{{ formatSize(a.fileSizeBytes) }} &middot; {{ a.uploadedByName }} &middot; {{ a.uploadedAt | date: 'dd-MMM-yy' }}</span>
            <a href="javascript:void(0)" class="delete-link" (click)="delete(a)">Remove</a>
          </li>
        }
        @if (attachments().length === 0) {
          <li class="empty">No attachments yet.</li>
        }
      </ul>
    </div>

    <p-dialog
      [(visible)]="imageViewerVisible"
      [modal]="true"
      [style]="{ width: '90vw', maxWidth: '900px' }"
      [breakpoints]="{ '960px': '95vw' }"
    >
      <ng-template #header>
        <div class="viewer-header">
          <span class="viewer-filename">{{ viewingImage()?.fileName ?? 'Image' }}</span>
          @if (imageAttachments().length > 1) {
            <span class="viewer-count">{{ viewingIndex() + 1 }} of {{ imageAttachments().length }}</span>
          }
        </div>
      </ng-template>
      <div class="viewer-body">
        @if (imageAttachments().length > 1) {
          <p-button
            icon="pi pi-chevron-left"
            [text]="true"
            [rounded]="true"
            styleClass="viewer-nav viewer-nav-prev"
            [disabled]="!hasPrev()"
            (onClick)="prevImage()"
            ariaLabel="Previous image"
          />
        }
        @if (viewingImage(); as img) {
          <img [src]="downloadUrl(img)" [alt]="img.fileName" class="image-preview" />
        }
        @if (imageAttachments().length > 1) {
          <p-button
            icon="pi pi-chevron-right"
            [text]="true"
            [rounded]="true"
            styleClass="viewer-nav viewer-nav-next"
            [disabled]="!hasNext()"
            (onClick)="nextImage()"
            ariaLabel="Next image"
          />
        }
      </div>
    </p-dialog>
  `,
  styles: [
    `
      .attach-btn {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        cursor: pointer;
        color: #7c2d12;
        font-size: 0.9rem;
      }
      .uploading {
        margin-left: 0.5rem;
        color: var(--p-text-muted-color);
        font-size: 0.85rem;
      }
      .attachment-list {
        list-style: none;
        padding: 0;
        margin: 0.5rem 0 0;
      }
      .attachment-list li {
        padding: 0.3rem 0;
        border-bottom: 1px solid var(--p-content-border-color);
        display: flex;
        align-items: center;
        gap: 0.5rem;
        flex-wrap: wrap;
      }
      .attachment-list a {
        color: #7c2d12;
        text-decoration: none;
      }
      .view-link {
        display: inline-flex;
        align-items: center;
        gap: 0.25rem;
        font-size: 0.8rem;
        background: #fefce8;
        border-radius: 3px;
        padding: 0.1rem 0.5rem;
      }
      .meta {
        font-size: 0.75rem;
        color: var(--p-text-muted-color);
      }
      .delete-link {
        margin-left: auto;
        font-size: 0.8rem;
      }
      .empty {
        color: var(--p-text-muted-color);
        border-bottom: none;
      }
      .image-preview {
        display: block;
        max-width: 100%;
        max-height: 75vh;
        margin: 0 auto;
      }
      .viewer-header {
        display: flex;
        align-items: baseline;
        gap: 0.6rem;
        min-width: 0;
      }
      .viewer-filename {
        font-weight: 600;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .viewer-count {
        font-size: 0.8rem;
        color: var(--p-text-muted-color);
        white-space: nowrap;
      }
      .viewer-body {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 40vh;
        padding: 0 4.5rem;
      }
      /* Enlarged nav buttons: cream fill with a dark-brown ring (this
         module's own brand brown, #5c2410/#7c2d12 — see .attach-btn/
         .attachment-list a above) AND a dark-brown arrow glyph, so the
         arrow itself reads as brown rather than white-on-brown. Cream fill
         keeps the ring/arrow readable against dark image content too.
         72px, growing to 88px on wider screens. Explicit width/height
         (rather than PrimeNG's size input, which only offers small/large
         steps) gives exact control over the click target. */
      .viewer-nav {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        z-index: 2;
        width: 72px;
        height: 72px;
        display: flex !important;
        align-items: center;
        justify-content: center;
        padding: 0 !important;
        border-radius: 50% !important;
        background: #fefce8 !important;
        color: #5c2410 !important;
        border: 3px solid #5c2410 !important;
        box-shadow: 0 2px 12px rgba(0, 0, 0, 0.45);
        transition: background-color 0.15s ease, border-color 0.15s ease, transform 0.15s ease, box-shadow 0.15s ease;
      }
      .viewer-nav:hover:not(:disabled) {
        background: #fdf3c7 !important;
        border-color: #7c2d12 !important;
        box-shadow: 0 2px 16px rgba(0, 0, 0, 0.55);
        transform: translateY(-50%) scale(1.1);
      }
      .viewer-nav:disabled {
        opacity: 0.35;
      }
      .viewer-nav ::ng-deep .p-button-icon {
        color: #5c2410 !important;
        font-size: 2rem;
      }
      .viewer-nav-prev {
        left: 0.5rem;
      }
      .viewer-nav-next {
        right: 0.5rem;
      }
      @media (min-width: 700px) {
        .viewer-nav {
          width: 88px;
          height: 88px;
        }
        .viewer-nav ::ng-deep .p-button-icon {
          font-size: 2.5rem;
        }
        .viewer-nav-prev {
          left: 1rem;
        }
        .viewer-nav-next {
          right: 1rem;
        }
      }
      @media (max-width: 480px) {
        .viewer-body {
          padding: 0 3.5rem;
        }
        .viewer-nav {
          width: 60px;
          height: 60px;
        }
        .viewer-nav ::ng-deep .p-button-icon {
          font-size: 1.75rem;
        }
      }
    `
  ]
})
export class EngHubAttachments implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  // No zone.js — `attachments`/`uploading` are signals so no markForCheck is
  // needed, but kept for consistency isn't required here.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly entityType = input.required<string>();
  readonly entityId = input.required<number>();

  readonly attachments = signal<AttachmentRow[]>([]);
  readonly uploading = signal(false);

  // Image viewer dialog — a plain img in a p-dialog rather than PrimeNG's
  // own Image/preview component, to match the p-dialog pattern already used
  // everywhere else in this module instead of introducing a second one.
  // Navigation is index-based over the image-only subset of attachments
  // (non-image files, e.g. PDFs, were never viewable here and stay excluded
  // from Prev/Next) so Next/Prev always lands on another real image.
  imageViewerVisible = false;
  viewingIndex = signal(-1);
  readonly imageAttachments = computed(() => this.attachments().filter((a) => this.isImage(a)));
  readonly viewingImage = computed<AttachmentRow | null>(() => {
    const imgs = this.imageAttachments();
    const idx = this.viewingIndex();
    return idx >= 0 && idx < imgs.length ? imgs[idx] : null;
  });
  readonly hasPrev = computed(() => this.viewingIndex() > 0);
  readonly hasNext = computed(() => this.viewingIndex() < this.imageAttachments().length - 1);

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.data.getAttachments(this.entityType(), this.entityId()).subscribe((rows) => this.attachments.set(rows));
  }

  onFilesSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const files = input.files;
    if (!files || files.length === 0) {
      return;
    }
    this.uploading.set(true);
    this.data.uploadAttachments(this.entityType(), this.entityId(), Array.from(files)).subscribe({
      next: () => {
        this.uploading.set(false);
        this.load();
      },
      error: (err) => {
        this.uploading.set(false);
        alert(err.error?.detail ?? 'Upload failed.');
        this.cdr.markForCheck();
      }
    });
    input.value = '';
  }

  download(row: AttachmentRow): void {
    window.open(this.data.getAttachmentDownloadUrl(row.attachmentId), '_blank');
  }

  downloadUrl(row: AttachmentRow): string {
    return this.data.getAttachmentDownloadUrl(row.attachmentId);
  }

  isImage(row: AttachmentRow): boolean {
    if (row.contentType?.startsWith('image/')) {
      return true;
    }
    const lowerName = row.fileName.toLowerCase();
    return IMAGE_EXTENSIONS.some((ext) => lowerName.endsWith(ext));
  }

  viewImage(row: AttachmentRow): void {
    const idx = this.imageAttachments().findIndex((a) => a.attachmentId === row.attachmentId);
    this.viewingIndex.set(idx);
    this.imageViewerVisible = true;
  }

  prevImage(): void {
    if (this.hasPrev()) {
      this.viewingIndex.update((i) => i - 1);
    }
  }

  nextImage(): void {
    if (this.hasNext()) {
      this.viewingIndex.update((i) => i + 1);
    }
  }

  // Arrow-key navigation while the viewer is open, alongside the explicit
  // Prev/Next buttons — only acts when the dialog is actually visible so it
  // never intercepts arrow keys used elsewhere on the page.
  @HostListener('window:keydown', ['$event'])
  onViewerKeydown(event: KeyboardEvent): void {
    if (!this.imageViewerVisible) {
      return;
    }
    if (event.key === 'ArrowLeft') {
      this.prevImage();
    } else if (event.key === 'ArrowRight') {
      this.nextImage();
    }
  }

  delete(row: AttachmentRow): void {
    if (!confirm(`Remove ${row.fileName}?`)) {
      return;
    }
    this.data.deleteAttachment(row.attachmentId).subscribe(() => this.load());
  }

  formatSize(bytes: number): string {
    if (bytes < 1024) {
      return `${bytes} B`;
    }
    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  }
}
