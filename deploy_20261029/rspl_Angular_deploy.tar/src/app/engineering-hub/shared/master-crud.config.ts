import { Observable } from 'rxjs';

/**
 * Config-driven shape consumed by EngHubMasterCrud (eng-hub-master-crud.ts)
 * — one generic grid+add-form scaffold standing in for what would otherwise
 * be a 9th–14th hand-copy of Agile's priority-master/module-master pattern
 * (see the approved design's §2, "shared/master-crud").
 */
export type MasterFieldType = 'text' | 'textarea' | 'checkbox' | 'color' | 'number';

export interface MasterField {
  key: string;
  label: string;
  type: MasterFieldType;
}

export interface MasterParentOption {
  label: string;
  value: number | string;
}

export interface MasterCrudConfig {
  key: string;
  title: string;
  idField: string;
  fields: MasterField[];
  /** When set, the console renders a parent selector above the grid (e.g.
   * Module scoped by Product, Status scoped by EntityType) and reloads on
   * change. Omit for the 7 plain id/name/enabled masters. */
  parentLabel?: string;
  parentOptions?: () => Observable<MasterParentOption[]>;
  load: (parentValue?: number | string) => Observable<Record<string, unknown>[]>;
  save: (row: Record<string, unknown>) => Observable<{ success: boolean }>;
  blankRow: (parentValue?: number | string) => Record<string, unknown>;
}
