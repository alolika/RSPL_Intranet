/** Contract for the Add Task page's inline "+" buttons: the Add Feature /
 * Add Development Item forms can run embedded in a dialog (instead of as a
 * routed page), prefilled from the Task form's current cascade, and report
 * back what they created so the Task form can select it without reloading. */
export interface QuickCreatePrefill {
  productId: number | null;
  moduleId: number | null;
  featureId?: number | null;
}

export interface QuickCreated {
  id: number;
  label: string;
  productId: number;
  moduleId: number;
  featureId?: number;
}
