import { Component, input, model, output } from '@angular/core';
import { DialogModule } from 'primeng/dialog';

import { AddDevelopmentItem } from '../add-development-item/add-development-item';
import { QuickCreatePrefill, QuickCreated } from './quick-create';

/** Inline "+ Dev Item" dialog — the full Add Development Item form, embedded. */
@Component({
  selector: 'app-quick-add-dev-item-dialog',
  imports: [DialogModule, AddDevelopmentItem],
  template: `
    <p-dialog
      header="Add Development Item"
      [visible]="visible()"
      (visibleChange)="visible.set($event)"
      [modal]="true"
      appendTo="body"
      [style]="{ width: '56rem' }"
      [breakpoints]="{ '960px': '90vw', '560px': '95vw' }"
    >
      @if (visible()) {
        <app-add-development-item [embedded]="true" [prefill]="prefill()" (saved)="onSaved($event)" (cancelled)="visible.set(false)" />
      }
    </p-dialog>
  `
})
export class QuickAddDevItemDialog {
  readonly visible = model(false);
  readonly prefill = input<QuickCreatePrefill | null>(null);
  readonly saved = output<QuickCreated>();

  onSaved(created: QuickCreated): void {
    this.visible.set(false);
    this.saved.emit(created);
  }
}
