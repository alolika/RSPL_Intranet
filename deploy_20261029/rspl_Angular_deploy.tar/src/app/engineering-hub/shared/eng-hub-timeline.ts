import { DatePipe } from '@angular/common';
import { Component, input } from '@angular/core';
import { TimelineModule } from 'primeng/timeline';

import { TimelineEntry } from '../engineering-hub-data.service';

/**
 * First use of PrimeNG's p-timeline in this app (confirmed unused
 * elsewhere). Renders the rolled-up Feature/Development Item/Task history
 * the PRD calls "Feature Timeline" — a UNION of Activities and Decisions
 * per the approved design (§4), merged and sorted by the caller via
 * mergeTimelineEntries() before being passed in here. Not a separately
 * stored timeline.
 */
@Component({
  selector: 'app-eng-hub-timeline',
  imports: [TimelineModule, DatePipe],
  template: `
    <p-timeline [value]="entries()" align="left" styleClass="eng-hub-timeline">
      <ng-template #content let-entry>
        @if (entry.kind === 'activity') {
          <div class="entry">
            <div class="entry-header">
              <span class="type-badge">{{ entry.activity.activityTypeName }}</span>
              <span class="occurred-at">{{ entry.activity.occurredAt | date: 'dd-MMM-yyyy hh:mm a' }}</span>
            </div>
            <div class="entry-body">
              @if (entry.activity.description) {
                <p>{{ entry.activity.description }}</p>
              }
              @if (entry.activity.durationMinutes) {
                <span class="chip">{{ entry.activity.durationMinutes }} min</span>
              }
              @if (entry.activity.newStatusName) {
                <span class="chip">Status: {{ entry.activity.oldStatusName || '—' }} &rarr; {{ entry.activity.newStatusName }}</span>
              }
            </div>
            <div class="entry-footer">by {{ entry.activity.loggedByName }}</div>
          </div>
        } @else {
          <div class="entry decision-entry">
            <div class="entry-header">
              <span class="type-badge decision-badge">Decision: {{ entry.decision.decisionTypeName }}</span>
              <span class="occurred-at">{{ entry.decision.createdAt | date: 'dd-MMM-yyyy hh:mm a' }}</span>
            </div>
            <div class="entry-body">
              <p>{{ entry.decision.description }}</p>
              <p class="reason"><i>Why:</i> {{ entry.decision.reason }}</p>
              <span class="chip risk-{{ entry.decision.riskLevel.toLowerCase() }}">Risk: {{ entry.decision.riskLevel }}</span>
            </div>
            <div class="entry-footer">
              by {{ entry.decision.createdByName }}
              @if (entry.decision.approverName || entry.decision.approverExternalName) {
                &middot; approved by {{ entry.decision.approverName || entry.decision.approverExternalName }}
              }
            </div>
          </div>
        }
      </ng-template>
    </p-timeline>
    @if (entries().length === 0) {
      <p class="empty">No activity logged yet.</p>
    }
  `,
  styles: [
    `
      .entry-header {
        display: flex;
        justify-content: space-between;
        gap: 0.5rem;
        font-size: 0.85rem;
      }
      .type-badge {
        font-weight: 600;
        color: #7c2d12;
      }
      .decision-badge {
        color: #92400e;
      }
      .decision-entry {
        background: #fffbeb;
        border-radius: 4px;
        padding: 0.35rem 0.5rem;
        margin: -0.35rem -0.5rem;
      }
      .occurred-at {
        color: var(--p-text-muted-color);
      }
      .entry-body p {
        margin: 0.25rem 0;
      }
      .entry-body .reason {
        font-size: 0.85rem;
        color: var(--p-text-muted-color);
      }
      .chip {
        display: inline-block;
        background: #fefce8;
        border-radius: 3px;
        padding: 0.1rem 0.4rem;
        font-size: 0.8rem;
        margin-right: 0.35rem;
      }
      .chip.risk-high {
        background: #fee2e2;
      }
      .chip.risk-medium {
        background: #fef3c7;
      }
      .chip.risk-low {
        background: #dcfce7;
      }
      .entry-footer {
        font-size: 0.75rem;
        color: var(--p-text-muted-color);
        margin-top: 0.15rem;
      }
      .empty {
        color: var(--p-text-muted-color);
        padding: 1rem 0;
      }
      /* align="left" still renders an empty "opposite" column that takes half
         the width, squeezing every entry into a narrow strip. Collapse it so
         the timeline sits at the left edge and entries use the full width. */
      :host ::ng-deep .eng-hub-timeline .p-timeline-event-opposite {
        flex: 0 0 0;
        padding: 0;
      }
      :host ::ng-deep .eng-hub-timeline .p-timeline-event-content {
        flex: 1 1 auto;
        min-width: 0;
      }
      .entry-body p {
        white-space: pre-line;
        overflow-wrap: break-word;
      }
    `
  ]
})
export class EngHubTimeline {
  readonly entries = input.required<TimelineEntry[]>();
}
