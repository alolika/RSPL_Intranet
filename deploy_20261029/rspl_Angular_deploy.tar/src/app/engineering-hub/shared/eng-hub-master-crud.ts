import { ChangeDetectorRef, Component, effect, inject, input, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { ColorPickerModule } from 'primeng/colorpicker';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { MasterCrudConfig, MasterParentOption } from './master-crud.config';

/**
 * Generic replacement for a 9th-14th hand-copy of Agile's
 * priority-master/module-master pattern (see approved design §2 and §6 —
 * "Masters — a single console page... selecting one loads the generic
 * shared/master-crud grid on the right"). One instance is reused across all
 * 9 master types by swapping the `config` input; the effect() below reloads
 * whenever the config (and therefore the underlying table) changes.
 */
@Component({
  selector: 'app-eng-hub-master-crud',
  imports: [
    FormsModule,
    ButtonModule,
    CheckboxModule,
    ColorPickerModule,
    InputNumberModule,
    InputTextModule,
    SelectModule,
    TableModule,
    TextareaModule
  ],
  templateUrl: './eng-hub-master-crud.html',
  styleUrl: './eng-hub-master-crud.scss'
})
export class EngHubMasterCrud {
  // No zone.js — plain properties (parentValue, newRow) mutated inside
  // subscribe callbacks need an explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly config = input.required<MasterCrudConfig>();

  readonly rows = signal<Record<string, unknown>[]>([]);
  readonly parentOptions = signal<MasterParentOption[]>([]);
  readonly saving = signal(false);

  parentValue: number | string | null = null;
  newRow: Record<string, unknown> = {};

  constructor() {
    effect(() => {
      const cfg = this.config();
      this.rows.set([]);
      this.parentOptions.set([]);
      this.parentValue = null;

      if (cfg.parentOptions) {
        cfg.parentOptions().subscribe((opts) => {
          this.parentOptions.set(opts);
          this.parentValue = opts[0]?.value ?? null;
          this.newRow = cfg.blankRow(this.parentValue ?? undefined);
          this.loadRows();
          this.cdr.markForCheck();
        });
      } else {
        this.newRow = cfg.blankRow();
        this.loadRows();
      }
    });
  }

  private loadRows(): void {
    this.config()
      .load(this.parentValue ?? undefined)
      .subscribe((rows) => this.rows.set(rows));
  }

  onParentChange(): void {
    this.newRow = this.config().blankRow(this.parentValue ?? undefined);
    this.loadRows();
  }

  submit(): void {
    const cfg = this.config();
    this.saving.set(true);
    cfg.save(this.newRow).subscribe(() => {
      this.saving.set(false);
      this.newRow = cfg.blankRow(this.parentValue ?? undefined);
      this.loadRows();
      this.cdr.markForCheck();
    });
  }

  saveRow(row: Record<string, unknown>): void {
    this.config()
      .save(row)
      .subscribe(() => this.loadRows());
  }
}
