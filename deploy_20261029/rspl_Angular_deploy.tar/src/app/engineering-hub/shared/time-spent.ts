/** Shared "Time Spent" formatter — originally built for Development Items'
 * grid, now reused by My Tasks and Features too, so every page renders the
 * exact same duration-minutes rollup the same way instead of drifting
 * copies. "5 hrs 30 mins" / "45 mins" (< 1 hour) / "1 hr" / "0 mins", with
 * correct singular "1 hr"/"1 min". */
export function formatTimeSpent(totalMinutes: number): string {
  const mins = Math.round(totalMinutes);
  const hrs = Math.floor(mins / 60);
  const remMins = mins % 60;
  if (hrs === 0) {
    return `${remMins} min${remMins === 1 ? '' : 's'}`;
  }
  const hrsLabel = `${hrs} hr${hrs === 1 ? '' : 's'}`;
  return remMins === 0 ? hrsLabel : `${hrsLabel} ${remMins} min${remMins === 1 ? '' : 's'}`;
}
