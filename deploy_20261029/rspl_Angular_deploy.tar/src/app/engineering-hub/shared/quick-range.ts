/** Shared "Quick Range" date preset — originally built for the My Tasks
 * filter bar, now reused everywhere else in Engineering Hub that has a
 * From/To date filter, so every page computes the exact same ranges from
 * one implementation instead of drifting copies. */
export type QuickRangeOption =
  | 'none'
  | 'lastMonth'
  | 'lastYear'
  | 'lastWeek'
  | 'currentWeek'
  | 'currentMonth'
  | 'calendarYear'
  | 'financialYear'
  | 'today';

export const QUICK_RANGE_OPTIONS: { label: string; value: QuickRangeOption }[] = [
  { label: 'None', value: 'none' },
  { label: 'Last Month', value: 'lastMonth' },
  { label: 'Last Year', value: 'lastYear' },
  { label: 'Last Week', value: 'lastWeek' },
  { label: 'Current Week', value: 'currentWeek' },
  { label: 'Current Month', value: 'currentMonth' },
  { label: 'Calendar Year', value: 'calendarYear' },
  { label: 'Financial Year', value: 'financialYear' },
  { label: 'Today', value: 'today' }
];

/** "Current *" ranges run start-of-period -> today (the period is still in
 * progress); "Last *" ranges are fully closed past periods. Returns
 * {from: null, to: null} for 'none' (and as a fallback for an unset option)
 * so callers can assign both bounds unconditionally. */
export function computeQuickRange(option: QuickRangeOption | null): { from: Date | null; to: Date | null } {
  const today = new Date();
  switch (option) {
    case 'today':
      return { from: today, to: today };
    case 'currentWeek': {
      const daysSinceMonday = today.getDay() === 0 ? 6 : today.getDay() - 1; // getDay(): 0=Sun..6=Sat
      return { from: new Date(today.getFullYear(), today.getMonth(), today.getDate() - daysSinceMonday), to: today };
    }
    case 'currentMonth':
      return { from: new Date(today.getFullYear(), today.getMonth(), 1), to: today };
    case 'lastWeek': {
      const daysSinceMonday = today.getDay() === 0 ? 6 : today.getDay() - 1;
      const thisMonday = new Date(today.getFullYear(), today.getMonth(), today.getDate() - daysSinceMonday);
      return {
        from: new Date(thisMonday.getFullYear(), thisMonday.getMonth(), thisMonday.getDate() - 7),
        to: new Date(thisMonday.getFullYear(), thisMonday.getMonth(), thisMonday.getDate() - 1)
      };
    }
    case 'lastMonth':
      return {
        from: new Date(today.getFullYear(), today.getMonth() - 1, 1),
        // Day 0 of the current month = the last day of the previous month.
        to: new Date(today.getFullYear(), today.getMonth(), 0)
      };
    case 'calendarYear':
      return { from: new Date(today.getFullYear(), 0, 1), to: today };
    case 'financialYear': {
      // India's FY runs 1-Apr -> 31-Mar; April is month index 3.
      const fyStartYear = today.getMonth() >= 3 ? today.getFullYear() : today.getFullYear() - 1;
      return { from: new Date(fyStartYear, 3, 1), to: today };
    }
    case 'lastYear':
      return { from: new Date(today.getFullYear() - 1, 0, 1), to: new Date(today.getFullYear() - 1, 11, 31) };
    case 'none':
    default:
      return { from: null, to: null };
  }
}
