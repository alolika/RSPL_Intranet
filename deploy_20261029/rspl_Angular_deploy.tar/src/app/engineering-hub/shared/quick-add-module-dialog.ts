import { ChangeDetectorRef, Component, effect, inject, input, model, output, signal, untracked } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';

import { EngineeringHubDataService, LookupOption } from '../engineering-hub-data.service';
import { QuickCreated } from './quick-create';

/** Inline "+ Module" dialog used next to every Module picker in Engineering
 * Hub's entry forms. Appended to body so it stacks correctly even when
 * opened from inside another dialog (e.g. Add Task > + Feature > + Module). */
@Component({
  selector: 'app-quick-add-module-dialog',
  imports: [FormsModule, ButtonModule, DialogModule, InputTextModule, SelectModule, TextareaModule],
  template: `
    <p-dialog
      header="Add Module"
      [visible]="visible()"
      (visibleChange)="visible.set($event)"
      [modal]="true"
      appendTo="body"
      [style]="{ width: '32rem' }"
      [breakpoints]="{ '960px': '90vw', '560px': '95vw' }"
    >
      @if (visible()) {
        <div class="row">
          <div class="field full">
            <label>* Product</label>
            <p-select [options]="products()" optionLabel="label" optionValue="value" [(ngModel)]="form.productId" [filter]="true" appendTo="body" />
          </div>
        </div>
        <div class="row">
          <div class="field full">
            <label>* Name</label>
            <input pInputText [(ngModel)]="form.name" />
          </div>
        </div>
        <div class="row">
          <div class="field full">
            <label>Description</label>
            <textarea pTextarea [(ngModel)]="form.description" rows="3"></textarea>
          </div>
        </div>
        <div class="quick-add-submit">
          <span class="hint">* Fields are compulsory</span>
          <p-button label="Save" (onClick)="save()" [loading]="saving()" />
          <p-button label="Close" severity="secondary" (onClick)="visible.set(false)" />
        </div>
      }
    </p-dialog>
  `
})
export class QuickAddModuleDialog {
  private readonly data = inject(EngineeringHubDataService);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly visible = model(false);
  readonly productId = input<number | null>(null);
  readonly saved = output<QuickCreated>();

  readonly products = signal<LookupOption[]>([]);
  readonly saving = signal(false);
  form = { productId: null as number | null, name: '', description: '' };

  constructor() {
    // Fresh form, prefilled with the host's current Product, on every open.
    effect(() => {
      if (!this.visible()) {
        return;
      }
      untracked(() => {
        this.form = { productId: this.productId(), name: '', description: '' };
        if (!this.products().length) {
          this.data.getProducts().subscribe((p) => this.products.set(p));
        }
        this.cdr.markForCheck();
      });
    });
  }

  save(): void {
    const { productId, description } = this.form;
    const name = this.form.name.trim();
    if (!productId) {
      alert('Please select a product.');
      return;
    }
    if (!name) {
      alert('Enter a module name.');
      return;
    }
    this.saving.set(true);
    this.data.saveModuleCrud({ moduleId: 0, productId, name, description, enabled: true }).subscribe({
      next: (res) => {
        this.saving.set(false);
        if (!res.success || !res.moduleId) {
          alert('Failed to save module.');
          return;
        }
        this.visible.set(false);
        this.saved.emit({ id: res.moduleId, label: name, productId, moduleId: res.moduleId });
      },
      error: () => {
        this.saving.set(false);
        alert('Failed to save module.');
      }
    });
  }
}
