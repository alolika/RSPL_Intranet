import { Component, input, model, output } from '@angular/core';
import { DialogModule } from 'primeng/dialog';

import { AddFeature } from '../add-feature/add-feature';
import { QuickCreatePrefill, QuickCreated } from './quick-create';

/** Inline "+ Feature" dialog — the full Add Feature form, embedded. Lives in
 * its own file (not beside QuickAddModuleDialog) because AddFeature itself
 * imports QuickAddModuleDialog. */
@Component({
  selector: 'app-quick-add-feature-dialog',
  imports: [DialogModule, AddFeature],
  template: `
    <p-dialog
      header="Add Feature"
      [visible]="visible()"
      (visibleChange)="visible.set($event)"
      [modal]="true"
      appendTo="body"
      [style]="{ width: '48rem' }"
      [breakpoints]="{ '960px': '90vw', '560px': '95vw' }"
    >
      @if (visible()) {
        <app-add-feature [embedded]="true" [prefill]="prefill()" (saved)="onSaved($event)" (cancelled)="visible.set(false)" />
      }
    </p-dialog>
  `
})
export class QuickAddFeatureDialog {
  readonly visible = model(false);
  readonly prefill = input<QuickCreatePrefill | null>(null);
  readonly saved = output<QuickCreated>();

  onSaved(created: QuickCreated): void {
    this.visible.set(false);
    this.saved.emit(created);
  }
}
