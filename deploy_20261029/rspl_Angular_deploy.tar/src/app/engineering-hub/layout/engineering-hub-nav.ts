import { EngHubMenuCode } from '../menu-rights.service';

export interface EngHubNavItem {
  /** Menu Rights code — a user only sees items they've been granted. */
  code: EngHubMenuCode;
  label: string;
  icon: string;
  link: string;
  /**
   * URL prefixes that should highlight this item as active, beyond its own
   * `link`. Several sub-pages (add-feature, feature-detail, reports/*, ...)
   * aren't nav entries themselves but are part of that section, so the
   * sidebar keeps that section highlighted while viewing them.
   */
  matchPrefixes: string[];
}

/**
 * Left sidebar nav for the Engineering Hub shell. Icons match the labels
 * already established in shared/mobile-nav's iconMap for this module (kept
 * consistent with the rest of the app rather than picked fresh).
 */
export function buildEngineeringHubNav(): EngHubNavItem[] {
  return [
    {
      code: 'DASHBOARD',
      label: 'Dashboard',
      icon: 'pi-home',
      link: '/engineering-hub/dashboard',
      matchPrefixes: ['/engineering-hub/dashboard']
    },
    {
      code: 'FEATURES',
      label: 'Features',
      icon: 'pi-folder',
      link: '/engineering-hub/features',
      matchPrefixes: ['/engineering-hub/features', '/engineering-hub/add-feature', '/engineering-hub/feature-detail']
    },
    {
      code: 'DEV_ITEMS',
      label: 'Development Items',
      icon: 'pi-wrench',
      link: '/engineering-hub/development-items',
      matchPrefixes: [
        '/engineering-hub/development-items',
        '/engineering-hub/add-development-item',
        '/engineering-hub/development-item-detail'
      ]
    },
    {
      code: 'TASKS',
      label: 'Tasks',
      icon: 'pi-check-square',
      link: '/engineering-hub/tasks',
      matchPrefixes: ['/engineering-hub/tasks', '/engineering-hub/add-task']
    },
    {
      code: 'ACTIVITIES',
      label: 'Activities',
      icon: 'pi-file-edit',
      link: '/engineering-hub/activities',
      matchPrefixes: ['/engineering-hub/activities']
    },
    {
      code: 'DECISIONS',
      label: 'Decisions',
      icon: 'pi-exclamation-triangle',
      link: '/engineering-hub/decisions',
      matchPrefixes: ['/engineering-hub/decisions', '/engineering-hub/add-decision']
    },
    {
      code: 'RELEASES',
      label: 'Releases',
      icon: 'pi-send',
      link: '/engineering-hub/releases',
      matchPrefixes: ['/engineering-hub/releases', '/engineering-hub/add-release', '/engineering-hub/release-detail']
    },
    {
      code: 'REPORTS',
      label: 'Reports',
      icon: 'pi-chart-bar',
      link: '/engineering-hub/reports',
      matchPrefixes: ['/engineering-hub/reports']
    },
    {
      code: 'MASTERS',
      label: 'Masters',
      icon: 'pi-cog',
      link: '/engineering-hub/masters',
      matchPrefixes: ['/engineering-hub/masters']
    }
  ];
}
