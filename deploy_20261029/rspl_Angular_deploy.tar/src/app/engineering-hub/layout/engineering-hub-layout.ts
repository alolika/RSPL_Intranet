import { Component, computed, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { NavigationEnd, Router, RouterLink, RouterOutlet } from '@angular/router';
import { filter, map, startWith } from 'rxjs';

import { PortalAuthService } from '../../core/auth/portal-auth.service';
import { EngHubMenuRightsService } from '../menu-rights.service';
import { buildEngineeringHubNav, EngHubNavItem } from './engineering-hub-nav';

/**
 * Enterprise-dashboard shell for Engineering Hub: fixed left sidebar (all
 * nav items, active-section highlighting) + top bar (brand/user/logout,
 * mobile menu toggle) + main content. Replaces the old top <p-menubar> +
 * app-mobile-nav pairing this module used to share with Main/Agile/
 * Recruitment — those other shells are untouched, this is Engineering
 * Hub-only.
 */
@Component({
  selector: 'app-engineering-hub-layout',
  imports: [RouterOutlet, RouterLink],
  templateUrl: './engineering-hub-layout.html',
  styleUrl: './engineering-hub-layout.scss'
})
export class EngineeringHubLayout {
  private readonly router = inject(Router);
  readonly auth = inject(PortalAuthService);
  readonly menuRights = inject(EngHubMenuRightsService);
  private readonly allNavItems = buildEngineeringHubNav();
  // Only the menus this user has been granted (see Menu Rights page).
  readonly navItems = computed(() => this.allNavItems.filter((item) => this.menuRights.menus().has(item.code)));

  // Off-canvas sidebar open/closed on narrow screens; irrelevant (sidebar
  // always visible) above the tablet breakpoint per the stylesheet.
  readonly sidebarOpen = signal(false);

  private readonly currentUrl = toSignal(
    this.router.events.pipe(
      filter((e): e is NavigationEnd => e instanceof NavigationEnd),
      map((e) => e.urlAfterRedirects),
      startWith(this.router.url)
    ),
    { initialValue: this.router.url }
  );

  isActive(item: EngHubNavItem): boolean {
    return this.isUrlActive(item.matchPrefixes);
  }

  isUrlActive(prefixes: string[]): boolean {
    const url = this.currentUrl();
    return prefixes.some((prefix) => url.startsWith(prefix));
  }

  toggleSidebar(): void {
    this.sidebarOpen.update((v) => !v);
  }

  closeSidebar(): void {
    this.sidebarOpen.set(false);
  }

  logout(): void {
    this.auth.logout();
    this.router.navigate(['/login']);
  }
}
