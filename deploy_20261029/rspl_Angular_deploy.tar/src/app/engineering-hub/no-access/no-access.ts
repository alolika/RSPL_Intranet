import { Component, computed, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { map } from 'rxjs';

import { buildEngineeringHubNav } from '../layout/engineering-hub-nav';
import { EngHubMenuRightsService } from '../menu-rights.service';

/** Shown when a user opens an Engineering Hub page whose menu they haven't
 * been granted (direct URL, or a link from a page they do have). */
@Component({
  selector: 'app-eng-hub-no-access',
  imports: [RouterLink],
  template: `
    <div class="page-card no-access">
      <i class="pi pi-lock"></i>
      <h2>Access not granted</h2>
      @if (menuLabel(); as label) {
        <p>You don't have rights to the <strong>{{ label }}</strong> menu in Engineering Hub.</p>
      } @else {
        <p>You don't have rights to this page in Engineering Hub.</p>
      }
      @if (menuRights.loaded() && menuRights.menus().size === 0) {
        <p class="hint">No Engineering Hub menus have been assigned to you yet.</p>
      }
      <p class="hint">Please contact your administrator to get access.</p>
      <a routerLink="/dashboard" class="back-link"><i class="pi pi-arrow-left"></i> Back to Portal</a>
    </div>
  `,
  styles: `
    .no-access {
      max-width: 520px;
      margin: 3rem auto;
      text-align: center;
      padding: 2.5rem 1.5rem;
    }
    .no-access > .pi {
      font-size: 2.5rem;
      color: #7c2d12;
    }
    h2 {
      margin: 0.75rem 0 0.5rem;
      color: #7c2d12;
    }
    p {
      margin: 0.35rem 0;
      color: #444;
    }
    .hint {
      color: #6b7280;
      font-size: 0.9rem;
    }
    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 0.4rem;
      margin-top: 1.25rem;
      color: #7c2d12;
      font-weight: 600;
      text-decoration: none;
    }
  `
})
export class NoAccess {
  private readonly route = inject(ActivatedRoute);
  readonly menuRights = inject(EngHubMenuRightsService);

  private readonly menuCode = toSignal(this.route.queryParamMap.pipe(map((p) => p.get('menu'))));
  readonly menuLabel = computed(() => buildEngineeringHubNav().find((i) => i.code === this.menuCode())?.label ?? null);
}
