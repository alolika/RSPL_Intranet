import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToCsv } from '../../shared/export-csv';
import { exportToPdf } from '../../shared/export-pdf';
import { EngineeringHubDataService, LookupOption, ReleaseProgressRow } from '../engineering-hub-data.service';

/** Release Progress — mapped Features/Dev Items per Release, and how many
 * of the Dev Items are already in a terminal (done) status. Product is an
 * optional filter narrowing which releases are shown. */
@Component({
  selector: 'app-report-release-progress',
  imports: [FormsModule, ButtonModule, SelectModule, TableModule],
  templateUrl: './report-release-progress.html',
  styleUrl: './report-release-progress.scss'
})
export class ReportReleaseProgress implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly location = inject(Location);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly rows = signal<ReleaseProgressRow[]>([]);
  readonly loading = signal(false);

  readonly products = signal<LookupOption[]>([]);
  productId: number | null = null;

  ngOnInit(): void {
    this.data.getProducts().subscribe((products) => {
      this.products.set(products);
      this.cdr.markForCheck();
    });
    this.load();
  }

  onProductChange(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.data.getReleaseProgress({ productId: this.productId ?? undefined }).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
      this.cdr.markForCheck();
    });
  }

  percentDone(row: ReleaseProgressRow): number {
    if (row.mappedDevItemCount === 0) {
      return 0;
    }
    return Math.round((row.devItemsDoneCount / row.mappedDevItemCount) * 100);
  }

  exportCsv(): void {
    exportToCsv('release-progress', this.rows());
  }

  exportPdf(): void {
    exportToPdf('release-progress', 'Release Progress', this.rows());
  }

  back(): void {
    this.location.back();
  }
}
