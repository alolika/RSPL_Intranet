import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { DevItemRow, EngineeringHubDataService, LookupOption, StatusOption } from '../engineering-hub-data.service';
import { formatTimeSpent } from '../shared/time-spent';

/** Development Items list — Product/Module/Feature filter (optional cascade),
 * Status filter, Add routes to the add-development-item form. */
@Component({
  selector: 'app-development-items',
  imports: [FormsModule, ButtonModule, CheckboxModule, SelectModule, TableModule],
  templateUrl: './development-items.html',
  styleUrl: './development-items.scss'
})
export class DevelopmentItems implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly location = inject(Location);
  // No zone.js — plain properties mutated inside subscribe callbacks need an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly products = signal<LookupOption[]>([]);
  readonly modules = signal<LookupOption[]>([]);
  readonly features = signal<LookupOption[]>([]);
  readonly statuses = signal<StatusOption[]>([]);
  readonly rows = signal<DevItemRow[]>([]);
  readonly loading = signal(false);

  productId: number | null = null;
  moduleId: number | null = null;
  featureId: number | null = null;
  statusId: number | null = null;
  includeClosed = false;

  // Backs the header's "Add Task" button — bound via p-table's [(selection)]
  // (selectionMode="single"), same pattern as the Features grid's "Add
  // Development Item" button.
  selectedDevItem: DevItemRow | null = null;

  ngOnInit(): void {
    this.data.getProducts().subscribe((products) => {
      this.products.set(products);
      this.cdr.markForCheck();
    });
    this.data.getStatuses('DevelopmentItem').subscribe((statuses) => this.statuses.set(statuses));
    this.load();
  }

  onProductChange(): void {
    this.moduleId = null;
    this.featureId = null;
    this.modules.set([]);
    this.features.set([]);
    if (this.productId) {
      this.data.getModules(this.productId).subscribe((modules) => {
        this.modules.set(modules);
        this.cdr.markForCheck();
      });
    }
    this.load();
  }

  onModuleChange(): void {
    this.featureId = null;
    this.features.set([]);
    if (this.moduleId) {
      this.data.getFeaturesLookup(this.moduleId).subscribe((features) => {
        this.features.set(features);
        this.cdr.markForCheck();
      });
    }
    this.load();
  }

  onFeatureChange(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    // A reload can change/narrow which rows exist (filters, Include Closed)
    // — clear any prior selection rather than leaving "Add Task" enabled for
    // a row that may no longer be in the grid.
    this.selectedDevItem = null;
    this.data
      .getDevelopmentItems(
        this.featureId ?? undefined, this.statusId ?? undefined, this.includeClosed,
        this.productId ?? undefined, this.moduleId ?? undefined
      )
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
        this.cdr.markForCheck();
      });
  }

  back(): void {
    this.location.back();
  }

  addDevelopmentItem(): void {
    this.router.navigate(['/engineering-hub/add-development-item']);
  }

  editDevelopmentItem(row: DevItemRow): void {
    this.router.navigate(['/engineering-hub/add-development-item'], { queryParams: { id: row.devItemId } });
  }

  viewDevelopmentItem(row: DevItemRow): void {
    this.router.navigate(['/engineering-hub/development-item-detail'], { queryParams: { id: row.devItemId } });
  }

  /** Same productId/moduleId/featureId/devItemId prefill contract as
   * Development Item detail's own "Add Task" button (add-task.ts reads
   * these four query params to preselect its Product > Module > Feature >
   * Dev Item cascade and set form.devItemId, so the new Task saves against
   * exactly the Development Item that was selected in the grid). DevItemRow
   * already carries productId/moduleId directly, no extra lookup needed. */
  /** row.actualMinutes is the backend's rollup of every duration-carrying
   * Activity attached to this Dev Item (directly or via one of its Tasks),
   * so it updates on its own the next time the grid reloads after new work
   * gets logged. See shared/time-spent.ts for the format itself. */
  readonly formatTimeSpent = formatTimeSpent;

  addTask(): void {
    if (!this.selectedDevItem) {
      return;
    }
    const d = this.selectedDevItem;
    this.router.navigate(['/engineering-hub/add-task'], {
      queryParams: { productId: d.productId, moduleId: d.moduleId, featureId: d.featureId, devItemId: d.devItemId }
    });
  }
}
