import { DecimalPipe, Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputNumberModule } from 'primeng/inputnumber';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToCsv } from '../../shared/export-csv';
import { exportToPdf } from '../../shared/export-pdf';
import { EngineeringHubDataService, LookupOption, SupportDrivenWorkRow } from '../engineering-hub-data.service';
import { QUICK_RANGE_OPTIONS, QuickRangeOption, computeQuickRange } from '../shared/quick-range';

/** Support-Driven Work — Development Items that originated from a Support
 * ticket, and how much effort has gone into each. Filters are independent
 * unscoped dropdowns (same non-cascading style as the My Tasks filter bar,
 * not a Product > Module > Feature cascade) since there's no Module level in
 * this report's own filter set. */
@Component({
  selector: 'app-report-support-driven-work',
  imports: [FormsModule, ButtonModule, DatePickerModule, InputNumberModule, SelectModule, TableModule, DecimalPipe],
  templateUrl: './report-support-driven-work.html',
  styleUrl: './report-support-driven-work.scss'
})
export class ReportSupportDrivenWork implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly location = inject(Location);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly rows = signal<SupportDrivenWorkRow[]>([]);
  readonly loading = signal(false);

  readonly products = signal<LookupOption[]>([]);
  readonly features = signal<LookupOption[]>([]);
  readonly devItems = signal<LookupOption[]>([]);
  readonly tasks = signal<LookupOption[]>([]);
  readonly users = signal<LookupOption[]>([]);

  productId: number | null = null;
  featureId: number | null = null;
  devItemId: number | null = null;
  taskId: number | null = null;
  ttNo: number | null = null;
  userId: number | null = null;

  dateFrom: Date | null = null;
  dateTo: Date | null = null;
  quickRangeOption: QuickRangeOption | null = null;
  readonly quickRangeOptions = QUICK_RANGE_OPTIONS;

  ngOnInit(): void {
    this.data.getProducts().subscribe((products) => {
      this.products.set(products);
      this.cdr.markForCheck();
    });
    this.data.getFeaturesLookup().subscribe((features) => this.features.set(features));
    this.data.getDevItemsLookup().subscribe((devItems) => this.devItems.set(devItems));
    this.data.getTasksLookup().subscribe((tasks) => this.tasks.set(tasks));
    this.data.getUsers().subscribe((users) => this.users.set(users));
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.data
      .getSupportDrivenWork({
        productId: this.productId ?? undefined,
        featureId: this.featureId ?? undefined,
        devItemId: this.devItemId ?? undefined,
        taskId: this.taskId ?? undefined,
        ttNo: this.ttNo ?? undefined,
        userId: this.userId ?? undefined,
        dateFrom: this.dateFrom ? this.dateFrom.toISOString() : undefined,
        dateTo: this.dateTo ? this.dateTo.toISOString() : undefined
      })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
        this.cdr.markForCheck();
      });
  }

  /** Fills From/To from the selected Quick Range option and refreshes the
   * grid immediately, same as My Tasks. */
  onQuickRangeChange(): void {
    const { from, to } = computeQuickRange(this.quickRangeOption);
    this.dateFrom = from;
    this.dateTo = to;
    this.load();
  }

  clearDateRange(): void {
    this.dateFrom = null;
    this.dateTo = null;
    this.quickRangeOption = null;
    this.load();
  }

  onDateRangeManualChange(): void {
    this.quickRangeOption = null;
    this.load();
  }

  hoursOf(minutes: number): number {
    return Math.round((minutes / 60) * 100) / 100;
  }

  exportCsv(): void {
    exportToCsv('support-driven-work', this.rows());
  }

  exportPdf(): void {
    exportToPdf('support-driven-work', 'Support-Driven Work', this.rows());
  }

  back(): void {
    this.location.back();
  }
}
