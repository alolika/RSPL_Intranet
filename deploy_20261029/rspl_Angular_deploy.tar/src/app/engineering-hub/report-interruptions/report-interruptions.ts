import { DatePipe, Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToCsv } from '../../shared/export-csv';
import { exportToPdf } from '../../shared/export-pdf';
import { EngineeringHubDataService, InterruptionReportRow } from '../engineering-hub-data.service';
import { QUICK_RANGE_OPTIONS, QuickRangeOption, computeQuickRange } from '../shared/quick-range';

/** Interruptions — who got interrupted, why, and what they switched to. */
@Component({
  selector: 'app-report-interruptions',
  imports: [FormsModule, ButtonModule, DatePickerModule, SelectModule, TableModule, DatePipe],
  templateUrl: './report-interruptions.html',
  styleUrl: './report-interruptions.scss'
})
export class ReportInterruptions implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly location = inject(Location);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly rows = signal<InterruptionReportRow[]>([]);
  readonly loading = signal(false);

  dateFrom: Date | null = null;
  dateTo: Date | null = null;
  quickRangeOption: QuickRangeOption | null = null;
  readonly quickRangeOptions = QUICK_RANGE_OPTIONS;

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.data
      .getInterruptionsReport({
        dateFrom: this.dateFrom ? this.dateFrom.toISOString() : undefined,
        dateTo: this.dateTo ? this.dateTo.toISOString() : undefined
      })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
        this.cdr.markForCheck();
      });
  }

  /** Fills From/To from the selected Quick Range option and refreshes the
   * grid immediately, same as My Tasks. */
  onQuickRangeChange(): void {
    const { from, to } = computeQuickRange(this.quickRangeOption);
    this.dateFrom = from;
    this.dateTo = to;
    this.load();
  }

  clearDateRange(): void {
    this.dateFrom = null;
    this.dateTo = null;
    this.quickRangeOption = null;
    this.load();
  }

  onDateRangeManualChange(): void {
    this.quickRangeOption = null;
    this.load();
  }

  exportCsv(): void {
    exportToCsv('interruptions', this.rows());
  }

  exportPdf(): void {
    exportToPdf('interruptions', 'Interruptions', this.rows());
  }

  back(): void {
    this.location.back();
  }
}
