import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';

import { exportToCsv } from '../../shared/export-csv';
import { exportToPdf } from '../../shared/export-pdf';
import { EngineeringHubDataService, ReleaseMappingRow, ReleaseNoteItem, ReleaseRow } from '../engineering-hub-data.service';

/** Release detail — mapped Features/Development Items with an Unmap action,
 * plus an auto-generated, exportable release-notes view (concatenated
 * titles/descriptions of everything mapped — generated on read, not stored,
 * per the approved design). */
@Component({
  selector: 'app-release-detail',
  imports: [ButtonModule, TableModule],
  templateUrl: './release-detail.html',
  styleUrl: './release-detail.scss'
})
export class ReleaseDetail implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly location = inject(Location);
  // No zone.js — plain properties mutated inside subscribe callbacks need an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly release = signal<ReleaseRow | null>(null);
  readonly mappings = signal<ReleaseMappingRow[]>([]);
  readonly notes = signal<ReleaseNoteItem[]>([]);

  private releaseId = 0;

  ngOnInit(): void {
    this.releaseId = Number(this.route.snapshot.queryParamMap.get('id') ?? 0);
    this.load();
  }

  private load(): void {
    this.data.getRelease(this.releaseId).subscribe((r) => {
      this.release.set(r);
      this.cdr.markForCheck();
    });
    this.data.getReleaseMappings(this.releaseId).subscribe((rows) => this.mappings.set(rows));
    this.data.getReleaseNotes(this.releaseId).subscribe((rows) => this.notes.set(rows));
  }

  unmap(row: ReleaseMappingRow): void {
    this.data.unmapFromRelease(this.releaseId, row.releaseMappingId).subscribe(() => this.load());
  }

  editRelease(): void {
    this.router.navigate(['/engineering-hub/add-release'], { queryParams: { id: this.releaseId } });
  }

  back(): void {
    this.location.back();
  }

  exportCsv(): void {
    const r = this.release();
    exportToCsv(`release-notes-${r?.name ?? this.releaseId}`, this.notes());
  }

  exportPdf(): void {
    const r = this.release();
    exportToPdf(`release-notes-${r?.name ?? this.releaseId}`, `Release Notes — ${r?.name ?? ''}`, this.notes());
  }
}
