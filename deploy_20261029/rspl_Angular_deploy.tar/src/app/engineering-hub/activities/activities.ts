import { DatePipe, Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { MultiSelectModule } from 'primeng/multiselect';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToCsv } from '../../shared/export-csv';
import { exportToPdf } from '../../shared/export-pdf';
import { ActivityBrowseRow, EngineeringHubDataService, LookupOption, StatusOption } from '../engineering-hub-data.service';
import { QUICK_RANGE_OPTIONS, QuickRangeOption, computeQuickRange } from '../shared/quick-range';

/** Activities — top-level "every activity ever logged" browse list.
 * Filter bar mirrors My Tasks exactly: the same 7 multi-selects (Product/
 * Module/Features/Development Items/Task Type/Status/Developer, all
 * unscoped lists with checkbox-based "Select All"), the same From Date/To
 * Date/Quick Range trio, and the same deferred-until-"Show" apply model —
 * Quick Range is the one control that still refreshes immediately on
 * selection, same exception as on Tasks. Activities themselves are always
 * created contextually (quick work-log, discussion, interruption) from the
 * Tasks list or a Feature/Dev Item detail page; this page is read-only. */
@Component({
  selector: 'app-activities',
  imports: [FormsModule, ButtonModule, SelectModule, MultiSelectModule, DatePickerModule, TableModule, DatePipe],
  templateUrl: './activities.html',
  styleUrl: './activities.scss'
})
export class Activities implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly router = inject(Router);
  private readonly location = inject(Location);
  // No zone.js — plain properties mutated inside subscribe callbacks need an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly activityTypes = signal<LookupOption[]>([]);
  readonly users = signal<LookupOption[]>([]);
  readonly rows = signal<ActivityBrowseRow[]>([]);
  readonly loading = signal(false);

  // Filter panel is collapsed by default, same as Tasks — the grid gets full
  // page space until the user opts to open it; nothing about filtering
  // itself changes based on whether the panel is open or closed.
  readonly filtersExpanded = signal(false);

  toggleFilters(): void {
    this.filtersExpanded.update((v) => !v);
  }

  // Same unscoped lookup lists as Tasks' filter bar.
  readonly filterProducts = signal<LookupOption[]>([]);
  readonly filterModules = signal<LookupOption[]>([]);
  readonly filterFeatures = signal<LookupOption[]>([]);
  readonly filterDevItems = signal<LookupOption[]>([]);
  readonly filterTaskTypes = signal<LookupOption[]>([]);
  readonly taskStatuses = signal<StatusOption[]>([]);

  activityTypeIds: number[] = [];
  loggedByUserIds: number[] = [];
  filterProductIds: number[] = [];
  filterModuleIds: number[] = [];
  filterFeatureIds: number[] = [];
  filterDevItemIds: number[] = [];
  filterTaskTypeIds: number[] = [];
  filterStatusIds: number[] = [];
  filterDeveloperUserIds: number[] = [];

  filterDateFrom: Date | null = null;
  filterDateTo: Date | null = null;
  quickRangeOption: QuickRangeOption | null = null;
  readonly quickRangeOptions = QUICK_RANGE_OPTIONS;

  ngOnInit(): void {
    this.data.getActivityTypes().subscribe((t) => this.activityTypes.set(t));
    this.data.getUsers().subscribe((u) => this.users.set(u));
    this.data.getProducts().subscribe((p) => this.filterProducts.set(p));
    this.data.getModules().subscribe((m) => this.filterModules.set(m));
    this.data.getFeaturesLookup().subscribe((f) => this.filterFeatures.set(f));
    this.data.getDevItemsLookup().subscribe((d) => this.filterDevItems.set(d));
    this.data.getTaskTypes().subscribe((t) => this.filterTaskTypes.set(t));
    this.data.getStatuses('Task').subscribe((s) => this.taskStatuses.set(s));
    this.load();
  }

  /** Bound to the "Show" button — every filter above only stages a change
   * locally (same deferred model as Tasks) until this actually re-queries. */
  showFiltered(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.data
      .browseActivities({
        activityTypeIds: this.activityTypeIds,
        loggedByUserIds: this.loggedByUserIds,
        productIds: this.filterProductIds,
        moduleIds: this.filterModuleIds,
        featureIds: this.filterFeatureIds,
        devItemIds: this.filterDevItemIds,
        taskTypeIds: this.filterTaskTypeIds,
        statusIds: this.filterStatusIds,
        developerUserIds: this.filterDeveloperUserIds,
        dateFrom: this.filterDateFrom ? this.toDateOnlyString(this.filterDateFrom) : undefined,
        dateTo: this.filterDateTo ? this.toDateOnlyString(this.filterDateTo) : undefined
      })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
        this.cdr.markForCheck();
      });
  }

  /** Sends a plain "YYYY-MM-DD" calendar date, not date.toISOString() —
   * converting through UTC shifts a locally-picked date onto the wrong day
   * for any user ahead of UTC (e.g. IST, +5:30). Same fix as Tasks. */
  private toDateOnlyString(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  /** Fills From/To from the selected Quick Range option and refreshes the
   * grid immediately — same exception to the deferred model as Tasks. */
  onQuickRangeChange(): void {
    const { from, to } = computeQuickRange(this.quickRangeOption);
    this.filterDateFrom = from;
    this.filterDateTo = to;
    this.load();
  }

  clearDateRange(): void {
    this.filterDateFrom = null;
    this.filterDateTo = null;
    this.quickRangeOption = null;
  }

  onDateRangeManualChange(): void {
    this.quickRangeOption = null;
  }

  linkLabel(row: ActivityBrowseRow): string {
    if (row.taskId) {
      return `Task: ${row.taskTitle}`;
    }
    if (row.devItemId) {
      return `Dev Item: ${row.devItemTitle}`;
    }
    if (row.featureId) {
      return `Feature: ${row.featureName}`;
    }
    return '-';
  }

  // Tasks have no standalone detail page in this app, so only
  // Feature/Dev-Item-linked rows are navigable.
  isLinkNavigable(row: ActivityBrowseRow): boolean {
    return !row.taskId && (!!row.devItemId || !!row.featureId);
  }

  goToLink(row: ActivityBrowseRow): void {
    if (row.devItemId) {
      this.router.navigate(['/engineering-hub/development-item-detail'], { queryParams: { id: row.devItemId } });
    } else if (row.featureId) {
      this.router.navigate(['/engineering-hub/feature-detail'], { queryParams: { id: row.featureId } });
    }
  }

  statusChange(row: ActivityBrowseRow): string {
    return row.newStatusName ? `${row.oldStatusName ?? '-'} → ${row.newStatusName}` : '-';
  }

  back(): void {
    this.location.back();
  }

  exportCsv(): void {
    exportToCsv('activities', this.rows());
  }

  exportPdf(): void {
    exportToPdf('activities', 'Activities', this.rows());
  }
}
