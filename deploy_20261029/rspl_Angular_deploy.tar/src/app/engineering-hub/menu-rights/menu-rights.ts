import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { forkJoin } from 'rxjs';

import { EngHubMenuCode, EngHubMenuOption, EngHubMenuRightsService, EngHubUserMenus } from '../menu-rights.service';

/**
 * Engineering Hub → Menu Rights (rights admins only). Pick a user, tick the
 * menus they should see, Save. A user sees only ticked menus; the grid below
 * lists everyone who has at least one menu.
 */
@Component({
  selector: 'app-eng-hub-menu-rights',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, MessageModule, SelectModule, TableModule],
  templateUrl: './menu-rights.html',
  styleUrl: './menu-rights.scss'
})
export class MenuRights implements OnInit {
  private readonly rights = inject(EngHubMenuRightsService);

  readonly menus = signal<EngHubMenuOption[]>([]);
  readonly users = signal<EngHubUserMenus[]>([]);
  readonly loading = signal(false);
  readonly saving = signal(false);
  readonly errorMessage = signal<string | null>(null);
  readonly successMessage = signal<string | null>(null);

  readonly selectedUserId = signal<number | null>(null);
  readonly selectedMenus = signal<Set<EngHubMenuCode>>(new Set());
  readonly search = signal('');

  readonly selectedUser = computed(() => this.users().find((u) => u.userId === this.selectedUserId()) ?? null);
  readonly allSelected = computed(() => this.menus().length > 0 && this.selectedMenus().size === this.menus().length);
  // Unsaved changes for the selected user — enables Save/Undo.
  readonly dirty = computed(() => {
    const user = this.selectedUser();
    if (!user) {
      return false;
    }
    const sel = this.selectedMenus();
    return sel.size !== user.menus.length || user.menus.some((m) => !sel.has(m));
  });

  readonly grantedUsers = computed(() => {
    const term = this.search().trim().toLowerCase();
    return this.users().filter((u) => u.menus.length > 0 && (!term || u.displayLabel.toLowerCase().includes(term)));
  });

  ngOnInit(): void {
    this.refresh();
  }

  refresh(): void {
    this.loading.set(true);
    this.errorMessage.set(null);
    forkJoin({ menus: this.rights.getAdminMenus(), users: this.rights.getAdminUsers() }).subscribe({
      next: ({ menus, users }) => {
        this.menus.set(menus);
        this.users.set(users);
        this.loading.set(false);
        this.resetSelection();
      },
      error: () => {
        this.loading.set(false);
        this.errorMessage.set('Could not load menu rights. Please try again.');
      }
    });
  }

  onUserChange(userId: number | null): void {
    this.selectedUserId.set(userId);
    this.successMessage.set(null);
    this.resetSelection();
  }

  editUser(user: EngHubUserMenus): void {
    this.onUserChange(user.userId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  isChecked(code: EngHubMenuCode): boolean {
    return this.selectedMenus().has(code);
  }

  toggle(code: EngHubMenuCode, checked: boolean): void {
    this.selectedMenus.update((set) => {
      const next = new Set(set);
      if (checked) {
        next.add(code);
      } else {
        next.delete(code);
      }
      return next;
    });
  }

  toggleAll(checked: boolean): void {
    this.selectedMenus.set(new Set(checked ? this.menus().map((m) => m.code) : []));
  }

  resetSelection(): void {
    this.selectedMenus.set(new Set(this.selectedUser()?.menus ?? []));
  }

  save(): void {
    const user = this.selectedUser();
    if (!user) {
      return;
    }
    // Keep canonical menu order in what we send/store.
    const menus = this.menus()
      .map((m) => m.code)
      .filter((c) => this.selectedMenus().has(c));
    this.saving.set(true);
    this.errorMessage.set(null);
    this.successMessage.set(null);
    this.rights.setUserMenus(user.userId, menus).subscribe({
      next: () => {
        this.saving.set(false);
        this.users.update((list) => list.map((u) => (u.userId === user.userId ? { ...u, menus } : u)));
        this.successMessage.set(`Menu rights saved for ${user.displayLabel}.`);
      },
      error: () => {
        this.saving.set(false);
        this.errorMessage.set('Could not save menu rights. Please try again.');
      }
    });
  }

  removeAll(user: EngHubUserMenus): void {
    if (!confirm(`Remove all Engineering Hub menus for ${user.displayLabel}?`)) {
      return;
    }
    this.errorMessage.set(null);
    this.successMessage.set(null);
    this.rights.setUserMenus(user.userId, []).subscribe({
      next: () => {
        this.users.update((list) => list.map((u) => (u.userId === user.userId ? { ...u, menus: [] } : u)));
        if (this.selectedUserId() === user.userId) {
          this.resetSelection();
        }
        this.successMessage.set(`All menus removed for ${user.displayLabel}.`);
      },
      error: () => this.errorMessage.set('Could not remove menu rights. Please try again.')
    });
  }

  menuLabel(code: EngHubMenuCode): string {
    return this.menus().find((m) => m.code === code)?.label ?? code;
  }
}
