import { DatePipe, DecimalPipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { PortalAuthService } from '../../core/auth/portal-auth.service';
import { exportToCsv } from '../../shared/export-csv';
import { DeveloperDashboard, EngineeringHubDataService, LookupOption } from '../engineering-hub-data.service';
import { EngHubMenuCode, EngHubMenuRightsService } from '../menu-rights.service';
import { QUICK_RANGE_OPTIONS, QuickRangeOption, computeQuickRange } from '../shared/quick-range';

/** One column of the "Hours by date" chart (a gap day has 0 minutes). */
interface DayBar {
  date: Date;
  minutes: number;
}

/** One row of a horizontal-bar breakdown (module / dev item type / task type). */
interface BarRow {
  label: string;
  sublabel?: string;
  minutes: number;
  /** Bar length as % of the largest row. */
  pct: number;
}

/** Engineering Hub dashboard — user-wise. Shows the logged-in user's own
 * work for a date range (default: current month): headline totals, hours by
 * date / module / development-item type / task type, task switches, open
 * tasks with deadlines, estimate vs actual, and the detailed work log. Only
 * users granted the "Dashboard: View All Developers" right (Menu Rights page,
 * DASHBOARD_ALL_USERS) get a Developer picker to view anyone's dashboard;
 * the API enforces this too. */
@Component({
  selector: 'app-eng-hub-dashboard',
  imports: [DecimalPipe, DatePipe, RouterLink, FormsModule, ButtonModule, DatePickerModule, SelectModule, TableModule],
  templateUrl: './eng-hub-dashboard.html',
  styleUrl: './eng-hub-dashboard.scss'
})
export class EngHubDashboard implements OnInit {
  private readonly data = inject(EngineeringHubDataService);
  private readonly menuRights = inject(EngHubMenuRightsService);
  private readonly auth = inject(PortalAuthService);
  // No zone.js — plain properties mutated inside subscribe callbacks need an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly dash = signal<DeveloperDashboard | null>(null);
  readonly loading = signal(false);
  readonly error = signal<string | null>(null);

  readonly canViewAll = computed(() => this.menuRights.has('DASHBOARD_ALL_USERS'));
  readonly users = signal<LookupOption[]>([]);
  selectedUserId: number | null = null;

  readonly quickRangeOptions = QUICK_RANGE_OPTIONS.filter((o) => o.value !== 'none');
  quickRangeOption: QuickRangeOption | null = 'today';
  dateFrom: Date | null = null;
  dateTo: Date | null = null;

  ngOnInit(): void {
    this.selectedUserId = this.auth.currentUser()?.userId ?? null;
    const r = computeQuickRange(this.quickRangeOption);
    this.dateFrom = r.from;
    this.dateTo = r.to;
    this.data.getUsers().subscribe((u) => {
      this.users.set(u);
      this.cdr.markForCheck();
    });
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.error.set(null);
    this.data
      .getDeveloperDashboard({
        userId: this.selectedUserId,
        dateFrom: this.toDateOnlyString(this.dateFrom),
        dateTo: this.toDateOnlyString(this.dateTo)
      })
      .subscribe({
        next: (d) => {
          this.dash.set(d);
          this.loading.set(false);
          this.cdr.markForCheck();
        },
        error: (err) => {
          this.error.set(err.error?.detail ?? 'Could not load the dashboard.');
          this.loading.set(false);
          this.cdr.markForCheck();
        }
      });
  }

  onQuickRangeChange(): void {
    if (!this.quickRangeOption) {
      return;
    }
    const r = computeQuickRange(this.quickRangeOption);
    this.dateFrom = r.from;
    this.dateTo = r.to;
    this.load();
  }

  onDateChange(): void {
    this.quickRangeOption = null;
    if (this.dateFrom && this.dateTo) {
      this.load();
    }
  }

  // ---- Derived chart data ----

  /** Every calendar day in the range (gap days = 0) when the range is up to
   * ~3 months; longer ranges show only the days that have work, so the
   * columns stay readable. */
  readonly dayBars = computed<DayBar[]>(() => {
    const d = this.dash();
    if (!d) {
      return [];
    }
    const byDate = new Map(d.byDate.map((x) => [x.date, x.minutes]));
    const from = this.fromDateOnlyString(d.dateFrom);
    const to = this.fromDateOnlyString(d.dateTo);
    const days: { date: Date; minutes: number }[] = [];
    const spanDays = Math.round((to.getTime() - from.getTime()) / 86400000) + 1;
    if (spanDays <= 93) {
      for (let i = 0; i < spanDays; i++) {
        const day = new Date(from.getFullYear(), from.getMonth(), from.getDate() + i);
        days.push({ date: day, minutes: byDate.get(this.toDateOnlyString(day)!) ?? 0 });
      }
    } else {
      for (const x of d.byDate) {
        days.push({ date: this.fromDateOnlyString(x.date), minutes: x.minutes });
      }
    }
    return days;
  });

  /** Y-axis top value (whole hours, at least 1). */
  readonly dayAxisMaxHours = computed(() => {
    const maxMin = Math.max(0, ...this.dayBars().map((b) => b.minutes));
    return Math.max(1, Math.ceil(maxMin / 60));
  });

  /** Bars are scaled to the axis max (not the raw max) so gridlines line up. */
  barHeightPct(minutes: number): number {
    return (minutes / (this.dayAxisMaxHours() * 60)) * 100;
  }

  /** Show every day's label for short ranges, every 7th otherwise. */
  showDayLabel(i: number): boolean {
    const n = this.dayBars().length;
    return n <= 16 || i % 7 === 0;
  }

  readonly moduleBars = computed<BarRow[]>(() =>
    this.toBars((this.dash()?.byModule ?? []).map((m) => ({ label: m.moduleName, sublabel: m.productName, minutes: m.minutes })))
  );
  readonly devItemTypeBars = computed<BarRow[]>(() =>
    this.toBars((this.dash()?.byDevItemType ?? []).map((m) => ({ label: m.name, minutes: m.minutes })))
  );
  readonly taskTypeBars = computed<BarRow[]>(() =>
    this.toBars((this.dash()?.byTaskType ?? []).map((m) => ({ label: m.name, minutes: m.minutes })))
  );

  private toBars(rows: { label: string; sublabel?: string; minutes: number }[]): BarRow[] {
    const max = Math.max(1, ...rows.map((r) => r.minutes));
    return rows.map((r) => ({ ...r, pct: (r.minutes / max) * 100 }));
  }

  readonly avgMinutesPerDay = computed(() => {
    const d = this.dash();
    return d && d.daysWorked > 0 ? d.totalMinutes / d.daysWorked : 0;
  });

  readonly viewingSelf = computed(() => {
    const d = this.dash();
    return !d || d.userId === this.auth.currentUser()?.userId;
  });

  // ---- Formatting ----

  hours(minutes: number | null | undefined): string {
    const h = (minutes ?? 0) / 60;
    return h === 0 ? '0' : h.toFixed(h < 10 ? 1 : 0).replace(/\.0$/, '');
  }

  overdueLabel(days: number | null): string {
    if (days === null) {
      return 'No deadline';
    }
    return days > 0 ? `${days} day${days === 1 ? '' : 's'}` : 'Not overdue';
  }

  /** Time Variance (hrs) = total time spent − estimate. Positive = over the
   * estimate, negative = under; null when the task has no estimate. */
  variance(e: { estimatedHours: number | null; totalMinutes: number }): number | null {
    return e.estimatedHours === null ? null : e.totalMinutes / 60 - e.estimatedHours;
  }

  /** "+1.5" / "-0.5" / "0" — the sign carries over/under, not just the color. */
  varianceLabel(e: { estimatedHours: number | null; totalMinutes: number }): string {
    const v = this.variance(e);
    if (v === null) {
      return '-';
    }
    const r = Math.round(v * 10) / 10;
    return r > 0 ? `+${r}` : `${r}`;
  }

  /** Over the estimate = spent more than estimated. */
  isOverEstimate(estimatedHours: number | null, minutes: number): boolean {
    return estimatedHours !== null && minutes > estimatedHours * 60;
  }

  exportWorkLog(): void {
    const d = this.dash();
    if (!d) {
      return;
    }
    exportToCsv(
      `work-log-${d.userName.replace(/\s+/g, '-').toLowerCase()}-${d.dateFrom}-to-${d.dateTo}`,
      d.workLog.map((w) => ({
        'Date/Time': new Date(w.occurredAt).toLocaleString('en-IN'),
        Activity: w.activityType,
        Task: w.taskTitle ?? '',
        'Development Item': w.devItemTitle ?? '',
        Module: w.moduleName ?? '',
        Minutes: w.minutes ?? '',
        Remark: w.description ?? ''
      }))
    );
  }

  // Tiles/quick actions only link to menus this user has been granted.
  can(code: EngHubMenuCode): boolean {
    return this.menuRights.has(code);
  }

  /** Plain "YYYY-MM-DD" (never toISOString(), which shifts IST dates a day back). */
  private toDateOnlyString(d: Date | null): string | null {
    if (!d) {
      return null;
    }
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  private fromDateOnlyString(s: string): Date {
    const [y, m, d] = s.slice(0, 10).split('-').map(Number);
    return new Date(y, m - 1, d);
  }
}
