/**
 * Google Maps JavaScript API key. Left blank in this frontend-only phase —
 * the source app's CustHeatMap/CustMapLocation/EntityLatLong pages load
 * Google Maps client-side with no key management of their own. Set a real
 * key here once one is provisioned; pages fall back to a data-table view
 * with a notice when this is empty.
 */
export const GOOGLE_MAPS_API_KEY = '';
