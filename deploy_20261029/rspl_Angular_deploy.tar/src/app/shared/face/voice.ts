export function greeting(firstName: string, at: Date = new Date()): string {
  const hour = at.getHours();
  const period = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening';
  const name = firstName.trim();
  return name ? `Good ${period}, ${name}` : `Good ${period}`;
}

function hasSpeech(): boolean {
  return (
    typeof window !== 'undefined' &&
    'speechSynthesis' in window &&
    typeof SpeechSynthesisUtterance === 'function'
  );
}

export function primeSpeech(): void {
  if (!hasSpeech()) return;
  try {
    window.speechSynthesis.getVoices();
    const silent = new SpeechSynthesisUtterance(' ');
    silent.volume = 0;
    silent.rate = 1;
    window.speechSynthesis.speak(silent);
  } catch {
    // Non-fatal
  }
}

export function speakGreeting(firstName: string, at: Date = new Date()): void {
  if (!hasSpeech()) return;
  const utterance = new SpeechSynthesisUtterance(greeting(firstName, at));
  utterance.rate = 1;
  utterance.pitch = 1;
  utterance.volume = 1;
  window.speechSynthesis.speak(utterance);
}
