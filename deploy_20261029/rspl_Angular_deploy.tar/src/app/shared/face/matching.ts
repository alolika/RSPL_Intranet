import { EnrolledFace } from './face.models';

export interface FaceMatch {
  face: EnrolledFace;
  similarity: number;
}

export function cosineSimilarity(a: ArrayLike<number>, b: ArrayLike<number>): number {
  if (a.length !== b.length || a.length === 0) return 0;
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  if (normA === 0 || normB === 0) return 0;
  return dot / Math.sqrt(normA * normB);
}

export function topMatch(
  descriptor: ArrayLike<number>,
  enrolled: Iterable<EnrolledFace>,
): FaceMatch | null {
  let best: FaceMatch | null = null;
  for (const face of enrolled) {
    let perFace = -Infinity;
    for (const template of face.embeddings) {
      const sim = cosineSimilarity(descriptor, template);
      if (sim > perFace) perFace = sim;
    }
    if (perFace > (best?.similarity ?? -Infinity)) best = { face, similarity: perFace };
  }
  return best;
}

export function bestMatch(
  descriptor: ArrayLike<number>,
  enrolled: Iterable<EnrolledFace>,
  threshold: number,
): FaceMatch | null {
  const top = topMatch(descriptor, enrolled);
  return top && top.similarity >= threshold ? top : null;
}
