import { Injectable } from '@angular/core';

const MODEL_URL = '/face-models';
export const FACE_DESCRIPTOR_LENGTH = 128;

// Minimal local types — mirrors what @vladmandic/face-api exports,
// defined here so Angular's compiler never needs to statically resolve
// that package (which lacks an `exports` field and breaks bundler-mode
// module resolution in the Angular compiler plugin).
export interface FaceBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface FacePoint {
  x: number;
  y: number;
}

export interface FaceLandmarks {
  positions: FacePoint[];
}

export interface FaceDetectionResult {
  score: number;
  box: FaceBox;
  landmarks: FaceLandmarks;
  descriptor: Float32Array;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type FaceApi = any;

@Injectable({ providedIn: 'root' })
export class FaceApiService {
  private loader: Promise<FaceApi> | null = null;

  private async api(): Promise<FaceApi> {
    if (!this.loader) {
      // Dynamic import so TypeScript never statically resolves the module.
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      this.loader = (import('@vladmandic/face-api' as any) as Promise<FaceApi>).then(
        async (fa: FaceApi) => {
          await Promise.all([
            fa.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
            fa.nets.faceLandmark68TinyNet.loadFromUri(MODEL_URL),
            fa.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
          ]);
          return fa;
        },
      );
    }
    return this.loader;
  }

  async ensureReady(): Promise<void> {
    await this.api();
  }

  async detect(
    source: HTMLVideoElement | HTMLCanvasElement | HTMLImageElement,
  ): Promise<FaceDetectionResult | null> {
    const fa = await this.api();
    const options = new fa.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 });
    const result = await fa
      .detectSingleFace(source, options)
      .withFaceLandmarks(true)
      .withFaceDescriptor();
    if (!result) return null;
    return {
      score: result.detection.score,
      box: result.detection.box,
      landmarks: result.landmarks,
      descriptor: result.descriptor,
    };
  }

  eyeAspectRatio(landmarks: FaceLandmarks): number {
    const points = landmarks.positions;
    const left = ear(points.slice(36, 42));
    const right = ear(points.slice(42, 48));
    return (left + right) / 2;
  }

  async cropToJpeg(source: HTMLVideoElement, box: FaceBox, side: number, quality = 0.9): Promise<Blob> {
    const pad = 0.3;
    const sx = Math.max(0, box.x - box.width * pad);
    const sy = Math.max(0, box.y - box.height * pad);
    const sw = Math.min(source.videoWidth - sx, box.width * (1 + 2 * pad));
    const sh = Math.min(source.videoHeight - sy, box.height * (1 + 2 * pad));
    const canvas = document.createElement('canvas');
    canvas.width = side;
    canvas.height = side;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D context unavailable');
    ctx.drawImage(source, sx, sy, sw, sh, 0, 0, side, side);
    return new Promise<Blob>((resolve, reject) => {
      canvas.toBlob(
        (blob) => (blob ? resolve(blob) : reject(new Error('Canvas toBlob returned null'))),
        'image/jpeg',
        quality,
      );
    });
  }
}

function ear(eye: FacePoint[]): number {
  const v1 = dist(eye[1], eye[5]);
  const v2 = dist(eye[2], eye[4]);
  const h = dist(eye[0], eye[3]) * 2;
  return h === 0 ? 0 : (v1 + v2) / h;
}

function dist(a: FacePoint, b: FacePoint): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}
