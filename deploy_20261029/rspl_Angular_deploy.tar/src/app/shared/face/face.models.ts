export interface EnrolledFace {
  memberId: string;
  memberName: string;
  firstName: string;
  embeddings: number[][];
  photoUrl: string;
  faceRegisteredAt: string;
}

export interface FaceEmbeddingsResponse {
  faces: EnrolledFace[];
  etag: string;
}

export interface FaceEnrolResponse {
  memberId: string;
  faceRegisteredAt: string;
  photoUrl: string;
}

export interface FaceAttendanceResponse {
  employeeId: string;
  memberName: string;
  firstName: string;
  alreadyMarked: boolean;
  arrivalTime: string;
  confidence: number;
  lat?: number;
  lng?: number;
  city?: string;
}

export interface FaceCheckoutResponse {
  employeeId: string;
  memberName: string;
  firstName: string;
  departureTime: string;
  alreadyCheckedOut: boolean;
}
