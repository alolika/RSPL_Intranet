import { Component, computed, inject, input, signal } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';

/**
 * Touch-friendly drawer nav for narrow (phone/APK) viewports, used by all
 * three shells (main/agile/recruitment) alongside their existing <p-menubar>.
 * Takes the same MenuItem[] each shell already builds for the desktop menu —
 * no changes to main-nav.ts/agile-nav.ts/recruitment-nav.ts needed. Hidden
 * entirely above the app's bp.mobile breakpoint (480px, see mobile-nav.scss)
 * so the desktop/tablet menubar is untouched.
 */
@Component({
  selector: 'app-mobile-nav',
  templateUrl: './mobile-nav.html',
  styleUrl: './mobile-nav.scss'
})
export class MobileNav {
  private readonly router = inject(Router);

  readonly items = input.required<MenuItem[]>();

  readonly open = signal(false);
  private readonly pathIndices = signal<number[]>([]);

  readonly currentLevel = computed(() => this.pathIndices().length);

  readonly currentItems = computed<MenuItem[]>(() => {
    let list = this.items();
    for (const idx of this.pathIndices()) {
      list = list[idx]?.items ?? [];
    }
    return list;
  });

  // Full ancestor trail for the breadcrumb bar, e.g.
  // [{label:'Home', level:0}, {label:'Master', level:1}, {label:'Student Master', level:2}].
  // `level` is the pathIndices length that crumb jumps back to when tapped.
  readonly breadcrumbTrail = computed<{ label: string; level: number }[]>(() => {
    const trail = [{ label: 'Home', level: 0 }];
    let list = this.items();
    const indices = this.pathIndices();
    for (let i = 0; i < indices.length; i++) {
      const item = list[indices[i]];
      if (!item) break;
      trail.push({ label: item.label ?? '', level: i + 1 });
      list = item.items ?? [];
    }
    return trail;
  });

  // Label -> primeicon, keyed lowercase. Falls back to a folder/file icon
  // by whether the item has children, so any label not listed here still
  // gets a sensible icon rather than none at all.
  private readonly iconMap: Record<string, string> = {
    dashboard: 'pi-home',
    home: 'pi-home',
    marketing: 'pi-megaphone',
    developer: 'pi-code',
    admin: 'pi-shield',
    accounts: 'pi-wallet',
    support: 'pi-headphones',
    general: 'pi-th-large',
    reports: 'pi-chart-bar',
    gst: 'pi-percentage',
    help: 'pi-question-circle',
    project: 'pi-briefcase',
    'product backlog': 'pi-list',
    'sprint planning': 'pi-calendar',
    'story master': 'pi-book',
    'test management': 'pi-check-square',
    masters: 'pi-cog',
    appreciation: 'pi-heart',
    'disc profile': 'pi-id-card',
    'question paper': 'pi-file-edit',
    features: 'pi-folder',
    'development items': 'pi-wrench',
    tasks: 'pi-check-square',
    activities: 'pi-file-edit',
    decisions: 'pi-exclamation-triangle',
    releases: 'pi-send'
  };

  toggle(): void {
    this.open.update((v) => !v);
  }

  close(): void {
    this.open.set(false);
    this.pathIndices.set([]);
  }

  back(): void {
    this.pathIndices.update((p) => p.slice(0, -1));
  }

  // Jump straight to any ancestor level tapped in the breadcrumb trail
  // (level 0 = root/"Home", matching breadcrumbTrail()'s `level` values).
  goToLevel(level: number): void {
    this.pathIndices.update((p) => p.slice(0, level));
  }

  hasChildren(item: MenuItem): boolean {
    return !!item.items && item.items.length > 0;
  }

  // A handful of items (e.g. main-nav's "Org Chart") are both a real link
  // AND a group with children - those get a split row (navigate vs expand)
  // in the template instead of one ambiguous tap target.
  isDualAction(item: MenuItem): boolean {
    return !!item.routerLink && this.hasChildren(item);
  }

  iconFor(item: MenuItem): string {
    const key = (item.label ?? '').trim().toLowerCase();
    return this.iconMap[key] ?? (this.hasChildren(item) ? 'pi-folder' : 'pi-file');
  }

  activate(item: MenuItem): void {
    if (item.routerLink) {
      this.navigate(item);
    } else if (this.hasChildren(item)) {
      this.drillInto(item);
    }
  }

  drillInto(item: MenuItem): void {
    const idx = this.currentItems().indexOf(item);
    if (idx === -1) return;
    this.pathIndices.update((p) => [...p, idx]);
  }

  navigate(item: MenuItem): void {
    const link = item.routerLink;
    if (!link) return;
    const commands = Array.isArray(link) ? link : [link];
    this.router.navigate(commands, item.queryParams ? { queryParams: item.queryParams } : {});
    this.close();
  }
}
