import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

/**
 * Mirrors App_Master/Index.master: logo + content + copyright, no nav menu,
 * no login state. Used by the source's unauthenticated email-action-link
 * pages (LeaveSanction, LeaveSanctionCancellation) reached via a mailed
 * link rather than through the portal menu.
 */
@Component({
  selector: 'app-bare-layout',
  imports: [RouterOutlet],
  template: `
    <header class="bare-header">
      <img src="/assets/retailware-logo.png" alt="Retailware" onerror="this.style.display='none'" />
    </header>
    <hr />
    <main class="page-content">
      <router-outlet />
    </main>
    <footer class="bare-footer">
      <hr />
      <p>Copyright &copy; Retailware Softech Pvt Ltd Pune - All Rights Reserved.</p>
    </footer>
  `,
  styles: [
    `
      .bare-header {
        display: flex;
        justify-content: center;
        padding: 1rem;
      }
      .page-content {
        padding: 1.5rem;
        min-height: 60vh;
      }
      .bare-footer {
        text-align: center;
        color: var(--p-text-muted-color);
        font-size: 0.85rem;
        padding-bottom: 2rem;
      }
    `
  ]
})
export class BareLayout {}
