import { Pipe, PipeTransform } from '@angular/core';

/**
 * Drop-in replacement for Angular's built-in `number` pipe, but grouping
 * digits the Indian way (lakh/crore: comma every 2 digits after the leading
 * 3 — "1,00,000.00") instead of the Western every-3 grouping Angular's
 * default 'en-US' locale produces ("100,000.00"). Takes the same
 * `digitsInfo` string (`'{minIntegerDigits}.{minFractionDigits}-{maxFractionDigits}'`)
 * as the built-in pipe so existing `| number: '1.2-2'` usages convert to
 * `| inrNumber: '1.2-2'` with no other template changes. Values that arrive
 * as backend-preformatted strings (e.g. "1,559,120") are re-parsed first so
 * they always end up in Indian grouping regardless of how the source
 * formatted them.
 */
@Pipe({ name: 'inrNumber', standalone: true })
export class IndianNumberPipe implements PipeTransform {
  transform(value: unknown, digitsInfo = '1.0-3'): string {
    if (value === null || value === undefined || value === '') {
      return '';
    }
    const n = typeof value === 'number' ? value : Number(String(value).replace(/,/g, ''));
    if (!Number.isFinite(n)) {
      return String(value);
    }
    const fractionPart = digitsInfo.split('.')[1] ?? '0-3';
    const [minFractionStr, maxFractionStr] = fractionPart.split('-');
    const minimumFractionDigits = Number(minFractionStr) || 0;
    const maximumFractionDigits = maxFractionStr !== undefined ? Number(maxFractionStr) : minimumFractionDigits;
    return n.toLocaleString('en-IN', { minimumFractionDigits, maximumFractionDigits });
  }
}
