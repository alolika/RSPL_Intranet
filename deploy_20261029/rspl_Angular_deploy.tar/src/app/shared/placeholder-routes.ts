import { Routes } from '@angular/router';

import { ComingSoon } from './coming-soon/coming-soon';

/**
 * Builds one placeholder route per [path, title] pair, all rendering
 * ComingSoon until the real page is migrated. Used to keep every source
 * page reachable (and checklist-verifiable) from day one, per section.
 */
export function placeholderRoutes(entries: Array<[path: string, title: string]>): Routes {
  return entries.map(([path, title]) => ({
    path,
    component: ComingSoon,
    data: { title }
  }));
}
