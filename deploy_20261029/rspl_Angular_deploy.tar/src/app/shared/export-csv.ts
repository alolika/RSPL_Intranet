/** Client-side CSV export, same rows/columns already on screen — no server round-trip. */
export function exportToCsv<T extends object>(fileName: string, rows: readonly T[]): void {
  if (rows.length === 0) {
    return;
  }
  const columns = Object.keys(rows[0]);
  const escape = (value: unknown): string => {
    const s = value == null ? '' : String(value);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [columns.map(escape).join(','), ...rows.map((row) => columns.map((c) => escape((row as Record<string, unknown>)[c])).join(','))];
  const blob = new Blob([lines.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${fileName}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}
