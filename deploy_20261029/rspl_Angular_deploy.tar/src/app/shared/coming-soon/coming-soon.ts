import { Component, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute } from '@angular/router';
import { map } from 'rxjs';

@Component({
  selector: 'app-coming-soon',
  template: `
    <div class="coming-soon">
      <i class="pi pi-hammer"></i>
      <h2>{{ title() }}</h2>
      <p>This page hasn't been migrated from the source ASP.NET app yet.</p>
    </div>
  `,
  styles: [
    `
      .coming-soon {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        padding: 4rem 1rem;
        color: var(--p-text-muted-color);
        text-align: center;
      }
      .pi {
        font-size: 2.5rem;
      }
      h2 {
        margin: 0;
      }
    `
  ]
})
export class ComingSoon {
  private readonly route = inject(ActivatedRoute);
  readonly title = toSignal(
    this.route.data.pipe(map((d) => (d['title'] as string) ?? 'Coming soon')),
    { initialValue: 'Coming soon' }
  );
}
