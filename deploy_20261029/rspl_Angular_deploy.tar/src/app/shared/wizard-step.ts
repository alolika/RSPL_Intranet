import { WritableSignal } from '@angular/core';

/**
 * One step of a `p-stepper` wizard (see cust-registration for the reference
 * implementation). `validate` mirrors the existing alert()-based checks each
 * form's save() method already did — just relocated to run when the user
 * tries to leave this step instead of only at the very end.
 */
export interface WizardStep {
  value: number;
  label: string;
  validate?: () => boolean;
}

/**
 * Drives a wizard's `activeStep` signal (bound via `<p-stepper [(value)]>`).
 * Moving forward validates every step strictly between the current one and
 * the target, stopping at the first failure (so its own alert() is what the
 * user sees). Moving backward is always unguarded — a user should never be
 * blocked from reviewing/editing an earlier step.
 */
export function goToStep(current: WritableSignal<number>, steps: readonly WizardStep[], target: number): void {
  const from = current();
  if (target > from) {
    for (let i = from; i < target; i++) {
      if (steps[i]?.validate && !steps[i].validate!()) {
        return;
      }
    }
  }
  current.set(target);
}
