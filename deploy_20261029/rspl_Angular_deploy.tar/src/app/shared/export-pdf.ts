import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

/** Client-side PDF export, same rows/columns already on screen — no server round-trip. */
export function exportToPdf<T extends object>(fileName: string, title: string, rows: readonly T[]): void {
  if (rows.length === 0) {
    return;
  }
  const columns = Object.keys(rows[0]);
  const doc = new jsPDF({ orientation: columns.length > 6 ? 'landscape' : 'portrait' });
  doc.setFontSize(12);
  doc.text(title, 14, 12);
  autoTable(doc, {
    startY: 18,
    head: [columns],
    body: rows.map((row) => columns.map((c) => String((row as Record<string, unknown>)[c] ?? ''))),
    styles: { fontSize: 8 },
    headStyles: { fillColor: [166, 25, 46] }
  });
  doc.save(`${fileName}.pdf`);
}
