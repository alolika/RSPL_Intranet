import * as XLSX from 'xlsx';

/** One exported column: header text plus how to read that column's display value off a row. */
export interface ExcelColumn<T> {
  header: string;
  value: (row: T) => string | number | null;
}

// Matches a plain ISO date ("2026-08-01") or a full ISO datetime
// ("2026-08-01T00:00:00", optionally with milliseconds/Z/offset) — the raw
// shape every date field in every row object across this app actually holds
// at export time (confirmed project-wide: no component pre-formats a date to
// a display string, or uses a native Date object, before it reaches here).
// Deliberately conservative — a plain number-shaped string or unrelated text
// containing a year (e.g. "2026 not a date") never matches.
const ISO_DATE_RE = /^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:?\d{2})?)?$/;

// Per explicit project-wide request: every exported date must display as
// dd-MMM-yyyy (e.g. "01-Aug-2026") AND be a genuine Excel date cell — sortable
// and filterable as a date in Excel, not text that merely looks like one.
// Converts any ISO-date-shaped string into a real JS Date (local-time
// midnight from the raw y/m/d parts, NOT `new Date(isoString)` — parsing a
// date-only ISO string that way treats it as UTC midnight, which can roll
// back a day once re-interpreted in a timezone behind UTC).
function toDateAwareValue(value: unknown): unknown {
  if (typeof value !== 'string' || !ISO_DATE_RE.test(value)) {
    return value;
  }
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(value);
  if (!match) {
    return value;
  }
  const parsed = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  return Number.isNaN(parsed.getTime()) ? value : parsed;
}

/**
 * Client-side replacement for the source app's server-side ClassExport
 * (App_Code/CS/ClassExport.cs), used by dozens of RadGrid "ExportToExcel"
 * buttons. Exports whatever rows/columns are currently shown, same as the
 * source's ExportSettings.IgnorePaging pattern (exports full filtered set,
 * not just the current page).
 *
 * Without `columns`, exports the raw row objects as-is (legacy behavior,
 * still used by most callers). Pass `columns` to make the workbook mirror a
 * specific on-screen grid exactly — same header text/order and the same
 * formatted/computed values shown in the UI, rather than raw field names.
 *
 * Every value (either path) is passed through toDateAwareValue() and any
 * resulting date cell gets Excel's own "dd-mmm-yyyy" number format stamped
 * on afterward — one place handles the whole project's date columns,
 * including the dynamic Record<string, unknown> report pages where column
 * names aren't known ahead of time, without needing to touch any of the 25+
 * individual call sites.
 */
export function exportToExcel<T extends object>(fileName: string, rows: readonly T[], columns?: readonly ExcelColumn<T>[]): void {
  const dateColumns = new Set<string>();

  const plainRows: Record<string, unknown>[] = columns?.length
    ? rows.map((row) => {
        const out: Record<string, unknown> = {};
        for (const col of columns) {
          const converted = toDateAwareValue(col.value(row));
          if (converted instanceof Date) {
            dateColumns.add(col.header);
          }
          out[col.header] = converted;
        }
        return out;
      })
    : rows.map((row) => {
        const out: Record<string, unknown> = {};
        for (const [key, value] of Object.entries(row)) {
          const converted = toDateAwareValue(value);
          if (converted instanceof Date) {
            dateColumns.add(key);
          }
          out[key] = converted;
        }
        return out;
      });

  // Explicit header order — columns' own order when given, otherwise the
  // union of every row's own keys in first-seen order (the same order
  // json_to_sheet would infer on its own, but now something WE know too, so
  // date columns can be found by their exact column index afterward instead
  // of guessing from whatever default number format SheetJS happens to
  // assign a Date-valued cell internally.
  const header = columns?.length ? columns.map((c) => c.header) : Array.from(new Set(plainRows.flatMap((r) => Object.keys(r))));

  const worksheet = XLSX.utils.json_to_sheet(plainRows, { header });

  header.forEach((key, colIndex) => {
    if (!dateColumns.has(key)) {
      return;
    }
    for (let rowIndex = 0; rowIndex < plainRows.length; rowIndex++) {
      const cell = worksheet[XLSX.utils.encode_cell({ r: rowIndex + 1, c: colIndex })];
      if (cell) {
        cell.z = 'dd-mmm-yyyy';
      }
    }
  });

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
  XLSX.writeFile(workbook, `${fileName}.xlsx`);
}
