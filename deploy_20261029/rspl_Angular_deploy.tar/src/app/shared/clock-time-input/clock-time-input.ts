import { ChangeDetectorRef, Component, forwardRef, inject } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

/**
 * Clock-style hour/minute stepper with an AM/PM toggle — replaces
 * p-datepicker[timeOnly] (reported hard to use: tiny 24-hour spinner
 * arrows) across the Customer Enquiry Action form's three time fields.
 * Implements ControlValueAccessor so it drops into [(ngModel)] exactly
 * like any other input, bound to a plain 24-hour "HH:mm" string — the
 * same format the backend's @ActionTime/@CompletedTime parameters already
 * expect, so no conversion is needed at the call site.
 *
 * Minute steps by 1 (not 5) even though real saved values land on all
 * sorts of minutes (e.g. "17:57", "13:02", "11:56" — confirmed against
 * live data) — a 5-minute step would make some already-saved times
 * unreachable by the stepper alone. The numeric fields are also directly
 * typable for fast entry; the arrows are for fine adjustment.
 */
@Component({
  selector: 'app-clock-time-input',
  standalone: true,
  templateUrl: './clock-time-input.html',
  styleUrl: './clock-time-input.scss',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => ClockTimeInput),
      multi: true
    }
  ]
})
export class ClockTimeInput implements ControlValueAccessor {
  // No zone.js in this app: ngModel calls writeValue asynchronously, after
  // the parent's change detection has already run, so without an explicit
  // markForCheck the new time (e.g. a defaulted "current time") never
  // reached the screen until some unrelated click re-rendered the view.
  private readonly cdr = inject(ChangeDetectorRef);
  hour12 = 12;
  minute = 0;
  ampm: 'AM' | 'PM' = 'AM';
  // Blank until a real value comes in (writeValue) or the user actually
  // interacts — mirrors the native time input's own empty-until-touched
  // behavior instead of always showing a misleading default of 12:00 AM.
  hasValue = false;
  disabled = false;

  private onChange: (value: string) => void = () => {};
  private onTouched: () => void = () => {};

  writeValue(value: string | null): void {
    if (!value) {
      this.hasValue = false;
      this.hour12 = 12;
      this.minute = 0;
      this.ampm = 'AM';
      this.cdr.markForCheck();
      return;
    }
    const match = /(\d{1,2}):(\d{2})/.exec(value);
    if (!match) {
      this.hasValue = false;
      this.cdr.markForCheck();
      return;
    }
    const h24 = Number(match[1]);
    this.minute = Number(match[2]);
    this.ampm = h24 >= 12 ? 'PM' : 'AM';
    this.hour12 = h24 % 12 || 12;
    this.hasValue = true;
    this.cdr.markForCheck();
  }

  registerOnChange(fn: (value: string) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
    this.cdr.markForCheck();
  }

  private emit(): void {
    this.hasValue = true;
    let h24 = this.hour12 % 12;
    if (this.ampm === 'PM') {
      h24 += 12;
    }
    const hh = String(h24).padStart(2, '0');
    const mm = String(this.minute).padStart(2, '0');
    this.onChange(`${hh}:${mm}`);
    this.onTouched();
  }

  stepHour(dir: 1 | -1): void {
    if (this.disabled) {
      return;
    }
    this.hour12 = ((this.hour12 - 1 + dir + 12) % 12) + 1;
    this.emit();
  }

  stepMinute(dir: 1 | -1): void {
    if (this.disabled) {
      return;
    }
    this.minute = (this.minute + dir + 60) % 60;
    this.emit();
  }

  onHourInput(raw: string): void {
    const n = Number(raw);
    if (!Number.isFinite(n)) {
      return;
    }
    this.hour12 = Math.min(12, Math.max(1, Math.round(n)));
    this.emit();
  }

  onMinuteInput(raw: string): void {
    const n = Number(raw);
    if (!Number.isFinite(n)) {
      return;
    }
    this.minute = Math.min(59, Math.max(0, Math.round(n)));
    this.emit();
  }

  setAmPm(value: 'AM' | 'PM'): void {
    if (this.disabled) {
      return;
    }
    this.ampm = value;
    this.emit();
  }

  hourDisplay(): string {
    return String(this.hour12).padStart(2, '0');
  }

  minuteDisplay(): string {
    return String(this.minute).padStart(2, '0');
  }
}
