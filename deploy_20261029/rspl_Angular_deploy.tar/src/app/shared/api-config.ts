import { environment } from '../../environments/environment';

/** Base URL for the FastAPI backend. Switches via Angular's fileReplacements
 * (see angular.json): environment.development.ts for `ng serve`, environment.ts
 * for `ng build --configuration production`. */
export const API_BASE_URL = environment.apiBaseUrl;
