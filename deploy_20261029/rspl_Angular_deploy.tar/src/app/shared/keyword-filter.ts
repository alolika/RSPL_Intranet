import { FilterService } from 'primeng/api';

/**
 * Registers a 'keywordAll' PrimeNG filter mode: splits the typed text into
 * words and requires each to appear somewhere in the option label, in any
 * order (e.g. "maha ino" matches "Mahaveer Inovation..."). PrimeNG's p-select
 * always re-filters its `options` list client-side using the typed text as
 * one literal contiguous substring — even when `options` was already
 * server-side filtered by keyword (see this app's several server-searched
 * pickers) — which silently hides correct multi-word matches again. Any
 * p-select doing server-side keyword search should bind
 * [filterMatchMode]="'keywordAll'" to use this instead of the PrimeNG default.
 */
export function registerKeywordAllFilter(filterService: FilterService): void {
  filterService.register('keywordAll', (value: unknown, filter: string) => {
    if (!filter || !filter.trim()) {
      return true;
    }
    if (value === undefined || value === null) {
      return false;
    }
    const haystack = value.toString().toLowerCase();
    return filter
      .trim()
      .toLowerCase()
      .split(/\s+/)
      .every((kw) => haystack.includes(kw));
  });
}
