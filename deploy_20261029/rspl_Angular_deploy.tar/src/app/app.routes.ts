import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  {
    path: 'login',
    loadComponent: () => import('./main/login/login').then((m) => m.Login)
  },
  {
    path: 'logout',
    loadComponent: () => import('./main/logout/logout').then((m) => m.Logout)
  },
  {
    // Default.aspx: unconditionally redirects to login.aspx regardless of session state.
    path: 'default',
    redirectTo: 'login'
  },
  {
    // Email-action-link pages (no login required in the source — Index.master, no session check).
    path: '',
    loadComponent: () => import('./shared/bare-layout/bare-layout').then((m) => m.BareLayout),
    children: [
      {
        path: 'leave-sanction',
        loadComponent: () => import('./main/sections/general/leave-sanction/leave-sanction').then((m) => m.LeaveSanction)
      },
      {
        path: 'leave-sanction-cancellation',
        loadComponent: () =>
          import('./main/sections/general/leave-sanction-cancellation/leave-sanction-cancellation').then(
            (m) => m.LeaveSanctionCancellation
          )
      },
      {
        // Default2.aspx: standalone leftover demo page, not on Home.master, no session check.
        path: 'default2',
        loadComponent: () => import('./main/default2/default2').then((m) => m.Default2)
      }
    ]
  },
  {
    path: '',
    loadChildren: () => import('./main/main.routes').then((m) => m.mainRoutes)
  },
  {
    path: 'agile',
    loadChildren: () => import('./agile/agile.routes').then((m) => m.agileRoutes)
  },
  {
    path: 'engineering-hub',
    loadChildren: () => import('./engineering-hub/engineering-hub.routes').then((m) => m.engineeringHubRoutes)
  },
  {
    path: 'recruitment',
    loadChildren: () => import('./recruitment/recruitment.routes').then((m) => m.recruitmentRoutes)
  },
  { path: '**', redirectTo: 'login' }
];
