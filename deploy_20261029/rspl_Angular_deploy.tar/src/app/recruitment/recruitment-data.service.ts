import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../shared/api-config';

const BASE = `${API_BASE_URL}/recruitment`;

export interface DiscQualityItem {
  qualitySrNo: number;
  qualityEnglish: string;
  qualityMarathi: string;
}

export interface DiscQualityGroup {
  qualityNo: number;
  items: DiscQualityItem[];
}

export interface DiscAnswer {
  qualityNo: number;
  mostSrNo: number | null;
  leastSrNo: number | null;
}

export interface DiscCandidateInfo {
  candidateId: number;
  name: string;
  mobileNo: string;
  emailId: string;
}

export interface DiscCandidateRow {
  candidateId: number;
  name: string;
  mobileNo: string;
  department: string;
  emailId: string;
  qualification: string;
  adaptedBehavior: string;
  naturalBehavior: string;
  questionPaperId: number;
  questionPaperName: string;
}

export interface DiscCandidateDetail {
  candidateId: number;
  name: string;
  mobileNo: string;
  emailId: string;
  department: string;
  qualification: string;
  loginName: string;
  password: string;
  enabled: boolean;
  showAnswer: boolean;
  questionPaperId: number;
  batchId: number;
}

export interface QuestionPaperTemplateRow {
  questionPaperId: number;
  name: string;
  department: string;
  timeInterval: number;
  disabled: boolean;
}

export type QuestionType = 'Singlechoice' | 'Multichoice' | 'Text';

export interface QuestionPaperQuestionRow {
  questionPaperId: number;
  questionId: number;
  question: string;
  questionType: QuestionType;
  answerList: string;
  actualAnswer: string;
  disabled: boolean;
}

export interface ExamQuestion {
  questionId: number;
  questionPaperId: number;
  question: string;
  questionType: QuestionType;
  answerOptions: string[];
}

export interface AnswerRegisterRow {
  candidateId: number;
  questionPaperId: number;
  name: string;
  mobileNo: string;
  emailId: string;
  department: string;
  qualification: string;
  examDate: string;
  examName: string;
  marks: number;
  outOf: number;
}

export interface AnswerRegisterDetailRow {
  questionId: number;
  question: string;
  answerGiven: string;
  marks: number;
}

export interface DiscAnswerSummaryRow {
  srNo: number;
  quality: string;
  mostCount: number;
  leastCount: number;
  mostLevelNo: number;
  leastLevelNo: number;
}

interface ApiDiscQualityItem {
  quality_sr_no: number;
  quality_english: string;
  quality_marathi: string;
}

interface ApiDiscQualityGroup {
  quality_no: number;
  items: ApiDiscQualityItem[];
}

interface ApiDiscCandidateRow {
  candidate_id: number;
  name: string;
  mobile_no: string;
  department: string;
  email_id: string;
  qualification: string;
  adapted_behavior: string;
  natural_behavior: string;
  question_paper_id: number;
  question_paper_name: string;
}

interface ApiDiscCandidateDetail {
  candidate_id: number;
  name: string;
  mobile_no: string;
  email_id: string;
  department: string;
  qualification: string;
  login_name: string;
  password: string;
  enabled: boolean;
  show_answer: boolean;
  question_paper_id: number;
  batch_id: number;
}

interface ApiQuestionPaperTemplateRow {
  question_paper_id: number;
  name: string;
  department: string;
  time_interval: number;
  disabled: boolean;
}

interface ApiQuestionPaperQuestionRow {
  question_paper_id: number;
  question_id: number;
  question: string;
  question_type: QuestionType;
  answer_list: string;
  actual_answer: string;
  disabled: boolean;
}

interface ApiExamQuestion {
  question_id: number;
  question_paper_id: number;
  question: string;
  question_type: QuestionType;
  answer_options: string[];
}

interface ApiExamPaper {
  time_interval_min: number;
  questions: ApiExamQuestion[];
}

interface ApiAnswerRegisterRow {
  candidate_id: number;
  question_paper_id: number;
  name: string;
  mobile_no: string;
  email_id: string;
  department: string;
  qualification: string;
  exam_date: string | null;
  exam_name: string;
  marks: number;
  out_of: number;
}

interface ApiAnswerRegisterDetailRow {
  question_id: number;
  question: string;
  answer_given: string;
  marks: number;
}

interface ApiDiscAnswerSummaryRow {
  sr_no: number;
  quality: string;
  most_count: number;
  least_count: number;
  most_level_no: number;
  least_level_no: number;
}

function toDiscCandidateRow(r: ApiDiscCandidateRow): DiscCandidateRow {
  return {
    candidateId: r.candidate_id,
    name: r.name,
    mobileNo: r.mobile_no,
    department: r.department,
    emailId: r.email_id,
    qualification: r.qualification,
    adaptedBehavior: r.adapted_behavior,
    naturalBehavior: r.natural_behavior,
    questionPaperId: r.question_paper_id,
    questionPaperName: r.question_paper_name
  };
}

function toDiscCandidateDetail(r: ApiDiscCandidateDetail): DiscCandidateDetail {
  return {
    candidateId: r.candidate_id,
    name: r.name,
    mobileNo: r.mobile_no,
    emailId: r.email_id,
    department: r.department,
    qualification: r.qualification,
    loginName: r.login_name,
    password: r.password,
    enabled: r.enabled,
    showAnswer: r.show_answer,
    questionPaperId: r.question_paper_id,
    batchId: r.batch_id
  };
}

function fromDiscCandidateDetail(d: DiscCandidateDetail): ApiDiscCandidateDetail {
  return {
    candidate_id: d.candidateId,
    name: d.name,
    mobile_no: d.mobileNo,
    email_id: d.emailId,
    department: d.department,
    qualification: d.qualification,
    login_name: d.loginName,
    password: d.password,
    enabled: d.enabled,
    show_answer: d.showAnswer,
    question_paper_id: d.questionPaperId,
    batch_id: d.batchId
  };
}

function toQuestionPaperTemplateRow(r: ApiQuestionPaperTemplateRow): QuestionPaperTemplateRow {
  return { questionPaperId: r.question_paper_id, name: r.name, department: r.department, timeInterval: r.time_interval, disabled: r.disabled };
}

function toQuestionPaperQuestionRow(r: ApiQuestionPaperQuestionRow): QuestionPaperQuestionRow {
  return {
    questionPaperId: r.question_paper_id,
    questionId: r.question_id,
    question: r.question,
    questionType: r.question_type,
    answerList: r.answer_list,
    actualAnswer: r.actual_answer,
    disabled: r.disabled
  };
}

function toAnswerRegisterRow(r: ApiAnswerRegisterRow): AnswerRegisterRow {
  return {
    candidateId: r.candidate_id,
    questionPaperId: r.question_paper_id,
    name: r.name,
    mobileNo: r.mobile_no,
    emailId: r.email_id,
    department: r.department,
    qualification: r.qualification,
    examDate: r.exam_date ?? '',
    examName: r.exam_name,
    marks: r.marks,
    outOf: r.out_of
  };
}

function toDiscAnswerSummaryRow(r: ApiDiscAnswerSummaryRow): DiscAnswerSummaryRow {
  return {
    srNo: r.sr_no,
    quality: r.quality,
    mostCount: r.most_count,
    leastCount: r.least_count,
    mostLevelNo: r.most_level_no,
    leastLevelNo: r.least_level_no
  };
}

/**
 * Mirrors Section_Recruitment's DISC profile flow (rspl_DiscProfile,
 * rspl_DiscAnswerDetail, rspl_DiscAnswerSummary tables + WebProc_
 * DiscAnswerSummary proc) plus the aptitude-test / question-paper-authoring
 * / DISC-candidate-admin pages.
 */
@Injectable({ providedIn: 'root' })
export class RecruitmentDataService {
  private readonly http = inject(HttpClient);

  getDiscQualityGroups(): Observable<DiscQualityGroup[]> {
    return this.http.get<ApiDiscQualityGroup[]>(`${BASE}/disc-quality-groups`).pipe(
      map((groups) =>
        groups.map((g) => ({
          qualityNo: g.quality_no,
          items: g.items.map((i) => ({ qualitySrNo: i.quality_sr_no, qualityEnglish: i.quality_english, qualityMarathi: i.quality_marathi }))
        }))
      )
    );
  }

  /** Mirrors DISCProfile.aspx.vb's btnSubmit_Click (delete+reinsert rspl_DiscAnswerDetail, then EXEC WebProc_DiscAnswerSummary). */
  submitDiscAnswers(candidateId: number, answers: DiscAnswer[]): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/disc-answers`, {
      answers: answers.map((a) => ({ quality_no: a.qualityNo, most_sr_no: a.mostSrNo, least_sr_no: a.leastSrNo }))
    });
  }

  /** Mirrors QuestionPaperTemplate.aspx.vb's FillGV (Select * From RSPL_QuestionPaperTemplate). */
  getQuestionPaperTemplates(): Observable<QuestionPaperTemplateRow[]> {
    return this.http
      .get<ApiQuestionPaperTemplateRow[]>(`${BASE}/question-paper-templates`)
      .pipe(map((rows) => rows.map(toQuestionPaperTemplateRow)));
  }

  /** Mirrors QuestionPaperTemplate.aspx.vb's btnSubmit_Click (Insert into RSPL_QuestionPaperTemplate). */
  addQuestionPaperTemplate(name: string, department: string, timeInterval: number): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/question-paper-templates`, { name, department, time_interval: timeInterval });
  }

  /** Mirrors QuestionPaperTemplate.aspx.vb's GV_UpdateCommand (Update RSPL_QuestionPaperTemplate). */
  updateQuestionPaperTemplate(row: QuestionPaperTemplateRow): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${BASE}/question-paper-templates/${row.questionPaperId}`, {
      question_paper_id: row.questionPaperId,
      name: row.name,
      department: row.department,
      time_interval: row.timeInterval,
      disabled: row.disabled
    });
  }

  /** Mirrors QuestionPaper.aspx.vb's FillGV (Select * From RSPL_QuestionPaper Where QuestionPaperID=). */
  getQuestionPaperQuestions(questionPaperId: number): Observable<QuestionPaperQuestionRow[]> {
    return this.http
      .get<ApiQuestionPaperQuestionRow[]>(`${BASE}/question-paper-templates/${questionPaperId}/questions`)
      .pipe(map((rows) => rows.map(toQuestionPaperQuestionRow)));
  }

  /** Mirrors QuestionPaper.aspx.vb's btnSubmit_Click (EXEC webproc_AddQuestion). */
  addQuestionPaperQuestion(
    questionPaperId: number,
    question: string,
    questionType: QuestionType,
    answerList: string,
    actualAnswer: string
  ): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/question-paper-templates/${questionPaperId}/questions`, {
      question,
      question_type: questionType,
      answer_list: answerList,
      actual_answer: actualAnswer
    });
  }

  /** Mirrors QuestionPaper.aspx.vb's GV_UpdateCommand (Update RSPL_QuestionPaper). */
  updateQuestionPaperQuestion(row: QuestionPaperQuestionRow): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${BASE}/question-paper-templates/${row.questionPaperId}/questions/${row.questionId}`, {
      question_paper_id: row.questionPaperId,
      question_id: row.questionId,
      question: row.question,
      question_type: row.questionType,
      answer_list: row.answerList,
      actual_answer: row.actualAnswer,
      disabled: row.disabled
    });
  }

  /** Mirrors AptiQuestion.aspx.vb's GenerateQuestion (Select * from RSPL_QuestionPaper where QuestionPaperId= and Disabled=0). */
  getExamQuestions(questionPaperId: number): Observable<{ timeIntervalMin: number; questions: ExamQuestion[] }> {
    return this.http.get<ApiExamPaper>(`${BASE}/exam/${questionPaperId}`).pipe(
      map((res) => ({
        timeIntervalMin: res.time_interval_min,
        questions: res.questions.map((q) => ({
          questionId: q.question_id,
          questionPaperId: q.question_paper_id,
          question: q.question,
          questionType: q.question_type,
          answerOptions: q.answer_options
        }))
      }))
    );
  }

  /** Mirrors AptiQuestion.aspx.vb's btnSubmit_click (Insert into RSPL_AnswerSheet per question, then clears QuestionPaperID). */
  submitExamAnswers(candidateId: number, questionPaperId: number, answers: { questionId: number; answerGiven: string }[]): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/exam/${questionPaperId}/submit`, {
      answers: answers.map((a) => ({ question_id: a.questionId, answer_given: a.answerGiven }))
    });
  }

  /** Mirrors AptiAns.aspx.vb / AptiNotification.aspx.vb's DisplayRecord (Select * From vw_CandidateAnswerSheet Where BatchID=). */
  getAnswerRegister(batchId: number): Observable<AnswerRegisterRow[]> {
    return this.http
      .get<ApiAnswerRegisterRow[]>(`${BASE}/answer-register`, { params: { batch_id: batchId } })
      .pipe(map((rows) => rows.map(toAnswerRegisterRow)));
  }

  /** Mirrors AptiAns.aspx.vb's GV_DetailTableDataBind (per-candidate question/answer/marks breakdown). */
  getAnswerRegisterDetail(candidateId: number, questionPaperId: number): Observable<AnswerRegisterDetailRow[]> {
    return this.http
      .get<ApiAnswerRegisterDetailRow[]>(`${BASE}/answer-register/${candidateId}/${questionPaperId}`)
      .pipe(
        map((rows) =>
          rows.map((r) => ({ questionId: r.question_id, question: r.question, answerGiven: r.answer_given, marks: r.marks }))
        )
      );
  }

  /** Mirrors AptiNotification.aspx.vb's btnSend_Click (per selected row, db.SendSMS — stubbed, no SMS gateway wired up). */
  sendBulkSms(candidateIds: number[], message: string): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/sms/bulk`, { candidate_ids: candidateIds, message });
  }

  /** Mirrors DISCCandidate.aspx.vb's fillInfo (EXEC WebProc_GetDiscCandidate 0). Admin-only page. */
  getDiscCandidates(): Observable<DiscCandidateRow[]> {
    return this.http.get<ApiDiscCandidateRow[]>(`${BASE}/disc-candidates`).pipe(map((rows) => rows.map(toDiscCandidateRow)));
  }

  /** Mirrors DiscCandidateAdd.aspx.vb's Page_Load (question-paper dropdown fill). */
  getQuestionPaperOptions(): Observable<{ label: string; value: number }[]> {
    return this.http.get<{ label: string; value: number }[]>(`${BASE}/question-paper-options`);
  }

  /** Mirrors DiscCandidateAdd.aspx.vb's ViewData (EXEC WebProc_getDiscCandidate). */
  getDiscCandidateDetail(candidateId: number): Observable<DiscCandidateDetail> {
    return this.http.get<ApiDiscCandidateDetail>(`${BASE}/disc-candidates/${candidateId}`).pipe(map(toDiscCandidateDetail));
  }

  /** Mirrors DiscCandidateAdd.aspx.vb's btnAddCandidate_Click (EXEC webProc_AddEditCandidate). */
  saveDiscCandidate(detail: DiscCandidateDetail): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/disc-candidates`, fromDiscCandidateDetail(detail));
  }

  /** Mirrors DISCAnswer.aspx.vb's ShowAnswerSheet (Select * From rspl_Candidate). */
  getDiscCandidateInfo(candidateId: number): Observable<DiscCandidateInfo> {
    return this.http
      .get<{ candidate_id: number; name: string; mobile_no: string; email_id: string }>(`${BASE}/disc-candidate-info`)
      .pipe(map((r) => ({ candidateId: r.candidate_id, name: r.name, mobileNo: r.mobile_no, emailId: r.email_id })));
  }

  /** Mirrors DISCAnswer.aspx.vb's rspl_DiscAnswerSummary query (Where graphEnabled=1). */
  getDiscAnswerSummary(candidateId: number): Observable<DiscAnswerSummaryRow[]> {
    return this.http
      .get<ApiDiscAnswerSummaryRow[]>(`${BASE}/disc-answer-summary`)
      .pipe(map((rows) => rows.map(toDiscAnswerSummaryRow)));
  }
}
