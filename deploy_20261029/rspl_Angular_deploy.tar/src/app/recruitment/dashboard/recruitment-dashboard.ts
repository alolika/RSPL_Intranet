import { Component, inject } from '@angular/core';

import { RecruitmentAuthService } from '../../core/auth/recruitment-auth.service';

/** Mirrors Section_Recruitment/DashBoard.aspx: a welcome panel showing the logged-in candidate's session-stored profile fields. */
@Component({
  selector: 'app-recruitment-dashboard',
  imports: [],
  templateUrl: './recruitment-dashboard.html',
  styleUrl: './recruitment-dashboard.scss'
})
export class RecruitmentDashboard {
  private readonly auth = inject(RecruitmentAuthService);

  readonly user = this.auth.currentUser;
}
