import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { QuestionPaperQuestionRow, QuestionType, RecruitmentDataService } from '../recruitment-data.service';

const QUESTION_TYPES: QuestionType[] = ['Singlechoice', 'Multichoice', 'Text'];

interface LookupOption2 {
  label: string;
  value: number;
}

/** Mirrors Section_Recruitment/QuestionPaper.aspx ("QuestionPaper Questions"): pick a template, author questions into it, with an inline-editable grid of existing questions. */
@Component({
  selector: 'app-question-paper',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, SelectModule, TableModule, TextareaModule],
  templateUrl: './question-paper.html',
  styleUrl: './question-paper.scss'
})
export class QuestionPaper implements OnInit {
  private readonly data = inject(RecruitmentDataService);
  // This app runs without zone.js — plain (non-signal) properties like
  // `questionPaperId`/`question`/`answerList`/`actualAnswer` below don't trigger a
  // re-render on their own when mutated inside an RxJS subscribe callback.
  // markForCheck() after each such mutation is what actually gets the new values
  // on screen.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly templates = signal<LookupOption2[]>([]);
  readonly questionTypes = QUESTION_TYPES;
  readonly rows = signal<QuestionPaperQuestionRow[]>([]);
  readonly saving = signal(false);

  questionPaperId: number | null = null;
  questionType: QuestionType = 'Singlechoice';
  question = '';
  answerList = '';
  actualAnswer = '';

  ngOnInit(): void {
    this.data.getQuestionPaperOptions().subscribe((opts) => {
      this.templates.set(opts);
      this.questionPaperId = opts[0]?.value ?? null;
      this.load();
      this.cdr.markForCheck();
    });
  }

  onTemplateChange(): void {
    this.load();
  }

  private load(): void {
    if (!this.questionPaperId) {
      return;
    }
    this.data.getQuestionPaperQuestions(this.questionPaperId).subscribe((rows) => this.rows.set(rows));
  }

  submit(): void {
    if (!this.questionPaperId) {
      return;
    }
    this.saving.set(true);
    this.data.addQuestionPaperQuestion(this.questionPaperId, this.question, this.questionType, this.answerList, this.actualAnswer).subscribe(() => {
      this.saving.set(false);
      alert('Save Sucessfully');
      this.question = '';
      this.answerList = '';
      this.actualAnswer = '';
      this.load();
      this.cdr.markForCheck();
    });
  }

  saveRow(row: QuestionPaperQuestionRow): void {
    this.data.updateQuestionPaperQuestion(row).subscribe(() => {
      alert('Updated Sucessfully');
      this.load();
    });
  }
}
