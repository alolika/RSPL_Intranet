import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { RadioButtonModule } from 'primeng/radiobutton';

import { RecruitmentAuthService } from '../../core/auth/recruitment-auth.service';
import { DiscAnswer, DiscQualityGroup, RecruitmentDataService } from '../recruitment-data.service';

/**
 * Mirrors Section_Recruitment/DISCProfile.aspx ("FILL YOUR DISC PROFILE"):
 * 24 quality groups of 4 items each, exactly one "Most Like" and one
 * "Least Like" pick per group (source implements this via checkboxes that
 * disable each other on selection — replicated here as two PrimeNG radio
 * groups per row, with the Least radio for whichever item is picked as
 * Most disabled, matching the source's row-level disable behavior). Submit
 * is blocked until all 24 groups have both picks made, same as the
 * source's Most/Least count-vs-24 check.
 */
@Component({
  selector: 'app-disc-profile',
  imports: [FormsModule, ButtonModule, RadioButtonModule],
  templateUrl: './disc-profile.html',
  styleUrl: './disc-profile.scss'
})
export class DiscProfile implements OnInit {
  private readonly data = inject(RecruitmentDataService);
  private readonly auth = inject(RecruitmentAuthService);
  private readonly router = inject(Router);

  readonly groups = signal<DiscQualityGroup[]>([]);
  readonly answers = signal<Map<number, DiscAnswer>>(new Map());
  readonly submitting = signal(false);

  readonly mostCount = computed(() => [...this.answers().values()].filter((a) => a.mostSrNo !== null).length);
  readonly leastCount = computed(() => [...this.answers().values()].filter((a) => a.leastSrNo !== null).length);

  ngOnInit(): void {
    this.data.getDiscQualityGroups().subscribe((groups) => {
      this.groups.set(groups);
      const map = new Map<number, DiscAnswer>();
      for (const g of groups) {
        map.set(g.qualityNo, { qualityNo: g.qualityNo, mostSrNo: null, leastSrNo: null });
      }
      this.answers.set(map);
    });
  }

  answerFor(qualityNo: number): DiscAnswer {
    return this.answers().get(qualityNo) ?? { qualityNo, mostSrNo: null, leastSrNo: null };
  }

  setMost(qualityNo: number, srNo: number): void {
    const map = new Map(this.answers());
    const current = map.get(qualityNo) ?? { qualityNo, mostSrNo: null, leastSrNo: null };
    map.set(qualityNo, { ...current, mostSrNo: srNo, leastSrNo: current.leastSrNo === srNo ? null : current.leastSrNo });
    this.answers.set(map);
  }

  setLeast(qualityNo: number, srNo: number): void {
    const map = new Map(this.answers());
    const current = map.get(qualityNo) ?? { qualityNo, mostSrNo: null, leastSrNo: null };
    map.set(qualityNo, { ...current, leastSrNo: srNo, mostSrNo: current.mostSrNo === srNo ? null : current.mostSrNo });
    this.answers.set(map);
  }

  submit(): void {
    const totalGroups = this.groups().length;
    if (this.mostCount() !== totalGroups || this.leastCount() !== totalGroups) {
      alert('Please Solve All Questions !');
      return;
    }
    const user = this.auth.currentUser();
    if (!user) {
      return;
    }
    this.submitting.set(true);
    this.data.submitDiscAnswers(user.candidateId, [...this.answers().values()]).subscribe(() => {
      this.submitting.set(false);
      alert('DISC Profile submitted Successfully!');
      this.router.navigate([user.showAnswer ? '/recruitment/disc-answer' : '/recruitment/dashboard']);
    });
  }
}
