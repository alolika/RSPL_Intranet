import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { PasswordModule } from 'primeng/password';

import { RecruitmentAuthService } from '../../core/auth/recruitment-auth.service';

@Component({
  selector: 'app-recruitment-login',
  imports: [ReactiveFormsModule, ButtonModule, InputTextModule, PasswordModule, MessageModule],
  templateUrl: './recruitment-login.html',
  styleUrl: './recruitment-login.scss'
})
export class RecruitmentLogin {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(RecruitmentAuthService);
  private readonly router = inject(Router);

  readonly errorMessage = signal<string | null>(null);
  readonly submitting = signal(false);

  readonly form = this.fb.nonNullable.group({
    loginName: ['', Validators.required],
    password: ['', Validators.required]
  });

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.errorMessage.set(null);
    this.submitting.set(true);
    const { loginName, password } = this.form.getRawValue();
    this.auth.login(loginName, password).subscribe({
      next: () => {
        this.submitting.set(false);
        this.router.navigate(['/recruitment/dashboard']);
      },
      error: (err: Error) => {
        this.submitting.set(false);
        this.errorMessage.set(err.message);
      }
    });
  }
}
