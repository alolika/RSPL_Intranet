import { MenuItem } from 'primeng/api';

/**
 * Mirrors App_Master/Recruitment.master's RadMenu. The "Admin" submenu is
 * Visible="false" in the source and gated in code-behind on
 * Session("AdminCode") = 4 (Recruitment.master.vb) — replicated here via
 * isAdmin rather than a hardcoded visibility flag.
 */
export function buildRecruitmentNav(isAdmin: boolean): MenuItem[] {
  const items: MenuItem[] = [
    { label: 'Home', routerLink: '/recruitment/dashboard' },
    {
      label: 'DISC Profile',
      items: [
        { label: 'DISC QPaper', routerLink: '/recruitment/disc-profile' },
        { label: 'DISC Answer', routerLink: '/recruitment/disc-answer' }
      ]
    },
    {
      label: 'Question Paper',
      items: [{ label: 'Question Paper', routerLink: '/recruitment/apti-question' }]
    }
  ];

  if (isAdmin) {
    items.push({
      label: 'Admin',
      items: [
        { label: 'Manage Candidate', routerLink: '/recruitment/disc-candidate' },
        { label: 'QuestionPaper Template', routerLink: '/recruitment/question-paper-template' },
        { label: 'QuestionPaper Question', routerLink: '/recruitment/question-paper' },
        { label: 'QuestionPaper Answer', routerLink: '/recruitment/apti-ans' }
      ]
    });
  }

  return items;
}
