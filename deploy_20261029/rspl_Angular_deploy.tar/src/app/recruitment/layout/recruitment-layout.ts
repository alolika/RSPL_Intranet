import { Component, computed, inject } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';
import { MenubarModule } from 'primeng/menubar';

import { RecruitmentAuthService } from '../../core/auth/recruitment-auth.service';
import { MobileNav } from '../../shared/mobile-nav/mobile-nav';
import { buildRecruitmentNav } from './recruitment-nav';

@Component({
  selector: 'app-recruitment-layout',
  imports: [RouterOutlet, MenubarModule, MobileNav],
  templateUrl: './recruitment-layout.html',
  styleUrl: './recruitment-layout.scss'
})
export class RecruitmentLayout {
  private readonly router = inject(Router);
  readonly auth = inject(RecruitmentAuthService);
  readonly navItems = computed(() => buildRecruitmentNav(this.auth.currentUser()?.isAdmin ?? false));

  logout(): void {
    this.auth.logout();
    this.router.navigate(['/recruitment/login']);
  }
}
