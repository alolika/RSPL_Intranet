import { Routes } from '@angular/router';

import { recruitmentAuthGuard } from '../core/auth/recruitment-auth.guard';

export const recruitmentRoutes: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./login/recruitment-login').then((m) => m.RecruitmentLogin)
  },
  {
    // Default.aspx: unconditional redirect to Login.aspx, no session check in the source.
    path: 'default',
    redirectTo: 'login'
  },
  {
    path: 'logout',
    loadComponent: () => import('./logout/recruitment-logout').then((m) => m.RecruitmentLogout)
  },
  {
    path: '',
    loadComponent: () => import('./layout/recruitment-layout').then((m) => m.RecruitmentLayout),
    canActivate: [recruitmentAuthGuard],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      {
        path: 'dashboard',
        loadComponent: () => import('./dashboard/recruitment-dashboard').then((m) => m.RecruitmentDashboard)
      },
      {
        path: 'disc-profile',
        loadComponent: () => import('./disc-profile/disc-profile').then((m) => m.DiscProfile)
      },
      {
        path: 'disc-answer',
        loadComponent: () => import('./disc-answer/disc-answer').then((m) => m.DiscAnswer)
      },
      {
        // DiscPrint.aspx's server-side Panel print (clsPrintDoc) has no web equivalent;
        // its functionality is now the "Print Profile" button on the Answer Sheet itself.
        path: 'disc-print',
        redirectTo: 'disc-answer'
      },
      {
        path: 'disc-candidate',
        loadComponent: () => import('./disc-candidate/disc-candidate').then((m) => m.DiscCandidate)
      },
      {
        path: 'disc-candidate-add',
        loadComponent: () => import('./disc-candidate-add/disc-candidate-add').then((m) => m.DiscCandidateAdd)
      },
      {
        path: 'apti-question',
        loadComponent: () => import('./apti-question/apti-question').then((m) => m.AptiQuestion)
      },
      {
        path: 'apti-ans',
        loadComponent: () => import('./apti-ans/apti-ans').then((m) => m.AptiAns)
      },
      {
        path: 'apti-notification',
        loadComponent: () => import('./apti-notification/apti-notification').then((m) => m.AptiNotification)
      },
      {
        path: 'question-paper',
        loadComponent: () => import('./question-paper/question-paper').then((m) => m.QuestionPaper)
      },
      {
        path: 'question-paper-template',
        loadComponent: () => import('./question-paper-template/question-paper-template').then((m) => m.QuestionPaperTemplate)
      }
    ]
  }
];
