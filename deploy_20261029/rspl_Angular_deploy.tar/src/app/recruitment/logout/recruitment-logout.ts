import { Component, OnInit, inject } from '@angular/core';
import { Router } from '@angular/router';

import { RecruitmentAuthService } from '../../core/auth/recruitment-auth.service';

/** Mirrors Section_Recruitment/LogOut.aspx: clears session, redirects to Login.aspx. */
@Component({
  selector: 'app-recruitment-logout',
  template: ''
})
export class RecruitmentLogout implements OnInit {
  private readonly auth = inject(RecruitmentAuthService);
  private readonly router = inject(Router);

  ngOnInit(): void {
    this.auth.logout();
    this.router.navigate(['/recruitment/login']);
  }
}
