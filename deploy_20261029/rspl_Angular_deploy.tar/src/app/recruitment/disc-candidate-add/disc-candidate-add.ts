import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';

import { DiscCandidateDetail, RecruitmentDataService } from '../recruitment-data.service';

const BATCH_OPTIONS = Array.from({ length: 10 }, (_, i) => ({ label: `Batch ${i + 1}`, value: i + 1 }));

/**
 * Mirrors Section_Recruitment/DiscCandidateAdd.aspx ("DISC Candidate
 * Add,Edit"): a standalone popup form (no master page in the source),
 * migrated as a routed page (?CandidateID=0 for Add, or the candidate's ID
 * for Edit) that navigates back to /recruitment/disc-candidate on
 * Submit/Cancel instead of the source's RadWindow close + parent-grid
 * refresh.
 */
@Component({
  selector: 'app-disc-candidate-add',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, SelectModule],
  templateUrl: './disc-candidate-add.html',
  styleUrl: './disc-candidate-add.scss'
})
export class DiscCandidateAdd implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly data = inject(RecruitmentDataService);
  // This app runs without zone.js — plain (non-signal) properties like `candidateId`/
  // `form` below don't trigger a re-render on their own when mutated inside an RxJS
  // subscribe callback. markForCheck() after each such mutation is what actually
  // gets the new values on screen.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly questionPapers = signal<{ label: string; value: number }[]>([]);
  readonly batchOptions = BATCH_OPTIONS;
  readonly saving = signal(false);

  candidateId = 0;
  form: DiscCandidateDetail = this.blankForm();

  ngOnInit(): void {
    this.data.getQuestionPaperOptions().subscribe((opts) => this.questionPapers.set(opts));

    // Reached repeatedly from the candidate grid's "Edit" links with a
    // different ?CandidateID each time — subscribe rather than reading a
    // one-time snapshot so editing a different candidate while this
    // component is already mounted actually loads their details.
    this.route.queryParamMap.subscribe((q) => {
      this.candidateId = Number(q.get('CandidateID') ?? 0);
      if (this.candidateId !== 0) {
        this.data.getDiscCandidateDetail(this.candidateId).subscribe((detail) => {
          this.form = detail;
          this.cdr.markForCheck();
        });
      } else {
        this.form = this.blankForm();
      }
      this.cdr.markForCheck();
    });
  }

  private blankForm(): DiscCandidateDetail {
    return {
      candidateId: 0,
      name: '',
      mobileNo: '',
      emailId: '',
      department: '',
      qualification: '',
      loginName: '',
      password: '',
      enabled: false,
      showAnswer: false,
      questionPaperId: 0,
      batchId: 1
    };
  }

  submit(): void {
    if (!this.form.name.trim() || !this.form.mobileNo.trim() || !this.form.emailId.trim() || !this.form.loginName.trim() || !this.form.password.trim()) {
      alert('Please fill all required fields.');
      return;
    }
    this.saving.set(true);
    this.data.saveDiscCandidate({ ...this.form, candidateId: this.candidateId }).subscribe(() => {
      this.saving.set(false);
      this.router.navigate(['/recruitment/disc-candidate']);
    });
  }

  cancel(): void {
    this.router.navigate(['/recruitment/disc-candidate']);
  }
}
