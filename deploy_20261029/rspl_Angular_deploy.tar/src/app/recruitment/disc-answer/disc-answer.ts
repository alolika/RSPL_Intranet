import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild, inject, signal } from '@angular/core';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { Chart, ChartConfiguration } from 'chart.js/auto';

import { RecruitmentAuthService } from '../../core/auth/recruitment-auth.service';
import { DiscAnswerSummaryRow, DiscCandidateInfo, RecruitmentDataService } from '../recruitment-data.service';

/**
 * Mirrors Section_Recruitment/DISCAnswer.aspx ("DISC PROFILE : ANSWER
 * SHEET"): candidate info, a Most/Least count summary grid, and two line
 * graphs (Adapted/"Most" behavior, Natural/"Least" behavior) — the source
 * server-renders these as static PNGs via System.Web.DataVisualization;
 * replaced here with Chart.js line charts driven by the same MostLevelNo/
 * LeastLevelNo values. "Print Profile" opened a separate DiscPrint.aspx
 * popup that server-side printed an ASP.NET Panel control (clsPrintDoc) —
 * no web equivalent exists, so Print here calls the browser's native
 * window.print() directly on this sheet instead.
 */
@Component({
  selector: 'app-disc-answer',
  imports: [TableModule, ButtonModule],
  templateUrl: './disc-answer.html',
  styleUrl: './disc-answer.scss'
})
export class DiscAnswer implements AfterViewInit, OnDestroy {
  private readonly data = inject(RecruitmentDataService);
  private readonly auth = inject(RecruitmentAuthService);

  @ViewChild('mostCanvas') mostCanvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('leastCanvas') leastCanvasRef!: ElementRef<HTMLCanvasElement>;

  readonly candidateInfo = signal<DiscCandidateInfo | null>(null);
  readonly summaryRows = signal<DiscAnswerSummaryRow[]>([]);
  readonly highestAdapted = signal('');
  readonly highestNatural = signal('');

  private mostChart: Chart | null = null;
  private leastChart: Chart | null = null;

  ngAfterViewInit(): void {
    const user = this.auth.currentUser();
    if (!user) {
      return;
    }
    this.data.getDiscCandidateInfo(user.candidateId).subscribe((info) => this.candidateInfo.set(info));
    this.data.getDiscAnswerSummary(user.candidateId).subscribe((rows) => {
      this.summaryRows.set(rows);
      const topMost = [...rows].sort((a, b) => b.mostLevelNo - a.mostLevelNo)[0];
      const topLeast = [...rows].sort((a, b) => b.leastLevelNo - a.leastLevelNo)[0];
      this.highestAdapted.set(topMost?.quality ?? '');
      this.highestNatural.set(topLeast?.quality ?? '');
      this.drawCharts(rows);
    });
  }

  ngOnDestroy(): void {
    this.mostChart?.destroy();
    this.leastChart?.destroy();
  }

  private drawCharts(rows: DiscAnswerSummaryRow[]): void {
    const labels = rows.map((r) => r.quality);
    const lineConfig = (data: number[], color: string): ChartConfiguration<'line'> => ({
      type: 'line',
      data: { labels, datasets: [{ data, borderColor: color, backgroundColor: color, tension: 0.2 }] },
      options: { plugins: { legend: { display: false } } }
    });
    this.mostChart?.destroy();
    this.leastChart?.destroy();
    this.mostChart = new Chart(this.mostCanvasRef.nativeElement, lineConfig(rows.map((r) => r.mostLevelNo), '#7c2d12'));
    this.leastChart = new Chart(this.leastCanvasRef.nativeElement, lineConfig(rows.map((r) => r.leastLevelNo), '#003057'));
  }

  print(): void {
    window.print();
  }
}
