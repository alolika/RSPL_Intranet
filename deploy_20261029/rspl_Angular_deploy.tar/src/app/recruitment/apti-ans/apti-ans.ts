import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../shared/export-excel';
import { AnswerRegisterDetailRow, AnswerRegisterRow, RecruitmentDataService } from '../recruitment-data.service';

const BATCH_OPTIONS = Array.from({ length: 10 }, (_, i) => ({ label: `Batch ${i + 1}`, value: i + 1 }));

/** Mirrors Section_Recruitment/AptiAns.aspx ("Answer Register"): Batch-filtered candidate exam results, expandable to per-question answer/marks detail. */
@Component({
  selector: 'app-apti-ans',
  imports: [FormsModule, ButtonModule, SelectModule, TableModule, DatePipe],
  templateUrl: './apti-ans.html',
  styleUrl: './apti-ans.scss'
})
export class AptiAns implements OnInit {
  private readonly data = inject(RecruitmentDataService);

  readonly batchOptions = BATCH_OPTIONS;
  readonly rows = signal<AnswerRegisterRow[]>([]);
  readonly loading = signal(false);
  readonly expandedCandidateId = signal<number | null>(null);
  readonly detailRows = signal<AnswerRegisterDetailRow[]>([]);

  batchId = 1;

  ngOnInit(): void {
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.expandedCandidateId.set(null);
    this.data.getAnswerRegister(this.batchId).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }

  toggleExpand(row: AnswerRegisterRow): void {
    if (this.expandedCandidateId() === row.candidateId) {
      this.expandedCandidateId.set(null);
      return;
    }
    this.expandedCandidateId.set(row.candidateId);
    this.data.getAnswerRegisterDetail(row.candidateId, row.questionPaperId).subscribe((rows) => this.detailRows.set(rows));
  }

  export(): void {
    exportToExcel('AnswerSheet', this.rows());
  }
}
