import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { AnswerRegisterRow, RecruitmentDataService } from '../recruitment-data.service';

const BATCH_OPTIONS = Array.from({ length: 10 }, (_, i) => ({ label: `Batch ${i + 1}`, value: i + 1 }));

/** Mirrors Section_Recruitment/AptiNotification.aspx ("Send SMS"): Batch-filtered candidate grid with per-row/select-all checkboxes and a bulk SMS send (mocked, no SMS gateway wired up in this frontend-only phase). */
@Component({
  selector: 'app-apti-notification',
  imports: [FormsModule, ButtonModule, CheckboxModule, SelectModule, TableModule, TextareaModule],
  templateUrl: './apti-notification.html',
  styleUrl: './apti-notification.scss'
})
export class AptiNotification implements OnInit {
  private readonly data = inject(RecruitmentDataService);
  // This app runs without zone.js — the plain (non-signal) `message` property below
  // doesn't trigger a re-render on its own when mutated inside an RxJS subscribe
  // callback. markForCheck() after that mutation is what actually gets the new
  // value on screen.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly batchOptions = BATCH_OPTIONS;
  readonly rows = signal<AnswerRegisterRow[]>([]);
  readonly loading = signal(false);
  readonly selected = signal<Set<number>>(new Set());
  readonly selectAll = signal(false);
  readonly sending = signal(false);

  batchId = 1;
  message = '';

  ngOnInit(): void {
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.selected.set(new Set());
    this.selectAll.set(false);
    this.data.getAnswerRegister(this.batchId).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }

  isSelected(candidateId: number): boolean {
    return this.selected().has(candidateId);
  }

  toggle(candidateId: number): void {
    const set = new Set(this.selected());
    if (set.has(candidateId)) {
      set.delete(candidateId);
    } else {
      set.add(candidateId);
    }
    this.selected.set(set);
  }

  onSelectAllChange(): void {
    this.selected.set(this.selectAll() ? new Set(this.rows().map((r) => r.candidateId)) : new Set());
  }

  send(): void {
    if (!this.message.trim()) {
      return;
    }
    this.sending.set(true);
    this.data.sendBulkSms([...this.selected()], this.message.trim()).subscribe(() => {
      this.sending.set(false);
      this.message = '';
      alert('SMS Send Successfully!');
      this.show();
      this.cdr.markForCheck();
    });
  }
}
