import { Component, OnDestroy, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { RadioButtonModule } from 'primeng/radiobutton';
import { TextareaModule } from 'primeng/textarea';

import { RecruitmentAuthService } from '../../core/auth/recruitment-auth.service';
import { ExamQuestion, RecruitmentDataService } from '../recruitment-data.service';

interface AnswerState {
  single: string | null;
  multi: Set<string>;
  text: string;
}

/**
 * Mirrors Section_Recruitment/AptiQuestion.aspx ("Question Paper"): the
 * candidate-facing aptitude test, dynamically rendered per question type
 * (Singlechoice → radio, Multichoice → checkboxes, Text → textarea), with a
 * countdown timer that auto-submits when it hits zero, same as the
 * source's Timer1_Tick calling btnSubmit_click directly.
 */
@Component({
  selector: 'app-apti-question',
  imports: [FormsModule, ButtonModule, CheckboxModule, RadioButtonModule, TextareaModule],
  templateUrl: './apti-question.html',
  styleUrl: './apti-question.scss'
})
export class AptiQuestion implements OnInit, OnDestroy {
  private readonly data = inject(RecruitmentDataService);
  private readonly auth = inject(RecruitmentAuthService);
  private readonly router = inject(Router);
  private timerHandle: ReturnType<typeof setInterval> | null = null;
  private deadline: Date | null = null;

  readonly questions = signal<ExamQuestion[]>([]);
  readonly answers = signal<Map<number, AnswerState>>(new Map());
  readonly timeLeftLabel = signal('');
  readonly submitting = signal(false);
  readonly hasTimer = signal(false);

  ngOnInit(): void {
    const user = this.auth.currentUser();
    if (!user || !user.questionPaperId) {
      alert('Question paper is not available!');
      this.router.navigate(['/recruitment/dashboard']);
      return;
    }
    this.data.getExamQuestions(user.questionPaperId).subscribe((res) => {
      this.questions.set(res.questions);
      const map = new Map<number, AnswerState>();
      for (const q of res.questions) {
        map.set(q.questionId, { single: null, multi: new Set(), text: '' });
      }
      this.answers.set(map);

      if (res.timeIntervalMin > 0) {
        this.hasTimer.set(true);
        this.deadline = new Date(Date.now() + res.timeIntervalMin * 60_000);
        this.timerHandle = setInterval(() => this.tick(), 1000);
        this.tick();
      }
    });
  }

  ngOnDestroy(): void {
    if (this.timerHandle) {
      clearInterval(this.timerHandle);
    }
  }

  private tick(): void {
    if (!this.deadline) {
      return;
    }
    const diffMs = this.deadline.getTime() - Date.now();
    if (diffMs <= 0) {
      this.timeLeftLabel.set('Test Time Over');
      if (this.timerHandle) {
        clearInterval(this.timerHandle);
      }
      this.submit();
      return;
    }
    const totalSeconds = Math.floor(diffMs / 1000);
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    this.timeLeftLabel.set(`Time left is ${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`);
  }

  answerFor(questionId: number): AnswerState {
    return this.answers().get(questionId) ?? { single: null, multi: new Set(), text: '' };
  }

  setSingle(questionId: number, value: string): void {
    const map = new Map(this.answers());
    map.set(questionId, { ...this.answerFor(questionId), single: value });
    this.answers.set(map);
  }

  toggleMulti(questionId: number, option: string): void {
    const map = new Map(this.answers());
    const current = this.answerFor(questionId);
    const multi = new Set(current.multi);
    if (multi.has(option)) {
      multi.delete(option);
    } else {
      multi.add(option);
    }
    map.set(questionId, { ...current, multi });
    this.answers.set(map);
  }

  setText(questionId: number, value: string): void {
    const map = new Map(this.answers());
    map.set(questionId, { ...this.answerFor(questionId), text: value });
    this.answers.set(map);
  }

  submit(): void {
    const user = this.auth.currentUser();
    if (!user) {
      return;
    }
    this.submitting.set(true);
    const answers = this.questions().map((q) => {
      const a = this.answerFor(q.questionId);
      const answerGiven = q.questionType === 'Singlechoice' ? (a.single ?? '') : q.questionType === 'Multichoice' ? [...a.multi].join(',') : a.text;
      return { questionId: q.questionId, answerGiven };
    });
    this.data.submitExamAnswers(user.candidateId, user.questionPaperId, answers).subscribe(() => {
      this.submitting.set(false);
      if (this.timerHandle) {
        clearInterval(this.timerHandle);
      }
      alert('Your Answer Sheet Submitted successfully');
      this.router.navigate(['/recruitment/dashboard']);
    });
  }
}
