import { Component, OnInit, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';

import { DiscCandidateRow, RecruitmentDataService } from '../recruitment-data.service';

/**
 * Mirrors Section_Recruitment/DISCCandidate.aspx ("DISC Candidate" —
 * admin-only, guarded by Session("AdminCode")<>0 in the source): a
 * candidate grid with Add/Edit links. The source's RadWindow popup to
 * DiscCandidateAdd.aspx is replaced with routed navigation to
 * /recruitment/disc-candidate-add (?CandidateID=), consistent with how
 * every other popup-form page in this app was migrated.
 */
@Component({
  selector: 'app-disc-candidate',
  imports: [ButtonModule, TableModule],
  templateUrl: './disc-candidate.html',
  styleUrl: './disc-candidate.scss'
})
export class DiscCandidate implements OnInit {
  private readonly data = inject(RecruitmentDataService);
  private readonly router = inject(Router);

  readonly rows = signal<DiscCandidateRow[]>([]);

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.data.getDiscCandidates().subscribe((rows) => this.rows.set(rows));
  }

  addCandidate(): void {
    this.router.navigate(['/recruitment/disc-candidate-add'], { queryParams: { CandidateID: 0 } });
  }

  editCandidate(row: DiscCandidateRow): void {
    this.router.navigate(['/recruitment/disc-candidate-add'], { queryParams: { CandidateID: row.candidateId } });
  }
}
