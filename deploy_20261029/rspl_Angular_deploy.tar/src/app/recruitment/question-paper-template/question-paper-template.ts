import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { QuestionPaperTemplateRow, RecruitmentDataService } from '../recruitment-data.service';

const DEPARTMENTS = ['Developer', 'Marketing', 'Support', 'Admin'];

/** Mirrors Section_Recruitment/QuestionPaperTemplate.aspx ("Question Paper Creation"): an add-form + inline-editable master grid of exam templates. */
@Component({
  selector: 'app-question-paper-template',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, SelectModule, TableModule],
  templateUrl: './question-paper-template.html',
  styleUrl: './question-paper-template.scss'
})
export class QuestionPaperTemplate implements OnInit {
  private readonly data = inject(RecruitmentDataService);
  // This app runs without zone.js — plain (non-signal) properties like `name`/
  // `timeInterval` below don't trigger a re-render on their own when mutated
  // inside an RxJS subscribe callback. markForCheck() after each such mutation is
  // what actually gets the new values on screen.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly departments = DEPARTMENTS;
  readonly rows = signal<QuestionPaperTemplateRow[]>([]);
  readonly saving = signal(false);

  name = '';
  department = DEPARTMENTS[0];
  timeInterval = '';

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.data.getQuestionPaperTemplates().subscribe((rows) => this.rows.set(rows));
  }

  submit(): void {
    this.saving.set(true);
    this.data.addQuestionPaperTemplate(this.name, this.department, Number(this.timeInterval) || 0).subscribe(() => {
      this.saving.set(false);
      alert('Save Sucessfully');
      this.name = '';
      this.timeInterval = '';
      this.load();
      this.cdr.markForCheck();
    });
  }

  saveRow(row: QuestionPaperTemplateRow): void {
    this.data.updateQuestionPaperTemplate(row).subscribe(() => {
      alert('Updated Sucessfully');
      this.load();
    });
  }
}
