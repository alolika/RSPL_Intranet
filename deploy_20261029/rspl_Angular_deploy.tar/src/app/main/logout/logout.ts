import { Component, OnInit, inject } from '@angular/core';
import { Router } from '@angular/router';

import { PortalAuthService } from '../../core/auth/portal-auth.service';

@Component({
  selector: 'app-logout',
  template: ''
})
export class Logout implements OnInit {
  private readonly auth = inject(PortalAuthService);
  private readonly router = inject(Router);

  ngOnInit(): void {
    this.auth.logout();
    this.router.navigate(['/login']);
  }
}
