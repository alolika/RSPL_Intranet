import { Routes } from '@angular/router';

import { portalAuthGuard } from '../core/auth/portal-auth.guard';
import { adminRoutes } from './sections/admin.routes';
import { developerRoutes } from './sections/developer.routes';
import { generalRoutes } from './sections/general.routes';
import { gstRoutes } from './sections/gst.routes';
import { marketingRoutes } from './sections/marketing.routes';
import { supportRoutes } from './sections/support.routes';

export const mainRoutes: Routes = [
  {
    path: '',
    loadComponent: () => import('./layout/main-layout').then((m) => m.MainLayout),
    canActivate: [portalAuthGuard],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      {
        path: 'dashboard',
        loadComponent: () => import('./dashboard/dashboard').then((m) => m.Dashboard)
      },
      {
        path: 'default',
        loadComponent: () => import('../shared/coming-soon/coming-soon').then((m) => m.ComingSoon),
        data: { title: 'Default' }
      },
      {
        path: 'default2',
        loadComponent: () => import('../shared/coming-soon/coming-soon').then((m) => m.ComingSoon),
        data: { title: 'Default2' }
      },
      { path: 'developer', children: developerRoutes },
      { path: 'gst', children: gstRoutes },
      { path: 'general', children: generalRoutes },
      { path: 'support', children: supportRoutes },
      { path: 'admin', children: adminRoutes },
      { path: 'marketing', children: marketingRoutes }
    ]
  }
];
