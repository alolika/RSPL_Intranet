import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../../shared/api-config';

export interface SoftwareClientCount {
  softwareName: string;
  totalCount: number;
}

interface ApiSoftwareClientCount {
  software_name: string;
  total_count: number;
}

export interface HolidayListItem {
  date: string;
  occasion: string;
  isoDate: string;
  isPast: boolean;
}

interface ApiHolidayListRow {
  holiday_date: string;
  to_date: string;
  day: string;
  event: string;
}

/**
 * Mirrors DashBoard.aspx.vb's FillStatistic ("EXEC webproc_softwarecusttotal")
 * — see general_dashboards.py's get_software_client_count for the real
 * per-software counts (RetailwarePro/Retailware/Jewelsoft/BillKwik/etc.).
 * Was a hardcoded 3-row all-zero mock until now.
 */
@Injectable({ providedIn: 'root' })
export class DashboardDataService {
  private readonly http = inject(HttpClient);

  getSoftwareClientCounts(): Observable<SoftwareClientCount[]> {
    return this.http.get<ApiSoftwareClientCount[]>(`${API_BASE_URL}/general/dashboards/software-client-count`).pipe(
      map((rows) => rows.map((r) => ({ softwareName: r.software_name, totalCount: r.total_count })))
    );
  }

  // "Holiday List" tile — now reads RSPL_HolidayMaster (managed via the new
  // Accounts > Holiday Master admin page) instead of a static mock. See
  // general_dashboards.py's get_holiday_list.
  getHolidayList(): Observable<HolidayListItem[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const fmt = (iso: string) => new Date(iso).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
    return this.http.get<ApiHolidayListRow[]>(`${API_BASE_URL}/general/dashboards/holiday-list`).pipe(
      map((rows) =>
        rows.map((r) => ({
          // Single-day holidays (the common case) show one date; multi-day
          // ranges show "From - To" now that Holiday Master supports them.
          date: r.holiday_date === r.to_date ? fmt(r.holiday_date) : `${fmt(r.holiday_date)} - ${fmt(r.to_date)}`,
          occasion: r.event,
          isoDate: r.holiday_date,
          // A multi-day holiday is only "past" once its whole range has
          // ended, not just its start date.
          isPast: new Date(r.to_date) < today
        }))
      )
    );
  }

  // Card title, editable from the same Holiday Master admin page (was
  // hardcoded "Holiday List 24-25" in this component before). See
  // general_dashboards.py's get_holiday_list_title.
  getHolidayListTitle(): Observable<string> {
    return this.http
      .get<{ name: string }>(`${API_BASE_URL}/general/dashboards/holiday-list-title`)
      .pipe(map((r) => r.name));
  }
}
