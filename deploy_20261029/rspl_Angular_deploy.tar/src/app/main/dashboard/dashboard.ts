import { DecimalPipe } from '@angular/common';
import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild, computed, inject, signal } from '@angular/core';
import { CardModule } from 'primeng/card';
import { TableModule } from 'primeng/table';
import { Chart, ChartConfiguration } from 'chart.js/auto';

import { PortalAuthService } from '../../core/auth/portal-auth.service';
import { DashboardDataService, HolidayListItem, SoftwareClientCount } from './dashboard-data.service';

interface ChartRow {
  label: string;
  value: number;
}

// Long tail of tiny/edge-case categories folds into "Other" for the chart
// only (per dataviz skill's series-count ladder) -- the full breakdown
// still shows in the table below, so no data is actually hidden.
const MAX_CHART_BARS = 6;

/**
 * Redesigned main dashboard (previously: two bare PrimeNG tables in a plain
 * flex column, both fed by hardcoded mocks -- see prior sessions' updates
 * that wired Software Client Count and Holiday List to real data). This
 * pass focuses purely on presentation: a KPI row, a ranked bar chart for
 * the software distribution (dataviz skill: "compare magnitude" -> bar,
 * sequential single hue -- not a pie, since 11 categories with a 1967-vs-1
 * spread would produce unreadable slivers), and a restyled holiday list
 * with Upcoming/Past badges. No new backend endpoints -- built entirely
 * from the two data sources already wired (software-client-count,
 * holiday-list) plus the logged-in user's short name for the greeting.
 */
@Component({
  selector: 'app-dashboard',
  imports: [CardModule, TableModule, DecimalPipe],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.scss'
})
export class Dashboard implements AfterViewInit, OnDestroy {
  private readonly data = inject(DashboardDataService);
  private readonly auth = inject(PortalAuthService);

  @ViewChild('clientChartCanvas') chartCanvasRef?: ElementRef<HTMLCanvasElement>;
  private chart: Chart | null = null;

  readonly userName = computed(() => this.auth.currentUser()?.userName || '');
  readonly today = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });

  readonly loadingSoftware = signal(true);
  readonly loadingHolidays = signal(true);
  readonly softwareCounts = signal<SoftwareClientCount[]>([]);
  readonly holidays = signal<HolidayListItem[]>([]);
  readonly holidayListTitle = signal('Holiday List');

  readonly totalClients = computed(() => this.softwareCounts().reduce((sum, r) => sum + r.totalCount, 0));
  readonly topSoftware = computed<SoftwareClientCount | null>(() => {
    const rows = this.softwareCounts();
    return rows.length === 0 ? null : rows.reduce((a, b) => (b.totalCount > a.totalCount ? b : a));
  });
  readonly categoryCount = computed(() => this.softwareCounts().length);
  readonly upcomingHolidayCount = computed(() => this.holidays().filter((h) => !h.isPast).length);

  ngAfterViewInit(): void {
    this.data.getSoftwareClientCounts().subscribe({
      next: (r) => {
        this.softwareCounts.set(r);
        this.loadingSoftware.set(false);
        setTimeout(() => this.drawChart(r));
      },
      error: () => {
        this.softwareCounts.set([]);
        this.loadingSoftware.set(false);
      }
    });
    this.data.getHolidayList().subscribe({
      next: (r) => {
        this.holidays.set(r);
        this.loadingHolidays.set(false);
      },
      error: () => {
        this.holidays.set([]);
        this.loadingHolidays.set(false);
      }
    });
    this.data.getHolidayListTitle().subscribe({
      next: (name) => this.holidayListTitle.set(name)
    });
  }

  ngOnDestroy(): void {
    this.chart?.destroy();
  }

  // Chart.js series color is the dataviz skill's validated sequential hue
  // (blue, one shade) -- this is a ranked-magnitude comparison of one
  // metric across many named categories, not a multi-series identity
  // chart, so a single hue is the correct color job (not categorical).
  private drawChart(rows: SoftwareClientCount[]): void {
    const canvas = this.chartCanvasRef?.nativeElement;
    if (!canvas || rows.length === 0) {
      return;
    }
    const sorted = [...rows].sort((a, b) => b.totalCount - a.totalCount);
    const top = sorted.slice(0, MAX_CHART_BARS);
    const rest = sorted.slice(MAX_CHART_BARS);
    const chartRows: ChartRow[] = top.map((r) => ({ label: this.titleCase(r.softwareName), value: r.totalCount }));
    if (rest.length > 0) {
      chartRows.push({ label: `Other (${rest.length})`, value: rest.reduce((sum, r) => sum + r.totalCount, 0) });
    }

    const config: ChartConfiguration<'bar'> = {
      type: 'bar',
      data: {
        labels: chartRows.map((r) => r.label),
        datasets: [{ data: chartRows.map((r) => r.value), backgroundColor: '#2a78d6', borderRadius: 4, maxBarThickness: 28 }]
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (ctx) => ` ${ctx.parsed.x.toLocaleString('en-IN')} clients`
            }
          }
        },
        scales: {
          x: {
            grid: { color: '#e1e0d9' },
            ticks: { callback: (v) => Number(v).toLocaleString('en-IN') }
          },
          y: { grid: { display: false } }
        }
      }
    };
    this.chart?.destroy();
    this.chart = new Chart(canvas, config);
  }

  // Plain title-casing would mangle acronym-like real category names (e.g.
  // "RL_AJ" -> "Rl_aj", "F&B" -> "F&b") -- any token with a non-letter
  // character is left as-is instead. A leading "." (".NOT APPLICABLE" in
  // the real data) is stripped as pure display noise.
  private titleCase(raw: string): string {
    return raw
      .replace(/^\.+/, '')
      .trim()
      .split(/\s+/)
      .map((w) => (/[^a-zA-Z]/.test(w) ? w : w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()))
      .join(' ');
  }

  displaySoftwareName(raw: string): string {
    return this.titleCase(raw);
  }
}
