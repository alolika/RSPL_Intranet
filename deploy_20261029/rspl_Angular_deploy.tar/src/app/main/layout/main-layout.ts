import { Component, computed, inject } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { MenubarModule } from 'primeng/menubar';

import { PortalAuthService } from '../../core/auth/portal-auth.service';
import { UserRightsService } from '../../core/auth/user-rights.service';
import { EngHubMenuRightsService } from '../../engineering-hub/menu-rights.service';
import { MobileNav } from '../../shared/mobile-nav/mobile-nav';
import { buildMainNav } from './main-nav';

@Component({
  selector: 'app-main-layout',
  imports: [RouterOutlet, RouterLink, MenubarModule, MobileNav],
  templateUrl: './main-layout.html',
  styleUrl: './main-layout.scss'
})
export class MainLayout {
  private readonly router = inject(Router);
  readonly auth = inject(PortalAuthService);
  private readonly rights = inject(UserRightsService);
  private readonly engHubMenuRights = inject(EngHubMenuRightsService);
  // computed (not a one-time call) so the menu updates itself once
  // /user-rights/me resolves, instead of freezing whatever it saw at the
  // instant this component was constructed.
  readonly navItems = computed(() =>
    buildMainNav((formCode) => this.rights.access(formCode), this.rights.isRightsAdmin(), this.engHubMenuRights.mine())
  );

  logout(): void {
    this.auth.logout();
    this.router.navigate(['/login']);
  }

  // Always /dashboard specifically — the same route login.ts itself
  // navigates to on successful login (main.routes.ts's default child route
  // under this same layout) — not `history.back()`, which would return to
  // whatever page was open before, not necessarily the dashboard.
  backToDashboard(): void {
    this.router.navigate(['/dashboard']);
  }
}
