import { MenuItem } from 'primeng/api';

import {
  AccessLevel,
  FORM_CALL_HISTORY,
  FORM_EMPLOYEE_ATTENDANCE_SHEET,
  FORM_EXEC_SCHEDULE,
  FORM_HOLIDAY_MASTER,
  FORM_SENTIMETER
} from '../../core/auth/user-rights.service';
import { buildEngineeringHubNav } from '../../engineering-hub/layout/engineering-hub-nav';
import { MyEngHubMenus } from '../../engineering-hub/menu-rights.service';

/**
 * Mirrors App_Master/Home.master's RadMenu tree exactly (item text, order,
 * nesting). Routes are namespaced by source section folder.
 *
 * Known source inconsistencies preserved rather than silently fixed:
 * - Help > Download points to Section_General/Downloads.aspx, which does not
 *   exist anywhere in the source project (dead link in the original app).
 * - "Developer" top menu is Visible="false" in the source; kept visible here
 *   so its pages stay reachable/verifiable during migration.
 *
 * `access` resolves a User Rights form code to this user's effective level —
 * Executive Schedule, Holiday Master, and Call History are the only 3 items
 * that ever get hidden (access === 'none'); every other item is unaffected
 * by User Rights entirely. `isRightsAdmin` additionally gates the "User
 * Rights" management item itself (Admin > Masters) to the fixed rights-admin
 * allow-list — everyone else never sees it, though the backend enforces
 * this independently regardless of what the menu shows.
 *
 * `engHubMenus` is the user's Engineering Hub Menu Rights (null until
 * loaded): the Engineering Hub group lists only granted menus, and is left
 * out entirely when there are none.
 */
export function buildMainNav(
  access: (formCode: string) => AccessLevel,
  isRightsAdmin: boolean,
  engHubMenus: MyEngHubMenus | null
): MenuItem[] {
  const engHubItems: MenuItem[] = buildEngineeringHubNav()
    .filter((item) => engHubMenus?.menus.includes(item.code))
    .map((item) => ({ label: item.label, routerLink: item.link }));
  if (engHubMenus?.isAdmin) {
    engHubItems.push({ label: 'Menu Rights', routerLink: '/engineering-hub/menu-rights' });
  }

  return [
    {
      label: 'Dashboard',
      // Mirrors App_Master/Home.master.vb's Page_Init, which builds this
      // menu group dynamically at runtime from rspl_ReportDashboardTypeMAster
      // (WHERE ApplicationType='Web' AND enabled=1) — confirmed live to have
      // 3 enabled rows (ReportTypeID 1/2/5). Hardcoded here since the app has
      // no equivalent "build nav from DB" mechanism anywhere else; the menu
      // group itself was previously missing everything except the one
      // separately-hardcoded AMCCo-OrdinatorDashBoard item below.
      items: [
        { label: 'AMCCo-OrdinatorDashBoard', routerLink: '/support/amc-coordinator-dashboard' },
        // ReportTypeID=1 "Support Co-Ordinator DashBoard" — confirmed same 8
        // tiles (byte-identical Report_Query proc names) as the already-built
        // RSPL_SupportCoOrdinatorDashboard-backed page, just reachable via a
        // second legacy table. Fully built and routed but never linked from
        // any menu in either the source app or this migration until now.
        { label: 'Support Co-Ordinator Dashboard', routerLink: '/support/support-coordinator-dashboard' },
        // ReportTypeID=2 — genuinely new, not previously migrated.
        { label: 'Sales Team DashBoard', routerLink: '/general/sales-team-dashboard' },
        // ReportTypeID=5 — genuinely new, distinct from AMCCo-OrdinatorDashBoard above.
        { label: 'AMC Dashboard', routerLink: '/general/amc-dashboard' }
      ]
    },
    {
      label: 'Marketing',
      items: [
        {
          label: 'Register Customer',
          items: [
            { label: 'Customer-Create', routerLink: '/marketing/cust-registration-new' },
            { label: 'Customer-Modify', routerLink: '/marketing/cust-registration-modify' }
          ]
        },
        {
          label: 'Lead Enquiry',
          items: [
            { label: 'Enquiry-DownLoaded', routerLink: '/marketing/enquiry-downloaded' },
            { label: 'Enquiry-Create', routerLink: '/marketing/cust-enquiry', queryParams: { ActionType: 1 } },
            { label: 'Enquiry-Modify', routerLink: '/marketing/cust-enquiry', queryParams: { ActionType: 2 } },
            {
              label: 'Enquiry-Action',
              routerLink: '/marketing/cust-enquiry-register',
              queryParams: { Auto: 0, CustID: 0 }
            },
            { label: 'Enquiry-Telecalling', routerLink: '/marketing/cust-tele-calling-register' },
            {
              label: 'Customer-Action',
              routerLink: '/marketing/cust-enquiry-register',
              queryParams: { Auto: 1, CustID: 0 }
            },
            { label: 'Customer-Action Delay', routerLink: '/marketing/action-delay-report' }
          ]
        },
        {
          label: 'Lead Reports',
          items: [
            { label: 'Lead Record', routerLink: '/marketing/lead-record' },
            { label: 'Enquiry Stage Report', routerLink: '/marketing/action-stage-summary-report' },
            { label: 'Tour Count Report', routerLink: '/marketing/tour-details' },
            { label: 'Lead Pending Status', routerLink: '/marketing/cust-enquiry-status' },
            { label: 'Lead Summary Report', routerLink: '/marketing/cust-lead-report' },
            { label: 'Lead Summary Chart', routerLink: '/marketing/cust-lead-chart' },
            { label: 'CRM Activity Report', routerLink: '/marketing/crm-activity' },
            { label: 'Enquiry Report', routerLink: '/marketing/crm-report' },
            { label: 'Enquiry Search Report', routerLink: '/marketing/action-search-report' },
            { label: 'Next Action Not Decided', routerLink: '/marketing/next-action-not-taken' },
            { label: 'Action Not taken', routerLink: '/marketing/action-not-taken' }
          ]
        },
        {
          label: 'Geo Location',
          items: [
            { label: 'CustomerMap-Locate', routerLink: '/marketing/entity-lat-long' },
            { label: 'CustomerMap-Pin', routerLink: '/marketing/cust-map-location' },
            { label: 'CustomerMap-Heat', routerLink: '/marketing/cust-heat-map' }
          ]
        },
        { label: 'Tour Report', routerLink: '/marketing/tour-report' },
        { label: 'Outstanding Followup', routerLink: '/marketing/outstanding-followup' },
        { label: 'e-Referral Register', routerLink: '/marketing/e-referral-register' },
        { label: 'Action Delay Report', routerLink: '/marketing/action-delay' },
        { label: 'Activity Status Log', routerLink: '/marketing/activity-status-log' },
        { label: 'Thanks Note', routerLink: '/marketing/thanks-note' }
      ]
    },
    {
      label: 'Developer',
      items: [
        { label: 'Daily Log Form', routerLink: '/developer/daily-log' },
        { label: 'Daily Log Register', routerLink: '/developer/daily-log-register' },
        { label: 'Retailware YTTable', routerLink: '/developer/table-list' }
      ]
    },
    {
      label: 'Admin',
      items: [
        {
          label: 'Masters',
          items: [
            { label: 'Web Masters', routerLink: '/admin/web-masters' },
            { label: 'New Article', routerLink: '/admin/article' },
            { label: 'My Caller History', routerLink: '/admin/my-caller-history' },
            { label: 'Add Videos', routerLink: '/admin/add-videos', queryParams: { Add: 1 } },
            ...(isRightsAdmin ? [{ label: 'User Rights', routerLink: '/admin/user-rights' }] : [])
          ]
        },
        {
          label: 'Register',
          items: [
            { label: 'CustModule Register', routerLink: '/admin/cust-ledger' },
            { label: 'Article Register', routerLink: '/admin/article-register' },
            { label: 'Feedback Register', routerLink: '/admin/feedback-register' },
            { label: 'Leave Register', routerLink: '/admin/leave-app-register' },
            { label: 'Leave App Register', routerLink: '/admin/leave-app-register1' },
            { label: 'Referral Analysis Report', routerLink: '/admin/referral-analysis' },
            {
              label: 'AMC Followup',
              routerLink: '/support/amc-pending',
              queryParams: { FromMenu: 'AMCPending' }
            },
            {
              label: "My Today's Work",
              routerLink: '/support/amc-pending',
              queryParams: { FromMenu: 'AMCLastAction' }
            },
            { label: 'CRM Review', routerLink: '/admin/crm-review' }
          ]
        },
        {
          label: 'Org Chart',
          routerLink: '/general/organizational-chart',
          items: [
            { label: 'Manage Chart', routerLink: '/general/manage-chart' },
            { label: 'Show Chart', routerLink: '/general/organizational-chart' }
          ]
        }
      ]
    },
    {
      label: 'Accounts',
      items: [
        { label: 'Pipe Line', routerLink: '/admin/ledger-balance' },
        { label: 'Advance', routerLink: '/admin/advance' },
        { label: 'Customer TIN No Follow Up', routerLink: '/admin/cust-tin-followup' },
        { label: 'Customer Answer', routerLink: '/admin/customer-ans' },
        { label: 'Customer License Violation', routerLink: '/admin/customer-license-violation' },
        { label: 'Customer Grace Period', routerLink: '/admin/customer-grace-period' },
        ...(access(FORM_HOLIDAY_MASTER) !== 'none' ? [{ label: 'Holiday Master', routerLink: '/admin/holiday-master' }] : []),
        { label: 'Face In/Out', routerLink: '/admin/face-in-out' },
        { label: 'Face Register', routerLink: '/admin/face-register' }
      ]
    },
    {
      label: 'Support',
      items: [
        { label: 'Trouble Ticket', routerLink: '/support/trouble-ticket' },
        { label: 'Pending TT Register', routerLink: '/support/trouble-ticket-modify' },
        { label: 'TT Register', routerLink: '/support/tt-register' },
        { label: 'VisitLog', routerLink: '/support/visit-log' },
        { label: 'VisitLog V1', routerLink: '/support/visit-log-register' },
        { label: 'VisitLog V2', routerLink: '/support/visit-log-report' },
        ...(access(FORM_EXEC_SCHEDULE) !== 'none' ? [{ label: 'Executive Schedule', routerLink: '/support/executive-schedule' }] : []),
        {
          label: 'Retailware Pending MissedCall',
          routerLink: '/support/missed-call',
          queryParams: { Product: 'Retailware' }
        },
        {
          label: 'Jewelsoft Pending MissedCall',
          routerLink: '/support/missed-call',
          queryParams: { Product: 'Jewelsoft' }
        },
        {
          label: 'Marketing Pending MissedCall',
          routerLink: '/support/missed-call',
          queryParams: { Product: 'Marketing' }
        },
        {
          label: 'DMS Pending MissedCall',
          routerLink: '/support/missed-call',
          queryParams: { Product: 'DONAR MANAGEMENT SYSTEM' }
        },
        ...(access(FORM_CALL_HISTORY) !== 'none' ? [{ label: 'Call History', routerLink: '/support/call-history' }] : []),
        ...(access(FORM_SENTIMETER) !== 'none' ? [{ label: 'Customer Sentimeter', routerLink: '/support/sentimeter' }] : []),
        { label: 'Einvoice Status', routerLink: '/support/einvoice-status' }
      ]
    },
    {
      label: 'General',
      items: [
        { label: 'New Feedback', routerLink: '/general/feedback' },
        { label: 'Video History', routerLink: '/support/video-history' },
        { label: 'Asset Track', routerLink: '/general/asset-track' },
        { label: 'Leave Application', routerLink: '/general/leave-application' },
        { label: 'Leave Cancellation', routerLink: '/general/leave-cancellation' },
        { label: 'Employee Attendance', routerLink: '/general/emp-attendance' },
        { label: 'Face Attendance', routerLink: '/general/face-attendance' },
        ...(access(FORM_EMPLOYEE_ATTENDANCE_SHEET) !== 'none'
          ? [{ label: 'Employee Attendance Sheet', routerLink: '/general/employee-attendance-sheet' }]
          : []),
        { label: 'Vote For Best Share', routerLink: '/developer/vote-for-best-share' },
        { label: 'Employee Schedule', routerLink: '/general/schedule' },
        { label: 'My Caller History', routerLink: '/general/my-caller' },
        {
          label: 'Payment Voucher',
          routerLink: '/admin/payment-voucher',
          queryParams: { IsPaymentVoucher: 1 }
        },
        {
          label: 'Prepayment Voucher',
          routerLink: '/admin/payment-voucher',
          queryParams: { IsPaymentVoucher: 0 }
        },
        { label: 'Developer Log', routerLink: '/developer/daily-log' }
      ]
    },
    { label: 'Reports', routerLink: '/general/dynamic-reports' },
    {
      label: 'GST',
      items: [
        { label: 'GST State Master', routerLink: '/gst/gst-state-master' },
        { label: 'GST Tax Master', routerLink: '/gst/gst-tax-master' },
        { label: 'GST Report Request Log', routerLink: '/gst/client-software-menu-request' },
        { label: 'GST Tax calculator', routerLink: '/gst/gst-tax-calculator' }
      ]
    },
    {
      label: 'Help',
      items: [
        { label: 'Download', routerLink: '/general/downloads' },
        { label: 'Training Videos', routerLink: '/admin/add-videos', queryParams: { Add: 0 } }
      ]
    },
    // Engineering Hub has no legacy Home.master counterpart (it's a brand-new
    // greenfield module, not a migrated page) — added here as the entry point
    // from the main portal. Sub-items come from engineering-hub-nav.ts,
    // filtered by the user's Engineering Hub Menu Rights.
    ...(engHubItems.length
      ? [
          {
            label: 'Engineering Hub',
            routerLink: '/engineering-hub',
            items: engHubItems
          }
        ]
      : [])
  ];
}
