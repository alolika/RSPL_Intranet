import { Component } from '@angular/core';

/**
 * Mirrors Default2.aspx: an unlinked leftover demo page embedding a sample
 * video. No session check in the source (standalone page, not on
 * Home.master). The source's obsolete Windows Media Player <object>/<embed>
 * fallback (for browsers with no native video support) is not replicated —
 * only the HTML5 <video> element, which is what actually renders anywhere
 * this app would be viewed today.
 */
@Component({
  selector: 'app-default2',
  imports: [],
  templateUrl: './default2.html',
  styleUrl: './default2.scss'
})
export class Default2 {}
