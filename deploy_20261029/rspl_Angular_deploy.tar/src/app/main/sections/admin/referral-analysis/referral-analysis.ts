import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import { AdminDataService, ReferralAnalysisRow } from '../admin-data.service';

/** Mirrors Section_Admin/ReferralAnalysis.aspx ("Customer Referral Analysis"): filter panel + grid with a bold Total summary row. */
@Component({
  selector: 'app-referral-analysis',
  imports: [FormsModule, ButtonModule, DatePickerModule, InputTextModule, SelectModule, TableModule, DatePipe, IndianNumberPipe],
  templateUrl: './referral-analysis.html',
  styleUrl: './referral-analysis.scss'
})
export class ReferralAnalysis implements OnInit {
  private readonly data = inject(AdminDataService);

  readonly cities = signal<string[]>([]);
  readonly referredByOptions = signal<string[]>([]);
  readonly referralNames = signal<string[]>([]);
  readonly orderByOptions = signal<string[]>([]);
  readonly rows = signal<ReferralAnalysisRow[]>([]);
  readonly loading = signal(false);
  readonly totalAmount = signal(0);
  readonly totalBalance = signal(0);

  readonly statusOptions = [
    { label: 'All', value: 0 },
    { label: 'Converted', value: 1 },
    { label: 'Pending', value: 2 }
  ];

  status = 0;
  referredCity = '';
  referredBy = '';
  fromDate: Date | null = null;
  toDate: Date | null = null;
  orderNo = '';
  referralCardNo = '';
  referralName = '';
  orderBy = '';

  ngOnInit(): void {
    this.data.getReferralAnalysisFilters().subscribe((f) => {
      this.cities.set(f.cities);
      this.referredByOptions.set(f.referredBy);
      this.referralNames.set(f.referralNames);
      this.orderByOptions.set(f.orderBy);
    });
    // Mirrors the source: ReferralAnalysis.aspx.vb's Page_Load only fills the
    // filter combos — FillGV only ever runs from btnShow_Click, never
    // unconditionally on open. The unfiltered query scans all 6595 rows of
    // VW_Customer_Refferal_Dtls (~2s) — auto-loading it on every page visit
    // (as this component previously did) was a deviation from the source,
    // not a faithful default.
  }

  onCityFilter(query: string): void {
    this.data.getReferralAnalysisCities(query).subscribe((c) => this.cities.set(c));
  }

  onReferredByFilter(query: string): void {
    this.data.getReferralAnalysisReferredBy(query).subscribe((r) => this.referredByOptions.set(r));
  }

  onReferralNameFilter(query: string): void {
    this.data.getReferralAnalysisReferralNames(query).subscribe((r) => this.referralNames.set(r));
  }

  show(): void {
    if (this.fromDate && this.toDate && this.fromDate > this.toDate) {
      alert('Please select From date smaller than To date');
      return;
    }
    this.loading.set(true);
    this.data
      .getReferralAnalysisRows({
        status: this.status,
        referredCity: this.referredCity,
        referredBy: this.referredBy,
        fromDate: this.fromDate,
        toDate: this.toDate,
        orderNo: this.orderNo,
        referralCardNo: this.referralCardNo,
        referralName: this.referralName,
        orderBy: this.orderBy
      })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.totalAmount.set(rows.reduce((sum, r) => sum + r.amount, 0));
        this.totalBalance.set(rows.reduce((sum, r) => sum + r.balanceAmt, 0));
        this.loading.set(false);
      });
  }

  export(): void {
    exportToExcel('ReferralAnalysisReport', this.rows());
  }
}
