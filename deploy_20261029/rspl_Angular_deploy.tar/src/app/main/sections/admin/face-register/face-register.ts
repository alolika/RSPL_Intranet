import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  computed,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

import { FaceApiService, FaceBox, FACE_DESCRIPTOR_LENGTH } from '../../../../shared/face/face-api.service';
import { EmployeeRow, FaceDataService } from '../../general/face-data.service';

type Phase = 'picker' | 'preparing' | 'guiding' | 'capturing' | 'uploading' | 'done' | 'error';
type Guidance = 'position' | 'noFace' | 'tooSmall' | 'tooLarge' | 'offCenter' | 'ok';

const SHOT_COUNT = 15;
const STABLE_FRAMES_REQUIRED = 10;
const DETECTION_INTERVAL_MS = 150;
const REFERENCE_IMAGE_SIDE = 320;
const MIN_CAPTURE_SCORE = 0.75;
const CAPTURES_PER_POSE = 5;
const POSE_PROMPTS = [
  'Look straight at the camera',
  'Turn your head slightly left',
  'Turn your head slightly right',
] as const;

@Component({
  selector: 'app-face-register',
  standalone: true,
  imports: [FormsModule, ButtonModule, InputTextModule, MessageModule, ProgressSpinnerModule],
  template: `
    <div class="face-register-page">
      <div class="page-hero">
        <div class="hero-icon"><i class="pi pi-camera"></i></div>
        <h3 class="hero-title">Face Registration</h3>
        <p class="hero-sub">Enrol employees for face-based attendance</p>
      </div>

      @if (phase() === 'picker') {
        <div class="toolbar-card">
          <input
            pInputText
            [(ngModel)]="searchText"
            placeholder="Search by name…"
            class="search-input"
          />
        </div>

        @if (loadError()) {
          <p-message severity="error" styleClass="w-full banner" [text]="loadError()!" />
        }

        @if (loading()) {
          <div class="centered-spinner">
            <p-progressSpinner strokeWidth="4" />
            <p>Loading employees…</p>
          </div>
        } @else {
          <p class="count-hint">{{ filtered().length }} of {{ employees().length }} employees</p>
          <div class="employee-list">
            @for (emp of filtered(); track emp.userId) {
              <div class="emp-card" (click)="startCapture(emp)" role="button" tabindex="0"
                   (keydown.enter)="startCapture(emp)">
                <div class="emp-avatar">
                  <i class="pi pi-user"></i>
                </div>
                <div class="emp-info">
                  <span class="emp-name">{{ emp.userName }}</span>
                </div>
                @if (emp.faceRegisteredAt) {
                  <span class="enrolled-badge">
                    <i class="pi pi-check-circle"></i> Enrolled
                  </span>
                } @else {
                  <span class="not-enrolled-badge">Not enrolled</span>
                }
              </div>
            } @empty {
              <p class="empty-hint">No employees match your search.</p>
            }
          </div>
        }
      } @else {
        <!-- Camera phase -->
        <div class="camera-panel">
          <div class="viewfinder-wrap">
            <video #video playsinline autoplay muted class="camera-video"></video>
            <canvas #overlay class="camera-overlay"></canvas>

            @if (phase() === 'uploading') {
              <div class="camera-scrim">
                <p-progressSpinner strokeWidth="4" />
                <p>Saving…</p>
              </div>
            }
            @if (phase() === 'done') {
              <div class="camera-scrim success">
                <i class="pi pi-check-circle"></i>
                <p>Enrolled!</p>
              </div>
            }
          </div>

          <div class="camera-status">
            <p class="employee-title">{{ selected()?.userName }}</p>

            @switch (phase()) {
              @case ('preparing') {
                <p><i class="pi pi-spin pi-spinner"></i> Starting camera…</p>
              }
              @case ('guiding') {
                <p [class]="guidance() === 'ok' ? 'ok-text' : 'guide-text'">
                  {{ guideMessage() }}
                </p>
              }
              @case ('capturing') {
                <p class="ok-text">{{ posePrompt() }}</p>
                <p class="muted-text">Captured {{ shotsTaken() }} of {{ shotCount }}</p>
              }
              @case ('uploading') {
                <p>Saving face data…</p>
              }
              @case ('done') {
                <p class="ok-text">{{ selected()?.userName }} is now enrolled.</p>
                <p-button label="Register another" icon="pi pi-refresh" (onClick)="backToPicker()" />
              }
              @case ('error') {
                <p-message severity="error" [text]="errorMessage()" styleClass="w-full" />
                <p-button label="Back" icon="pi pi-arrow-left" (onClick)="backToPicker()" />
              }
            }

            @if (phase() !== 'done' && phase() !== 'error') {
              <p-button
                label="Cancel"
                severity="secondary"
                [text]="true"
                (onClick)="backToPicker()"
              />
            }
          </div>
        </div>
      }
    </div>
  `,
  styles: `
    .face-register-page { padding: 20px; max-width: 700px; margin: 0 auto; }

    .page-hero { text-align: center; margin-bottom: 24px; }
    .hero-icon { font-size: 2.5rem; color: var(--p-primary-color, #6366f1); }
    .hero-title { font-size: 1.5rem; font-weight: 700; margin: 8px 0 4px; }
    .hero-sub { color: #666; margin: 0; }

    .toolbar-card { margin-bottom: 16px; }
    .search-input { width: 100%; }

    .count-hint { font-size: 0.85rem; color: #888; margin-bottom: 8px; }

    .employee-list { display: flex; flex-direction: column; gap: 8px; }
    .emp-card {
      display: flex; align-items: center; gap: 12px;
      padding: 12px 16px; border-radius: 10px;
      border: 1px solid #e0e0e0; background: #fff;
      cursor: pointer; transition: box-shadow 0.15s;
    }
    .emp-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
    .emp-avatar {
      width: 42px; height: 42px; border-radius: 50%;
      background: #e8eaf6; display: flex; align-items: center; justify-content: center;
      font-size: 1.2rem; color: #5c6bc0; flex-shrink: 0;
    }
    .emp-info { flex: 1; }
    .emp-name { font-weight: 600; }
    .enrolled-badge {
      font-size: 0.75rem; background: #e6f4ea; color: #2e7d32;
      padding: 3px 8px; border-radius: 12px; white-space: nowrap;
    }
    .not-enrolled-badge {
      font-size: 0.75rem; background: #f5f5f5; color: #888;
      padding: 3px 8px; border-radius: 12px; white-space: nowrap;
    }
    .empty-hint { text-align: center; color: #888; padding: 20px; }

    .centered-spinner { display: flex; flex-direction: column; align-items: center; gap: 12px; padding: 40px; }

    /* Camera */
    .camera-panel { display: flex; flex-direction: column; align-items: center; gap: 16px; }
    .viewfinder-wrap {
      position: relative; width: min(340px, 100%); aspect-ratio: 3/4;
      background: #000; border-radius: 18px; overflow: hidden;
      box-shadow: 0 10px 24px rgba(0,0,0,0.22);
    }
    .camera-video {
      width: 100%; height: 100%; object-fit: cover;
      transform: scaleX(-1);
    }
    .camera-overlay {
      position: absolute; inset: 0; width: 100%; height: 100%; pointer-events: none;
    }
    .camera-scrim {
      position: absolute; inset: 0;
      background: rgba(0,0,0,0.55); color: #fff;
      display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 12px;
    }
    .camera-scrim.success { background: rgba(16,124,16,0.72); }
    .camera-scrim .pi-check-circle { font-size: 72px; }

    .camera-status { text-align: center; display: flex; flex-direction: column; align-items: center; gap: 8px; }
    .employee-title { font-size: 1.1rem; font-weight: 700; margin: 0; }
    .ok-text { color: #2e7d32; font-weight: 600; margin: 0; }
    .guide-text { color: #b26a00; margin: 0; }
    .muted-text { color: #888; font-size: 0.9rem; margin: 0; }
  `,
})
export class FaceRegister implements OnInit, OnDestroy {
  protected readonly shotCount = SHOT_COUNT;

  private readonly faceData = inject(FaceDataService);
  private readonly faceApi = inject(FaceApiService);
  private readonly cdr = inject(ChangeDetectorRef);

  private readonly videoRef = viewChild<ElementRef<HTMLVideoElement>>('video');
  private readonly overlayRef = viewChild<ElementRef<HTMLCanvasElement>>('overlay');

  protected readonly employees = signal<EmployeeRow[]>([]);
  protected readonly loading = signal(false);
  protected readonly loadError = signal<string | null>(null);
  protected searchText = '';

  protected readonly filtered = computed(() => {
    const q = this.searchText.toLowerCase().trim();
    return this.employees().filter(
      (e) => !q || e.userName.toLowerCase().includes(q),
    );
  });

  protected readonly phase = signal<Phase>('picker');
  protected readonly selected = signal<EmployeeRow | null>(null);
  protected readonly guidance = signal<Guidance>('position');
  protected readonly shotsTaken = signal(0);
  protected readonly errorMessage = signal('');

  protected readonly guideMessage = computed((): string => {
    switch (this.guidance()) {
      case 'noFace': return 'Looking for a face…';
      case 'tooSmall': return 'Move a little closer.';
      case 'tooLarge': return 'Move a little further back.';
      case 'offCenter': return 'Center your face in the oval.';
      case 'ok': return 'Hold steady — capturing in a moment.';
      default: return 'Position your face in the oval.';
    }
  });

  protected readonly posePrompt = computed((): string => {
    const idx = Math.min(
      POSE_PROMPTS.length - 1,
      Math.floor(this.shotsTaken() / CAPTURES_PER_POSE),
    );
    return POSE_PROMPTS[idx];
  });

  private stableFrames = 0;
  private descriptors: Float32Array[] = [];
  private snapshotPending: { video: HTMLVideoElement; box: FaceBox } | null = null;
  private stream: MediaStream | null = null;
  private detectTimer: ReturnType<typeof setInterval> | null = null;
  private disposed = false;

  ngOnInit(): void {
    void this.loadEmployees();
  }

  ngOnDestroy(): void {
    this.disposed = true;
    this.stopCamera();
  }

  private async loadEmployees(): Promise<void> {
    this.loading.set(true);
    this.loadError.set(null);
    try {
      this.employees.set(await this.faceData.listEmployees());
    } catch (err) {
      this.loadError.set((err as Error).message || 'Could not load employees.');
    } finally {
      this.loading.set(false);
      this.cdr.markForCheck();
    }
  }

  async startCapture(emp: EmployeeRow): Promise<void> {
    this.selected.set(emp);
    this.phase.set('preparing');
    this.descriptors = [];
    this.snapshotPending = null;
    this.stableFrames = 0;
    this.shotsTaken.set(0);
    this.guidance.set('position');
    this.errorMessage.set('');

    try {
      await this.faceApi.ensureReady();
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 720 }, height: { ideal: 960 } },
        audio: false,
      });
      const video = this.videoRef()?.nativeElement;
      if (!video) throw new Error('Camera surface not ready.');
      video.srcObject = this.stream;
      await video.play();
      const overlay = this.overlayRef()?.nativeElement;
      if (overlay) {
        overlay.width = video.videoWidth;
        overlay.height = video.videoHeight;
      }
      this.drawOverlay();
      this.phase.set('guiding');
      this.detectTimer = setInterval(() => void this.tick(), DETECTION_INTERVAL_MS);
    } catch (err) {
      this.showError((err as Error).message || 'Could not start the camera.');
    }
  }

  backToPicker(): void {
    this.stopCamera();
    this.selected.set(null);
    this.phase.set('picker');
  }

  private async tick(): Promise<void> {
    if (this.disposed) return;
    const p = this.phase();
    if (p !== 'guiding' && p !== 'capturing') return;
    const video = this.videoRef()?.nativeElement;
    if (!video || video.readyState < 2 || !video.videoWidth) return;

    const result = await this.faceApi.detect(video).catch(() => null);
    if (!result) {
      if (p === 'guiding') { this.guidance.set('noFace'); this.stableFrames = 0; }
      return;
    }
    const ratio = result.box.width / video.videoWidth;
    if (ratio < 0.25) {
      if (p === 'guiding') { this.guidance.set('tooSmall'); this.stableFrames = 0; }
      return;
    }
    if (ratio > 0.75) {
      if (p === 'guiding') { this.guidance.set('tooLarge'); this.stableFrames = 0; }
      return;
    }
    const cx = result.box.x + result.box.width / 2;
    const cy = result.box.y + result.box.height / 2;
    const dx = ((cx - video.videoWidth / 2) / (video.videoWidth * 0.35)) ** 2;
    const dy = ((cy - video.videoHeight / 2) / (video.videoHeight * 0.40)) ** 2;
    if (dx + dy > 1) {
      if (p === 'guiding') { this.guidance.set('offCenter'); this.stableFrames = 0; }
      return;
    }

    if (p === 'guiding') {
      this.guidance.set('ok');
      this.stableFrames++;
      if (this.stableFrames >= STABLE_FRAMES_REQUIRED) {
        this.phase.set('capturing');
        this.descriptors = [];
        this.shotsTaken.set(0);
      }
      return;
    }

    // capturing
    if (result.score >= MIN_CAPTURE_SCORE && this.descriptors.length < SHOT_COUNT) {
      this.descriptors.push(result.descriptor);
      this.shotsTaken.set(this.descriptors.length);
      this.snapshotPending = { video, box: result.box };
    }
    if (this.descriptors.length >= SHOT_COUNT) {
      this.clearDetectTimer();
      await this.finishCapture();
    }
  }

  private async finishCapture(): Promise<void> {
    this.phase.set('uploading');
    try {
      const templates = this.descriptors.map((d) => Array.from(d));
      if (templates.some((t) => t.length !== FACE_DESCRIPTOR_LENGTH)) {
        throw new Error('Face descriptors had an unexpected shape.');
      }
      if (!this.snapshotPending) throw new Error('No reference frame captured.');
      const blob = await this.faceApi.cropToJpeg(
        this.snapshotPending.video,
        this.snapshotPending.box,
        REFERENCE_IMAGE_SIDE,
      );
      const emp = this.selected();
      if (!emp) throw new Error('No employee selected.');
      const resp = await this.faceData.enrol(emp.userId, templates, blob);
      this.employees.update((list) =>
        list.map((e) =>
          e.userId === emp.userId
            ? { ...e, faceRegisteredAt: resp.faceRegisteredAt }
            : e,
        ),
      );
      this.phase.set('done');
      this.stopCamera();
    } catch (err) {
      this.showError((err as Error).message || 'Upload failed.');
    }
    this.cdr.markForCheck();
  }

  private drawOverlay(): void {
    const canvas = this.overlayRef()?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const { width, height } = canvas;
    ctx.clearRect(0, 0, width, height);
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.fillRect(0, 0, width, height);
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.ellipse(width / 2, height / 2, width * 0.35, height * 0.4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    ctx.save();
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(width / 2, height / 2, width * 0.35, height * 0.4, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  private stopCamera(): void {
    this.clearDetectTimer();
    const video = this.videoRef()?.nativeElement;
    if (video) { video.pause(); video.srcObject = null; }
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
  }

  private clearDetectTimer(): void {
    if (this.detectTimer !== null) { clearInterval(this.detectTimer); this.detectTimer = null; }
  }

  private showError(message: string): void {
    this.errorMessage.set(message);
    this.phase.set('error');
    this.stopCamera();
    this.cdr.markForCheck();
  }
}
