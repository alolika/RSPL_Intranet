import { DatePipe } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import { AdminDataService, LedgerBalanceRow } from '../admin-data.service';

/**
 * Mirrors Section_Admin/LedgerBalance.aspx ("Pipe Line"): a searchable
 * customer-outstanding grid with four mutually-exclusive per-row category
 * checkboxes (Immediate/Distance/Long Distance/Writeoff), each with a
 * running total shown above the grid — same numbers the source computed by
 * mutating GridHeaderItem label controls on every per-cell AutoPostBack
 * checkbox change, done here with a computed() over the row signal
 * instead. The Outstanding link opens VoucherDetail (outstanding bills for
 * that customer) and MobileNo is a click-to-call stub, both matching the
 * patterns already established elsewhere (AmcPending, MissedCall).
 */
@Component({
  selector: 'app-ledger-balance',
  imports: [FormsModule, RouterLink, ButtonModule, CheckboxModule, InputTextModule, SelectModule, TableModule, DatePipe, IndianNumberPipe],
  templateUrl: './ledger-balance.html',
  styleUrl: './ledger-balance.scss'
})
export class LedgerBalance implements OnInit {
  private readonly data = inject(AdminDataService);

  readonly searchFields = [
    { label: 'No Filter', value: '0' },
    { label: 'DisplayName', value: '1' },
    { label: 'City', value: '2' },
    { label: 'MobileNo', value: '3' },
    { label: 'ContactPerson', value: '4' },
    { label: 'First Salesman', value: '6' }
  ];

  readonly rows = signal<LedgerBalanceRow[]>([]);
  readonly loading = signal(false);
  // p-table's page-button range doesn't recompute on its own when `rows()`
  // shrinks (e.g. a narrower search) unless `totalRecords` is bound and the
  // current page offset is reset — otherwise it keeps showing stale page
  // numbers from the previous, larger result set.
  readonly first = signal(0);

  readonly immediateTotal = computed(() => this.sumBy('immediate'));
  readonly distanceTotal = computed(() => this.sumBy('distance'));
  readonly longDistanceTotal = computed(() => this.sumBy('longDistance'));
  readonly writeoffTotal = computed(() => this.sumBy('writeoff'));
  readonly grandTotal = computed(() => this.rows().reduce((sum, r) => sum + r.outstanding, 0));

  sipExtensionNo = '18';
  searchField = '0';
  searchValue = '';

  ngOnInit(): void {
    this.show();
  }

  private sumBy(flag: 'immediate' | 'distance' | 'longDistance' | 'writeoff'): number {
    return this.rows()
      .filter((r) => r[flag])
      .reduce((sum, r) => sum + r.outstanding, 0);
  }

  show(): void {
    this.loading.set(true);
    this.first.set(0);
    this.data.getLedgerBalanceRows(this.searchField, this.searchValue).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }

  toggleFlag(row: LedgerBalanceRow, flag: 'immediate' | 'distance' | 'longDistance' | 'writeoff'): void {
    const value = !row[flag];
    this.data.updateLedgerBalanceFlag(row.custId, flag, value).subscribe(() => {
      this.rows.update((rows) =>
        rows.map((r) =>
          r.custId === row.custId
            ? { ...r, immediate: flag === 'immediate' ? value : false, distance: flag === 'distance' ? value : false, longDistance: flag === 'longDistance' ? value : false, writeoff: flag === 'writeoff' ? value : false }
            : r
        )
      );
    });
  }

  callNow(mobileNo: string): void {
    alert(`Dialing ${mobileNo} via SIP ext ${this.sipExtensionNo} (external Synapse integration — not wired up without a backend)`);
  }

  export(): void {
    exportToExcel('Ledger_Balance', this.rows());
  }
}
