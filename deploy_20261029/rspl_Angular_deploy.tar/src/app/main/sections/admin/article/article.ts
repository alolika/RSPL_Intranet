import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { RadioButtonModule } from 'primeng/radiobutton';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';

import { AdminDataService, LookupOption } from '../admin-data.service';

/** Mirrors Section_Admin/Article.aspx: Add/Edit toggle form for web_article (CEO message board / dashboard news feed). */
@Component({
  selector: 'app-article',
  imports: [FormsModule, ButtonModule, CheckboxModule, DatePickerModule, InputTextModule, RadioButtonModule, SelectModule, TextareaModule],
  templateUrl: './article.html',
  styleUrl: './article.scss'
})
export class Article implements OnInit {
  private readonly data = inject(AdminDataService);
  // No zone.js in this app — plain (non-signal) properties like
  // `publishDate`/`title`/`author`/`description`/`enabled`/`categoryId`/
  // `selectedArticleId` below don't trigger a re-render when mutated inside
  // an RxJS subscribe callback.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly categories = signal<LookupOption[]>([]);
  readonly articleIds = signal<LookupOption[]>([]);
  readonly saving = signal(false);
  readonly errorMessage = signal<string | null>(null);

  mode: 'add' | 'edit' = 'add';
  selectedArticleId: number | null = null;
  categoryId = 1;
  publishDate: Date | null = new Date();
  title = '';
  author = '';
  description = '';
  enabled = true;

  ngOnInit(): void {
    this.clearControl();
    this.data.getArticleCategories().subscribe((categories) => this.categories.set(categories));
  }

  onModeChange(): void {
    if (this.mode === 'edit') {
      this.data.getArticleIds().subscribe((ids) => {
        this.articleIds.set(ids);
        this.selectedArticleId = ids[0]?.value ?? null;
        this.cdr.markForCheck();
        this.onArticleSelected();
      });
    } else {
      this.publishDate = new Date();
      this.clearControl();
    }
  }

  onArticleSelected(): void {
    if (this.selectedArticleId == null) {
      return;
    }
    this.data.getArticle(this.selectedArticleId).subscribe((article) => {
      if (!article) {
        return;
      }
      this.publishDate = new Date(article.publishDate);
      this.title = article.title;
      this.author = article.author;
      this.description = article.description;
      this.enabled = article.enabled;
      this.categoryId = article.categoryId;
      this.cdr.markForCheck();
    });
  }

  submit(): void {
    if (!this.title.trim() || !this.author.trim() || !this.description.trim()) {
      this.errorMessage.set('Please enter Title, Author and Description.');
      return;
    }
    this.errorMessage.set(null);
    this.saving.set(true);
    this.data
      .saveArticle(this.mode === 'edit' ? this.selectedArticleId : null, {
        publishDate: (this.publishDate ?? new Date()).toISOString(),
        categoryId: this.categoryId,
        title: this.title,
        author: this.author,
        description: this.description,
        enabled: this.enabled
      })
      .subscribe(() => {
        this.saving.set(false);
        alert(this.mode === 'add' ? 'Record insert successfully' : 'Web_Article edited successfully!');
        this.clearControl();
        this.cdr.markForCheck();
      });
  }

  private clearControl(): void {
    this.title = '';
    this.author = '';
    this.description = '';
    this.enabled = true;
  }
}
