import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';

import { AdminDataService, LeaveAppRow } from '../admin-data.service';

interface DayEntry {
  name: string;
  color: string;
  pending: boolean;
  articleId: number;
  tooltip: string;
}

interface CalendarDay {
  date: Date;
  inMonth: boolean;
  entries: DayEntry[];
}

/**
 * Mirrors Section_Admin/LeaveAppRegister.aspx: a month calendar with
 * colored per-day leave entries (yellow=half-day 1st half, red=half-day
 * 2nd half, green=full-day sanctioned, blue=pending sanction). The source's
 * CalDetails_DayRender is ~430 lines of manual ASP.NET Calendar
 * cell-control construction with 3 near-identical loops (FromDate cell /
 * ToDate cell / in-between cells) — rebuilt here as a single per-day
 * lookup over a computed month grid, same visible legend and per-day
 * coloring rules.
 *
 * Pending entries used to be clickable, navigating straight to
 * /leave-sanction (an unauthenticated email-action-link page meant to be
 * reached only via a link privately emailed to the HOD) — any user able to
 * view this register could open and act on someone else's pending leave
 * from here, bypassing the intended HOD-email-only approval channel.
 * Removed on request; entries are informational only now.
 */
@Component({
  selector: 'app-leave-app-register',
  imports: [FormsModule, ButtonModule, CheckboxModule, DatePickerModule],
  templateUrl: './leave-app-register.html',
  styleUrl: './leave-app-register.scss'
})
export class LeaveAppRegister implements OnInit {
  private readonly data = inject(AdminDataService);

  // Defaults to the current month (1st through last day) so the calendar
  // opens already populated with this month's leave entries instead of
  // only whatever happens to be active on today's single date.
  private readonly today = new Date();
  useDateFilter = true;
  fromDate: Date | null = new Date(this.today.getFullYear(), this.today.getMonth(), 1);
  toDate: Date | null = new Date(this.today.getFullYear(), this.today.getMonth() + 1, 0);

  readonly weeks = signal<CalendarDay[][]>([]);
  readonly loading = signal(false);

  private rows: LeaveAppRow[] = [];
  private viewMonth = new Date();

  ngOnInit(): void {
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.data.getLeaveAppRows({ fromDate: this.fromDate, toDate: this.toDate }).subscribe((rows) => {
      this.rows = rows;
      this.viewMonth = this.fromDate ?? new Date();
      this.buildCalendar();
      this.loading.set(false);
    });
  }

  private buildCalendar(): void {
    const year = this.viewMonth.getFullYear();
    const month = this.viewMonth.getMonth();
    const firstOfMonth = new Date(year, month, 1);
    const startOffset = firstOfMonth.getDay();
    const gridStart = new Date(year, month, 1 - startOffset);

    const days: CalendarDay[] = [];
    for (let i = 0; i < 42; i++) {
      const date = new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + i);
      days.push({ date, inMonth: date.getMonth() === month, entries: this.entriesFor(date) });
    }

    const weeks: CalendarDay[][] = [];
    for (let i = 0; i < days.length; i += 7) {
      weeks.push(days.slice(i, i + 7));
    }
    this.weeks.set(weeks);
  }

  private entriesFor(date: Date): DayEntry[] {
    const dayStr = date.toDateString();
    return this.rows
      .filter((row) => {
        // A leave the HOD (or the applicant) has cancelled must stop
        // blocking out its dates here — this calendar had no cancelled
        // check at all, so a cancelled leave kept showing the employee's
        // name on those dates exactly as if it were still active.
        if (row.cancelled) {
          return false;
        }
        const from = new Date(row.fromDate);
        const to = new Date(row.toDate);
        return date >= new Date(from.toDateString()) && date <= new Date(to.toDateString());
      })
      .map((row) => this.toEntry(row, dayStr === new Date(row.fromDate).toDateString()));
  }

  private toEntry(row: LeaveAppRow, isFromDay: boolean): DayEntry {
    const pending = !row.hoSanctioned && !row.ceoSanctioned;
    let color = '#00ff00';
    if (isFromDay && row.forDays === '0.5 (1st Half)') {
      color = '#ffff00';
    } else if (isFromDay && row.forDays === '0.5 (2nd Half)') {
      color = '#ff0000';
    } else if (pending) {
      color = '#0000ff';
    }
    const tooltip = `Application Date: ${new Date(row.appDate).toLocaleDateString()}; For Days: ${row.forDays}; From: ${new Date(row.fromDate).toLocaleDateString()}; To: ${new Date(row.toDate).toLocaleDateString()}; Reason: ${row.reason}`;
    return { name: row.name, color, pending, articleId: row.articleId, tooltip };
  }
}
