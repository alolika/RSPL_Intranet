import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { DialogModule } from 'primeng/dialog';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { AdminDataService, LookupOption } from '../admin-data.service';
import { CrmReviewDetail, CrmReviewDetailParams } from '../crm-review-detail/crm-review-detail';

/**
 * Mirrors Section_Admin/CRMReview.aspx: a dynamic-column report (EXEC
 * CRMReview) with the first columns as plain values and the remaining
 * ones rendered as drill-down links into CRMReviewDetail (dynamic
 * GridTemplateColumn construction in the source's FillGV) — same
 * simplified report-engine treatment as report-viewer/Modules.
 */
@Component({
  selector: 'app-crm-review',
  imports: [FormsModule, ButtonModule, DatePickerModule, DialogModule, SelectModule, TableModule, CrmReviewDetail],
  templateUrl: './crm-review.html',
  styleUrl: './crm-review.scss'
})
export class CrmReview implements OnInit {
  private readonly data = inject(AdminDataService);

  readonly users = signal<LookupOption[]>([]);
  readonly columns = signal<string[]>([]);
  readonly linkColumns = signal<string[]>([]);
  readonly rows = signal<Record<string, unknown>[]>([]);
  readonly loading = signal(false);
  // Non-null only while the drill-down dialog is open — kept as a dialog
  // instead of a route navigation specifically so closing it never touches
  // this component: previously every drill-down link routed to a full
  // /admin/crm-review-detail page, and Location.back() on close destroyed
  // and recreated this whole report, resetting the filters/loaded rows/
  // scroll position every single time. Deliberately not cleared back to
  // null on close (see closeDetailDialog) so the dialog's own close/fade
  // animation doesn't reveal an empty body mid-transition.
  readonly detailParams = signal<CrmReviewDetailParams | null>(null);
  readonly detailDialogVisible = signal(false);

  userId = 0;
  fromDate: Date | null = new Date();
  toDate: Date | null = new Date();

  // Columns are server-driven (dynamic), so numeric alignment is computed
  // generically rather than hardcoded per column name: a column is "numeric"
  // only if every row's value for it is either a number or absent — the
  // moment any row holds a real non-numeric string there, it's treated as
  // text instead.
  private readonly numericColumns = computed<Set<string>>(() => {
    const result = new Set<string>();
    for (const col of this.columns()) {
      let hasNumber = false;
      let hasText = false;
      for (const row of this.rows()) {
        const v = row[col];
        if (v === null || v === undefined || v === '') {
          continue;
        }
        if (typeof v === 'number') {
          hasNumber = true;
        } else {
          hasText = true;
          break;
        }
      }
      if (hasNumber && !hasText) {
        result.add(col);
      }
    }
    return result;
  });

  ngOnInit(): void {
    this.data.getCrmReviewUsers().subscribe((u) => this.users.set(u));
  }

  isNumericColumn(col: string): boolean {
    return this.numericColumns().has(col);
  }

  show(): void {
    this.loading.set(true);
    this.data.getCrmReviewRows(this.userId, this.fromDate, this.toDate).subscribe((res) => {
      this.columns.set(res.columns);
      this.linkColumns.set(res.linkColumns);
      this.rows.set(res.rows);
      this.loading.set(false);
    });
  }

  export(): void {
    exportToExcel('CRMReview', this.rows());
  }

  isLink(col: string): boolean {
    return this.linkColumns().includes(col);
  }

  drillDown(row: Record<string, unknown>, col: string): void {
    this.detailParams.set({
      userId: row['UserID'] as number,
      executiveName: row['Name'] as string,
      actionStageName: col,
      fromDate: this.fromDate,
      toDate: this.toDate
    });
    this.detailDialogVisible.set(true);
  }

  closeDetailDialog(): void {
    this.detailDialogVisible.set(false);
  }
}
