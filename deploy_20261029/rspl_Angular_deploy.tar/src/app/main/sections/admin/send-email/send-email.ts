import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { TextareaModule } from 'primeng/textarea';

import { AdminDataService } from '../admin-data.service';

/**
 * Mirrors Section_Admin/SendEmail.aspx: despite the page name, this is a
 * small "Remark" popup that appends a call-remark string to
 * CustomerAttributes for a customer (?ID=), launched from LedgerBalance.
 */
@Component({
  selector: 'app-send-email',
  imports: [FormsModule, ButtonModule, TextareaModule],
  templateUrl: './send-email.html',
  styleUrl: './send-email.scss'
})
export class SendEmail implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(AdminDataService);
  private readonly location = inject(Location);
  // No zone.js in this app — the plain (non-signal) `body` property below
  // doesn't trigger a re-render when mutated inside an RxJS subscribe callback.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly saving = signal(false);
  body = '';

  private get custId(): number {
    return Number(this.route.snapshot.queryParamMap.get('ID') ?? 0);
  }

  ngOnInit(): void {
    // Launched repeatedly from LedgerBalance's rows for different
    // customers — the custId getter above always reads the live snapshot so
    // it's never stale, but without this, a remark typed for one customer
    // and left unsaved would still be sitting in the textarea (and about to
    // be saved against the WRONG customer) if this component gets reused
    // for a different one.
    this.route.queryParamMap.subscribe(() => {
      this.body = '';
      this.cdr.markForCheck();
    });
  }

  save(): void {
    this.saving.set(true);
    this.data.saveCallRemark(this.custId, this.body).subscribe(() => {
      this.saving.set(false);
      this.body = '';
      this.cdr.markForCheck();
      this.location.back();
    });
  }

  cancel(): void {
    this.body = '';
    this.location.back();
  }
}
