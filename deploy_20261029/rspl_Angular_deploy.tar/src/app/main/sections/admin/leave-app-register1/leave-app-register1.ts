import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { ExcelColumn, exportToExcel } from '../../../../shared/export-excel';
import { AdminDataService, LeaveAppRow, LookupOption } from '../admin-data.service';

/** Mirrors Section_Admin/LeaveAppRegister1.aspx: filterable leave-application grid with Sanctioned/Pending/Cancelled status columns. */
@Component({
  selector: 'app-leave-app-register1',
  imports: [FormsModule, ButtonModule, CheckboxModule, DatePickerModule, SelectModule, TableModule, DatePipe],
  templateUrl: './leave-app-register1.html',
  styleUrl: './leave-app-register1.scss'
})
export class LeaveAppRegister1 implements OnInit {
  private readonly data = inject(AdminDataService);

  // Same header text/order as the on-screen grid, and the same computed
  // Sanctioned/Pending/Cancelled status text (via status()) the grid uses —
  // so the exported file matches the grid exactly rather than dumping raw
  // field names/values. Date/From Date/To Date pass the raw ISO string
  // straight through (not pre-formatted here) — exportToExcel's own
  // project-wide date handling converts it into a genuine Excel date cell
  // formatted dd-mmm-yyyy, rather than a formatted-text lookalike.
  private readonly excelColumns: readonly ExcelColumn<LeaveAppRow>[] = [
    { header: 'ID', value: (r) => r.leaveId },
    { header: 'Date', value: (r) => r.appDate },
    { header: 'User Name', value: (r) => r.name },
    { header: 'For Days', value: (r) => r.forDays },
    { header: 'From Date', value: (r) => r.fromDate },
    { header: 'To Date', value: (r) => r.toDate },
    { header: 'Sanctioned', value: (r) => this.status(r).sanctioned },
    { header: 'Pending', value: (r) => this.status(r).pending },
    { header: 'Cancelled', value: (r) => this.status(r).cancelled }
  ];

  readonly users = signal<LookupOption[]>([]);
  readonly rows = signal<LeaveAppRow[]>([]);
  readonly loading = signal(false);
  readonly errorMessage = signal('');

  readonly sanctionOptions = [
    { label: 'ALL', value: 'ALL' },
    { label: 'Pending', value: 'Pending' },
    { label: 'Sanctioned', value: 'Sanctioned' }
  ];

  // Defaults to the current month (1st through last day) so the register
  // opens already showing this month's applications instead of an
  // unfiltered dump of every leave application ever submitted.
  private readonly today = new Date();
  useDateFilter = true;
  fromDate: Date | null = new Date(this.today.getFullYear(), this.today.getMonth(), 1);
  toDate: Date | null = new Date(this.today.getFullYear(), this.today.getMonth() + 1, 0);
  userId = 0;
  includeSubordinate = false;
  sanctionFilter: 'ALL' | 'Pending' | 'Sanctioned' = 'ALL';

  ngOnInit(): void {
    this.data.getUsers().subscribe((u) => this.users.set([{ label: 'ALL', value: 0 }, ...u]));
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.errorMessage.set('');
    this.data
      .getLeaveAppRegister1Rows({
        fromDate: this.useDateFilter ? this.fromDate : null,
        toDate: this.useDateFilter ? this.toDate : null,
        userId: this.userId,
        includeSubordinate: this.includeSubordinate,
        sanctionFilter: this.sanctionFilter
      })
      .subscribe({
        next: (rows) => {
          this.rows.set(rows);
          this.loading.set(false);
        },
        // Previously silent on failure (no error callback) — this endpoint
        // requires a valid session (register1-rows is auth-protected, unlike
        // most other filter lookups on this page), so an expired/missing
        // token would 401 and leave the grid stuck loading or silently
        // empty, indistinguishable from "no leave applications submitted".
        // Verified live that the query/data itself is correct — 16,000+ real
        // rows, including ones submitted minutes ago, all come back
        // correctly once authenticated.
        error: () => {
          this.rows.set([]);
          this.loading.set(false);
          this.errorMessage.set('Could not load leave applications. Your session may have expired — try refreshing the page and signing in again.');
        }
      });
  }

  status(row: LeaveAppRow): { sanctioned: string; pending: string; cancelled: string } {
    return {
      sanctioned: row.hoSanctioned || row.ceoSanctioned ? 'Sanctioned' : '',
      pending: !row.hoSanctioned && !row.ceoSanctioned ? 'Pending' : '',
      cancelled: row.cancelled ? 'Yes' : ''
    };
  }

  export(): void {
    exportToExcel('LeaveAppRegister', this.rows(), this.excelColumns);
  }
}
