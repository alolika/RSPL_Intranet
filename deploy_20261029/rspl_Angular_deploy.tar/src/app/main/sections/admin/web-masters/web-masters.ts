import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { RadioButtonModule } from 'primeng/radiobutton';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { AdminDataService } from '../admin-data.service';

/** Mirrors Section_Admin/WebMasters.aspx: generic Add/Edit editor for web_littlemaster lookup values, grouped by MasterName. */
@Component({
  selector: 'app-web-masters',
  imports: [FormsModule, ButtonModule, InputTextModule, RadioButtonModule, SelectModule, TableModule],
  templateUrl: './web-masters.html',
  styleUrl: './web-masters.scss'
})
export class WebMasters implements OnInit {
  private readonly data = inject(AdminDataService);
  // No zone.js in this app — plain (non-signal) properties like `masterName`/
  // `masterValue` below don't trigger a re-render when mutated inside an
  // RxJS subscribe callback.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly masterNames = signal<string[]>([]);
  readonly masterValues = signal<{ id: number; value: string }[]>([]);
  readonly saving = signal(false);

  mode: 'add' | 'edit' = 'add';
  masterName = '';
  selectedValueId: number | null = null;
  masterValue = '';

  ngOnInit(): void {
    this.data.getWebMasterNames().subscribe((names) => {
      this.masterNames.set(names);
      this.masterName = names[0] ?? '';
      this.cdr.markForCheck();
      this.onMasterNameChange();
    });
  }

  onMasterNameChange(): void {
    if (!this.masterName) {
      return;
    }
    this.data.getWebMasterValues(this.masterName).subscribe((v) => this.masterValues.set(v));
  }

  onModeChange(): void {
    this.masterValue = '';
    this.selectedValueId = null;
  }

  onValueSelected(): void {
    const found = this.masterValues().find((v) => v.id === this.selectedValueId);
    this.masterValue = found?.value ?? '';
  }

  submit(): void {
    if (!this.masterValue.trim()) {
      return;
    }
    this.saving.set(true);
    this.data.saveWebMasterValue(this.masterName, this.mode === 'edit' ? this.selectedValueId : null, this.masterValue).subscribe((res) => {
      this.saving.set(false);
      alert(res.message);
      if (res.success) {
        this.masterValue = '';
        this.cdr.markForCheck();
        this.onMasterNameChange();
      }
    });
  }
}
