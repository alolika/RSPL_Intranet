import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, delay, map, of } from 'rxjs';

import { API_BASE_URL } from '../../../shared/api-config';

const BASE = `${API_BASE_URL}/admin`;

export interface LookupOption {
  label: string;
  value: number;
}

interface ApiArticleRow {
  article_id: number;
  publish_date: string;
  category_id: number;
  category: string;
  title: string;
  author: string;
  description: string;
  enabled: boolean;
}

function toArticleRow(r: ApiArticleRow): ArticleRow {
  return {
    articleId: r.article_id,
    publishDate: r.publish_date,
    categoryId: r.category_id,
    category: r.category,
    title: r.title,
    author: r.author,
    description: r.description,
    enabled: r.enabled
  };
}

interface ApiHolidayRow {
  holiday_id: number;
  holiday_date: string;
  to_date: string;
  day: string;
  event: string;
  enabled: boolean;
}

export interface HolidayRow {
  holidayId: number;
  holidayDate: string;
  toDate: string;
  day: string;
  event: string;
  enabled: boolean;
}

function toHolidayRow(r: ApiHolidayRow): HolidayRow {
  return { holidayId: r.holiday_id, holidayDate: r.holiday_date, toDate: r.to_date, day: r.day, event: r.event, enabled: r.enabled };
}

interface ApiFaceInOutRow {
  face_id: number;
  name: string;
  date: string;
  week_day: string;
  in_time: string;
  break_time: string;
  resume_time: string;
  out_time: string;
}

/** Face In/Out (new page, backed by the FaceInOut table) — see admin_face_inout.py. */
export interface FaceInOutRow {
  faceId: number;
  name: string;
  date: string;
  weekDay: string;
  inTime: string;
  breakTime: string;
  resumeTime: string;
  outTime: string;
}

function toFaceInOutRow(r: ApiFaceInOutRow): FaceInOutRow {
  return {
    faceId: r.face_id, name: r.name, date: r.date, weekDay: r.week_day,
    inTime: r.in_time, breakTime: r.break_time, resumeTime: r.resume_time, outTime: r.out_time
  };
}

// 'pune' (existing FaceInOut table) | 'nagar' (new FaceInOut_Nagar table,
// see admin_face_inout.py's 2026-08-04 update note). Defaults to 'pune' on
// the backend when omitted, but the frontend always sends it explicitly.
export type FaceInOutTeam = 'pune' | 'nagar' | 'face_attendance';

export interface FaceInOutImportRow {
  faceId: number | string;
  name: string;
  date: string;
  inTime?: string;
  breakTime?: string;
  resumeTime?: string;
  outTime?: string;
  // Nagar-only: the ~25 device-export columns beyond the shared core fields
  // above, keyed by exact Excel header text (e.g. "Work", "Day Type",
  // "Diff.OT") — see admin_face_inout.py's _NAGAR_TEXT_EXTRA_FIELDS/
  // _NAGAR_FLOAT_EXTRA_FIELDS, which parse these by type server-side. Never
  // populated for Pune imports.
  extra?: Record<string, string>;
}

export interface FaceInOutImportResult {
  importedCount: number;
  skipped: { rowNumber: number; reason: string }[];
}

/** Records from the FaceAttendance table — face-recognition auto-attendance. */
export interface FaceAttendanceRecord {
  userId: number;
  userName: string;
  attendanceDate: string;
  arrivalTime: string;
  departureTime: string | null;
  confidence: number | null;
  lat: number | null;
  lng: number | null;
  accuracyM: number | null;
  city: string | null;
  state: string | null;
  country: string | null;
}

interface ApiVideoRow {
  id: number;
  name: string;
  module_id: number;
  module: string;
  details: string;
  video_url: string;
  disabled: boolean;
}

function toVideoRow(r: ApiVideoRow): VideoRow {
  return { id: r.id, name: r.name, moduleId: r.module_id, module: r.module, details: r.details, videoUrl: r.video_url, disabled: r.disabled };
}

interface ApiAdvanceVoucherRow {
  voucher_no: number;
  date: string;
  customer_id: number;
  customer_name: string;
  contact_person: string;
  narration: string;
  amount: number;
}

function toAdvanceVoucherRow(r: ApiAdvanceVoucherRow): AdvanceVoucherRow {
  return {
    voucherNo: r.voucher_no,
    date: r.date,
    customerId: r.customer_id,
    customerName: r.customer_name,
    contactPerson: r.contact_person,
    narration: r.narration,
    amount: r.amount
  };
}

interface ApiPaymentVoucherRow {
  voucher_no: number;
  is_payment_voucher: boolean;
  date: string;
  debit_account: string;
  debit_account_id: number;
  credit_account: string;
  credit_account_id: number;
  paid_to: string;
  payment_for: string;
  amount: number;
}

function toPaymentVoucherRow(r: ApiPaymentVoucherRow): PaymentVoucherRow {
  return {
    voucherNo: r.voucher_no,
    isPaymentVoucher: r.is_payment_voucher,
    date: r.date,
    debitAccount: r.debit_account,
    debitAccountId: r.debit_account_id,
    creditAccount: r.credit_account,
    creditAccountId: r.credit_account_id,
    paidTo: r.paid_to,
    paymentFor: r.payment_for,
    amount: r.amount
  };
}

interface ApiOutstandingVoucherRow {
  voucher_no: number;
  date: string;
  sales_man: string;
  bill_amt: number;
  outstanding: number;
}

function toOutstandingVoucherRow(r: ApiOutstandingVoucherRow): OutstandingVoucherRow {
  return { voucherNo: r.voucher_no, date: r.date, salesMan: r.sales_man, billAmt: r.bill_amt, outstanding: r.outstanding };
}

interface ApiCustomerInfoRow {
  cust_id: number;
  customer_name: string;
  group_name: string;
  address: string;
  contact_person: string;
  mobile_no: string;
  phone_no: string;
  email: string;
}

function toCustomerInfoRow(r: ApiCustomerInfoRow): CustomerInfoRow {
  return {
    custId: r.cust_id,
    customerName: r.customer_name,
    groupName: r.group_name,
    address: r.address,
    contactPerson: r.contact_person,
    mobileNo: r.mobile_no,
    phoneNo: r.phone_no,
    email: r.email
  };
}

interface ApiCustLedgerRow {
  customer_id: number;
  customer_name: string;
  area: string;
  city_name: string;
  email: string;
  mobile_no: string;
  amc: string | null;
  yt_date: string | null;
  yt_status: string;
  yt_remark: string;
  exe_status: string;
  yt_user: string;
}

function toCustLedgerRow(r: ApiCustLedgerRow): CustLedgerRow {
  return {
    customerId: r.customer_id,
    customerName: r.customer_name,
    area: r.area,
    cityName: r.city_name,
    email: r.email,
    mobileNo: r.mobile_no,
    amc: r.amc ?? '',
    ytDate: r.yt_date,
    ytStatus: r.yt_status,
    ytRemark: r.yt_remark,
    exeStatus: r.exe_status,
    ytUser: r.yt_user
  };
}

interface ApiCustLedgerSaleRow {
  customer_id: number;
  voucher_no: number;
  date: string;
  expiry: string | null;
  sr_no: number;
  product_name: string;
  qty: number;
  rate: number;
  amount: number;
}

function toCustLedgerSaleRow(r: ApiCustLedgerSaleRow): CustLedgerSaleRow {
  return {
    customerId: r.customer_id,
    voucherNo: r.voucher_no,
    date: r.date,
    expiry: r.expiry ?? '',
    srNo: r.sr_no,
    productName: r.product_name,
    qty: r.qty,
    rate: r.rate,
    amount: r.amount
  };
}

interface ApiCustTinFollowupRow {
  cust_id: number;
  software: string;
  display_name: string;
  class_name: string;
  amc_expiry: string | null;
  sales_person: string;
  mobile_no: string;
  email: string;
  tin_no: string;
  followup_remark: string;
}

function toCustTinFollowupRow(r: ApiCustTinFollowupRow): CustTinFollowupRow {
  return {
    custId: r.cust_id,
    software: r.software,
    displayName: r.display_name,
    className: r.class_name,
    amcExpiry: r.amc_expiry ?? '',
    salesPerson: r.sales_person,
    mobileNo: r.mobile_no,
    email: r.email,
    tinNo: r.tin_no,
    followupRemark: r.followup_remark
  };
}

interface ApiCustomerAnsRow {
  client_id: number;
  client_name: string;
  amc_expiry_date: string | null;
  question: string;
  answer: string;
  answer_date: string | null;
  answer_time: string;
  user_name: string;
  machine_name: string;
}

function toCustomerAnsRow(r: ApiCustomerAnsRow): CustomerAnsRow {
  return {
    clientId: r.client_id,
    clientName: r.client_name,
    amcExpiryDate: r.amc_expiry_date ?? '',
    question: r.question,
    answer: r.answer,
    answerDate: r.answer_date ?? '',
    answerTime: r.answer_time,
    userName: r.user_name,
    machineName: r.machine_name
  };
}

interface ApiGracePeriodRow {
  software_name: string;
  client_id: number;
  client_name: string;
  city: string;
  amc_due_date: string | null;
  amc_due_delay_days: number;
  amc_grace_remark: string;
  disabled: boolean;
}

function toGracePeriodRow(r: ApiGracePeriodRow): GracePeriodRow {
  return {
    softwareName: r.software_name,
    clientId: r.client_id,
    clientName: r.client_name,
    city: r.city,
    amcDueDate: r.amc_due_date ?? '',
    amcDueDelayDays: r.amc_due_delay_days,
    amcGraceRemark: r.amc_grace_remark,
    disabled: r.disabled
  };
}

interface ApiLicenseViolationRow {
  cust_id: number;
  display_name: string;
  city: string;
  amc_due_date: string | null;
  amc_amount: number;
  ledger_balance: number;
  pirated_qty: number;
  piracy_amt: number;
  first_bill: string | null;
  first_salesman: string;
}

function toLicenseViolationRow(r: ApiLicenseViolationRow): LicenseViolationRow {
  return {
    custId: r.cust_id,
    displayName: r.display_name,
    city: r.city,
    amcDueDate: r.amc_due_date ?? '',
    amcAmount: r.amc_amount,
    ledgerBalance: r.ledger_balance,
    piratedQty: r.pirated_qty,
    piracyAmt: r.piracy_amt,
    firstBill: r.first_bill ?? '',
    firstSalesman: r.first_salesman
  };
}

interface ApiLicenseModuleRow {
  pirated: boolean;
  product_id: number;
  product_name: string;
  active_qty: number;
  billed_qty: number;
  pirated_qty: number;
  piracy_amt: number;
  answer_time: string;
}

function toLicenseModuleRow(r: ApiLicenseModuleRow): LicenseModuleRow {
  return {
    pirated: r.pirated,
    productId: r.product_id,
    productName: r.product_name,
    activeQty: r.active_qty,
    billedQty: r.billed_qty,
    piratedQty: r.pirated_qty,
    piracyAmt: r.piracy_amt,
    answerTime: r.answer_time
  };
}

interface ApiLedgerBalanceRow {
  cust_id: number;
  display_name: string;
  mobile_no: string;
  avg_days: number;
  city: string;
  area: string;
  contact_person: string;
  outstanding: number;
  immediate: boolean;
  distance: boolean;
  long_distance: boolean;
  writeoff: boolean;
  follow_up_user: string;
  amc_date: string | null;
}

function toLedgerBalanceRow(r: ApiLedgerBalanceRow): LedgerBalanceRow {
  return {
    custId: r.cust_id,
    displayName: r.display_name,
    mobileNo: r.mobile_no,
    avgDays: r.avg_days,
    city: r.city,
    area: r.area,
    contactPerson: r.contact_person,
    outstanding: r.outstanding,
    immediate: r.immediate,
    distance: r.distance,
    longDistance: r.long_distance,
    writeoff: r.writeoff,
    followUpUser: r.follow_up_user,
    amcDate: r.amc_date ?? ''
  };
}

interface ApiLeaveAppRow {
  leave_id: number;
  user_id: number;
  name: string;
  app_date: string;
  from_date: string;
  to_date: string;
  for_days: string;
  reason: string;
  ho_sanctioned: boolean;
  ho_sanctioned_date: string | null;
  ceo_sanctioned: boolean;
  ceo_sanctioned_date: string | null;
  cancelled: boolean;
  article_id: number;
}

function toLeaveAppRow(r: ApiLeaveAppRow): LeaveAppRow {
  return {
    leaveId: r.leave_id,
    userId: r.user_id,
    name: r.name,
    appDate: r.app_date,
    fromDate: r.from_date,
    toDate: r.to_date,
    forDays: r.for_days,
    reason: r.reason,
    hoSanctioned: r.ho_sanctioned,
    hoSanctionedDate: r.ho_sanctioned_date,
    ceoSanctioned: r.ceo_sanctioned,
    ceoSanctionedDate: r.ceo_sanctioned_date,
    cancelled: r.cancelled,
    articleId: r.article_id
  };
}

interface ApiFeedbackRow {
  feedback_id: number;
  date: string;
  name: string;
  email: string;
  city: string;
  subject: string;
  message: string;
  user_name: string;
}

function toFeedbackRow(r: ApiFeedbackRow): FeedbackRow {
  return {
    feedbackId: r.feedback_id,
    date: r.date,
    name: r.name,
    email: r.email,
    city: r.city,
    subject: r.subject,
    message: r.message,
    userName: r.user_name
  };
}

interface ApiReferralAnalysisRow {
  referred_by: string;
  referred_cust_id: number;
  referred_city: string;
  cust_id: number;
  new_customer: string;
  city: string;
  enquiry_date: string | null;
  balance_amt: number;
  amount: number;
  referral_card_no: string;
  order_no: number | null;
  order_date: string | null;
  order_by: string;
  introduced_by: string;
}

function toReferralAnalysisRow(r: ApiReferralAnalysisRow): ReferralAnalysisRow {
  return {
    referredBy: r.referred_by,
    referredCustId: r.referred_cust_id,
    referredCity: r.referred_city,
    custId: r.cust_id,
    newCustomer: r.new_customer,
    city: r.city,
    enquiryDate: r.enquiry_date ?? '',
    balanceAmt: r.balance_amt,
    amount: r.amount,
    referralCardNo: r.referral_card_no,
    orderNo: r.order_no,
    orderDate: r.order_date,
    orderBy: r.order_by,
    introducedBy: r.introduced_by
  };
}

interface ApiLicenseActionRow {
  action_id: number;
  creation_date: string | null;
  creation_time: string;
  follow_up_by: string;
  follow_up_remark: string;
  assigned_to: string;
  action_description: string;
  action_remark: string;
  next_action: string;
}

function toLicenseActionRow(r: ApiLicenseActionRow): LicenseActionRow {
  return {
    actionId: r.action_id,
    creationDate: r.creation_date ?? '',
    creationTime: r.creation_time,
    followUpBy: r.follow_up_by,
    followUpRemark: r.follow_up_remark,
    assignedTo: r.assigned_to,
    actionDescription: r.action_description,
    actionRemark: r.action_remark,
    nextAction: r.next_action as LicenseActionRow['nextAction']
  };
}

/** Mirrors web_leaveapplication joined with UserMaster, used by LeaveAppRegister.aspx and LeaveAppRegister1.aspx. */
export interface LeaveAppRow {
  leaveId: number;
  userId: number;
  name: string;
  appDate: string;
  fromDate: string;
  toDate: string;
  forDays: string;
  reason: string;
  hoSanctioned: boolean;
  hoSanctionedDate: string | null;
  ceoSanctioned: boolean;
  ceoSanctionedDate: string | null;
  cancelled: boolean;
  articleId: number;
}

/** Data services backing Section_Admin's Angular migration — one shared service, mirroring the support-data.service.ts pattern. */
@Injectable({ providedIn: 'root' })
export class AdminDataService {
  private readonly http = inject(HttpClient);

  /** Mirrors LeaveAppRegister.aspx.vb's FillGV/CalDetails_DayRender query. */
  getLeaveAppRows(filters: { fromDate?: Date | null; toDate?: Date | null }): Observable<LeaveAppRow[]> {
    const params: Record<string, string> = {};
    if (filters.fromDate) {
      params['from_date'] = this.toDateParam(filters.fromDate);
    }
    if (filters.toDate) {
      params['to_date'] = this.toDateParam(filters.toDate);
    }
    return this.http.get<ApiLeaveAppRow[]>(`${BASE}/leave/rows`, { params }).pipe(map((rows) => rows.map(toLeaveAppRow)));
  }

  /** Mirrors LeaveAppRegister1.aspx.vb's FillGV (same table, employee/subordinate/sanction-status filters). */
  getLeaveAppRegister1Rows(filters: {
    fromDate?: Date | null;
    toDate?: Date | null;
    userId?: number | null;
    includeSubordinate?: boolean;
    sanctionFilter?: 'ALL' | 'Pending' | 'Sanctioned';
  }): Observable<LeaveAppRow[]> {
    const params: Record<string, string | number | boolean> = {
      user_id: filters.userId ?? 0,
      include_subordinate: filters.includeSubordinate ?? false,
      sanction_filter: filters.sanctionFilter ?? 'ALL'
    };
    if (filters.fromDate) {
      params['from_date'] = this.toDateParam(filters.fromDate);
    }
    if (filters.toDate) {
      params['to_date'] = this.toDateParam(filters.toDate);
    }
    return this.http.get<ApiLeaveAppRow[]>(`${BASE}/leave/register1-rows`, { params }).pipe(map((rows) => rows.map(toLeaveAppRow)));
  }

  getUsers(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/leave/users`);
  }

  /** Mirrors AddVideos.aspx.vb's rcbModule/rcbSearchModule source (VideoModuleMaster). */
  getVideoModules(): Observable<VideoModuleOption[]> {
    return this.http.get<{ module_id: number; name: string }[]>(`${BASE}/content/video-modules`).pipe(
      map((rows) => rows.map((r) => ({ moduleId: r.module_id, name: r.name })))
    );
  }

  /** Mirrors AddVideos.aspx.vb's FillGV (Webproc_GetVideoDetails). */
  getVideos(search: string): Observable<VideoRow[]> {
    return this.http.get<ApiVideoRow[]>(`${BASE}/content/videos`, { params: { search } }).pipe(map((rows) => rows.map(toVideoRow)));
  }

  /** Mirrors AddVideos.aspx.vb's btnAdd_Click / rgvVideo_UpdateCommand (Webproc_AddVideoDetails). */
  saveVideo(id: number, payload: { name: string; details: string; videoUrl: string; disabled: boolean; moduleName: string }): Observable<{ success: boolean; message: string }> {
    return this.http.post<{ success: boolean; message: string }>(`${BASE}/content/video`, {
      name: payload.name,
      details: payload.details,
      video_url: payload.videoUrl,
      disabled: payload.disabled,
      module_name: payload.moduleName
    }, { params: { video_id: id } });
  }

  /** Mirrors AddVideos.aspx.vb's lnkbtn_Click/imdAdd_Click (Webproc_AddVideoModuleMaster). */
  addVideoModule(name: string): Observable<{ success: boolean; message: string }> {
    return this.http.post<{ success: boolean; message: string }>(`${BASE}/content/video-module`, null, { params: { name } });
  }

  /** Mirrors Article.aspx.vb/ArticleRegister.aspx.vb's category source (web_littlemaster, MasterName='ArticleCategory'). */
  getArticleCategories(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/content/article-categories`);
  }

  /** Mirrors Article.aspx.vb's ddlarticleId source (RDBEdit mode, web_article). */
  getArticleIds(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/content/article-ids`);
  }

  getArticle(articleId: number): Observable<ArticleRow | null> {
    return this.http.get<ApiArticleRow | null>(`${BASE}/content/article/${articleId}`).pipe(map((r) => (r ? toArticleRow(r) : null)));
  }

  /** Mirrors Article.aspx.vb's btnsubmit_Click (webproc_WebArticleAdd / Webproc_WebArticleEdit). */
  saveArticle(articleId: number | null, payload: Omit<ArticleRow, 'articleId' | 'category'>): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/content/article`, {
      article_id: articleId,
      category_id: payload.categoryId,
      publish_date: payload.publishDate.slice(0, 10),
      title: payload.title,
      author: payload.author,
      description: payload.description,
      enabled: payload.enabled
    });
  }

  /** Mirrors ArticleRegister.aspx.vb's FillGV. */
  getArticleRegisterRows(categoryId: number | null): Observable<ArticleRow[]> {
    return this.http
      .get<ApiArticleRow[]>(`${BASE}/content/article-register`, { params: { category_id: categoryId ?? 0 } })
      .pipe(map((rows) => rows.map(toArticleRow)));
  }

  /** Mirrors CustomerInfo.aspx.vb's ShowCustomerInformation. */
  getCustomerInfo(custId: number): Observable<CustomerInfoRow | null> {
    return this.http
      .get<ApiCustomerInfoRow | null>(`${BASE}/customers/info/${custId}`)
      .pipe(map((r) => (r ? toCustomerInfoRow(r) : null)));
  }

  /** Mirrors CustLedger.aspx.vb's filter-source lookups (cascading combos simplified to independent lists). */
  getCustLedgerFilters(): Observable<{ software: LookupOption[]; ytStatuses: LookupOption[]; cities: string[]; areas: string[]; groups: LookupOption[]; customers: string[] }> {
    return this.http
      .get<{
        software: LookupOption[];
        yt_statuses: LookupOption[];
        cities: string[];
        areas: string[];
        groups: LookupOption[];
        customers: string[];
      }>(`${BASE}/customers/cust-ledger/filters`)
      .pipe(
        map((f) => ({
          software: f.software,
          ytStatuses: f.yt_statuses,
          cities: f.cities,
          areas: f.areas,
          groups: f.groups,
          customers: f.customers
        }))
      );
  }

  // Bound to Customer Module Report's City/Area/Customer <p-select>'s
  // (onFilter) — re-queries the server with whatever's typed instead of only
  // filtering the already-loaded top 100 client-side (same load-on-demand
  // shape as /customers-for-search).
  getCustLedgerCities(search = ''): Observable<string[]> {
    return this.http.get<string[]>(`${BASE}/customers/cust-ledger/cities`, { params: { search } });
  }

  getCustLedgerAreas(search = ''): Observable<string[]> {
    return this.http.get<string[]>(`${BASE}/customers/cust-ledger/areas`, { params: { search } });
  }

  getCustLedgerCustomers(search = ''): Observable<string[]> {
    return this.http.get<string[]>(`${BASE}/customers/cust-ledger/customers`, { params: { search } });
  }

  getCustLedgerLedgerGroups(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/customers/cust-ledger/ledger-groups`, { params: { search } });
  }

  /** Mirrors CustLedger.aspx.vb's FillGV. */
  getCustLedgerRows(filters: {
    software: string;
    city: string;
    ytStatus: string;
    customer: string;
    area: string;
    ledgerGroupId: number;
  }): Observable<CustLedgerRow[]> {
    return this.http
      .get<ApiCustLedgerRow[]>(`${BASE}/customers/cust-ledger`, {
        params: {
          software: filters.software,
          city: filters.city,
          yt_status: filters.ytStatus,
          customer: filters.customer,
          area: filters.area,
          ledger_group_id: filters.ledgerGroupId
        }
      })
      .pipe(map((rows) => rows.map(toCustLedgerRow)));
  }

  /** Mirrors CustLedger.aspx.vb's RadGrid1_DetailTableDataBind ("SaleBillNo"). */
  getCustLedgerSaleDetail(customerId: number, withAmc: boolean): Observable<CustLedgerSaleRow[]> {
    return this.http
      .get<ApiCustLedgerSaleRow[]>(`${BASE}/customers/cust-ledger/${customerId}/sale-detail`, { params: { with_amc: withAmc } })
      .pipe(map((rows) => rows.map(toCustLedgerSaleRow)));
  }

  /** Mirrors CustLedger.aspx.vb's GVStatus_UpdateCommand. */
  updateCustLedgerYtInfo(customerId: number, payload: { ytStatus: string; ytDate: string | null; ytRemark: string; exeStatus: string }): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/customers/cust-ledger/${customerId}/yt-info`, {
      yt_status: payload.ytStatus,
      yt_date: payload.ytDate ? payload.ytDate.slice(0, 10) : null,
      yt_remark: payload.ytRemark,
      exe_status: payload.exeStatus
    });
  }

  /** Mirrors CustTINFollowup.aspx.vb's rcbSalesman/rcbSoftware/rcbFollowupRemark source (vw_CustomerTINFollowup). */
  getCustTinFollowupFilters(): Observable<{ salesmen: string[]; software: string[]; followupRemarks: string[] }> {
    return this.http
      .get<{ salesmen: string[]; software: string[]; followup_remarks: string[] }>(`${BASE}/customers/tin-followup/filters`)
      .pipe(map((f) => ({ salesmen: f.salesmen, software: f.software, followupRemarks: f.followup_remarks })));
  }

  /** Mirrors CustTINFollowup.aspx.vb's fillGV (vw_CustomerTINFollowup). */
  getCustTinFollowupRows(filters: { software: string; salesman: string; followupRemark: string }): Observable<CustTinFollowupRow[]> {
    return this.http
      .get<ApiCustTinFollowupRow[]>(`${BASE}/customers/tin-followup`, {
        params: { software: filters.software, salesman: filters.salesman, followup_remark: filters.followupRemark }
      })
      .pipe(map((rows) => rows.map(toCustTinFollowupRow)));
  }

  /** Mirrors CustTINFollowup.aspx.vb's rgvCustTINFollowup_UpdateCommand (webProc_UpdateCustTINNo). */
  updateCustTin(custId: number, tinNo: string, email: string, followupRemark: string): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/customers/tin-followup/${custId}`, {
      tin_no: tinNo,
      email,
      followup_remark: followupRemark
    });
  }

  /** Mirrors CustomerAns.aspx.vb's rcbQuestion source (vw_web_clientAnswerSheet — currently blocked, see admin_customers.py). Customer is the standard getCustomers() picker instead. */
  getCustomerAnsFilters(): Observable<{ questions: string[] }> {
    return this.http.get<{ questions: string[] }>(`${BASE}/customers/ans/filters`);
  }

  getCustomerAnsRows(filters: { customerId: number | null; question: string }): Observable<CustomerAnsRow[]> {
    return this.http
      .get<ApiCustomerAnsRow[]>(`${BASE}/customers/ans`, { params: { customer_id: filters.customerId ?? 0, question: filters.question } })
      .pipe(map((rows) => rows.map(toCustomerAnsRow)));
  }

  /** Mirrors CustomerGracePeriod.aspx.vb's rcbQuestion source (vw_web_softwaremaster — currently blocked, see admin_customers.py). */
  getGracePeriodSoftware(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/customers/grace-period/software`);
  }

  getGracePeriodRows(softwareId: number | null): Observable<GracePeriodRow[]> {
    return this.http
      .get<ApiGracePeriodRow[]>(`${BASE}/customers/grace-period`, { params: { software_id: softwareId ?? 0 } })
      .pipe(map((rows) => rows.map(toGracePeriodRow)));
  }

  /** Mirrors CustomerLicenseViolation.aspx.vb's FillGVCounter (WebProc_GetCustVoilationDetails — currently blocked, see admin_customers.py). */
  getLicenseViolationRows(customerId: number | null): Observable<LicenseViolationRow[]> {
    return this.http
      .get<ApiLicenseViolationRow[]>(`${BASE}/customers/license-violation`, { params: { customer_id: customerId ?? 0 } })
      .pipe(map((rows) => rows.map(toLicenseViolationRow)));
  }

  /** Mirrors CustomerLicenseViolation.aspx.vb's rgvCustModuleList_ItemDataBound (webproc_GetDrillDownCustLicenceVoilation — currently blocked). */
  getLicenseViolationModules(custId: number): Observable<LicenseModuleRow[]> {
    return this.http
      .get<ApiLicenseModuleRow[]>(`${BASE}/customers/license-violation/${custId}/modules`)
      .pipe(map((rows) => rows.map(toLicenseModuleRow)));
  }

  /** Mirrors CustomerLicenseViolation.aspx.vb's rgCounter_DetailTableDataBind ("CustEnquiryAction", ActionStageID=28). */
  getLicenseViolationActions(custId: number): Observable<LicenseActionRow[]> {
    return this.http
      .get<ApiLicenseActionRow[]>(`${BASE}/customers/license-violation/${custId}/actions`)
      .pipe(map((rows) => rows.map(toLicenseActionRow)));
  }

  /** Top 100, re-queried by name as the user types — shared by Advance and CustomerAns's Customer picker. */
  getCustomers(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/vouchers/customers`, { params: { search } });
  }

  /** Mirrors Advance.aspx.vb's ClearControls (advance.voucherno list) and cmbContactPersonName source. */
  getAdvanceVoucherNumbers(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/vouchers/advance-numbers`);
  }

  getAdvanceVoucher(voucherNo: number): Observable<AdvanceVoucherRow | null> {
    return this.http.get<ApiAdvanceVoucherRow | null>(`${BASE}/vouchers/advance/${voucherNo}`).pipe(map((r) => (r ? toAdvanceVoucherRow(r) : null)));
  }

  /** Mirrors Advance.aspx.vb's ShowLastVoucherno. */
  getLastAdvance(): Observable<AdvanceVoucherRow | null> {
    return this.http.get<ApiAdvanceVoucherRow | null>(`${BASE}/vouchers/advance/last`).pipe(map((r) => (r ? toAdvanceVoucherRow(r) : null)));
  }

  /** Mirrors Advance.aspx.vb's showDetails (Custdependents/CustomerMaster address block). */
  getCustomerAddressBlock(customerId: number): Observable<string> {
    return this.http.get<string>(`${BASE}/vouchers/customer-address/${customerId}`);
  }

  /** Mirrors Advance.aspx.vb's radBtmSubmit_Click (pro_InsertUpdateAdvance). */
  saveAdvance(payload: Omit<AdvanceVoucherRow, 'voucherNo' | 'date'>): Observable<{ success: boolean; voucherNo: number }> {
    return this.http.post<{ success: boolean; voucherNo: number }>(`${BASE}/vouchers/advance`, {
      customer_id: payload.customerId,
      contact_person: payload.contactPerson,
      narration: payload.narration,
      amount: payload.amount
    });
  }

  /** Mirrors CRMReview.aspx.vb's rcbFirstReceivedBy source. */
  getCrmReviewUsers(): Observable<LookupOption[]> {
    return this.http
      .get<LookupOption[]>(`${BASE}/reports/crm-review-users`)
      .pipe(map((rows) => [{ label: '', value: 0 }, ...rows]));
  }

  /**
   * Mirrors CRMReview.aspx.vb's FillGV (EXEC CRMReview — an ad-hoc report
   * proc with dynamic columns; columns after index 2 in the source become
   * clickable drill-down links to CRMReviewdetail.aspx).
   */
  getCrmReviewRows(userId: number, fromDate: Date | null, toDate: Date | null): Observable<{ columns: string[]; linkColumns: string[]; rows: Record<string, unknown>[] }> {
    const params: Record<string, string | number> = { user_id: userId };
    if (fromDate) {
      params['from_date'] = this.toDateParam(fromDate);
    }
    if (toDate) {
      params['to_date'] = this.toDateParam(toDate);
    }
    return this.http
      .get<{ columns: string[]; rows: Record<string, unknown>[] }>(`${BASE}/reports/crm-review`, { params })
      .pipe(map((res) => ({ ...res, linkColumns: res.columns.slice(3) })));
  }

  /** Mirrors CRMReviewdetail.aspx.vb's FillGV (EXEC CRMDetails / EXEC SynapseDetails). */
  getCrmReviewDetailRows(
    actionStageName: string, userId = 0, fromDate: Date | null = null, toDate: Date | null = null
  ): Observable<{ columns: string[]; rows: Record<string, unknown>[] }> {
    const params: Record<string, string | number> = { action_stage_name: actionStageName, user_id: userId };
    if (fromDate) {
      params['from_date'] = this.toDateParam(fromDate);
    }
    if (toDate) {
      params['to_date'] = this.toDateParam(toDate);
    }
    return this.http.get<{ columns: string[]; rows: Record<string, unknown>[] }>(`${BASE}/reports/crm-review-detail`, { params });
  }

  /** Mirrors FeedbackRegister.aspx.vb's FillGV (web_feedback joined UserMaster). */
  getFeedbackRows(): Observable<FeedbackRow[]> {
    return this.http.get<ApiFeedbackRow[]>(`${BASE}/reports/feedback`).pipe(map((rows) => rows.map(toFeedbackRow)));
  }

  /** Mirrors MyCallerHistory.aspx.vb's rcbuser source (userMaster restricted to RSPL_CallHistory users). */
  getMyCallerUsers(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/reports/my-caller-users`);
  }

  /** Mirrors MyCallerHistory.aspx.vb's fillGV (WebProc_GetMobileCallhistory). */
  getMyCallerHistory(userId: number, fromDate: Date | null, toDate: Date | null): Observable<{ columns: string[]; rows: Record<string, unknown>[] }> {
    return this.http.get<{ columns: string[]; rows: Record<string, unknown>[] }>(`${BASE}/reports/my-caller-history`, {
      params: {
        user_id: userId,
        from_date: this.toDateParam(fromDate ?? new Date()),
        to_date: this.toDateParam(toDate ?? new Date())
      }
    });
  }

  /** Mirrors ReferralAnalysis.aspx.vb's filter-source lookups (VW_Customer_Refferal_Dtls). */
  getReferralAnalysisFilters(): Observable<{ cities: string[]; referredBy: string[]; referralNames: string[]; orderBy: string[] }> {
    return this.http
      .get<{ cities: string[]; referred_by: string[]; referral_names: string[]; order_by: string[] }>(`${BASE}/reports/referral-analysis/filters`)
      .pipe(map((f) => ({ cities: f.cities, referredBy: f.referred_by, referralNames: f.referral_names, orderBy: f.order_by })));
  }

  // Bound to Customer Referral Analysis's Referred City/Referred By/Referral
  // Name <p-select>'s (onFilter) — re-queries the server with whatever's
  // typed instead of only filtering the already-loaded top 100 client-side
  // (same load-on-demand shape as /customers-for-search).
  getReferralAnalysisCities(search = ''): Observable<string[]> {
    return this.http.get<string[]>(`${BASE}/reports/referral-analysis/cities`, { params: { search } });
  }

  getReferralAnalysisReferredBy(search = ''): Observable<string[]> {
    return this.http.get<string[]>(`${BASE}/reports/referral-analysis/referred-by`, { params: { search } });
  }

  getReferralAnalysisReferralNames(search = ''): Observable<string[]> {
    return this.http.get<string[]>(`${BASE}/reports/referral-analysis/referral-names`, { params: { search } });
  }

  /** Mirrors ReferralAnalysis.aspx.vb's FillGv (VW_Customer_Refferal_Dtls) with a bold Total summary row appended by the component. */
  getReferralAnalysisRows(filters: {
    status: number;
    referredCity: string;
    referredBy: string;
    fromDate: Date | null;
    toDate: Date | null;
    orderNo: string;
    referralCardNo: string;
    referralName: string;
    orderBy: string;
  }): Observable<ReferralAnalysisRow[]> {
    const params: Record<string, string | number> = {
      status: filters.status,
      city: filters.referredCity,
      referred_by: filters.referredBy,
      order_no: filters.orderNo,
      referral_card_no: filters.referralCardNo,
      referral_name: filters.referralName,
      order_by: filters.orderBy
    };
    if (filters.fromDate) {
      params['from_date'] = this.toDateParam(filters.fromDate);
    }
    if (filters.toDate) {
      params['to_date'] = this.toDateParam(filters.toDate);
    }
    return this.http
      .get<ApiReferralAnalysisRow[]>(`${BASE}/reports/referral-analysis`, { params })
      .pipe(map((rows) => rows.map(toReferralAnalysisRow)));
  }

  /** Mirrors SendEmail.aspx.vb's btnSend_Click — despite the page name, it appends a call-remark string to CustomerAttributes. */
  saveCallRemark(custId: number, remark: string): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/reports/customer-call-remark/${custId}`, null, { params: { remark } });
  }

  private toDateParam(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  /** Mirrors WebMasters.aspx.vb's ddlmastername source (distinct web_littlemaster.MasterName). */
  getWebMasterNames(): Observable<string[]> {
    return this.http.get<string[]>(`${BASE}/content/web-master-names`);
  }

  getWebMasterValues(masterName: string): Observable<{ id: number; value: string }[]> {
    return this.http.get<{ id: number; value: string }[]>(`${BASE}/content/web-master-values`, { params: { master_name: masterName } });
  }

  /** Mirrors WebMasters.aspx.vb's btnsubmit_Click (webproc_Webmasteradd / Webproc_WebMasterEdit). */
  saveWebMasterValue(masterName: string, id: number | null, value: string): Observable<{ success: boolean; message: string }> {
    return this.http.post<{ success: boolean; message: string }>(`${BASE}/content/web-master-value`, {
      master_name: masterName,
      id,
      value
    });
  }

  getAccountOptions(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/vouchers/accounts`);
  }

  getBankOptions(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/vouchers/banks`);
  }

  /** Mirrors PaymentVoucher.aspx.vb's cmbVoucherNo source (PaymentRegister / PrePaymentRegister). */
  getPaymentVoucherNumbers(isPaymentVoucher: boolean): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/vouchers/payment-voucher-numbers`, { params: { is_payment_voucher: isPaymentVoucher } });
  }

  getPaymentVoucher(voucherNo: number, isPaymentVoucher: boolean): Observable<PaymentVoucherRow | null> {
    return this.http
      .get<ApiPaymentVoucherRow | null>(`${BASE}/vouchers/payment-voucher/${voucherNo}`, { params: { is_payment_voucher: isPaymentVoucher } })
      .pipe(map((r) => (r ? toPaymentVoucherRow(r) : null)));
  }

  /** Mirrors PaymentVoucher.aspx.vb's btnSubmit_Click (Exec PaymentVoucher / Exec Proc_PrePaymentVoucher). */
  savePaymentVoucher(payload: Omit<PaymentVoucherRow, 'voucherNo'>): Observable<{ success: boolean; voucherNo: number; message: string }> {
    return this.http.post<{ success: boolean; voucherNo: number; message: string }>(`${BASE}/vouchers/payment-voucher`, {
      is_payment_voucher: payload.isPaymentVoucher,
      debit_account: payload.debitAccount,
      paid_to: payload.paidTo,
      payment_for: payload.paymentFor,
      amount: payload.amount
    });
  }

  /** Mirrors VoucherDetail.aspx.vb's Page_Load (outstanding SalesMaster rows for a customer). */
  getOutstandingVouchers(custId: number): Observable<OutstandingVoucherRow[]> {
    return this.http
      .get<ApiOutstandingVoucherRow[]>(`${BASE}/vouchers/outstanding/${custId}`)
      .pipe(map((rows) => rows.map(toOutstandingVoucherRow)));
  }

  /** Mirrors LedgerBalance.aspx.vb's fillGV (Exec Proc_DisplayLedgerBalance) with the rcbSearch/txtSearch filter applied server-side. */
  getLedgerBalanceRows(searchField: string, searchValue: string): Observable<LedgerBalanceRow[]> {
    return this.http
      .get<ApiLedgerBalanceRow[]>(`${BASE}/ledger/rows`, { params: { search_field: searchField, search_value: searchValue } })
      .pipe(map((rows) => rows.map(toLedgerBalanceRow)));
  }

  /** Mirrors LedgerBalance.aspx.vb's chkImmediate_checked/chkDistance_checked/chkLDistance_checked/chkWriteoff_checked (mutually exclusive flags on vwCustLedgerBalanceOutStanding). */
  updateLedgerBalanceFlag(custId: number, flag: 'immediate' | 'distance' | 'longDistance' | 'writeoff', value: boolean): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/ledger/${custId}/flag`, { flag, value });
  }

  /** Mirrors AddTag.aspx.vb's cmbTagType1 source (tagUsingTable, TagId for PayRegNo). */
  getTagTypes(): Observable<TagTypeOption[]> {
    return this.http.get<{ sr_no: number; name: string }[]>(`${BASE}/vouchers/tag-types`).pipe(
      map((rows) => rows.map((r) => ({ srNo: r.sr_no, name: r.name })))
    );
  }

  /** Mirrors AddTag.aspx.vb's fillgvTagType (tagUsingTable.QueryString run per tag type, or a customer search for SrNo=8). */
  getTagTypeValues(tagTypeSrNo: number, search?: string): Observable<TagValueOption[]> {
    return this.http.get<TagValueOption[]>(`${BASE}/vouchers/tag-type-values`, {
      params: { tag_type_sr_no: tagTypeSrNo, search: search ?? '' }
    });
  }

  /** Mirrors AddTag.aspx.vb's FillGvAssigneTag (TagValues, tilde/comma-encoded — decoded into groups here). */
  getAssignedTags(voucherNo: number): Observable<AssignedTagGroup[]> {
    return this.http.get<{ tag_type_sr_no: number; tag_type_name: string; values: TagValueOption[] }[]>(`${BASE}/vouchers/assigned-tags/${voucherNo}`).pipe(
      map((rows) => rows.map((r) => ({ tagTypeSrNo: r.tag_type_sr_no, tagTypeName: r.tag_type_name, values: r.values })))
    );
  }

  /** Mirrors AddTag.aspx.vb's btnApplay_Click (WebProc_Insert_TagVlaues). */
  saveTags(voucherNo: number, groups: AssignedTagGroup[]): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/vouchers/${voucherNo}/tags`, {
      groups: groups.map((g) => ({ tag_type_sr_no: g.tagTypeSrNo, tag_type_name: g.tagTypeName, values: g.values }))
    });
  }

  /** Holiday Master (new page, backed by RSPL_HolidayMaster) — see admin_holiday.py. */
  getHolidays(): Observable<HolidayRow[]> {
    return this.http.get<ApiHolidayRow[]>(`${BASE}/holidays`).pipe(map((rows) => rows.map(toHolidayRow)));
  }

  addHoliday(holidayDate: string, toDate: string, event: string): Observable<HolidayRow> {
    return this.http.post<ApiHolidayRow>(`${BASE}/holidays`, { holiday_date: holidayDate, to_date: toDate, event }).pipe(map(toHolidayRow));
  }

  updateHoliday(holidayId: number, holidayDate: string, toDate: string, event: string): Observable<HolidayRow> {
    return this.http
      .put<ApiHolidayRow>(`${BASE}/holidays/${holidayId}`, { holiday_date: holidayDate, to_date: toDate, event })
      .pipe(map(toHolidayRow));
  }

  deleteHoliday(holidayId: number): Observable<{ success: boolean }> {
    return this.http.delete<{ success: boolean }>(`${BASE}/holidays/${holidayId}`);
  }

  setHolidayStatus(holidayId: number, enabled: boolean): Observable<HolidayRow> {
    return this.http.put<ApiHolidayRow>(`${BASE}/holidays/${holidayId}/status`, { enabled }).pipe(map(toHolidayRow));
  }

  // Dashboard card title (RSPL_HolidayMasterSettings) — editable here, read by the dashboard.
  getHolidayListTitle(): Observable<string> {
    return this.http.get<{ name: string }>(`${BASE}/holidays/title`).pipe(map((r) => r.name));
  }

  setHolidayListTitle(name: string): Observable<string> {
    return this.http.put<{ name: string }>(`${BASE}/holidays/title`, { name }).pipe(map((r) => r.name));
  }

  // Face In/Out (new page, backed by FaceInOut for Pune / FaceInOut_Nagar for
  // Nagar — see admin_face_inout.py's 2026-08-04 update note). `capped` is
  // true when there were more matching rows than the backend's safety cap
  // returned — a device export accumulates roughly one row per person per
  // day, so an unfiltered (or very broad) search can otherwise grow without
  // limit as the table ages.
  getFaceInOutRows(filters: {
    team: FaceInOutTeam;
    name?: string;
    dateFrom?: Date | null;
    dateTo?: Date | null;
  }): Observable<{ rows: FaceInOutRow[]; capped: boolean }> {
    const params: Record<string, string> = { team: filters.team };
    if (filters.name?.trim()) {
      params['name'] = filters.name.trim();
    }
    if (filters.dateFrom) {
      params['date_from'] = this.toDateParam(filters.dateFrom);
    }
    if (filters.dateTo) {
      params['date_to'] = this.toDateParam(filters.dateTo);
    }
    return this.http
      .get<{ rows: ApiFaceInOutRow[]; capped: boolean }>(`${BASE}/face-inout`, { params })
      .pipe(map((res) => ({ rows: res.rows.map(toFaceInOutRow), capped: res.capped })));
  }

  importFaceInOutRows(team: FaceInOutTeam, rows: FaceInOutImportRow[]): Observable<FaceInOutImportResult> {
    return this.http
      .post<{ imported_count: number; skipped: { row_number: number; reason: string }[] }>(`${BASE}/face-inout/import`, {
        team,
        rows: rows.map((r) => ({
          face_id: r.faceId,
          name: r.name,
          date: r.date,
          in_time: r.inTime ?? '',
          break_time: r.breakTime ?? '',
          resume_time: r.resumeTime ?? '',
          out_time: r.outTime ?? '',
          extra: r.extra ?? {}
        }))
      })
      .pipe(
        map((res) => ({
          importedCount: res.imported_count,
          skipped: res.skipped.map((s) => ({ rowNumber: s.row_number, reason: s.reason }))
        }))
      );
  }

  getFaceAttendanceRecords(filters: {
    name?: string;
    dateFrom?: Date | null;
    dateTo?: Date | null;
  }): Observable<FaceAttendanceRecord[]> {
    const params: Record<string, string> = {};
    if (filters.name?.trim()) {
      params['name'] = filters.name.trim();
    }
    if (filters.dateFrom) {
      params['date_from'] = this.toDateParam(filters.dateFrom);
    }
    if (filters.dateTo) {
      params['date_to'] = this.toDateParam(filters.dateTo);
    }
    return this.http.get<FaceAttendanceRecord[]>(`${API_BASE_URL}/admin/face/attendance-report`, { params });
  }
}

export interface CustTinFollowupRow {
  custId: number;
  software: string;
  displayName: string;
  className: string;
  amcExpiry: string;
  salesPerson: string;
  mobileNo: string;
  email: string;
  tinNo: string;
  followupRemark: string;
}

export interface ReferralAnalysisRow {
  referredBy: string;
  referredCustId: number;
  referredCity: string;
  custId: number;
  newCustomer: string;
  city: string;
  enquiryDate: string;
  balanceAmt: number;
  amount: number;
  referralCardNo: string;
  orderNo: number | null;
  orderDate: string | null;
  orderBy: string;
  introducedBy: string;
}

export interface FeedbackRow {
  feedbackId: number;
  date: string;
  name: string;
  email: string;
  city: string;
  subject: string;
  message: string;
  userName: string;
}

export interface LedgerBalanceRow {
  custId: number;
  displayName: string;
  mobileNo: string;
  avgDays: number;
  city: string;
  area: string;
  contactPerson: string;
  outstanding: number;
  immediate: boolean;
  distance: boolean;
  longDistance: boolean;
  writeoff: boolean;
  followUpUser: string;
  amcDate: string;
}

export interface PaymentVoucherRow {
  voucherNo: number;
  isPaymentVoucher: boolean;
  date: string;
  debitAccount: string;
  debitAccountId: number;
  creditAccount: string;
  creditAccountId: number;
  paidTo: string;
  paymentFor: string;
  amount: number;
}

export interface OutstandingVoucherRow {
  voucherNo: number;
  date: string;
  salesMan: string;
  billAmt: number;
  outstanding: number;
}

export interface AdvanceVoucherRow {
  voucherNo: number;
  date: string;
  customerId: number;
  customerName: string;
  contactPerson: string;
  narration: string;
  amount: number;
}

export interface CustomerAnsRow {
  clientId: number;
  clientName: string;
  amcExpiryDate: string;
  question: string;
  answer: string;
  answerDate: string;
  answerTime: string;
  userName: string;
  machineName: string;
}

export interface GracePeriodRow {
  softwareName: string;
  clientId: number;
  clientName: string;
  city: string;
  amcDueDate: string;
  amcDueDelayDays: number;
  amcGraceRemark: string;
  disabled: boolean;
}

export interface LicenseViolationRow {
  custId: number;
  displayName: string;
  city: string;
  amcDueDate: string;
  amcAmount: number;
  ledgerBalance: number;
  piratedQty: number;
  piracyAmt: number;
  firstBill: string;
  firstSalesman: string;
}

export interface LicenseModuleRow {
  pirated: boolean;
  productId: number;
  productName: string;
  activeQty: number;
  billedQty: number;
  piratedQty: number;
  piracyAmt: number;
  answerTime: string;
}

export interface LicenseActionRow {
  actionId: number;
  creationDate: string;
  creationTime: string;
  followUpBy: string;
  followUpRemark: string;
  assignedTo: string;
  actionDescription: string;
  actionRemark: string;
  nextAction: 'Add' | 'Close' | 'Closed';
}

export interface CustomerInfoRow {
  custId: number;
  customerName: string;
  groupName: string;
  address: string;
  contactPerson: string;
  mobileNo: string;
  phoneNo: string;
  email: string;
}

export interface CustLedgerRow {
  customerId: number;
  customerName: string;
  area: string;
  cityName: string;
  email: string;
  mobileNo: string;
  amc: string;
  ytDate: string | null;
  ytStatus: string;
  ytRemark: string;
  exeStatus: string;
  ytUser: string;
}

export interface CustLedgerSaleRow {
  customerId: number;
  voucherNo: number;
  date: string;
  expiry: string;
  srNo: number;
  productName: string;
  qty: number;
  rate: number;
  amount: number;
}

export interface ArticleRow {
  articleId: number;
  publishDate: string;
  categoryId: number;
  category: string;
  title: string;
  author: string;
  description: string;
  enabled: boolean;
}

export interface VideoModuleOption {
  moduleId: number;
  name: string;
}

export interface VideoRow {
  id: number;
  name: string;
  moduleId: number;
  module: string;
  details: string;
  videoUrl: string;
  disabled: boolean;
}

export interface TagTypeOption {
  srNo: number;
  name: string;
}

export interface TagValueOption {
  id: number;
  name: string;
}

export interface AssignedTagGroup {
  tagTypeSrNo: number;
  tagTypeName: string;
  values: TagValueOption[];
}
