import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { AdminDataService, AssignedTagGroup, TagTypeOption, TagValueOption } from '../admin-data.service';

/**
 * Mirrors Section_Admin/AddTag.aspx: assign tag values (grouped by tag
 * type) to a payment voucher via a two-panel picker (available values on
 * the left, ">>" moves checked values into the assigned-tags list on the
 * right, grouped by tag type with a per-value remove). The source's
 * tilde/comma-delimited string encoding for persistence (TagsMasterBasedData
 * ~ TagsKey ~ TagsMasterAttributeID) is an internal storage detail with no
 * user-facing equivalent — simplified to typed groups, same picker
 * behavior. VoucherNo came from Session("VoucherNo") set by
 * PaymentVoucher.aspx in the source; read from a ?VoucherNo= query param
 * here instead since there's no cross-page session state in this frontend
 * phase.
 */
@Component({
  selector: 'app-add-tag',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, SelectModule],
  templateUrl: './add-tag.html',
  styleUrl: './add-tag.scss'
})
export class AddTag implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(AdminDataService);
  private readonly router = inject(Router);
  // No zone.js in this app — plain (non-signal) properties like `voucherNo`/
  // `selectedTagTypeSrNo` below don't trigger a re-render when mutated inside
  // an RxJS subscribe callback.
  private readonly cdr = inject(ChangeDetectorRef);

  voucherNo = 0;

  readonly tagTypes = signal<TagTypeOption[]>([]);
  readonly values = signal<(TagValueOption & { checked: boolean })[]>([]);
  readonly assignedGroups = signal<AssignedTagGroup[]>([]);
  readonly saving = signal(false);

  selectedTagTypeSrNo: number | null = null;
  searchText = '';

  // Debounces the customer-search-as-you-type filter so it re-queries the
  // server once typing pauses, instead of firing one HTTP request per
  // keystroke — same pattern as Advance/TroubleTicket's customer pickers.
  private readonly customerSearch$ = new Subject<string>();

  get isCustomerSearch(): boolean {
    return this.selectedTagTypeSrNo === 8;
  }

  ngOnInit(): void {
    this.data.getTagTypes().subscribe((t) => this.tagTypes.set(t));

    // Reached repeatedly from PaymentVoucher's "Add Tag" button with a
    // different ?VoucherNo each time — subscribe rather than reading a
    // one-time snapshot so tagging a different voucher while already
    // mounted actually reloads that voucher's assigned tags.
    this.route.queryParamMap.subscribe((q) => {
      this.voucherNo = Number(q.get('VoucherNo') ?? 0);
      this.selectedTagTypeSrNo = null;
      this.values.set([]);
      this.cdr.markForCheck();
      this.data.getAssignedTags(this.voucherNo).subscribe((g) => this.assignedGroups.set(g));
    });

    this.customerSearch$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((query) => this.data.getTagTypeValues(8, query))
      )
      .subscribe((values) => this.values.set(values.map((v) => ({ ...v, checked: false }))));
  }

  onTagTypeChange(): void {
    if (this.selectedTagTypeSrNo == null) {
      this.values.set([]);
      return;
    }
    this.searchText = '';
    this.loadValues();
  }

  private loadValues(search?: string): void {
    if (this.selectedTagTypeSrNo == null) {
      return;
    }
    this.data.getTagTypeValues(this.selectedTagTypeSrNo, search).subscribe((values) => {
      this.values.set(values.map((v) => ({ ...v, checked: false })));
    });
  }

  // Bound to the customer search input's (ngModelChange) — pushes into the
  // debounced pipeline set up in ngOnInit for live "type to search" results,
  // same as every other customer picker in this app. Only relevant when
  // isCustomerSearch is true (tag type 8) since that's the only tag type
  // with a genuinely large enough underlying table to need this.
  onCustomerSearchInput(value: string): void {
    this.customerSearch$.next(value);
  }

  // Explicit trigger for an immediate lookup without waiting for the
  // debounce — kept alongside the live search above rather than removed.
  // Previously cleared searchText right after searching, which made no
  // sense once live-as-you-type search existed alongside it (the box would
  // go blank the moment you clicked Search).
  search(): void {
    this.loadValues(this.searchText);
  }

  assign(): void {
    const tagType = this.tagTypes().find((t) => t.srNo === this.selectedTagTypeSrNo);
    const checked = this.values().filter((v) => v.checked);
    if (!tagType || checked.length === 0) {
      alert('Please Select Tag Name.');
      return;
    }
    this.assignedGroups.update((groups) => {
      const existing = groups.find((g) => g.tagTypeSrNo === tagType.srNo);
      if (existing) {
        const existingIds = new Set(existing.values.map((v) => v.id));
        existing.values.push(...checked.filter((v) => !existingIds.has(v.id)));
        return [...groups];
      }
      return [...groups, { tagTypeSrNo: tagType.srNo, tagTypeName: tagType.name, values: checked.map(({ id, name }) => ({ id, name })) }];
    });
    this.selectedTagTypeSrNo = null;
    this.values.set([]);
  }

  removeValue(group: AssignedTagGroup, value: TagValueOption): void {
    this.assignedGroups.update((groups) => {
      const updated = groups
        .map((g) => (g === group ? { ...g, values: g.values.filter((v) => v.id !== value.id) } : g))
        .filter((g) => g.values.length > 0);
      return updated;
    });
  }

  apply(): void {
    if (this.assignedGroups().length === 0) {
      alert('Please select Tag information.');
      return;
    }
    this.saving.set(true);
    this.data.saveTags(this.voucherNo, this.assignedGroups()).subscribe((res) => {
      this.saving.set(false);
      if (res.success) {
        this.router.navigate(['/admin/payment-voucher']);
      } else {
        alert('Tags can not be applied.');
      }
    });
  }
}
