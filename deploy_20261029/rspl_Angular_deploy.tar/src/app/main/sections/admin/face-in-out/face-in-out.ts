import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import * as XLSX from 'xlsx';

import { ExcelColumn, exportToExcel } from '../../../../shared/export-excel';
import { AdminDataService, FaceAttendanceRecord, FaceInOutImportRow, FaceInOutRow, FaceInOutTeam } from '../admin-data.service';

// Nagar's ~25 device-export-only columns beyond the shared core fields
// (Employee ID/Name/Date/In/Break/Resume/Out) — exact Excel header text,
// matching admin_face_inout.py's _NAGAR_TEXT_EXTRA_FIELDS/
// _NAGAR_FLOAT_EXTRA_FIELDS/"No." exactly (that's what parses/types them
// server-side; this list only needs to know WHICH keys to carry through).
const NAGAR_EXTRA_COLUMNS = [
  'No.', 'empno', 'Card ID', 'Group', 'Department', 'Section', 'Day Type', 'Schedule',
  'OT', 'Done', 'Work', 'Overtime', 'Diff.OT', 'Short Minutes', 'sumhr', 'sumot',
  'sumdiff', 'sumshort', 'leavetype', 'leavehour', 'leaveday', 'Remark', 'reason_l', 'reason_e', 'reason_m'
];

/**
 * New "Face In/Out" admin page (Accounts menu) — search/grid/export/import
 * for a face-recognition attendance device's per-day In/Break/Resume/Out
 * punch records. See app/routers/admin_face_inout.py for the backend design
 * (composite (FaceId, Date) key, server-derived WeekDay, free-text punch
 * times, duplicate/invalid-row handling on import).
 *
 * Import is parsed client-side (mirrors executive-schedule.ts's own Import
 * from Excel — this app's established convention) rather than uploading the
 * raw file for the server to parse.
 *
 * Update (2026-08-04): extended for a separate Nagar Team, per explicit
 * request — same page/grid/search/export, just a Team selector that
 * switches which table (FaceInOut vs FaceInOut_Nagar) is read/written and
 * which Excel import format is expected. See admin_face_inout.py's own
 * 2026-08-04 update note for the backend/table design.
 */
@Component({
  selector: 'app-face-in-out',
  imports: [FormsModule, ButtonModule, DatePickerModule, InputTextModule, MessageModule, SelectModule, TableModule, DatePipe],
  templateUrl: './face-in-out.html',
  styleUrl: './face-in-out.scss'
})
export class FaceInOut implements OnInit {
  private readonly data = inject(AdminDataService);

  readonly rows = signal<FaceInOutRow[]>([]);
  readonly faceAttendanceRows = signal<FaceAttendanceRecord[]>([]);
  readonly loading = signal(false);
  readonly importing = signal(false);
  readonly errorMessage = signal<string | null>(null);
  readonly importSummary = signal<string | null>(null);
  readonly cappedMessage = signal<string | null>(null);

  readonly teamOptions: { label: string; value: FaceInOutTeam }[] = [
    { label: 'Pune Team', value: 'pune' },
    { label: 'Nagar Team', value: 'nagar' },
    { label: 'Face Attendance', value: 'face_attendance' }
  ];
  team: FaceInOutTeam = 'pune';

  name = '';
  // Defaults to the current month rather than truly unbounded — a device
  // export accumulates roughly one row per person per day, so leaving this
  // wide open by default gets slower to load every year the table grows.
  // Still fully searchable beyond this — just not the opening default.
  private readonly today = new Date();
  dateFrom: Date | null = new Date(this.today.getFullYear(), this.today.getMonth(), 1);
  dateTo: Date | null = new Date(this.today.getFullYear(), this.today.getMonth() + 1, 0);

  // Same header text/order as the on-screen grid, rather than dumping raw
  // camelCase field names — Date passes the raw ISO string straight through
  // so exportToExcel's own project-wide date handling turns it into a
  // genuine Excel date cell formatted dd-mmm-yyyy.
  private readonly excelColumns: readonly ExcelColumn<FaceInOutRow>[] = [
    { header: 'Face ID', value: (r) => r.faceId },
    { header: 'Name', value: (r) => r.name },
    { header: 'Date', value: (r) => r.date },
    { header: 'Week Day', value: (r) => r.weekDay },
    { header: 'In', value: (r) => r.inTime },
    { header: 'Break', value: (r) => r.breakTime },
    { header: 'Resume', value: (r) => r.resumeTime },
    { header: 'Out', value: (r) => r.outTime }
  ];

  ngOnInit(): void {
    this.search();
  }

  // Bound to the Team <p-select>'s (onChange) — re-runs the search against
  // the newly selected team's own table immediately, same as changing any
  // other filter. Name/date filters are left as-is rather than reset, since
  // there's no reason a date range or partial name wouldn't still be a
  // reasonable filter after switching teams.
  onTeamChange(): void {
    this.search();
  }

  search(): void {
    this.loading.set(true);
    this.errorMessage.set(null);
    this.cappedMessage.set(null);

    if (this.team === 'face_attendance') {
      this.data.getFaceAttendanceRecords({ name: this.name, dateFrom: this.dateFrom, dateTo: this.dateTo }).subscribe({
        next: (records) => {
          this.faceAttendanceRows.set(records);
          this.loading.set(false);
        },
        error: () => {
          this.loading.set(false);
          this.errorMessage.set('Could not load Face Attendance records. Please check your connection and try again.');
        }
      });
      return;
    }

    this.data.getFaceInOutRows({ team: this.team, name: this.name, dateFrom: this.dateFrom, dateTo: this.dateTo }).subscribe({
      next: (result) => {
        this.rows.set(result.rows);
        this.loading.set(false);
        if (result.capped) {
          this.cappedMessage.set(`Showing the most recent ${result.rows.length.toLocaleString()} matching records — narrow the date range or add a name to see a complete result.`);
        }
      },
      error: () => {
        this.loading.set(false);
        this.errorMessage.set('Could not load Face In/Out records. Please check your connection and try again.');
      }
    });
  }

  exportExcel(): void {
    if (this.team === 'face_attendance') {
      const faColumns: ExcelColumn<FaceAttendanceRecord>[] = [
        { header: 'Employee Name', value: (r) => r.userName },
        { header: 'Date', value: (r) => r.attendanceDate },
        { header: 'Arrival Time', value: (r) => r.arrivalTime },
        { header: 'Confidence %', value: (r) => r.confidence != null ? +(r.confidence * 100).toFixed(1) : '' },
        { header: 'City', value: (r) => r.city ?? '' },
        { header: 'State', value: (r) => r.state ?? '' },
        { header: 'Country', value: (r) => r.country ?? '' },
        { header: 'Lat', value: (r) => r.lat ?? '' },
        { header: 'Lng', value: (r) => r.lng ?? '' },
        { header: 'Accuracy (m)', value: (r) => r.accuracyM ?? '' },
      ];
      exportToExcel('FaceAttendance', this.faceAttendanceRows(), faColumns);
      return;
    }
    exportToExcel(this.team === 'nagar' ? 'FaceInOut_Nagar' : 'FaceInOut_Pune', this.rows(), this.excelColumns);
  }

  onImportFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (!file) {
      return;
    }
    this.errorMessage.set(null);
    this.importSummary.set(null);
    this.importing.set(true);

    file.arrayBuffer().then((buffer) => {
      // cellDates + dateNF: a genuine Excel date cell in the imported file
      // (e.g. typed via the date picker, or the Nagar device export's own
      // dd-mmm-yy-formatted Date column — confirmed live via xlrd against
      // the real D:\Maruti\ATT.xls reference file) always arrives here as a
      // clean "yyyy-mm-dd" string, regardless of the workbook's own display
      // format/locale — the backend also accepts a few common human-typed
      // fallbacks (dd-MMM-yyyy, dd/mm/yyyy, mm/dd/yyyy) for cells that were
      // entered as plain text instead of a real date.
      const workbook = XLSX.read(buffer, { type: 'array', cellDates: true });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const parsedRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { raw: false, dateNF: 'yyyy-mm-dd' });

      if (!parsedRows.length) {
        this.importing.set(false);
        this.errorMessage.set('The selected file has no data rows.');
        return;
      }

      const importRows = this.team === 'nagar' ? this.parseNagarRows(parsedRows) : this.parsePuneRows(parsedRows);

      this.data.importFaceInOutRows(this.team, importRows).subscribe({
        next: (result) => {
          this.importing.set(false);
          const preview = result.skipped
            .slice(0, 5)
            .map((s) => `#${s.rowNumber} (${s.reason})`)
            .join(', ');
          const skippedText = result.skipped.length ? ` ${result.skipped.length} row(s) skipped: ${preview}${result.skipped.length > 5 ? ', …' : ''}` : '';
          this.importSummary.set(`Imported ${result.importedCount} record(s).${skippedText}`);
          this.search();
        },
        error: () => {
          this.importing.set(false);
          this.errorMessage.set('Could not import the file. Please check your connection and try again.');
        }
      });
    });
  }

  // Accepts two header conventions: the full FaceId/Name/Date/In/Break/
  // Resume/Out shape, or a plain device-roster export (User ID/First Name
  // only, e.g. D:\Maruti\inout.xlsx — confirmed live to have just those two
  // columns for 108 rows, padded with trailing spaces on the name). Per
  // explicit request, a roster row with no Date column defaults to today —
  // Date is part of FaceInOut's primary key, so it can never be left blank
  // — with In/Break/Resume/Out left empty, ready to be filled in by a later
  // real attendance import/edit.
  private parsePuneRows(parsedRows: Record<string, unknown>[]): FaceInOutImportRow[] {
    const today = this.toIsoDate(new Date());
    return parsedRows.map((r) => ({
      faceId: String(r['FaceId'] ?? r['User ID'] ?? '').trim(),
      name: String(r['Name'] ?? r['First Name'] ?? '').trim(),
      date: String(r['Date'] ?? '').trim() || today,
      inTime: String(r['In'] ?? '').trim(),
      breakTime: String(r['Break'] ?? '').trim(),
      resumeTime: String(r['Resume'] ?? '').trim(),
      outTime: String(r['Out'] ?? '').trim()
    }));
  }

  // Nagar's real device-export shape (confirmed live against
  // D:\Maruti\ATT.xls via xlrd — 33 columns: Employee ID/Name/Date/In/
  // Break/Resume/Out plus ~25 richer attendance-system columns). Employee
  // ID is this team's FaceId-equivalent — same natural-key role, different
  // column name. Everything beyond the 7 shared core fields goes into
  // `extra`, keyed by the exact Excel header text (see NAGAR_EXTRA_COLUMNS
  // and admin_face_inout.py's matching _NAGAR_TEXT_EXTRA_FIELDS/
  // _NAGAR_FLOAT_EXTRA_FIELDS, which parse/type these server-side) — no
  // "today" fallback here, unlike Pune's roster format, since every real
  // Nagar export row always has its own Date column.
  private parseNagarRows(parsedRows: Record<string, unknown>[]): FaceInOutImportRow[] {
    return parsedRows.map((r) => {
      const extra: Record<string, string> = {};
      for (const col of NAGAR_EXTRA_COLUMNS) {
        extra[col] = String(r[col] ?? '').trim();
      }
      return {
        faceId: String(r['Employee ID'] ?? '').trim(),
        name: String(r['Name'] ?? '').trim(),
        date: String(r['Date'] ?? '').trim(),
        inTime: String(r['In'] ?? '').trim(),
        breakTime: String(r['Break'] ?? '').trim(),
        resumeTime: String(r['Resume'] ?? '').trim(),
        outTime: String(r['Out'] ?? '').trim(),
        extra
      };
    });
  }

  private toIsoDate(d: Date): string {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
}
