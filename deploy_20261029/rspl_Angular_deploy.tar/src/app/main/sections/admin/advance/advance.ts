import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { AdminDataService, LookupOption } from '../admin-data.service';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';

/**
 * Mirrors Section_Admin/Advance.aspx: create/view advance-payment vouchers
 * against a customer, with a "Last Advance Details" side panel. Printing
 * (the source's voucher print preview) is not offered in this form.
 */
@Component({
  selector: 'app-advance',
  imports: [FormsModule, ButtonModule, SelectModule, TextareaModule, InputNumberModule, InputTextModule, DatePipe, IndianNumberPipe],
  templateUrl: './advance.html',
  styleUrl: './advance.scss'
})
export class Advance implements OnInit {
  private readonly data = inject(AdminDataService);
  // No zone.js in this app — plain (non-signal) properties like `date`/
  // `customerId`/`contactPerson`/`narration`/`amount`/`mode` below don't
  // trigger a re-render when mutated inside an RxJS subscribe callback.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly voucherNumbers = signal<LookupOption[]>([]);
  readonly customers = signal<LookupOption[]>([]);
  readonly customerDetails = signal('Customer Not Selected');
  readonly lastAdvance = signal<{ voucherNo: number; customerName: string; amount: number } | null>(null);
  readonly saving = signal(false);

  mode: 'view' | 'add' = 'view';
  selectedVoucherNo: number | null = null;
  date = new Date().toISOString();
  customerId: number | null = null;
  customerName = '';
  contactPerson = '';
  narration = '';
  amount: number | null = null;

  // Debounces the customer-search-as-you-type filter so it re-queries the
  // server once typing pauses, instead of firing one HTTP request per
  // keystroke (PrimeNG's p-select onFilter emits immediately, with no
  // built-in delay).
  private readonly customerFilter$ = new Subject<string>();

  ngOnInit(): void {
    this.loadVoucherNumbers();
    this.loadLastAdvance();
    this.data.getCustomers().subscribe((c) => this.customers.set(c));

    this.customerFilter$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((query) => this.data.getCustomers(query))
      )
      .subscribe((c) => this.customers.set(c));
  }

  private loadVoucherNumbers(): void {
    this.data.getAdvanceVoucherNumbers().subscribe((v) => this.voucherNumbers.set(v));
  }

  private loadLastAdvance(): void {
    this.data.getLastAdvance().subscribe((v) => {
      this.lastAdvance.set(v ? { voucherNo: v.voucherNo, customerName: v.customerName, amount: v.amount } : null);
    });
  }

  onVoucherSelected(): void {
    if (!this.selectedVoucherNo) {
      return;
    }
    this.data.getAdvanceVoucher(this.selectedVoucherNo).subscribe((v) => {
      if (!v) {
        return;
      }
      this.date = v.date;
      this.customerId = v.customerId;
      this.contactPerson = v.contactPerson;
      this.narration = v.narration;
      this.amount = v.amount;
      // The picker is also capped to a top-100/search-narrowed list — an existing
      // voucher's customer can easily be outside that window, which would otherwise
      // leave the dropdown showing blank despite a real selection existing.
      const customerId = v.customerId;
      this.customers.update((opts) => (opts.some((o) => o.value === customerId) ? opts : [{ label: v.customerName, value: customerId }, ...opts]));
      this.cdr.markForCheck();
      this.data.getCustomerAddressBlock(v.customerId).subscribe((text) => this.customerDetails.set(text));
    });
  }

  // Bound to <p-select>'s (onFilter) — pushes into the debounced pipeline set
  // up in ngOnInit instead of calling the server directly on every keystroke.
  onCustomerFilter(query: string): void {
    this.customerFilter$.next(query);
  }

  onCustomerChange(): void {
    if (!this.customerId) {
      return;
    }
    this.data.getCustomerAddressBlock(this.customerId).subscribe((text) => this.customerDetails.set(text));
  }

  add(): void {
    this.mode = 'add';
    this.selectedVoucherNo = null;
    this.customerId = null;
    this.contactPerson = '';
    this.narration = '';
    this.amount = null;
    this.customerDetails.set('Customer Not Selected');
  }

  save(): void {
    if (!this.customerId || !this.narration.trim() || !this.amount) {
      alert('Please select customer, enter narration and advance amount.');
      return;
    }
    const customerName = this.customers().find((c) => c.value === this.customerId)?.label ?? '';
    this.saving.set(true);
    this.data
      .saveAdvance({ customerId: this.customerId, customerName, contactPerson: this.contactPerson, narration: this.narration, amount: this.amount })
      .subscribe({
        next: () => {
          this.saving.set(false);
          alert('Advance Inserted Successfully');
          this.mode = 'view';
          this.loadVoucherNumbers();
          this.loadLastAdvance();
          this.cancel();
          this.cdr.markForCheck();
        },
        // Previously silent on failure (no error callback) — the Save
        // button would stay stuck in its loading state with no feedback.
        error: () => {
          this.saving.set(false);
          alert('Could not save the advance voucher. Please try again.');
          this.cdr.markForCheck();
        }
      });
  }

  cancel(): void {
    this.mode = 'view';
    this.selectedVoucherNo = null;
    this.customerId = null;
    this.contactPerson = '';
    this.narration = '';
    this.amount = null;
    this.customerDetails.set('Customer Not Selected');
  }
}
