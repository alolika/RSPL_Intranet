import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { AdminDataService, CustTinFollowupRow } from '../admin-data.service';

/** Mirrors Section_Admin/CustTINFollowup.aspx: filterable grid with inline-editable TIN No / Email / Follow Up Remark. */
@Component({
  selector: 'app-cust-tin-followup',
  imports: [FormsModule, ButtonModule, InputTextModule, SelectModule, TableModule, DatePipe],
  templateUrl: './cust-tin-followup.html',
  styleUrl: './cust-tin-followup.scss'
})
export class CustTinFollowup implements OnInit {
  private readonly data = inject(AdminDataService);

  readonly salesmen = signal<string[]>([]);
  readonly software = signal<string[]>([]);
  readonly followupRemarks = signal<string[]>([]);
  readonly rows = signal<CustTinFollowupRow[]>([]);
  readonly loading = signal(false);

  salesman = '';
  softwareFilter = '';
  followupRemarkFilter = '';

  ngOnInit(): void {
    this.data.getCustTinFollowupFilters().subscribe((f) => {
      this.salesmen.set(f.salesmen);
      this.software.set(f.software);
      this.followupRemarks.set(f.followupRemarks);
    });
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.data
      .getCustTinFollowupRows({ software: this.softwareFilter, salesman: this.salesman, followupRemark: this.followupRemarkFilter })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      });
  }

  saveRow(row: CustTinFollowupRow): void {
    this.data.updateCustTin(row.custId, row.tinNo, row.email, row.followupRemark).subscribe(() => {
      alert('Customer details Modified successfully!');
    });
  }
}
