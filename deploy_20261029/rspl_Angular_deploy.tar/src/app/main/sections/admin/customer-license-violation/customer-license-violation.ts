import { DatePipe, DecimalPipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { AdminDataService, LicenseActionRow, LicenseModuleRow, LicenseViolationRow, LookupOption } from '../admin-data.service';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';

/**
 * Mirrors Section_Admin/CustomerLicenseViolation.aspx: a customer-filtered
 * grid of pirated-module revenue, with a per-row expandable detail panel
 * combining what the source split across two separate nested grids — the
 * module-level piracy drill-down (webproc_GetDrillDownCustLicenceVoilation)
 * and the enquiry-action next-step list (ActionStageID=28, same
 * Add/Close/Closed pattern as AmcPending/AmcCoordinatorDashboard). The
 * source's CustID link opens a small CustInfo.aspx RadWindow — routed to
 * the CustomerInfo page here instead.
 *
 * The source's rcbCustomer combo was dead code (commented out in
 * CustomerLicenseViolation.aspx.vb), so this previously stayed a single
 * "All" option rather than inventing a picker the legacy page never had.
 * A working Customer filter (Top 100 + search, same picker as
 * Advance/CustomerAns) was added on explicit request — the backend
 * endpoint already accepted a customer_id filter (get_license_violation_rows),
 * it just had no real picker feeding it.
 */
@Component({
  selector: 'app-customer-license-violation',
  imports: [FormsModule, RouterLink, ButtonModule, SelectModule, TableModule, DatePipe, DecimalPipe, IndianNumberPipe],
  templateUrl: './customer-license-violation.html',
  styleUrl: './customer-license-violation.scss'
})
export class CustomerLicenseViolation implements OnInit {
  private readonly data = inject(AdminDataService);
  private readonly router = inject(Router);

  readonly customerOptions = signal<LookupOption[]>([]);
  readonly rows = signal<LicenseViolationRow[]>([]);
  readonly loading = signal(false);
  readonly totalRevenue = signal(0);
  readonly errorMessage = signal('');
  readonly expandedCustId = signal<number | null>(null);
  readonly moduleDetail = signal<LicenseModuleRow[]>([]);
  readonly actionHistory = signal<LicenseActionRow[]>([]);
  readonly detailError = signal('');

  customerId: number | null = null;

  // Debounces the customer-search-as-you-type filter so it re-queries the
  // server once typing pauses, instead of firing one HTTP request per
  // keystroke (PrimeNG's p-select onFilter emits immediately, with no
  // built-in delay).
  private readonly customerFilter$ = new Subject<string>();

  ngOnInit(): void {
    this.data.getCustomers().subscribe((c) => this.customerOptions.set(c));
    this.show();

    this.customerFilter$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((query) => this.data.getCustomers(query))
      )
      .subscribe((c) => this.customerOptions.set(c));
  }

  // Bound to <p-select>'s (onFilter) — pushes into the debounced pipeline set
  // up in ngOnInit instead of calling the server directly on every keystroke.
  onCustomerFilter(query: string): void {
    this.customerFilter$.next(query);
  }

  show(): void {
    this.loading.set(true);
    this.errorMessage.set('');
    this.expandedCustId.set(null);
    this.data.getLicenseViolationRows(this.customerId).subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.totalRevenue.set(rows.reduce((sum, r) => sum + r.piracyAmt, 0));
        this.loading.set(false);
      },
      // This grid's data source (WebProc_GetCustVoilationDetails) depends on
      // a "[License]" linked server that isn't configured on this SQL
      // instance — a pre-existing infrastructure gap (see admin_customers.py's
      // module docstring), not something fixable from this form. Previously
      // this silently fell back to an empty grid on any failure, which is
      // indistinguishable from "this customer genuinely has no violations" —
      // surfacing the real reason so it doesn't read as data mysteriously
      // failing to load after picking a customer.
      error: () => {
        this.rows.set([]);
        this.totalRevenue.set(0);
        this.loading.set(false);
        this.errorMessage.set(
          'Could not load violation data. This report depends on a linked database server that is not currently configured — contact your database administrator.'
        );
      }
    });
  }

  toggleExpand(row: LicenseViolationRow): void {
    if (this.expandedCustId() === row.custId) {
      this.expandedCustId.set(null);
      return;
    }
    this.expandedCustId.set(row.custId);
    this.detailError.set('');
    this.data.getLicenseViolationModules(row.custId).subscribe({
      next: (rows) => this.moduleDetail.set(rows),
      error: () => {
        this.moduleDetail.set([]);
        this.detailError.set('Could not load module detail — the linked data source required for this drill-down is unavailable.');
      }
    });
    this.data.getLicenseViolationActions(row.custId).subscribe({
      next: (rows) => this.actionHistory.set(rows),
      error: () => this.actionHistory.set([])
    });
  }

  nextStep(row: LicenseViolationRow, action: LicenseActionRow): void {
    if (action.nextAction === 'Closed') {
      return;
    }
    this.router.navigate(['/marketing/cust-enquiry-action'], {
      queryParams: {
        ActionStageID: 28,
        FromAMCPending: 0,
        CustID: row.custId,
        RefActionID: action.actionId,
        ActionType: action.nextAction === 'Add' ? 1 : 2
      }
    });
  }
}
