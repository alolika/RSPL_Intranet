import { Location } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, inject, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { AdminDataService } from '../admin-data.service';

export interface CrmReviewDetailParams {
  actionStageName: string;
  executiveName: string;
  userId: number;
  fromDate: Date | null;
  toDate: Date | null;
}

/**
 * Mirrors Section_Admin/CRMReviewdetail.aspx: dynamic-column drill-down grid
 * launched from CRMReview's per-column links. Embedded as a dialog by the
 * parent (via [params]/(closeRequested)) instead of a routed navigation —
 * navigating away and Location.back()-ing on close previously destroyed and
 * recreated CrmReview, resetting its filters/rows/scroll position every
 * single time a drill-down was closed. The route-param path below is kept
 * only as a fallback for direct navigation, but the parent no longer uses it.
 */
@Component({
  selector: 'app-crm-review-detail',
  imports: [ButtonModule, TableModule],
  templateUrl: './crm-review-detail.html',
  styleUrl: './crm-review-detail.scss'
})
export class CrmReviewDetail implements OnInit, OnChanges {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(AdminDataService);
  private readonly location = inject(Location);

  @Input() params: CrmReviewDetailParams | null = null;
  @Output() readonly closeRequested = new EventEmitter<void>();

  readonly heading = signal('');
  readonly columns = signal<string[]>([]);
  readonly rows = signal<Record<string, unknown>[]>([]);

  ngOnInit(): void {
    if (this.params) {
      this.load(this.params);
      return;
    }
    // Launched repeatedly from CRMReview's per-column links with different
    // params each time — Angular reuses this component instance rather than
    // re-running ngOnInit, so a one-time snapshot read would keep showing
    // the first drill-down clicked. Subscribing re-runs this on every visit.
    this.route.queryParamMap.subscribe((q) => {
      const fromDateStr = q.get('FromDate');
      const toDateStr = q.get('ToDate');
      this.load({
        actionStageName: q.get('ActionStageName') ?? '',
        executiveName: q.get('ExecutiveName') ?? '',
        userId: Number(q.get('User') ?? 0),
        fromDate: fromDateStr ? new Date(fromDateStr) : null,
        toDate: toDateStr ? new Date(toDateStr) : null
      });
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.params && changes['params'] && !changes['params'].firstChange) {
      this.load(this.params);
    }
  }

  private load(p: CrmReviewDetailParams): void {
    this.heading.set(`CRM Review detail  - ${p.actionStageName} By ${p.executiveName}`);
    this.data.getCrmReviewDetailRows(p.actionStageName, p.userId, p.fromDate, p.toDate).subscribe((res) => {
      this.columns.set(res.columns);
      this.rows.set(res.rows);
    });
  }

  export(): void {
    exportToExcel('CRMReviewDetail', this.rows());
  }

  close(): void {
    if (this.params) {
      this.closeRequested.emit();
      return;
    }
    this.location.back();
  }
}
