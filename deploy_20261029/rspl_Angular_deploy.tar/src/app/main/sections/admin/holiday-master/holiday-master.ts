import { DatePipe } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { TableModule } from 'primeng/table';
import { TooltipModule } from 'primeng/tooltip';

import { FORM_HOLIDAY_MASTER, UserRightsService } from '../../../../core/auth/user-rights.service';
import { AdminDataService, HolidayRow } from '../admin-data.service';

function toIsoDate(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * New "Holiday Master" admin page (Accounts menu) — manages the
 * RSPL_HolidayMaster table that the main dashboard's Holiday List tile now
 * reads from (see dashboard-data.service.ts). Day is always derived
 * server-side from the picked date, so it's shown read-only here rather
 * than editable.
 */
@Component({
  selector: 'app-holiday-master',
  imports: [FormsModule, ButtonModule, DatePickerModule, InputTextModule, MessageModule, TableModule, TooltipModule, DatePipe],
  templateUrl: './holiday-master.html',
  styleUrl: './holiday-master.scss'
})
export class HolidayMaster implements OnInit {
  private readonly data = inject(AdminDataService);
  private readonly rights = inject(UserRightsService);

  readonly canEdit = computed(() => this.rights.canEdit(FORM_HOLIDAY_MASTER));

  readonly rows = signal<HolidayRow[]>([]);
  readonly loading = signal(false);
  readonly saving = signal(false);
  readonly errorMessage = signal<string | null>(null);
  readonly savingTitle = signal(false);

  editingId: number | null = null;
  holidayDate: Date | null = null;
  toDate: Date | null = null;
  event = '';
  listTitle = '';

  ngOnInit(): void {
    this.refresh();
    this.data.getHolidayListTitle().subscribe({
      next: (name) => (this.listTitle = name),
      error: () => this.errorMessage.set('Could not load the dashboard title. Please try again.')
    });
  }

  saveTitle(): void {
    if (!this.canEdit() || !this.listTitle.trim()) {
      return;
    }
    this.savingTitle.set(true);
    this.data.setHolidayListTitle(this.listTitle.trim()).subscribe({
      next: (name) => {
        this.listTitle = name;
        this.savingTitle.set(false);
      },
      error: () => {
        this.savingTitle.set(false);
        this.errorMessage.set('Could not save the dashboard title. Please try again.');
      }
    });
  }

  refresh(): void {
    this.loading.set(true);
    this.errorMessage.set(null);
    this.data.getHolidays().subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
        this.errorMessage.set('Could not load the holiday list. Please try again.');
      }
    });
  }

  // Bound to the From Date picker — defaults To Date to match it whenever
  // To Date hasn't been set yet, or is now earlier than the new From Date.
  // Keeps the common single-day case a one-click pick instead of forcing
  // the same date to be selected twice, while never silently overwriting
  // a To Date the user already deliberately chose further out.
  onFromDateChange(): void {
    if (this.holidayDate && (!this.toDate || this.toDate < this.holidayDate)) {
      this.toDate = this.holidayDate;
    }
  }

  edit(row: HolidayRow): void {
    this.editingId = row.holidayId;
    this.holidayDate = new Date(row.holidayDate);
    this.toDate = new Date(row.toDate);
    this.event = row.event;
  }

  cancelEdit(): void {
    this.editingId = null;
    this.holidayDate = null;
    this.toDate = null;
    this.event = '';
  }

  submit(): void {
    if (!this.canEdit() || !this.holidayDate || !this.toDate || !this.event.trim()) {
      return;
    }
    if (this.toDate < this.holidayDate) {
      this.errorMessage.set('To Date cannot be earlier than From Date.');
      return;
    }
    this.saving.set(true);
    this.errorMessage.set(null);
    const isoFromDate = toIsoDate(this.holidayDate);
    const isoToDate = toIsoDate(this.toDate);
    const request$ = this.editingId
      ? this.data.updateHoliday(this.editingId, isoFromDate, isoToDate, this.event.trim())
      : this.data.addHoliday(isoFromDate, isoToDate, this.event.trim());
    request$.subscribe({
      next: () => {
        this.saving.set(false);
        this.cancelEdit();
        this.refresh();
      },
      error: () => {
        this.saving.set(false);
        this.errorMessage.set('Could not save this holiday. Please try again.');
      }
    });
  }

  toggleStatus(row: HolidayRow): void {
    if (!this.canEdit()) {
      return;
    }
    const nextEnabled = !row.enabled;
    if (nextEnabled === false && !confirm(`Mark "${row.event}" (${row.holidayDate}) as Inactive? It will drop off the dashboard.`)) {
      return;
    }
    this.data.setHolidayStatus(row.holidayId, nextEnabled).subscribe({
      next: () => this.refresh(),
      error: () => this.errorMessage.set('Could not update this holiday\'s status. Please try again.')
    });
  }
}
