import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { TableModule } from 'primeng/table';

import { AdminDataService, FeedbackRow } from '../admin-data.service';

/** Mirrors Section_Admin/FeedbackRegister.aspx ("Suggestion Register"): unfiltered read grid of web_feedback. */
@Component({
  selector: 'app-feedback-register',
  imports: [TableModule, DatePipe],
  templateUrl: './feedback-register.html',
  styleUrl: './feedback-register.scss'
})
export class FeedbackRegister implements OnInit {
  private readonly data = inject(AdminDataService);

  readonly rows = signal<FeedbackRow[]>([]);

  ngOnInit(): void {
    this.data.getFeedbackRows().subscribe((rows) => this.rows.set(rows));
  }
}
