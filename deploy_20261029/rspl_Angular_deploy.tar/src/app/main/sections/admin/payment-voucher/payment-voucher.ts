import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { InputNumberModule } from 'primeng/inputnumber';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';

import { AdminDataService, LookupOption } from '../admin-data.service';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';

/**
 * Mirrors Section_Admin/PaymentVoucher.aspx: shared page for both "Payment
 * Voucher" and "Prepayment Voucher" (switched via ?IsPaymentVoucher=), New/
 * Select toggle, debit/credit account, paid-to/payment-for, and a print
 * preview — same pattern as Advance.aspx. "Add Tag" navigates to AddTag
 * with the voucher number as a query param (the source used
 * Session("VoucherNo") for this handoff).
 */
@Component({
  selector: 'app-payment-voucher',
  imports: [FormsModule, ButtonModule, SelectModule, TextareaModule, InputNumberModule, DatePipe, IndianNumberPipe],
  templateUrl: './payment-voucher.html',
  styleUrl: './payment-voucher.scss'
})
export class PaymentVoucher implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(AdminDataService);
  private readonly router = inject(Router);
  // No zone.js in this app — plain (non-signal) properties like
  // `isPaymentVoucher`/`date`/`paidTo`/`paymentFor`/`amount`/`mode` below
  // don't trigger a re-render when mutated inside an RxJS subscribe callback.
  private readonly cdr = inject(ChangeDetectorRef);

  isPaymentVoucher = true;
  readonly voucherType = signal('Payment Voucher');

  readonly voucherNumbers = signal<LookupOption[]>([]);
  readonly debitAccounts = signal<LookupOption[]>([]);
  readonly creditAccounts = signal<LookupOption[]>([]);
  readonly saving = signal(false);
  readonly showPrint = signal(false);
  readonly printData = signal<{ voucherNo: number; date: string; account: string; through: string; onAccountOf: string; amount: number } | null>(null);

  mode: 'view' | 'add' = 'view';
  selectedVoucherNo: number | null = null;
  date = new Date().toISOString();
  debitAccountId: number | null = null;
  creditAccountId: number | null = null;
  paidTo = '';
  paymentFor = '';
  amount: number | null = null;

  ngOnInit(): void {
    this.data.getAccountOptions().subscribe((a) => this.debitAccounts.set(a));
    this.data.getBankOptions().subscribe((b) => this.creditAccounts.set(b));

    // Payment Voucher and Prepayment Voucher both route to this same
    // component (only ?IsPaymentVoucher differs) — subscribe rather than
    // reading a one-time snapshot so switching between them while mounted
    // actually updates instead of keeping the previous voucher type/list.
    this.route.queryParamMap.subscribe((q) => {
      this.isPaymentVoucher = q.get('IsPaymentVoucher') === '1';
      this.voucherType.set(this.isPaymentVoucher ? 'Payment Voucher' : 'Prepayment Voucher');
      this.cancel();
      this.loadVoucherNumbers();
      this.cdr.markForCheck();
    });
  }

  private loadVoucherNumbers(): void {
    this.data.getPaymentVoucherNumbers(this.isPaymentVoucher).subscribe((v) => this.voucherNumbers.set(v));
  }

  onVoucherSelected(): void {
    if (!this.selectedVoucherNo) {
      return;
    }
    this.data.getPaymentVoucher(this.selectedVoucherNo, this.isPaymentVoucher).subscribe({
      next: (v) => {
        if (!v) {
          return;
        }
        this.date = v.date;
        this.paidTo = v.paidTo;
        this.paymentFor = v.paymentFor;
        this.amount = v.amount;
        this.debitAccountId = v.debitAccountId;
        this.creditAccountId = v.creditAccountId;
        // Both lists are scoped to the current user's Rspl_UserWiseLedger
        // assignment — a saved voucher's account can easily fall outside
        // that scoped list, which would otherwise leave the dropdown
        // showing blank despite a real selection existing.
        const debitAccountId = v.debitAccountId;
        this.debitAccounts.update((opts) =>
          opts.some((o) => o.value === debitAccountId) ? opts : [{ label: v.debitAccount, value: debitAccountId }, ...opts]
        );
        const creditAccountId = v.creditAccountId;
        this.creditAccounts.update((opts) =>
          opts.some((o) => o.value === creditAccountId) ? opts : [{ label: v.creditAccount, value: creditAccountId }, ...opts]
        );
        this.cdr.markForCheck();
      },
      error: () => alert('Could not load this voucher. Please try again.')
    });
  }

  add(): void {
    this.mode = 'add';
    this.selectedVoucherNo = null;
    this.date = new Date().toISOString();
    this.debitAccountId = null;
    this.creditAccountId = null;
    this.paidTo = '';
    this.paymentFor = '';
    this.amount = null;
    this.showPrint.set(false);
  }

  save(): void {
    if (!this.debitAccountId || !this.creditAccountId || !this.paidTo.trim() || !this.paymentFor.trim() || !this.amount) {
      alert('Please fill Debit Account, Credit Account, Paid To, Payment For and Amount.');
      return;
    }
    if (this.paidTo.includes("'") || this.paymentFor.includes("'")) {
      alert('Special characters are not allowed.');
      return;
    }
    const debitAccount = this.debitAccounts().find((a) => a.value === this.debitAccountId)?.label ?? '';
    const creditAccount = this.creditAccounts().find((a) => a.value === this.creditAccountId)?.label ?? '';
    this.saving.set(true);
    this.data
      .savePaymentVoucher({
        isPaymentVoucher: this.isPaymentVoucher,
        date: new Date().toISOString(),
        debitAccount,
        debitAccountId: this.debitAccountId ?? 0,
        creditAccount,
        creditAccountId: this.creditAccountId ?? 0,
        paidTo: this.paidTo,
        paymentFor: this.paymentFor,
        amount: this.amount
      })
      .subscribe({
        next: (res) => {
          this.saving.set(false);
          alert(res.message);
          this.printData.set({ voucherNo: res.voucherNo, date: new Date().toISOString(), account: debitAccount, through: creditAccount, onAccountOf: this.paymentFor, amount: this.amount ?? 0 });
          this.showPrint.set(true);
          this.loadVoucherNumbers();
          this.cancel();
          this.cdr.markForCheck();
        },
        // Previously silent on failure (no error callback) — confirmed live
        // this endpoint 500'd on every single save before being fixed (a
        // column-name case mismatch, "ResultMsg" vs the proc's actual
        // "Resultmsg" — see admin_vouchers.py), and the Save button would
        // just stay stuck in its loading state with zero indication anything
        // was wrong.
        error: () => {
          this.saving.set(false);
          alert('Could not save the voucher. Please try again.');
          this.cdr.markForCheck();
        }
      });
  }

  print(): void {
    if (confirm('Do you want to Print Voucher?')) {
      window.print();
    }
  }

  addTag(): void {
    if (!this.selectedVoucherNo) {
      alert('Please select Voucher no.');
      return;
    }
    this.router.navigate(['/admin/add-tag'], { queryParams: { VoucherNo: this.selectedVoucherNo } });
  }

  cancel(): void {
    this.mode = 'view';
    this.selectedVoucherNo = null;
    this.date = new Date().toISOString();
    this.debitAccountId = null;
    this.creditAccountId = null;
    this.paidTo = '';
    this.paymentFor = '';
    this.amount = null;
  }
}
