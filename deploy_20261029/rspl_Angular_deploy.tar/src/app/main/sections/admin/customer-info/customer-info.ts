import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { AdminDataService, CustomerInfoRow } from '../admin-data.service';

/** Mirrors Section_Admin/CustomerInfo.aspx: a small read-only customer-detail popup, launched from CustLedger's customer-name link. */
@Component({
  selector: 'app-customer-info',
  imports: [],
  templateUrl: './customer-info.html',
  styleUrl: './customer-info.scss'
})
export class CustomerInfo implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(AdminDataService);

  readonly info = signal<CustomerInfoRow | null>(null);

  ngOnInit(): void {
    // Launched repeatedly from CustLedger's customer-name links with a
    // different ?CustID each time — subscribe rather than reading a
    // one-time snapshot so opening a different customer while already
    // mounted actually reloads instead of showing stale info.
    this.route.queryParamMap.subscribe((q) => {
      const custId = Number(q.get('CustID') ?? 0);
      this.data.getCustomerInfo(custId).subscribe((info) => this.info.set(info));
    });
  }
}
