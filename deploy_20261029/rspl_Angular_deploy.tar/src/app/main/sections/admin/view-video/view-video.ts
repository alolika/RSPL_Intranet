import { Location } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';

/** Mirrors ViewVideo.aspx: plays a single video by URL, launched from AddVideos' "Play Video" button. */
@Component({
  selector: 'app-view-video',
  imports: [ButtonModule],
  templateUrl: './view-video.html',
  styleUrl: './view-video.scss'
})
export class ViewVideo implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly location = inject(Location);

  readonly videoUrl = signal('');

  ngOnInit(): void {
    // Launched repeatedly from AddVideos' "Play Video" buttons with a
    // different ?URL each time — subscribe rather than reading a one-time
    // snapshot so playing a different video while already mounted actually
    // switches instead of keeping the previous video's URL.
    this.route.queryParamMap.subscribe((q) => {
      this.videoUrl.set(q.get('URL') ?? '');
    });
  }

  close(): void {
    this.location.back();
  }
}
