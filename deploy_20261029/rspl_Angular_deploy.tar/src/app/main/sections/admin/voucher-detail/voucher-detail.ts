import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TableModule } from 'primeng/table';

import { AdminDataService, OutstandingVoucherRow } from '../admin-data.service';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';

/** Mirrors Section_Admin/VoucherDetail.aspx: outstanding-bills popup for a customer, launched from LedgerBalance (?CustID=). */
@Component({
  selector: 'app-voucher-detail',
  imports: [TableModule, DatePipe, IndianNumberPipe],
  templateUrl: './voucher-detail.html',
  styleUrl: './voucher-detail.scss'
})
export class VoucherDetail implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(AdminDataService);

  readonly rows = signal<OutstandingVoucherRow[]>([]);

  ngOnInit(): void {
    // Launched repeatedly from LedgerBalance's rows with a different
    // ?CustID each time — subscribe rather than reading a one-time snapshot
    // so opening this for a different customer while already mounted
    // actually reloads instead of showing the previous customer's vouchers.
    this.route.queryParamMap.subscribe((q) => {
      const custId = Number(q.get('CustID') ?? 0);
      this.data.getOutstandingVouchers(custId).subscribe((rows) => this.rows.set(rows));
    });
  }
}
