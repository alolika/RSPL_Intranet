import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { AdminDataService, GracePeriodRow, LookupOption } from '../admin-data.service';

/** Mirrors Section_Admin/CustomerGracePeriod.aspx: software-filtered grid of customers past AMC due date with a grace remark. */
@Component({
  selector: 'app-customer-grace-period',
  imports: [FormsModule, ButtonModule, SelectModule, TableModule, DatePipe],
  templateUrl: './customer-grace-period.html',
  styleUrl: './customer-grace-period.scss'
})
export class CustomerGracePeriod implements OnInit {
  private readonly data = inject(AdminDataService);

  readonly software = signal<LookupOption[]>([{ label: 'All', value: 0 }]);
  readonly rows = signal<GracePeriodRow[]>([]);
  readonly loading = signal(false);
  readonly errorMessage = signal('');

  softwareId: number | null = null;

  ngOnInit(): void {
    // Both this list and the rows grid below depend on vw_web_softwaremaster/
    // vw_web_AMCGracePeriodCustomer, which read from two separate linked
    // servers not configured on this SQL instance (see admin_customers.py's
    // module docstring) — unlike Advance/CustomerAns's customer picker, there
    // is no local table to fall back to here, so this can come back empty.
    // Falling back to just "All" on failure (instead of leaving the dropdown
    // with nothing at all, which is what happened before with no error
    // handler here).
    this.data.getGracePeriodSoftware().subscribe({
      next: (s) => this.software.set([{ label: 'All', value: 0 }, ...s]),
      error: () => this.software.set([{ label: 'All', value: 0 }])
    });
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.errorMessage.set('');
    this.data.getGracePeriodRows(this.softwareId).subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      // Previously silent on failure (no error callback) — the loading
      // spinner would spin forever instead of settling on an empty grid,
      // indistinguishable from "no customers in their grace period".
      error: () => {
        this.rows.set([]);
        this.loading.set(false);
        this.errorMessage.set(
          'Could not load grace period data. This report depends on linked database servers that are not currently configured — contact your database administrator.'
        );
      }
    });
  }
}
