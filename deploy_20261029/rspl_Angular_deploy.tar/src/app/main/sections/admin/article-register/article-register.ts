import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { AdminDataService, ArticleRow, LookupOption } from '../admin-data.service';

/** Mirrors Section_Admin/ArticleRegister.aspx: category-filtered grid of published articles. */
@Component({
  selector: 'app-article-register',
  imports: [FormsModule, SelectModule, TableModule, DatePipe],
  templateUrl: './article-register.html',
  styleUrl: './article-register.scss'
})
export class ArticleRegister implements OnInit {
  private readonly data = inject(AdminDataService);

  readonly categories = signal<LookupOption[]>([{ label: 'ALL', value: 0 }]);
  readonly rows = signal<ArticleRow[]>([]);
  readonly loading = signal(false);

  categoryId = 0;

  ngOnInit(): void {
    this.data.getArticleCategories().subscribe((categories) => this.categories.set([{ label: 'ALL', value: 0 }, ...categories]));
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.data.getArticleRegisterRows(this.categoryId || null).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }
}
