import { ChangeDetectorRef, Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { MessageModule } from 'primeng/message';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { forkJoin } from 'rxjs';

import { AccessLevel, RightsFormOption, RightsRow, RightsUserOption, UserRightsService } from '../../../../core/auth/user-rights.service';

interface FormLevelSelection {
  formCode: string;
  formLabel: string;
  level: AccessLevel | 'default';
}

/**
 * New admin-only page — assigns per-user Can View / Can Edit / No Access
 * rights for Executive Schedule, Holiday Master, and Call History Report
 * (see app/rights.py for the backend design). Reachable only by the fixed
 * rights-admin allow-list (UserRightsService.isRightsAdmin()); every backend
 * endpoint this page calls independently 403s anyone else, so hiding the
 * form here is a convenience, not the actual security boundary.
 *
 * "Currently Restricted" only lists users with an explicit
 * RSPL_UserFormRights row — everyone else defaults to Can Edit on all 3
 * forms and simply doesn't appear, matching the rollout decision that
 * nobody loses access until an admin explicitly dials them back.
 */
@Component({
  selector: 'app-user-rights',
  imports: [FormsModule, ButtonModule, MessageModule, SelectModule, TableModule],
  templateUrl: './user-rights.html',
  styleUrl: './user-rights.scss'
})
export class UserRights implements OnInit {
  private readonly rights = inject(UserRightsService);
  // No zone.js in this app — refresh()'s subscribe() callback below mutates
  // `selections` (a plain property, via onUserSelected()) asynchronously,
  // after the triggering event has already finished, so it needs an
  // explicit markForCheck() to actually show up (same pattern as
  // cust-registration.ts's loadCustomer()).
  private readonly cdr = inject(ChangeDetectorRef);

  readonly isAuthorized = this.rights.isRightsAdmin();

  readonly forms = signal<RightsFormOption[]>([]);
  readonly users = signal<RightsUserOption[]>([]);
  readonly rows = signal<RightsRow[]>([]);
  readonly loading = signal(false);
  readonly saving = signal(false);
  readonly errorMessage = signal<string | null>(null);

  readonly levelOptions: { label: string; value: AccessLevel | 'default' }[] = [
    { label: 'Default (Can Edit)', value: 'default' },
    { label: 'Can View', value: 'view' },
    { label: 'Can Edit', value: 'edit' },
    { label: 'No Access', value: 'none' }
  ];

  // A signal (not a plain property) specifically so selectedUserDisplayLabel
  // below can react to it — computed() only re-evaluates on signal reads.
  readonly selectedUserId = signal<number | null>(null);
  selections: FormLevelSelection[] = [];

  readonly selectedUserDisplayLabel = computed(() => this.users().find((u) => u.userId === this.selectedUserId())?.displayLabel ?? '');

  ngOnInit(): void {
    if (!this.isAuthorized) {
      return;
    }
    this.refresh();
  }

  refresh(): void {
    this.loading.set(true);
    this.errorMessage.set(null);
    this.rights.getAdminForms().subscribe({
      next: (forms) => this.forms.set(forms),
      error: () => this.errorMessage.set('Could not load the form list. Please try again.')
    });
    this.rights.getAdminUsers().subscribe({
      next: (users) => this.users.set(users),
      error: () => this.errorMessage.set('Could not load the user list. Please try again.')
    });
    this.rights.getAdminRights().subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
        if (this.selectedUserId()) {
          this.onUserSelected();
        }
        // This whole callback runs asynchronously, after the triggering
        // event (page load, or the Save button click that called refresh())
        // has already finished — `selections` is a plain property mutated
        // above via onUserSelected(), so without this the form silently
        // keeps showing the pre-save values even though the save succeeded.
        this.cdr.markForCheck();
      },
      error: () => {
        this.loading.set(false);
        this.errorMessage.set('Could not load user rights. Please try again.');
      }
    });
  }

  onUserSelected(): void {
    const existing = this.rows().filter((r) => r.userId === this.selectedUserId());
    this.selections = this.forms().map((f) => {
      const match = existing.find((r) => r.formCode === f.code);
      return { formCode: f.code, formLabel: f.label, level: match ? match.accessLevel : 'default' };
    });
  }

  saveSelections(): void {
    const userId = this.selectedUserId();
    if (!userId || !this.selections.length) {
      return;
    }
    this.saving.set(true);
    this.errorMessage.set(null);
    const calls = this.selections.map((sel) =>
      sel.level === 'default' ? this.rights.resetAdminRight(userId, sel.formCode) : this.rights.setAdminRight(userId, sel.formCode, sel.level)
    );
    forkJoin(calls).subscribe({
      next: () => {
        this.saving.set(false);
        this.refresh();
      },
      error: () => {
        this.saving.set(false);
        this.errorMessage.set('Could not save changes. Please try again.');
      }
    });
  }

  resetOne(row: RightsRow): void {
    this.rights.resetAdminRight(row.userId, row.formCode).subscribe({
      next: () => this.refresh(),
      error: () => this.errorMessage.set('Could not reset this right. Please try again.')
    });
  }
}
