import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { AdminDataService, CustomerAnsRow, LookupOption } from '../admin-data.service';

/** Mirrors Section_Admin/CustomerAns.aspx: filterable grid of client survey answers (vw_web_clientAnswerSheet). */
@Component({
  selector: 'app-customer-ans',
  imports: [FormsModule, ButtonModule, SelectModule, TableModule, DatePipe],
  templateUrl: './customer-ans.html',
  styleUrl: './customer-ans.scss'
})
export class CustomerAns implements OnInit {
  private readonly data = inject(AdminDataService);

  readonly customerOptions = signal<LookupOption[]>([]);
  readonly questions = signal<string[]>([]);
  readonly rows = signal<CustomerAnsRow[]>([]);
  readonly loading = signal(false);

  customerId: number | null = null;
  question = '';

  // Debounces the customer-search-as-you-type filter so it re-queries the
  // server once typing pauses, instead of firing one HTTP request per
  // keystroke (PrimeNG's p-select onFilter emits immediately, with no
  // built-in delay).
  private readonly customerFilter$ = new Subject<string>();

  ngOnInit(): void {
    this.data.getCustomerAnsFilters().subscribe((f) => this.questions.set(f.questions));
    this.data.getCustomers().subscribe((c) => this.customerOptions.set(c));

    this.customerFilter$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((query) => this.data.getCustomers(query))
      )
      .subscribe((c) => this.customerOptions.set(c));
  }

  // Bound to <p-select>'s (onFilter) — pushes into the debounced pipeline set
  // up in ngOnInit instead of calling the server directly on every keystroke.
  onCustomerFilter(query: string): void {
    this.customerFilter$.next(query);
  }

  show(): void {
    this.loading.set(true);
    this.data.getCustomerAnsRows({ customerId: this.customerId, question: this.question }).subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      // Previously silent on failure (no error callback) — the loading
      // spinner would spin forever instead of settling on an empty grid.
      error: () => {
        this.rows.set([]);
        this.loading.set(false);
      }
    });
  }
}
