import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { AdminDataService, LookupOption } from '../admin-data.service';

/** Mirrors Section_Admin/MyCallerHistory.aspx: user + date-range filtered mobile call-history grid (auto-generated columns in source). */
@Component({
  selector: 'app-my-caller-history',
  imports: [FormsModule, ButtonModule, DatePickerModule, SelectModule, TableModule],
  templateUrl: './my-caller-history.html',
  styleUrl: './my-caller-history.scss'
})
export class MyCallerHistory implements OnInit {
  private readonly data = inject(AdminDataService);

  readonly users = signal<LookupOption[]>([]);
  readonly columns = signal<string[]>([]);
  readonly rows = signal<Record<string, unknown>[]>([]);
  readonly loading = signal(false);

  userId: number | null = null;
  fromDate: Date | null = new Date();
  toDate: Date | null = new Date();

  // Columns are server-driven (dynamic), so numeric alignment is computed
  // generically rather than hardcoded per column name: a column is "numeric"
  // only if every row's value for it looks numeric (or is absent) — the
  // moment any row holds a real non-numeric string there, it's treated as
  // text instead. "Looks numeric" also covers digit-only strings, not just
  // the JS `number` type — MobileNo comes back from the proc as a string
  // like '+919372151855' (it needs the leading + preserved), which is
  // conceptually numeric but would never satisfy a strict `typeof === 'number'`
  // check.
  private readonly numericColumns = computed<Set<string>>(() => {
    const result = new Set<string>();
    for (const col of this.columns()) {
      let hasNumber = false;
      let hasText = false;
      for (const row of this.rows()) {
        const v = row[col];
        if (v === null || v === undefined) {
          continue;
        }
        if (this.looksNumeric(v)) {
          hasNumber = true;
        } else {
          hasText = true;
          break;
        }
      }
      if (hasNumber && !hasText) {
        result.add(col);
      }
    }
    return result;
  });

  private looksNumeric(v: unknown): boolean {
    if (typeof v === 'number') {
      return true;
    }
    if (typeof v === 'string') {
      const trimmed = v.trim();
      return trimmed !== '' && /^[+-]?\d+(\.\d+)?$/.test(trimmed);
    }
    return false;
  }

  ngOnInit(): void {
    this.data.getMyCallerUsers().subscribe((u) => this.users.set(u));
  }

  isNumericColumn(col: string): boolean {
    return this.numericColumns().has(col);
  }

  show(): void {
    if (!this.userId) {
      return;
    }
    this.loading.set(true);
    this.data.getMyCallerHistory(this.userId, this.fromDate, this.toDate).subscribe((res) => {
      this.columns.set(res.columns);
      this.rows.set(res.rows);
      this.loading.set(false);
    });
  }
}
