import { ChangeDetectorRef, Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

import { AdminDataService, VideoModuleOption, VideoRow } from '../admin-data.service';

/**
 * Mirrors Section_Admin's Videos.aspx (menu labels: "Add Videos" with
 * ?Add=1 showing the add form + inline-editable grid, "Training Videos"
 * list mode with ?Add=0 hiding the add form and edit column — read-only
 * browsing). The FTP-upload code path in the source is fully commented
 * out (dead code, never wired to a control) — not carried forward. The
 * inline "Create Module"/"Save Module" toggle link is preserved as a
 * simplified prompt-free inline text input + button.
 *
 * Two real fixes made here:
 * - The "Module" search filter was rendered but never actually bound to
 *   anything — no `[(ngModel)]`, and neither the frontend nor the backend
 *   (nor, checked against the legacy source, the *original* ASP.NET page
 *   either) ever passed it into the search. It looked like a working
 *   filter and silently did nothing. Since module filtering is otherwise
 *   unsupported server-side, it's now applied client-side over the
 *   already-fetched rows — correct and effectively instant given this
 *   list is under 100 rows. (VideoModuleMaster is genuinely empty in
 *   production today, so this has no visible effect until modules exist,
 *   but the control now does what it visually claims to.)
 * - "Play Video" navigated to a whole separate route, losing the current
 *   search/scroll state and paying full router-navigation overhead just
 *   to show a <video> tag. Replaced with an inline dialog — same player,
 *   opens instantly, list stays exactly as it was underneath.
 */
@Component({
  selector: 'app-add-videos',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, SelectModule, TableModule, TextareaModule, DialogModule, MessageModule],
  templateUrl: './add-videos.html',
  styleUrl: './add-videos.scss'
})
export class AddVideos implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(AdminDataService);
  // No zone.js in this app — plain (non-signal) properties like `addMode`/
  // `name`/`description`/`videoUrl`/`disabled` below don't trigger a
  // re-render when mutated inside an RxJS subscribe callback.
  private readonly cdr = inject(ChangeDetectorRef);

  addMode = true;
  readonly modules = signal<VideoModuleOption[]>([]);
  readonly rows = signal<VideoRow[]>([]);
  readonly loading = signal(false);
  readonly saving = signal(false);
  readonly creatingModule = signal(false);
  readonly loadError = signal<string | null>(null);
  readonly formMessage = signal<string | null>(null);

  readonly playingVideoUrl = signal<string | null>(null);
  readonly playingVideoName = signal('');

  name = '';
  description = '';
  moduleName = '';
  videoUrl = 'https://opas.retailindia.in/Videos/';
  disabled = false;
  newModuleName = '';

  searchText = '';
  moduleFilter: string | null = null;

  readonly filteredRows = computed(() => {
    if (!this.moduleFilter) {
      return this.rows();
    }
    return this.rows().filter((r) => r.module === this.moduleFilter);
  });

  private readonly searchInput$ = new Subject<string>();

  ngOnInit(): void {
    this.data.getVideoModules().subscribe({
      next: (m) => this.modules.set(m),
      error: () => this.loadError.set('Could not load video modules.')
    });
    this.search();

    // Debounced live search as the user types, in addition to the explicit
    // Show button for anyone who prefers that — same pattern used by every
    // other search box in this app.
    this.searchInput$.pipe(debounceTime(300), distinctUntilChanged()).subscribe(() => this.search());

    // "Add Videos" and "Training Videos" (list mode) both route to this
    // same component (only ?Add differs) — subscribe rather than reading a
    // one-time snapshot so switching between them while mounted updates.
    this.route.queryParamMap.subscribe((q) => {
      this.addMode = q.get('Add') !== '0';
      this.cdr.markForCheck();
    });
  }

  onSearchInput(): void {
    this.searchInput$.next(this.searchText);
  }

  search(): void {
    this.loading.set(true);
    this.loadError.set(null);
    this.data.getVideos(this.searchText).subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
        this.loadError.set('Could not load videos. Please try again.');
      }
    });
  }

  toggleCreateModule(): void {
    if (this.creatingModule()) {
      if (this.newModuleName.trim()) {
        this.data.addVideoModule(this.newModuleName.trim()).subscribe({
          next: () => this.data.getVideoModules().subscribe((m) => this.modules.set(m)),
          error: () => this.formMessage.set('Could not create the module. Please try again.')
        });
      }
      this.creatingModule.set(false);
      this.newModuleName = '';
    } else {
      this.creatingModule.set(true);
    }
  }

  submit(): void {
    if (!this.name.trim()) {
      this.formMessage.set('Please enter a video name.');
      return;
    }
    this.formMessage.set(null);
    this.saving.set(true);
    this.data
      .saveVideo(0, { name: this.name, details: this.description, videoUrl: this.videoUrl, disabled: this.disabled, moduleName: this.moduleName })
      .subscribe({
        next: (res) => {
          this.saving.set(false);
          this.formMessage.set(res.message);
          this.name = '';
          this.description = '';
          this.videoUrl = 'https://opas.retailindia.in/Videos/';
          this.disabled = false;
          this.cdr.markForCheck();
          this.search();
        },
        error: () => {
          this.saving.set(false);
          this.formMessage.set('Could not save the video. Please try again.');
        }
      });
  }

  saveRow(row: VideoRow): void {
    this.data
      .saveVideo(row.id, { name: row.name, details: row.details, videoUrl: row.videoUrl, disabled: row.disabled, moduleName: row.module })
      .subscribe({
        next: (res) => this.formMessage.set(res.message),
        error: () => this.formMessage.set('Could not update the video. Please try again.')
      });
  }

  play(row: VideoRow): void {
    this.playingVideoName.set(row.name);
    this.playingVideoUrl.set(row.videoUrl);
  }

  closePlayer(): void {
    this.playingVideoUrl.set(null);
  }
}
