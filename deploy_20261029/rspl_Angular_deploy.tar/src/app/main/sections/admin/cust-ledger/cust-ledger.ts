import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { AdminDataService, CustLedgerRow, CustLedgerSaleRow, LookupOption } from '../admin-data.service';

/**
 * Mirrors Section_Admin/CustLedger.aspx ("Customer Module Report"): filter
 * bar over customers-with-software-attribute, expandable rows showing
 * purchased-module sale detail, and (when "Show YT information" is
 * checked) inline-editable YT status/date/remark/exe-status per row. The
 * source's cascading combo-refresh chain (software -> city/area/customer
 * lists narrow as you pick) is simplified to independent filter lists —
 * same effective filtering, no client-side dependent-dropdown mechanics.
 * The customer-name link opens CustomerInfo.aspx as a RadWindow popup in
 * the source — routed to the CustomerInfo page here instead of embedded.
 */
@Component({
  selector: 'app-cust-ledger',
  imports: [FormsModule, RouterLink, ButtonModule, CheckboxModule, DatePickerModule, InputTextModule, SelectModule, TableModule, DatePipe],
  templateUrl: './cust-ledger.html',
  styleUrl: './cust-ledger.scss'
})
export class CustLedger implements OnInit {
  private readonly data = inject(AdminDataService);

  readonly software = signal<LookupOption[]>([]);
  readonly ytStatuses = signal<LookupOption[]>([]);
  readonly cities = signal<string[]>([]);
  readonly areas = signal<string[]>([]);
  readonly groups = signal<LookupOption[]>([]);
  readonly customers = signal<string[]>([]);
  readonly rows = signal<CustLedgerRow[]>([]);
  readonly loading = signal(false);
  readonly expandedCustomerId = signal<number | null>(null);
  readonly saleDetail = signal<CustLedgerSaleRow[]>([]);

  softwareId = 0;
  ytStatusId = 0;
  city = '';
  area = '';
  groupId = 0;
  customer = '';
  withAmc = false;
  showYtInfo = false;

  ngOnInit(): void {
    this.data.getCustLedgerFilters().subscribe((f) => {
      this.software.set(f.software);
      this.ytStatuses.set(f.ytStatuses);
      this.cities.set(f.cities);
      this.areas.set(f.areas);
      this.groups.set(f.groups);
      this.customers.set(f.customers);
    });
    this.show();
  }

  onCityFilter(query: string): void {
    this.data.getCustLedgerCities(query).subscribe((c) => this.cities.set(c));
  }

  onAreaFilter(query: string): void {
    this.data.getCustLedgerAreas(query).subscribe((a) => this.areas.set(a));
  }

  onCustomerFilter(query: string): void {
    this.data.getCustLedgerCustomers(query).subscribe((c) => this.customers.set(c));
  }

  onGroupFilter(query: string): void {
    this.data.getCustLedgerLedgerGroups(query).subscribe((g) => this.groups.set(g));
  }

  show(): void {
    this.loading.set(true);
    this.expandedCustomerId.set(null);
    const label = (options: LookupOption[], value: number): string => options.find((o) => o.value === value)?.label ?? '';
    this.data
      .getCustLedgerRows({
        software: label(this.software(), this.softwareId),
        city: this.city,
        ytStatus: label(this.ytStatuses(), this.ytStatusId),
        area: this.area,
        customer: this.customer,
        ledgerGroupId: this.groupId
      })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      });
  }

  toggleExpand(row: CustLedgerRow): void {
    if (this.expandedCustomerId() === row.customerId) {
      this.expandedCustomerId.set(null);
      return;
    }
    this.expandedCustomerId.set(row.customerId);
    this.data.getCustLedgerSaleDetail(row.customerId, this.withAmc).subscribe((rows) => this.saleDetail.set(rows));
  }

  saveYtInfo(row: CustLedgerRow): void {
    this.data
      .updateCustLedgerYtInfo(row.customerId, { ytStatus: row.ytStatus, ytDate: row.ytDate, ytRemark: row.ytRemark, exeStatus: row.exeStatus })
      .subscribe(() => alert('Updated successfully.'));
  }
}
