import { Routes } from '@angular/router';

import { formAccessGuard } from '../../core/auth/form-access.guard';
import { FORM_CALL_HISTORY, FORM_EXEC_SCHEDULE, FORM_SENTIMETER } from '../../core/auth/user-rights.service';

export const supportRoutes: Routes = [
  {
    path: 'trouble-ticket',
    loadComponent: () => import('./support/trouble-ticket/trouble-ticket').then((m) => m.TroubleTicket)
  },
  {
    path: 'tt-register',
    loadComponent: () => import('./support/tt-register/tt-register').then((m) => m.TtRegister)
  },
  {
    path: 'visit-log',
    loadComponent: () => import('./support/visit-log/visit-log').then((m) => m.VisitLog)
  },
  {
    path: 'close-popup',
    loadComponent: () => import('./support/close-popup/close-popup').then((m) => m.ClosePopup)
  },
  {
    path: 'attachment-download',
    loadComponent: () => import('./support/attachment-download/attachment-download').then((m) => m.AttachmentDownload)
  },
  {
    path: 'call-history',
    canActivate: [formAccessGuard(FORM_CALL_HISTORY)],
    loadComponent: () => import('./support/call-history/call-history').then((m) => m.CallHistory)
  },
  {
    path: 'call-history-details',
    canActivate: [formAccessGuard(FORM_CALL_HISTORY)],
    loadComponent: () => import('./support/call-history-details/call-history-details').then((m) => m.CallHistoryDetails)
  },
  {
    path: 'missed-call',
    loadComponent: () => import('./support/missed-call/missed-call').then((m) => m.MissedCall)
  },
  {
    path: 'amc-pending',
    loadComponent: () => import('./support/amc-pending/amc-pending').then((m) => m.AmcPending)
  },
  {
    path: 'cust-amc-followup',
    loadComponent: () => import('./support/cust-amc-followup/cust-amc-followup').then((m) => m.CustAmcFollowup)
  },
  {
    path: 'einvoice-status',
    loadComponent: () => import('./support/einvoice-status/einvoice-status').then((m) => m.EinvoiceStatus)
  },
  {
    path: 'pay-bank',
    loadComponent: () => import('./support/pay-bank/pay-bank').then((m) => m.PayBank)
  },
  {
    path: 'cust-dependent',
    loadComponent: () => import('./support/cust-dependent/cust-dependent').then((m) => m.CustDependent)
  },
  {
    path: 'modules',
    loadComponent: () => import('./support/modules/modules').then((m) => m.Modules)
  },
  {
    path: 'amc-coordinator-dashboard',
    loadComponent: () =>
      import('./support/amc-coordinator-dashboard/amc-coordinator-dashboard').then((m) => m.AmcCoordinatorDashboard)
  },
  {
    path: 'add-new-action',
    loadComponent: () => import('./support/add-new-action/add-new-action').then((m) => m.AddNewAction)
  },
  {
    path: 'tt-action',
    loadComponent: () => import('./support/tt-action/tt-action').then((m) => m.TtAction)
  },
  {
    path: 'issue-detail',
    loadComponent: () => import('./support/issue-detail/issue-detail').then((m) => m.IssueDetail)
  },
  {
    path: 'support-coordinator-dashboard',
    loadComponent: () =>
      import('./support/support-coordinator-dashboard/support-coordinator-dashboard').then((m) => m.SupportCoOrdinatorDashboard)
  },
  {
    path: 'lead-report',
    loadComponent: () => import('./support/lead-report/lead-report').then((m) => m.LeadReport)
  },
  {
    path: 'trouble-ticket-modify',
    loadComponent: () => import('./support/trouble-ticket-modify/trouble-ticket-modify').then((m) => m.TroubleTicketModify)
  },
  {
    path: 'video-history',
    loadComponent: () => import('./support/video-history/video-history').then((m) => m.VideoHistory)
  },
  {
    path: 'executive-schedule',
    canActivate: [formAccessGuard(FORM_EXEC_SCHEDULE)],
    loadComponent: () => import('./support/executive-schedule/executive-schedule').then((m) => m.ExecutiveSchedule)
  },
  {
    path: 'visit-log-register',
    loadComponent: () => import('./support/visit-log-register/visit-log-register').then((m) => m.VisitLogRegister)
  },
  {
    path: 'visit-log-report',
    loadComponent: () => import('./support/visit-log-report/visit-log-report').then((m) => m.VisitLogReport)
  },
  {
    path: 'sentimeter',
    canActivate: [formAccessGuard(FORM_SENTIMETER)],
    loadComponent: () => import('./support/sentimeter/sentimeter').then((m) => m.Sentimeter)
  }
];
