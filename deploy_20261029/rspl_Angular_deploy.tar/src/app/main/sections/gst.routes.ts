import { Routes } from '@angular/router';

export const gstRoutes: Routes = [
  {
    path: 'gst-state-master',
    loadComponent: () => import('./gst/gst-state-master/gst-state-master').then((m) => m.GstStateMaster)
  },
  {
    path: 'gst-tax-master',
    loadComponent: () => import('./gst/gst-tax-master/gst-tax-master').then((m) => m.GstTaxMaster)
  },
  {
    path: 'gst-tax-calculator',
    loadComponent: () => import('./gst/gst-tax-calculator/gst-tax-calculator').then((m) => m.GstTaxCalculator)
  },
  {
    path: 'client-software-menu-request',
    loadComponent: () =>
      import('./gst/client-software-menu-request/client-software-menu-request').then((m) => m.ClientSoftwareMenuRequest)
  }
];
