import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { LookupOption, SupportDataService, VideoHistoryRow } from '../support-data.service';

/** Mirrors Section_Support/VideoHistory.aspx: customer filter + video-training-history grid. */
@Component({
  selector: 'app-video-history',
  imports: [FormsModule, SelectModule, TableModule, DatePipe],
  templateUrl: './video-history.html',
  styleUrl: './video-history.scss'
})
export class VideoHistory implements OnInit {
  private readonly data = inject(SupportDataService);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly customers = signal<LookupOption[]>([]);
  readonly rows = signal<VideoHistoryRow[]>([]);
  readonly loading = signal(false);
  // PrimeNG's p-table doesn't reset its current page when [value] changes —
  // without this, switching customers while sitting on a later page can
  // leave the paginator on an offset past the end of the new result set.
  readonly first = signal(0);

  customerId: number | null = null;

  // Debounces the customer-search-as-you-type filter so it re-queries the
  // server once typing pauses, instead of firing one HTTP request per
  // keystroke (PrimeNG's p-select onFilter emits immediately, with no
  // built-in delay).
  private readonly customerFilter$ = new Subject<string>();

  ngOnInit(): void {
    // Was scoped to only customers who already had video-history rows —
    // switched to the same general Top-100/search customer picker
    // TroubleTicket uses (support.py's get_customers) so any customer can be
    // searched and selected, not just the handful who happen to already have
    // history. No customer is pre-selected; the grid starts empty until one
    // is chosen (same convention as Advance/TroubleTicket).
    this.data.getCustomers().subscribe((c) => {
      this.customers.set(c);
      this.cdr.markForCheck();
    });

    this.customerFilter$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((query) => this.data.getCustomers(query))
      )
      .subscribe((c) => this.customers.set(c));
  }

  // Bound to <p-select>'s (onFilter) — pushes into the debounced pipeline set
  // up in ngOnInit instead of calling the server directly on every keystroke.
  onCustomerFilter(query: string): void {
    this.customerFilter$.next(query);
  }

  show(): void {
    this.loading.set(true);
    this.first.set(0);
    this.data.getVideoHistory(this.customerId ?? 0).subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: () => {
        this.rows.set([]);
        this.loading.set(false);
      }
    });
  }
}
