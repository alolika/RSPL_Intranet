import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import {
  AmcActionRow,
  AmcCoordAmcRow,
  AmcCoordPendingRow,
  LookupOption,
  SupportDataService
} from '../support-data.service';

/**
 * Mirrors Section_Support/AMCCo-OrdinatorDashBoard.aspx: two swappable report
 * panels ("AMC Pending Action" and "AMC") selected via a report-name dropdown,
 * each with its own filter set and grid. The Pending Action grid's per-row
 * "Next Step" detail expansion reuses the same AmcActionRow shape/behavior as
 * the AmcPending page (Add/Close navigates to Marketing's CustEnquiryAction,
 * Closed is inert). Cookie-persisted last-used filters from the source are
 * not replicated (no functional value without a backend).
 */
@Component({
  selector: 'app-amc-coordinator-dashboard',
  imports: [FormsModule, ButtonModule, SelectModule, DatePickerModule, InputTextModule, TableModule, DatePipe, IndianNumberPipe],
  templateUrl: './amc-coordinator-dashboard.html',
  styleUrl: './amc-coordinator-dashboard.scss'
})
export class AmcCoordinatorDashboard implements OnInit {
  private readonly data = inject(SupportDataService);
  private readonly router = inject(Router);

  reportName: 'AMC Pending Action' | 'AMC' = 'AMC Pending Action';
  readonly reportOptions = [
    { label: 'AMC Pending Action', value: 'AMC Pending Action' },
    { label: 'AMC', value: 'AMC' }
  ];

  readonly actionOnUsers = signal<string[]>([]);
  readonly products = signal<LookupOption[]>([]);
  readonly ledgerGroups = signal<LookupOption[]>([]);

  actionOn = 'All';
  searchRemark = '';
  customerFilter = '';
  productId = 0;
  ledgerGroupId = 0;
  fromExpiryDate: Date | null = null;
  toExpiryDate: Date | null = null;
  customer1Filter = '';

  readonly loading = signal(false);
  readonly pendingRows = signal<AmcCoordPendingRow[]>([]);
  readonly amcRows = signal<AmcCoordAmcRow[]>([]);
  readonly expandedCustId = signal<number | null>(null);
  readonly actionHistory = signal<AmcActionRow[]>([]);

  ngOnInit(): void {
    this.data.getAmcCoordActionOnUsers().subscribe((u) => this.actionOnUsers.set(['All', ...u]));
    this.data.getAmcProducts().subscribe((p) => this.products.set([{ label: 'All', value: 0 }, ...p]));
    this.data.getLedgerGroups().subscribe((g) => this.ledgerGroups.set(g));
  }

  show(): void {
    this.loading.set(true);
    this.expandedCustId.set(null);
    if (this.reportName === 'AMC Pending Action') {
      this.data
        .getAmcCoordPendingRows({ actionOn: String(this.actionOn), remark: this.searchRemark, customer: this.customerFilter })
        .subscribe((rows) => {
          this.pendingRows.set(rows);
          this.loading.set(false);
        });
    } else {
      this.data
        .getAmcCoordAmcRows({
          productId: this.productId,
          ledgerGroupId: this.ledgerGroupId,
          fromExpiryDate: this.fromExpiryDate,
          toExpiryDate: this.toExpiryDate,
          customer: this.customer1Filter
        })
        .subscribe((rows) => {
          this.amcRows.set(rows);
          this.loading.set(false);
        });
    }
  }

  export(): void {
    if (this.reportName === 'AMC Pending Action') {
      exportToExcel('PendingAction', this.pendingRows());
    } else {
      exportToExcel('AMCReport', this.amcRows());
    }
  }

  toggleExpand(row: AmcCoordPendingRow): void {
    if (this.expandedCustId() === row.custId) {
      this.expandedCustId.set(null);
      return;
    }
    this.expandedCustId.set(row.custId);
    this.data.getAmcActionHistory(row.custId).subscribe((rows) => this.actionHistory.set(rows));
  }

  nextStep(row: AmcCoordPendingRow, action: AmcActionRow): void {
    if (action.nextAction === 'Closed') {
      return;
    }
    this.router.navigate(['/marketing/cust-enquiry-action'], {
      queryParams: {
        CustID: row.custId,
        RefActionID: action.actionId,
        ActionType: action.nextAction === 'Add' ? 1 : 2,
        'FromAMCCo-OrdinatorDashboard': 1
      }
    });
  }
}
