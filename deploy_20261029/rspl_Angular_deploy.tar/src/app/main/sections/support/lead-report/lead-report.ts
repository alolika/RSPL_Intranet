import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

/**
 * Mirrors Section_Support/LeadReport.aspx: in the source, this page is
 * unfinished scaffolding — rcbSegment/rcbProduct are never populated
 * (FillDropDownlist calls are commented out), btnshow_Click and Fillgv are
 * empty try/catch blocks, and the RadGrid has no columns defined, so it
 * never renders any data. Replicated as-is (filter shell with inert
 * Show/Export buttons and an empty grid) rather than inventing a working
 * CRM report the source never built — same "preserve, don't invent"
 * treatment as the dead Help>Download menu link.
 */
@Component({
  selector: 'app-lead-report',
  imports: [FormsModule, ButtonModule, DatePickerModule, SelectModule, TableModule],
  templateUrl: './lead-report.html',
  styleUrl: './lead-report.scss'
})
export class LeadReport {
  fromEnqDate: Date | null = null;
  toEnqDate: Date | null = null;
  segmentId: number | null = null;
  productId: number | null = null;

  readonly segments: { label: string; value: number }[] = [];
  readonly products: { label: string; value: number }[] = [];
  readonly rows: Record<string, unknown>[] = [];
}
