import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, WritableSignal, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { RadioButtonModule } from 'primeng/radiobutton';
import { SelectModule } from 'primeng/select';
import { StepperModule } from 'primeng/stepper';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { WizardStep, goToStep } from '../../../../shared/wizard-step';
import { LookupOption, PendingIssueRow, SupportDataService, VisitLogRecord } from '../support-data.service';

type Mode = 'load' | 'new' | 'modify';
type LockStatus = 0 | 1 | 2 | 3;

/**
 * Mirrors Section_Support/VisitLog.aspx (New/Modify/Save visit-log entry
 * with hardware-lock status tracking, chargeable amount, pending-issue
 * sub-grid). The source's many ViewState-driven control-visibility toggles
 * (Disable()/enable()/visibility() with "Load"/"New"/"Modify" string flags)
 * are expressed here as one `mode` signal instead — same visible/enabled
 * behavior per mode.
 *
 * Two real bugs fixed against the source while redesigning this page:
 * - "For Worldnet" was bound to the customer/client list instead of a
 *   salesman list — the source's cmbWorld is filled from `Salesman`, but
 *   this field also feeds `salesmanId` on save, so picking an option here
 *   was silently writing a CustID into a SalesmanID column.
 * - The save date was sent via `Date.toISOString()`, which converts to
 *   UTC — for any user in a timezone ahead of UTC (this app is built for
 *   Retailware's Pune office, IST/UTC+5:30), a local midnight date rolls
 *   back to the previous day once converted, silently saving the wrong
 *   visit date. Replaced with the same local-date formatting helper used
 *   everywhere else in this app's filters.
 *
 * The file-attachment control from the previous version of this page
 * (kept as UI-only decoration with no backend behind it) has been removed
 * — the legacy source has no file upload on this page at all, so it was
 * purely invented UI that could mislead a user into thinking a file they
 * picked had been saved when nothing was ever uploaded anywhere.
 *
 * Every dropdown on this page used to load its full unbounded list on
 * every visit: Products (2,222 rows), CauseMaster (219), the free-text
 * SupportReason history (5,700 distinct values), VisitLogMaster's log IDs
 * (23,615), and worst of all Client Name (CustDependents, 86,433 rows) —
 * that's what was actually causing the "hanging" popups, not a rendering
 * glitch. All five now load only their top 100 by default and re-query
 * with a debounced search as the user types, same pattern as the Customer
 * picker used elsewhere in this app.
 */
@Component({
  selector: 'app-visit-log',
  imports: [
    FormsModule,
    RouterLink,
    ButtonModule,
    SelectModule,
    DatePickerModule,
    InputTextModule,
    TextareaModule,
    CheckboxModule,
    RadioButtonModule,
    StepperModule,
    TableModule,
    MessageModule
  ],
  templateUrl: './visit-log.html',
  styleUrl: './visit-log.scss'
})
export class VisitLog implements OnInit {
  private readonly data = inject(SupportDataService);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly location = inject(Location);

  mode = signal<Mode>('load');
  readonly activeStep = signal(0);
  readonly steps: WizardStep[] = [
    { value: 0, label: 'Client & Visit Details', validate: () => this.validateVisitDetailsStep() },
    { value: 1, label: 'Products / Modules Tested', validate: () => this.validateProductsStep() },
    { value: 2, label: 'Additional Details' }
  ];
  readonly lastLogId = signal<number | null>(null);
  readonly logIds = signal<LookupOption[]>([]);
  readonly logIdsLoading = signal(false);
  readonly clients = signal<LookupOption[]>([]);
  readonly clientsLoading = signal(false);
  readonly salesmen = signal<LookupOption[]>([]);
  readonly products = signal<LookupOption[]>([]);
  readonly productsLoading = signal(false);
  readonly causes = signal<LookupOption[]>([]);
  readonly causesLoading = signal(false);
  readonly supportReasons = signal<string[]>([]);
  readonly supportReasonsLoading = signal(false);
  readonly pendingIssues = signal<PendingIssueRow[]>([]);
  readonly pendingIssuesLoading = signal(false);
  readonly saving = signal(false);
  readonly loadingRecord = signal(false);
  showPending = false;

  selectedLogId: number | null = null;
  refNo = '';
  clientId: number | null = null;
  clientRepresentative = '';
  address = '';
  productId: number | null = null;
  date: Date = new Date();
  causeId: number | null = null;
  supportReason = '';
  modules = '';
  otherModules = '';
  remark = '';
  worldnetSalesmanId: number | null = null;

  hardwareLock = false;
  lockStatus: LockStatus = 3;
  lockSrNo = '';

  coreProductsTested = false;
  reportsTested = false;

  warrantyOrAmc: 'warranty' | 'amc' = 'warranty';
  chargeable = false;
  charges = 0;

  readonly formError = signal<string | null>(null);
  readonly formSuccess = signal<string | null>(null);
  readonly touched = signal(false);
  private successTimer?: ReturnType<typeof setTimeout>;

  private readonly clientsFilter$ = new Subject<string>();
  private readonly productsFilter$ = new Subject<string>();
  private readonly causesFilter$ = new Subject<string>();
  private readonly supportReasonsFilter$ = new Subject<string>();
  private readonly logIdsFilter$ = new Subject<string>();

  ngOnInit(): void {
    this.refreshLastLogId();
    this.data.getSalesmen().subscribe((s) => this.salesmen.set(s));

    this.wireSearchableLookup(this.clientsFilter$, (s) => this.data.getVisitLogClients(s), this.clients, this.clientsLoading);
    this.wireSearchableLookup(this.productsFilter$, (s) => this.data.getVisitLogProducts(s), this.products, this.productsLoading);
    this.wireSearchableLookup(this.causesFilter$, (s) => this.data.getVisitLogCauses(s), this.causes, this.causesLoading);
    this.wireSearchableLookup(this.supportReasonsFilter$, (s) => this.data.getSupportReasons(s), this.supportReasons, this.supportReasonsLoading);
    this.wireSearchableLookup(this.logIdsFilter$, (s) => this.data.getLogIds(s), this.logIds, this.logIdsLoading);
  }

  // Shared by every top-100/type-to-search dropdown on this page: loads the
  // default top-100 once, then re-queries (debounced) as the user types.
  private wireSearchableLookup<T>(
    filter$: Subject<string>,
    fetch: (search: string) => Observable<T[]>,
    target: WritableSignal<T[]>,
    loading: WritableSignal<boolean>
  ): void {
    loading.set(true);
    fetch('').subscribe((items) => {
      target.set(items);
      loading.set(false);
    });
    filter$.pipe(debounceTime(300), distinctUntilChanged(), switchMap((q) => fetch(q))).subscribe((items) => target.set(items));
  }

  onClientsFilter(query: string): void {
    this.clientsFilter$.next(query);
  }

  onProductsFilter(query: string): void {
    this.productsFilter$.next(query);
  }

  onCausesFilter(query: string): void {
    this.causesFilter$.next(query);
  }

  onSupportReasonsFilter(query: string): void {
    this.supportReasonsFilter$.next(query);
  }

  onLogIdsFilter(query: string): void {
    this.logIdsFilter$.next(query);
  }

  private refreshLastLogId(): void {
    this.data.getLastLogId().subscribe((id) => this.lastLogId.set(id));
  }

  onClientChange(): void {
    if (!this.clientId) {
      return;
    }
    this.data.getClientAddress(this.clientId).subscribe((addr) => {
      this.address = addr;
      this.cdr.markForCheck();
    });
  }

  onHardwareLockChange(): void {
    if (this.hardwareLock) {
      this.lockStatus = 0;
    }
  }

  onChkShowPendingChange(): void {
    if (this.showPending && this.selectedLogId) {
      this.pendingIssuesLoading.set(true);
      this.data.getPendingIssues(this.selectedLogId).subscribe((rows) => {
        this.pendingIssues.set(rows);
        this.pendingIssuesLoading.set(false);
      });
    }
  }

  newRecord(): void {
    this.mode.set('new');
    this.activeStep.set(0);
    this.clearControls();
  }

  modifyRecord(): void {
    if (!this.selectedLogId) {
      this.formError.set('Please select a Visit Log ID to modify.');
      return;
    }
    this.formError.set(null);
    this.mode.set('modify');
    this.loadingRecord.set(true);
    this.data.getVisitLog(this.selectedLogId).subscribe({
      next: (record) => {
        this.loadingRecord.set(false);
        if (record) {
          this.loadRecord(record);
          this.activeStep.set(0);
          this.cdr.markForCheck();
        }
      },
      error: () => {
        this.loadingRecord.set(false);
        this.formError.set('Failed to load this visit log record. Please try again.');
      }
    });
  }

  private loadRecord(record: VisitLogRecord): void {
    this.refNo = String(record.refNo);
    this.clientId = record.clientId;
    this.clientRepresentative = record.clientRepresentative;
    this.productId = record.productId;
    this.date = new Date(record.date);
    this.causeId = record.causeId;
    this.supportReason = record.supportReason;
    this.modules = record.modules;
    this.otherModules = record.otherModules;
    this.remark = record.remark;
    this.warrantyOrAmc = record.withinWarranty ? 'warranty' : 'amc';
    this.chargeable = record.chargeable;
    this.charges = record.charges;
    this.worldnetSalesmanId = record.salesmanId;
    this.hardwareLock = record.lock !== 3;
    this.lockStatus = record.lock;
    this.lockSrNo = record.lockSrNo;
    this.coreProductsTested = record.coreProductsTested;
    this.reportsTested = record.reportsTested;
    this.address = record.clientAddress;

    // The dropdowns only ever hold a top-100/search-matched slice now, not
    // every row (Client Name alone has 86,433) — an existing record's
    // referenced client/product/cause can easily fall outside that window,
    // which would render as a blank/unselected field even though the real
    // value is intact. Resolve each by its exact ID and splice it in if
    // it's missing. SupportReason has no separate ID — it's stored and
    // bound as the same free-text string, so the record's own value is
    // already usable as its own option.
    this.ensureOptionPresent(this.clients, record.clientId, (id) => this.data.getVisitLogClients('', id));
    this.ensureOptionPresent(this.products, record.productId, (id) => this.data.getVisitLogProducts('', id));
    this.ensureOptionPresent(this.causes, record.causeId, (id) => this.data.getVisitLogCauses('', id));
    if (record.supportReason && !this.supportReasons().includes(record.supportReason)) {
      this.supportReasons.update((reasons) => [record.supportReason, ...reasons]);
    }
  }

  private ensureOptionPresent(target: WritableSignal<LookupOption[]>, id: number, fetchOne: (id: number) => Observable<LookupOption[]>): void {
    if (!id || target().some((o) => o.value === id)) {
      return;
    }
    fetchOne(id).subscribe((resolved) => {
      if (resolved.length && !target().some((o) => o.value === id)) {
        target.update((opts) => [...resolved, ...opts]);
        this.cdr.markForCheck();
      }
    });
  }

  goNext(): void {
    goToStep(this.activeStep, this.steps, this.activeStep() + 1);
  }

  goPrev(): void {
    goToStep(this.activeStep, this.steps, this.activeStep() - 1);
  }

  cancel(): void {
    this.mode.set('load');
    this.activeStep.set(0);
    this.refreshLastLogId();
    this.clearControls();
  }

  private clearControls(): void {
    this.refNo = '';
    this.clientId = null;
    this.clientRepresentative = '';
    this.address = '';
    this.productId = null;
    this.causeId = null;
    this.supportReason = '';
    this.modules = '';
    this.otherModules = '';
    this.remark = '';
    this.charges = 0;
    this.lockSrNo = '';
    this.hardwareLock = false;
    this.lockStatus = 3;
    this.coreProductsTested = false;
    this.reportsTested = false;
    this.chargeable = false;
    this.warrantyOrAmc = 'warranty';
    this.showPending = false;
    this.worldnetSalesmanId = null;
    this.touched.set(false);
    this.formError.set(null);
  }

  private validateVisitDetailsStep(): boolean {
    this.touched.set(true);
    if (!this.clientId) {
      this.formError.set('Please select a Client Name.');
      return false;
    }
    if (!this.address.trim()) {
      this.formError.set('Please enter the Address.');
      return false;
    }
    if (!this.productId) {
      this.formError.set('Please select a Product.');
      return false;
    }
    if (!this.causeId) {
      this.formError.set('Please select a Cause of Visit.');
      return false;
    }
    if (!this.supportReason) {
      this.formError.set('Please select what support was for.');
      return false;
    }
    if (!this.worldnetSalesmanId) {
      this.formError.set('Please select For Worldnet.');
      return false;
    }
    if (this.refNo && !/^\d{1,10}$/.test(this.refNo)) {
      this.formError.set('Ref. No. must contain digits only.');
      return false;
    }
    this.formError.set(null);
    return true;
  }

  private validateProductsStep(): boolean {
    if (this.hardwareLock && this.lockSrNo && !/^\d{1,10}$/.test(this.lockSrNo)) {
      this.formError.set('Lock Srno must contain digits only.');
      return false;
    }
    this.formError.set(null);
    return true;
  }

  save(): void {
    if (this.saving()) {
      return;
    }
    this.formSuccess.set(null);

    if (!this.validateVisitDetailsStep()) {
      this.activeStep.set(0);
      return;
    }
    if (!this.validateProductsStep()) {
      this.activeStep.set(1);
      return;
    }

    const record: VisitLogRecord = {
      logId: this.selectedLogId ?? 0,
      refNo: Number(this.refNo) || 0,
      // Non-null: validateVisitDetailsStep() above already confirmed these are set.
      clientId: this.clientId!,
      clientRepresentative: this.clientRepresentative,
      salesmanId: this.worldnetSalesmanId!,
      productId: this.productId!,
      date: this.toDateParam(this.date),
      causeId: this.causeId!,
      supportReason: this.supportReason,
      modules: this.modules,
      lock: this.hardwareLock ? this.lockStatus : 3,
      lockSrNo: this.lockSrNo,
      otherModules: this.otherModules,
      remark: this.remark,
      withinWarranty: this.warrantyOrAmc === 'warranty',
      amc: this.warrantyOrAmc === 'amc',
      chargeable: this.chargeable,
      charges: this.chargeable ? this.charges : 0,
      coreProductsTested: this.coreProductsTested,
      reportsTested: this.reportsTested,
      clientAddress: this.address
    };
    this.saving.set(true);
    const wasNew = this.mode() === 'new';
    this.data.saveVisitLog(record, wasNew).subscribe({
      next: () => {
        this.saving.set(false);
        this.cancel();
        this.showSuccess(wasNew ? 'Visit log record inserted successfully.' : 'Visit log record updated successfully.');
        this.data.getLogIds().subscribe((ids) => this.logIds.set(ids));
      },
      error: (err) => {
        this.saving.set(false);
        this.formError.set(err?.error?.detail ?? 'Failed to save the visit log. Please try again.');
      }
    });
  }

  private showSuccess(message: string): void {
    this.formSuccess.set(message);
    if (this.successTimer) {
      clearTimeout(this.successTimer);
    }
    this.successTimer = setTimeout(() => this.formSuccess.set(null), 5000);
  }

  private toDateParam(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  exit(): void {
    this.cancel();
  }

  goBack(): void {
    this.location.back();
  }
}
