import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';

import { PortalAuthService } from '../../../../core/auth/portal-auth.service';
import { LookupOption, SupportDataService } from '../support-data.service';

const FOLLOW_UP_TYPES = [
  { label: 'Call', value: 'Call' },
  { label: 'Email', value: 'Email' },
  { label: 'Letter', value: 'Letter' }
];

/** Mirrors Section_Support/CustAMCFollowUp.aspx: a RadWindow popup to add a follow-up action for a customer's AMC (?CustID=). */
@Component({
  selector: 'app-cust-amc-followup',
  imports: [FormsModule, ButtonModule, SelectModule, DatePickerModule, TextareaModule],
  templateUrl: './cust-amc-followup.html',
  styleUrl: './cust-amc-followup.scss'
})
export class CustAmcFollowup implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(SupportDataService);
  private readonly auth = inject(PortalAuthService);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly followUpByOptions = signal<LookupOption[]>([]);
  readonly followUpTypes = FOLLOW_UP_TYPES;
  readonly submitting = signal(false);

  followUpBy: number | null = null;
  followUpType = 'Call';
  followUpDate: Date | null = null;
  followUpTime: Date | null = null;
  remark = '';
  contactPerson = '';

  private custId = 0;

  ngOnInit(): void {
    this.data.getUsers().subscribe((users) => {
      this.followUpByOptions.set(users);
      this.followUpBy = this.auth.currentUser()?.userId ?? null;
      this.cdr.markForCheck();
    });

    // Reached repeatedly with a different ?CustID each time — subscribe
    // rather than reading a one-time snapshot so opening this for a
    // different customer while already mounted targets the right one
    // instead of silently submitting against the previous customer.
    this.route.queryParamMap.subscribe((q) => {
      this.custId = Number(q.get('CustID') ?? 0);
      this.clear();
    });
  }

  submit(): void {
    this.submitting.set(true);
    const time = this.followUpTime ? this.followUpTime.toTimeString().slice(0, 5) : '';
    this.data
      .addAmcFollowUp(this.custId, this.followUpBy ?? 0, this.followUpDate ?? new Date(), time, this.contactPerson, this.remark)
      .subscribe(() => {
        this.submitting.set(false);
        this.clear();
      });
  }

  cancel(): void {
    this.clear();
  }

  private clear(): void {
    this.followUpDate = null;
    this.followUpTime = null;
    this.remark = '';
    this.contactPerson = '';
  }
}
