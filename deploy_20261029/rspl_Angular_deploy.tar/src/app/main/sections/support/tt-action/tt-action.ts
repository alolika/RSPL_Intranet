import { DatePipe, Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { PortalAuthService } from '../../../../core/auth/portal-auth.service';
import { exportToExcel } from '../../../../shared/export-excel';
import { LookupOption, SupportDataService, TtActionRow } from '../support-data.service';

/**
 * Mirrors Section_Support/TTAction.aspx: two disjoint panels selected via
 * ?IsAdd= — "1" shows the add-action form for a ticket (pnlAddAction),
 * otherwise shows the read-only action history grid (pnlViewAction). Both
 * were separate RadWindow popups from different launch points in the
 * source; kept as one route with the same query-param switch.
 */
@Component({
  selector: 'app-tt-action',
  imports: [FormsModule, ButtonModule, SelectModule, DatePickerModule, InputTextModule, TextareaModule, CheckboxModule, TableModule, DatePipe],
  templateUrl: './tt-action.html',
  styleUrl: './tt-action.scss'
})
export class TtAction implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(SupportDataService);
  private readonly location = inject(Location);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly auth = inject(PortalAuthService);

  isAdd = false;
  ttNo = 0;
  custId = 0;
  custName = '';

  readonly users = signal<LookupOption[]>([]);
  readonly customer = signal('');
  readonly issue = signal('');
  readonly saving = signal(false);
  readonly errorMessage = signal<string | null>(null);
  readonly successMessage = signal<string | null>(null);

  actionTakenBy: number | null = null;
  callBack = false;
  callBackDate: Date | null = new Date();
  callBackTime = '';
  actionOn: number | null = null;
  actionDetails = '';

  viewTtNo = 0;
  readonly rows = signal<TtActionRow[]>([]);
  readonly loading = signal(false);

  ngOnInit(): void {
    // Reached repeatedly from different tickets' rows/launch points, with
    // different ?TTNo / ?ttno each time — subscribe rather than reading a
    // one-time snapshot so opening this for a different ticket while
    // already mounted actually reloads instead of showing stale data.
    this.route.queryParamMap.subscribe((q) => {
      this.isAdd = q.get('IsAdd') === '1';
      this.actionDetails = '';
      this.errorMessage.set(null);
      this.successMessage.set(null);

      if (this.isAdd) {
        this.ttNo = Number(q.get('TTNo') ?? 0);
        this.data.getUsers().subscribe((u) => {
          this.users.set(u);
          // Defaults to whoever's actually logged in and adding this action
          // (matches the "Action Taken By" semantics — it's recording who
          // took the action, which is normally the current user) instead of
          // just the first name in the list; still fully editable/searchable
          // below if a different user genuinely took the action.
          const currentUserId = this.auth.currentUser()?.userId;
          this.actionTakenBy = (currentUserId != null && u.some((o) => o.value === currentUserId) ? currentUserId : u[0]?.value) ?? null;
          this.cdr.markForCheck();
        });
        this.data.getTicketBrief(this.ttNo).subscribe((info) => {
          if (info) {
            this.customer.set(info.customer);
            this.issue.set(info.issue);
          }
        });
      } else {
        this.viewTtNo = Number(q.get('ttno') ?? 0);
        this.custId = Number(q.get('CustID') ?? 0);
        this.custName = q.get('CustName') ?? '';
        this.showActions();
      }
      this.cdr.markForCheck();
    });
  }

  save(): void {
    if (!this.actionDetails.trim()) {
      this.errorMessage.set('Please enter text in Action Details.');
      return;
    }
    this.errorMessage.set(null);
    this.saving.set(true);
    this.data
      .addTtAction({
        ttNo: this.ttNo,
        actionDetails: this.actionDetails,
        actionTakenBy: this.actionTakenBy ?? 0,
        callBack: this.callBack,
        actionOn: this.actionOn ?? 0,
        callBackDate: this.callBackDate ?? new Date(),
        callBackTime: this.callBackTime
      })
      .subscribe({
        next: () => {
          this.saving.set(false);
          this.successMessage.set(`Action saved successfully, for the TT no ${this.ttNo}.`);
          this.cdr.markForCheck();
        },
        // Without this, an HTTP failure left `saving` stuck at true forever
        // — the Save button shows its loading spinner indefinitely with no
        // error shown and no way to retry short of reloading the page.
        error: (err: { error?: { detail?: string } }) => {
          this.saving.set(false);
          this.errorMessage.set(err?.error?.detail ?? 'Failed to save the action. Please check your connection and try again.');
          this.cdr.markForCheck();
        }
      });
  }

  close(): void {
    this.location.back();
  }

  showActions(): void {
    this.loading.set(true);
    this.data.getTtActions(this.viewTtNo, this.custId).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }

  export(): void {
    exportToExcel('TTAction', this.rows());
  }
}
