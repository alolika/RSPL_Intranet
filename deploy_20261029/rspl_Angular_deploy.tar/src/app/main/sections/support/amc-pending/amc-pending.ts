import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AutoCompleteCompleteEvent, AutoCompleteModule } from 'primeng/autocomplete';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import { AmcActionRow, AmcRow, LookupOption, SupportDataService } from '../support-data.service';

/**
 * Mirrors Section_Support/AMCPending.aspx, reused for two menu entries via
 * ?FromMenu=: "AMCPending" (AMC Followup, filter-driven) and
 * "AMCLastAction" (My Today's Work, per-user last-action view, row-colored
 * green/pink by ActionStageID). The CustEnquiryAction.aspx RadWindow
 * "Add/Close next step" popup is routed to (once that Marketing page
 * exists) rather than embedded.
 */
@Component({
  selector: 'app-amc-pending',
  imports: [FormsModule, AutoCompleteModule, ButtonModule, SelectModule, DatePickerModule, InputTextModule, TableModule, DatePipe, IndianNumberPipe],
  templateUrl: './amc-pending.html',
  styleUrl: './amc-pending.scss'
})
export class AmcPending implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(SupportDataService);
  private readonly router = inject(Router);
  private readonly cdr = inject(ChangeDetectorRef);

  mode: 'AMCPending' | 'AMCLastAction' = 'AMCPending';
  readonly products = signal<LookupOption[]>([]);
  readonly users = signal<LookupOption[]>([]);
  readonly rows = signal<AmcRow[]>([]);
  readonly loading = signal(false);
  readonly expandedCustId = signal<number | null>(null);
  readonly actionHistory = signal<AmcActionRow[]>([]);
  readonly customerSuggestions = signal<string[]>([]);
  /** True when the grid is showing only the first INITIAL_LIMIT rows (no filter applied). */
  readonly limited = signal(false);
  readonly exporting = signal(false);
  readonly INITIAL_LIMIT = 50;

  customerFilter = '';
  productId: number | null = null;
  sign = '>=';
  amount = '';
  fromExpiryDate: Date | null = null;
  toExpiryDate: Date | null = null;
  userId: number | null = null;

  ngOnInit(): void {
    this.data.getAmcProducts().subscribe((p) => this.products.set(p));
    this.data.getUsers().subscribe((u) => this.users.set([{ label: 'All', value: 0 }, ...u]));

    // "AMC Followup" and "My Today's Work" both route to this same
    // component (only ?FromMenu differs) — subscribe rather than reading a
    // one-time snapshot so switching between them while mounted updates.
    //
    // Update (2026-07-28, per explicit request): the source's Page_Load only
    // fills combos and never auto-runs FillGV — this component previously
    // matched that faithfully, leaving the grid empty until Show was
    // clicked, specifically to avoid running the expensive
    // VWAMCForAllCustomers view / WebProc_GetLastAMCAction on every page
    // visit. That was read as "the report shows no data" rather than "the
    // report requires a click," so it now auto-loads on open instead,
    // trading that avoided cost (confirmed live: ~4.5s, 11.5k+ rows for the
    // unfiltered AMCPending case) back in for data being visible immediately.
    this.route.queryParamMap.subscribe((q) => {
      this.mode = (q.get('FromMenu') as 'AMCPending' | 'AMCLastAction') ?? 'AMCPending';
      this.cdr.markForCheck();
      this.show();
    });
  }

  private filters() {
    return {
      customer: this.customerFilter?.trim() ?? '',
      productId: this.productId,
      sign: this.sign,
      amount: this.amount,
      fromExpiryDate: this.fromExpiryDate,
      toExpiryDate: this.toExpiryDate,
      userId: this.userId
    };
  }

  // The unfiltered AMC Followup view is ~11.8k rows / ~6s; with no filter
  // only the first 50 are fetched (~0.5s). Any filter -> full matching set.
  private hasFilter(): boolean {
    const f = this.filters();
    return !!(f.customer || f.productId || f.amount || f.fromExpiryDate || f.toExpiryDate);
  }

  show(): void {
    this.loading.set(true);
    const limit = this.mode === 'AMCPending' && !this.hasFilter() ? this.INITIAL_LIMIT : 0;
    this.data.getAmcRows(this.mode, { ...this.filters(), limit }).subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.limited.set(limit > 0);
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  searchCustomers(event: AutoCompleteCompleteEvent): void {
    this.data.searchAmcCustomers(event.query).subscribe((names) => this.customerSuggestions.set(names));
  }

  clearCustomer(): void {
    this.customerFilter = '';
    this.show();
  }

  // When the grid holds only the first 50 rows, export fetches the full
  // (filtered) set instead so the workbook isn't silently truncated.
  export(): void {
    if (!this.limited()) {
      exportToExcel('AMCInfo', this.rows());
      return;
    }
    this.exporting.set(true);
    this.data.getAmcRows(this.mode, this.filters()).subscribe({
      next: (rows) => {
        exportToExcel('AMCInfo', rows);
        this.exporting.set(false);
      },
      error: () => this.exporting.set(false)
    });
  }

  rowColor(row: AmcRow): string {
    if (this.mode !== 'AMCLastAction') {
      return '';
    }
    return row.actionStageId === 18 ? '#90EE90' : '#FFB6C1';
  }

  toggleExpand(row: AmcRow): void {
    if (this.expandedCustId() === row.custId) {
      this.expandedCustId.set(null);
      return;
    }
    this.expandedCustId.set(row.custId);
    this.data.getAmcActionHistory(row.custId).subscribe((rows) => this.actionHistory.set(rows));
  }

  nextStep(row: AmcRow, action: AmcActionRow): void {
    if (action.nextAction === 'Closed') {
      return;
    }
    const actionStageId = row.actionStageId === 18 || row.actionStageId === 0 ? 18 : 27;
    this.router.navigate(['/marketing/cust-enquiry-action'], {
      queryParams: {
        CustID: row.custId,
        RefActionID: action.actionId,
        ActionType: action.nextAction === 'Add' ? 1 : 2,
        ActionStageID: actionStageId,
        FromAMCPending: 1
      }
    });
  }

  callNow(mobileNo: string): void {
    alert(`Dialing ${mobileNo} (external Synapse/SIP call — not wired up without a backend)`);
  }
}
