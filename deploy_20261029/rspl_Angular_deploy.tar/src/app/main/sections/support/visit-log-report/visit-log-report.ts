import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { SupportDataService, VisitLogRegisterRow } from '../support-data.service';

/**
 * Mirrors Section_Support/VisitLogReport.aspx: unfiltered visit-log grid
 * (same VisitLogMaster join as VisitLogRegister, without the filter panel)
 * with per-column sort and Contains-filter — replicated via PrimeNG's
 * native pSortableColumn + p-column-filter instead of the source's
 * RadGrid AutoPostBackOnFilter mechanics. No lookup popups exist on this
 * page (matches the legacy source, which has none either) — it's read
 * results only, filtered/sorted client-side once loaded.
 */
@Component({
  selector: 'app-visit-log-report',
  imports: [TableModule, ButtonModule, DatePipe],
  templateUrl: './visit-log-report.html',
  styleUrl: './visit-log-report.scss'
})
export class VisitLogReport implements OnInit {
  private readonly data = inject(SupportDataService);

  readonly rows = signal<VisitLogRegisterRow[]>([]);
  readonly loading = signal(false);
  readonly loadError = signal<string | null>(null);

  ngOnInit(): void {
    this.refresh();
  }

  refresh(): void {
    this.loading.set(true);
    this.loadError.set(null);
    this.data.getVisitLogReportRows().subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      // The load had no error handler at all before — a failed request left
      // `loading` stuck true forever with an empty grid and no indication
      // anything had gone wrong.
      error: () => {
        this.loading.set(false);
        this.loadError.set('Failed to load the visit log report. Please try again.');
      }
    });
  }

  export(): void {
    exportToExcel('VisitLogReport', this.rows());
  }
}
