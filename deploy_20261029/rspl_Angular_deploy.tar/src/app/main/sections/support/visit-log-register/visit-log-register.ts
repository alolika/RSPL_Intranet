import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { LookupOption, SupportDataService, VisitLogRegisterRow } from '../support-data.service';

const ALL_OPTION: LookupOption = { label: 'ALL', value: 0 };

/**
 * Mirrors Section_Support/VisitLogRegister.aspx: collapsible filter panel +
 * visit-log grid. Read-only — there is no save/update/edit capability on
 * this page in the legacy source either, just filtering and display; the
 * actual data-entry form is the separate Visit Log page.
 *
 * Two real filter bugs found and fixed here:
 * - Ref. No. From/To compared VisitLogMaster.RefNo (stored as nvarchar) as
 *   text, not a number — confirmed live that searching the numeric range
 *   [9, 99] returned 764 rows by string comparison vs the correct 88 by
 *   numeric comparison (e.g. "10" sorts before "9" as text). Backend now
 *   compares via TRY_CAST(RefNo AS INT).
 * - The Narration filter was applied unconditionally (`LIKE '%' + '' + '%'`
 *   even with nothing typed) — harmless today since no row has a NULL
 *   SupportReason, but would have silently hidden any that did regardless
 *   of whether a user ever touched this filter. Now only applied when set.
 *
 * Customer/Product/Cause used to load without any search — the backend
 * already caps these to top-100 (shared with the Visit Log entry form's
 * fix), but this page never wired up the search-as-you-type side of it,
 * so anything past the first 100 was simply unreachable. Wired here too.
 */
@Component({
  selector: 'app-visit-log-register',
  imports: [FormsModule, ButtonModule, CheckboxModule, DatePickerModule, InputTextModule, SelectModule, TableModule, TextareaModule, DatePipe],
  templateUrl: './visit-log-register.html',
  styleUrl: './visit-log-register.scss'
})
export class VisitLogRegister implements OnInit {
  private readonly data = inject(SupportDataService);

  readonly customers = signal<LookupOption[]>([]);
  readonly customersLoading = signal(false);
  readonly persons = signal<LookupOption[]>([]);
  readonly products = signal<LookupOption[]>([]);
  readonly productsLoading = signal(false);
  readonly causes = signal<LookupOption[]>([]);
  readonly causesLoading = signal(false);
  readonly rows = signal<VisitLogRegisterRow[]>([]);
  readonly loading = signal(false);

  // Bound one-way to <p-table>'s [first] — see the same fix on Pending TT
  // Register/TT Register: PrimeNG otherwise keeps a stale page/total-record
  // count once a new, smaller result set replaces the current one.
  firstRow = 0;

  useDateFilter = false;
  fromDate: Date | null = new Date();
  toDate: Date | null = new Date();
  customerId: number | null = null;
  personId: number | null = null;
  productId: number | null = null;
  causeId: number | null = null;
  narration = '';
  fromRef = '';
  toRef = '';

  readonly refNoError = signal<string | null>(null);

  private readonly customersFilter$ = new Subject<string>();
  private readonly productsFilter$ = new Subject<string>();
  private readonly causesFilter$ = new Subject<string>();

  ngOnInit(): void {
    this.data.getSalesmen().subscribe((p) => this.persons.set([ALL_OPTION, ...p]));

    this.customersLoading.set(true);
    this.data.getVisitLogClients().subscribe((c) => {
      this.customers.set([ALL_OPTION, ...c]);
      this.customersLoading.set(false);
    });
    this.customersFilter$
      .pipe(debounceTime(300), distinctUntilChanged(), switchMap((q) => this.data.getVisitLogClients(q)))
      .subscribe((c) => this.customers.set([ALL_OPTION, ...c]));

    this.productsLoading.set(true);
    this.data.getVisitLogProducts().subscribe((p) => {
      this.products.set([ALL_OPTION, ...p]);
      this.productsLoading.set(false);
    });
    this.productsFilter$
      .pipe(debounceTime(300), distinctUntilChanged(), switchMap((q) => this.data.getVisitLogProducts(q)))
      .subscribe((p) => this.products.set([ALL_OPTION, ...p]));

    this.causesLoading.set(true);
    this.data.getVisitLogCauses().subscribe((c) => {
      this.causes.set([ALL_OPTION, ...c]);
      this.causesLoading.set(false);
    });
    this.causesFilter$
      .pipe(debounceTime(300), distinctUntilChanged(), switchMap((q) => this.data.getVisitLogCauses(q)))
      .subscribe((c) => this.causes.set([ALL_OPTION, ...c]));

    this.show();
  }

  onCustomersFilter(query: string): void {
    this.customersFilter$.next(query);
  }

  onProductsFilter(query: string): void {
    this.productsFilter$.next(query);
  }

  onCausesFilter(query: string): void {
    this.causesFilter$.next(query);
  }

  show(): void {
    if (this.loading()) {
      return;
    }
    if (this.fromRef && !/^\d+$/.test(this.fromRef)) {
      this.refNoError.set('Ref. No. From must be a number.');
      return;
    }
    if (this.toRef && !/^\d+$/.test(this.toRef)) {
      this.refNoError.set('Ref. No. To must be a number.');
      return;
    }
    this.refNoError.set(null);
    this.loading.set(true);
    this.firstRow = 0;
    this.data
      .getVisitLogRegisterRows({
        useDateFilter: this.useDateFilter,
        fromDate: this.fromDate,
        toDate: this.toDate,
        customerId: this.customerId,
        personId: this.personId,
        productId: this.productId,
        causeId: this.causeId,
        narration: this.narration,
        fromRef: this.fromRef,
        toRef: this.toRef
      })
      .subscribe({
        next: (rows) => {
          this.rows.set(rows);
          this.loading.set(false);
        },
        error: () => {
          this.loading.set(false);
        }
      });
  }

  resetFilters(): void {
    this.useDateFilter = false;
    this.fromDate = new Date();
    this.toDate = new Date();
    this.customerId = null;
    this.personId = null;
    this.productId = null;
    this.causeId = null;
    this.narration = '';
    this.fromRef = '';
    this.toRef = '';
    this.refNoError.set(null);
    this.show();
  }
}
