import { Location } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';

import { SupportDataService } from '../support-data.service';

interface DependentRow {
  name: string;
  mobileNo: string;
  email: string;
}

/**
 * Mirrors Section_Support/CustDependent.aspx: list of a customer's
 * dependents (?CustID=). The source's RadWindow had its own close chrome;
 * here it's a real route, so it needs its own Back control.
 *
 * The Add form (Name/Mobile No/Email + Save) is a genuinely new addition —
 * the source page itself was purely read-only (a RadGrid + Close button,
 * confirmed against CustDependent.aspx.vb). Added per explicit request.
 * The backend reuses the same duplicate-mobile-check and per-customer
 * DepID-assignment logic as the one place the legacy app itself ever
 * inserts a CustDependents row (WebProc_UpdateSIPEventRegisterCDR, the
 * unrelated ClosePopup "Add Dependent" flow) — see
 * support_modules.py's add_customer_dependent for the full explanation.
 */
@Component({
  selector: 'app-cust-dependent',
  imports: [ButtonModule, CheckboxModule, FormsModule, InputTextModule, TableModule],
  templateUrl: './cust-dependent.html',
  styleUrl: './cust-dependent.scss'
})
export class CustDependent implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(SupportDataService);
  private readonly location = inject(Location);

  readonly rows = signal<DependentRow[]>([]);
  readonly showAddForm = signal(false);
  readonly saving = signal(false);
  readonly errorMessage = signal('');

  name = '';
  mobileNo = '';
  email = '';

  private custId = 0;

  ngOnInit(): void {
    // Reached repeatedly with a different ?CustID each time — subscribe
    // rather than reading a one-time snapshot so opening this for a
    // different customer while already mounted actually reloads.
    this.route.queryParamMap.subscribe((q) => {
      this.custId = Number(q.get('CustID') ?? 0);
      this.showAddForm.set(false);
      this.errorMessage.set('');
      this.clearForm();
      this.load();
    });
  }

  private load(): void {
    this.data.getCustomerDependents(this.custId).subscribe((rows) => this.rows.set(rows));
  }

  private clearForm(): void {
    this.name = '';
    this.mobileNo = '';
    this.email = '';
  }

  save(): void {
    this.errorMessage.set('');
    if (!this.name.trim() || !this.mobileNo.trim()) {
      this.errorMessage.set('Please enter dependent name and mobile number.');
      return;
    }
    this.saving.set(true);
    this.data.addCustomerDependent(this.custId, this.name.trim(), this.mobileNo.trim(), this.email.trim()).subscribe({
      next: (res) => {
        this.saving.set(false);
        if (!res.success) {
          this.errorMessage.set(res.message);
          return;
        }
        this.clearForm();
        this.showAddForm.set(false);
        this.load();
      },
      error: () => {
        this.saving.set(false);
        this.errorMessage.set('Could not save the dependent. Please try again.');
      }
    });
  }

  cancelAdd(): void {
    this.showAddForm.set(false);
    this.errorMessage.set('');
    this.clearForm();
  }

  goBack(): void {
    this.location.back();
  }
}
