import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TableModule } from 'primeng/table';

import { SupportDataService } from '../support-data.service';

/** Mirrors Section_Support/AttachmentDownload.aspx: lists uploaded files for a given ?Logid=. */
@Component({
  selector: 'app-attachment-download',
  imports: [TableModule],
  templateUrl: './attachment-download.html',
  styleUrl: './attachment-download.scss'
})
export class AttachmentDownload implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(SupportDataService);

  readonly files = signal<string[]>([]);
  private logId = 0;

  ngOnInit(): void {
    // Reached repeatedly with a different ?Logid each time — subscribe
    // rather than reading a one-time snapshot so opening this for a
    // different log while already mounted actually reloads its files.
    this.route.queryParamMap.subscribe((q) => {
      this.logId = Number(q.get('Logid') ?? 0);
      this.data.getUploadedFiles(this.logId).subscribe((files) => this.files.set(files));
    });
  }

  download(fileName: string): void {
    // Source streams the file via Response.WriteFile — no backend/file storage wired up yet in this phase.
    alert(`Download not available yet (no backend): ${fileName}`);
  }
}
