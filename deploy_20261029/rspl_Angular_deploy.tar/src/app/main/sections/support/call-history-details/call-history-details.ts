import { DatePipe, Location } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TableModule } from 'primeng/table';

import { API_BASE_URL } from '../../../../shared/api-config';
import { CallHistoryDetailRow, SupportDataService } from '../support-data.service';

/**
 * Mirrors Section_Support/CallHistoryDetails.aspx (?fromDate=&ToDate=&EntityID=&Mobileno=).
 * SynapseCDR-backed — confirmed live and working (see support_callsip.py's
 * module docstring). Listen/Download both proxy the recording through this
 * API's /call-recording/download endpoint rather than the raw RecordingPath
 * — see nowPlayingRecordNo's own doc comment for why the direct-PBX-URL
 * approach this used to take was unreliable.
 */
@Component({
  selector: 'app-call-history-details',
  imports: [TableModule, DatePipe],
  templateUrl: './call-history-details.html',
  styleUrl: './call-history-details.scss'
})
export class CallHistoryDetails implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(SupportDataService);
  private readonly location = inject(Location);

  readonly rows = signal<CallHistoryDetailRow[]>([]);
  readonly loading = signal(false);
  readonly loadError = signal<string | null>(null);
  // Listen used to point <audio src> straight at the raw RecordingPath
  // (the PBX's own 192.168.200.188 URL) — worked only when the browser
  // itself could reach that exact internal host, and failed completely
  // silently otherwise (no error, no sound, nothing) whenever a user's
  // machine wasn't on that network, or when the file legitimately doesn't
  // exist yet (confirmed live: some very recent recordings 404 on the PBX
  // server before it finishes writing them). Routed through the same
  // /call-recording/download proxy Download already uses (?inline=true) so
  // playback is exactly as reliable as the already-verified download path,
  // and failures now surface via the audio element's own (error) event
  // instead of playing silence. Only one plays at a time via this shared
  // signal/audio element, rather than an inline player per row.
  readonly nowPlayingRecordNo = signal<number | null>(null);
  readonly playError = signal<string | null>(null);
  // Downloading, unlike Listen, goes through the API's own
  // /call-recording/download proxy rather than the raw RecordingPath — that
  // PBX server sends neither a Content-Disposition header (so a direct link
  // just plays the file instead of downloading it) nor CORS headers (so a
  // cross-origin fetch()+blob download can't reach it at all). Only one
  // download runs at a time; recordNo of the in-flight row drives its
  // button's own spinner without needing a Set for what's always at most one.
  readonly downloadingRecordNo = signal<number | null>(null);
  readonly downloadError = signal<string | null>(null);

  ngOnInit(): void {
    // Reached repeatedly with different params each time — subscribe
    // rather than reading a one-time snapshot so opening this for a
    // different entity/date-range while already mounted actually reloads.
    this.route.queryParamMap.subscribe((q) => {
      this.loading.set(true);
      this.loadError.set(null);
      this.data
        .getCallHistoryDetail(q.get('fromDate') ?? '', q.get('ToDate') ?? '', Number(q.get('EntityID') ?? 0), q.get('Mobileno') ?? '')
        .subscribe({
          next: (rows) => {
            this.rows.set(rows);
            this.loading.set(false);
          },
          error: () => {
            this.loading.set(false);
            this.loadError.set(
              'Could not load call details. This report depends on the SynapseCDR call-log database, which is not currently available on this server.'
            );
          }
        });
    });
  }

  goBack(): void {
    this.location.back();
  }

  play(row: CallHistoryDetailRow): void {
    this.playError.set(null);
    this.nowPlayingRecordNo.set(row.recordNo);
  }

  stopPlaying(): void {
    this.nowPlayingRecordNo.set(null);
    this.playError.set(null);
  }

  playingUrl(): string | null {
    const recordNo = this.nowPlayingRecordNo();
    return recordNo ? `${API_BASE_URL}/support/call-recording/download?record_no=${recordNo}&inline=true` : null;
  }

  // Bound to the <audio> element's (error) event — fires when the browser
  // can't play whatever playingUrl() pointed it at (missing/purged
  // recording -> proxy 404s, PBX unreachable -> proxy 502s, etc.). Without
  // this, a failed load just sat there silent with no explanation, which is
  // exactly what read as "the recording voice is not coming" — the player
  // was there, it just never had anything to play and never said why.
  onPlaybackError(): void {
    this.playError.set(
      'This recording could not be played — it may not exist yet, may have been purged, or the recording server may be unreachable right now. Try again in a moment, or use Download.'
    );
  }

  download(row: CallHistoryDetailRow): void {
    this.downloadError.set(null);
    this.downloadingRecordNo.set(row.recordNo);
    this.data.downloadCallRecording(row.recordNo).subscribe({
      next: (res) => {
        this.downloadingRecordNo.set(null);
        const blob = res.body;
        if (!blob || blob.size === 0) {
          this.downloadError.set('The recording server returned an empty file. Please try again.');
          return;
        }
        const filename = this.extractFilename(res.headers.get('Content-Disposition')) ?? `call-recording-${row.recordNo}.wav`;
        const objectUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = objectUrl;
        link.download = filename;
        link.click();
        URL.revokeObjectURL(objectUrl);
      },
      error: (err: unknown) => {
        this.downloadingRecordNo.set(null);
        void this.resolveDownloadErrorMessage(err).then((message) => this.downloadError.set(message));
      }
    });
  }

  private extractFilename(contentDisposition: string | null): string | null {
    if (!contentDisposition) {
      return null;
    }
    const match = /filename="?([^";]+)"?/.exec(contentDisposition);
    return match ? match[1] : null;
  }

  // With responseType: 'blob', Angular's HttpClient parses an ERROR response
  // body as a Blob too (not JSON) even though the backend actually sent
  // `{"detail": "..."}` — without this, every one of the backend's carefully
  // specific messages ("No recording is available for this call.", "Could
  // not reach the recording server...", etc.) would be lost behind an opaque
  // Blob object and the user would only ever see a generic fallback.
  private async resolveDownloadErrorMessage(err: unknown): Promise<string> {
    const httpError = err as { error?: unknown };
    if (httpError?.error instanceof Blob) {
      try {
        const text = await httpError.error.text();
        const parsed = JSON.parse(text) as { detail?: string };
        if (parsed?.detail) {
          return parsed.detail;
        }
      } catch {
        // Not JSON (or empty) — fall through to the generic message below.
      }
    }
    return 'Could not download the recording. Please check your connection and try again.';
  }

  // Duration and Bill Seconds arrive from Proc_CallHistory as plain seconds
  // (e.g. "125", 15) — display-only conversion to MM:SS min per explicit
  // request; the underlying API/DB values are untouched, this only changes
  // what's rendered in these two cells.
  formatSecondsAsMinSec(totalSecondsText: string | number): string {
    const totalSeconds = Number(totalSecondsText);
    if (!Number.isFinite(totalSeconds) || totalSeconds < 0) {
      return String(totalSecondsText);
    }
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = Math.floor(totalSeconds % 60);
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${pad(minutes)}:${pad(seconds)} min`;
  }
}
