import { Location } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { MessageModule } from 'primeng/message';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { ModulesFieldName, SupportDataService } from '../support-data.service';

/**
 * Mirrors Section_Support/Modules.aspx: one generic grid popup reused for
 * seven different data shapes via ?FieldName= (Modules/Invoices/VisitLog/
 * AMCDate/ViewAction/Notification/ExeVersion). Columns are rendered
 * dynamically from the mock row keys, same approach as the report-viewer
 * pages for the same reason (AutoGenerateColumns in the source). The
 * source's RadWindow had its own close chrome; here it's a real route, so
 * it needs its own Back control.
 *
 * "Show Pirated from Online" (btnShowPiratedOnline in the source .aspx) is
 * a plain, always-visible button with no Visible= gating anywhere in the
 * source markup or codebehind — a previous version of this migration
 * incorrectly restricted it to the "Modules" FieldName only, which is why
 * it appeared to be missing on every other tab (Notification included).
 * Shown on every FieldName now, matching the source.
 *
 * Pirated rows render in their OWN separate table instead of being merged
 * into the main grid's rows/columns. An earlier version unioned both
 * row shapes into one array + one derived column set (the source's own
 * DataTable.Merge() behavior) — verified correct in an isolated headless
 * test (right row count, no exception), but that only proves the JS logic
 * is sound, not that a real browser paints a giant sparse table (100+ rows
 * of one shape, 3 of a completely different shape sharing no meaningful
 * columns) without some layout/rendering quirk jsdom can't catch. Given a
 * live report of the page going blank specifically when real pirated rows
 * exist (not when the "none found" empty-state path runs), separating the
 * two datasets into independent tables removes that entire class of risk
 * rather than continuing to chase it blind.
 */
@Component({
  selector: 'app-modules',
  imports: [ButtonModule, MessageModule, TableModule],
  templateUrl: './modules.html',
  styleUrl: './modules.scss'
})
export class Modules implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(SupportDataService);
  private readonly location = inject(Location);

  readonly title = signal('');
  readonly rows = signal<Record<string, unknown>[]>([]);
  readonly columns = signal<string[]>([]);
  readonly loading = signal(true);
  readonly loadError = signal<string | null>(null);

  readonly piratedRows = signal<Record<string, unknown>[]>([]);
  readonly piratedColumns = signal<string[]>([]);
  readonly piratedError = signal<string | null>(null);
  readonly piratedLoading = signal(false);
  readonly piratedEmpty = signal(false);
  readonly piratedChecked = signal(false);

  private custId = 0;
  private fieldName: ModulesFieldName = 'Modules';

  ngOnInit(): void {
    // Reused for 7 different data shapes via ?FieldName=, reached repeatedly
    // from various grids with different ?CustId — subscribe rather than
    // reading a one-time snapshot so opening this for a different
    // customer/field while already mounted actually reloads.
    this.route.queryParamMap.subscribe((q) => {
      this.custId = Number(q.get('CustId') ?? 0);
      this.fieldName = (q.get('FieldName') as ModulesFieldName) ?? 'Modules';
      this.loading.set(true);
      this.loadError.set(null);
      this.piratedError.set(null);
      this.piratedEmpty.set(false);
      this.piratedChecked.set(false);
      this.piratedRows.set([]);
      this.piratedColumns.set([]);
      this.title.set('');
      this.rows.set([]);
      this.columns.set([]);

      this.data.getModulesData(this.fieldName, this.custId).subscribe({
        next: (res) => {
          this.title.set(res.title);
          this.rows.set(res.rows);
          this.columns.set(res.rows.length > 0 ? Object.keys(res.rows[0]) : []);
          this.loading.set(false);
        },
        // Previously had no error path at all — a failed request (e.g.
        // ExeVersion/Show Pirated/EinvoiceStatus, all three confirmed to
        // depend on the [License] linked server, which either doesn't
        // exist or — confirmed live on this database — exists but errors
        // with a distributed-transaction/OLE-DB failure) left this page
        // entirely blank: no title, no grid, no indication anything had
        // gone wrong. Easy to mistake for "this feature doesn't exist"
        // rather than "it failed."
        error: () => {
          this.loading.set(false);
          this.loadError.set(
            'Could not load this data. This feature depends on a linked database server that is not currently working correctly — contact your database administrator.'
          );
        }
      });
    });
  }

  showPiratedOnline(): void {
    this.piratedError.set(null);
    this.piratedEmpty.set(false);
    this.piratedLoading.set(true);
    this.data.getPiratedModules(this.custId).subscribe({
      next: (pirated) => {
        this.piratedLoading.set(false);
        this.piratedChecked.set(true);
        this.piratedRows.set(pirated);
        this.piratedColumns.set(pirated.length > 0 ? Object.keys(pirated[0]) : []);
        this.piratedEmpty.set(pirated.length === 0);
      },
      error: (err) => {
        this.piratedLoading.set(false);
        console.error('Show Pirated from Online: request failed', err);
        this.piratedError.set(
          'Could not load pirated modules. This feature depends on a linked database server that is not currently working correctly — contact your database administrator.'
        );
      }
    });
  }

  export(): void {
    exportToExcel(this.title() || 'Export', this.rows());
  }

  goBack(): void {
    this.location.back();
  }
}
