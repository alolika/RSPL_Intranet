import { DatePipe } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { CallHistorySummaryRow, LookupOption, SupportDataService } from '../support-data.service';

/**
 * Mirrors Section_Support/CallHistory.aspx. The "EntityName" link opened
 * CallHistoryDetails.aspx as a RadWindow popup in the source — routed to
 * /support/call-history-details here instead (see the cross-link
 * simplification note on TroubleTicket).
 *
 * NOTE: this page's data source, Proc_CallHistory, reads
 * `synapsecdr.dbo.SIPEventRegisterCDR` — an earlier note here claimed
 * SynapseCDR doesn't exist and every call 500s; that's stale (see
 * support_callsip.py's own updated docstring) — it's confirmed live and
 * working for a normal, filtered request. The one real remaining gap: a
 * broad, unfiltered multi-week "all customers" date range can time out
 * past the backend's 60s connection cap (SIPEventRegisterCDR has ~297K
 * rows with no index on the columns Proc_CallHistory filters by) — a
 * single day or a customer/mobile-filtered range runs in a couple of
 * seconds.
 *
 * Two real bugs found and fixed while reviewing this:
 * - The Customer Name filter was wired to `getVisitLogClients()`
 *   (CustDependents, DepID=1 — a dependents/contacts list used by the
 *   Visit Log pages) instead of the real customer master. Checked
 *   Proc_CallHistory's own definition: its `@EntityID` parameter is
 *   compared directly against `CustomerMaster.CustID` (confirmed by the
 *   proc's own embedded sample calls, e.g. `Select * from CustomerMaster
 *   where CustID in (41936,40491)`), and the source's rcbCustomer combo
 *   is filled via the same generic `GenSearchCustWithGroupID1` service
 *   method used by Trouble Ticket's customer picker — not the dependents
 *   list. Switched to the standard top-100/search customer picker
 *   (SupportDataService.getCustomers), which also fixed the second issue
 *   below as a side effect.
 * - There was no error handling on `show()` at all. Since the request is
 *   guaranteed to fail today (see above), every visit to this page left
 *   `loading` stuck true forever with the table's loading spinner
 *   spinning indefinitely — which reads exactly like "running very slow"
 *   even though the actual failed request takes under half a second.
 *
 * Update (2026-08-04): calls from/to phone numbers that don't match any
 * known customer ("unregistered" numbers) are now included too, per
 * explicit request/investigation — see support_callsip.py's own update
 * note for the full story (a small but real ~0.16% slice of calls were
 * being silently dropped by a guard this page's backend inherited from the
 * legacy Proc_CallHistory). Those rows show entityId=0, entityName
 * "Unregistered" (styled via .unregistered-link in the .html/.scss), and
 * their own entityPhone — the "View Details" drill-down link now passes
 * that row's own phone number instead of the page-level mobile-number
 * filter for these rows specifically, since there's no real entityId to
 * key off of.
 */
@Component({
  selector: 'app-call-history',
  imports: [FormsModule, RouterLink, ButtonModule, SelectModule, DatePickerModule, InputTextModule, TableModule, MessageModule, DatePipe],
  templateUrl: './call-history.html',
  styleUrl: './call-history.scss'
})
export class CallHistory implements OnInit {
  private readonly data = inject(SupportDataService);

  readonly customers = signal<LookupOption[]>([]);
  readonly customersLoading = signal(false);
  readonly rows = signal<CallHistorySummaryRow[]>([]);
  readonly loading = signal(false);
  readonly loadError = signal<string | null>(null);

  // Call Type is a client-side filter layered on top of the server-side
  // Customer/Date/Mobile filters, not another Proc_CallHistory parameter —
  // the summary proc already returns both incoming and outgoing counts
  // together on one row per customer (there's no "give me only incoming"
  // server mode), so "show only Incoming/Outgoing records" is implemented
  // as: keep only the customer rows that actually have a non-zero count
  // for the selected direction. Combines with the existing filters
  // naturally since it filters whatever show() already fetched, the same
  // way the table's own [value] binding already worked.
  readonly callTypeOptions = [
    { label: 'All Calls', value: 'all' as const },
    { label: 'Incoming Calls', value: 'incoming' as const },
    { label: 'Outgoing Calls', value: 'outgoing' as const }
  ];
  // A signal, not a plain property, deliberately — computed() below only
  // re-runs when a SIGNAL it reads changes; a plain property mutated via
  // ngModel wouldn't be tracked as a dependency at all, and displayRows()
  // would keep returning its stale memoized result until something else
  // (rows()) happened to change.
  readonly callTypeFilter = signal<'all' | 'incoming' | 'outgoing'>('all');

  // Call Status is a second, independent client-side filter layered on top
  // of Call Type — each summary row carries answered/missed counts split
  // by direction (answeredIncomingCalls, missedIncomingCalls,
  // answeredOutgoingCalls, missedOutgoingCalls; see
  // support_callsip.py's _get_answered_unanswered_counts) precisely so the
  // two filters combine correctly: "Incoming + Unanswered" must only match
  // customers with a missed INCOMING call, not any missed call regardless
  // of direction.
  readonly callStatusOptions = [
    { label: 'All Calls', value: 'all' as const },
    { label: 'Answered Calls', value: 'answered' as const },
    { label: 'Unanswered Calls', value: 'unanswered' as const }
  ];
  readonly callStatusFilter = signal<'all' | 'answered' | 'unanswered'>('all');

  // Per explicit request: ascending order by First Incoming Call's actual
  // date/time value (not the "dd-MMM-yyyy hh:mm:ss a" text the template
  // displays via DatePipe — sorting that string would put e.g. "01-Jan"
  // after "02-Aug" alphabetically). Applied here, after the existing
  // Call Type/Call Status filters (rows()'s underlying order/calculations
  // are untouched — this only reorders whatever the filter step already
  // produced), so it's automatic on every show()/clearSearch() and every
  // filter change alike, since displayRows() is what the table actually
  // binds to either way.
  readonly displayRows = computed(() => {
    const rows = this.rows();
    const callType = this.callTypeFilter();
    const callStatus = this.callStatusFilter();

    return rows
      .filter((r) => {
        if (callType === 'incoming' && r.noOfIncomingCall === 0) {
          return false;
        }
        if (callType === 'outgoing' && r.noOfOutgoingCall === 0) {
          return false;
        }
        if (callStatus === 'all') {
          return true;
        }
        const { answered, missed } = this.answeredMissedFor(r, callType);
        return callStatus === 'answered' ? answered > 0 : missed > 0;
      })
      .sort((a, b) => CallHistory.firstIncomingTimestamp(a) - CallHistory.firstIncomingTimestamp(b));
  });

  // Rows with no incoming calls at all have an empty firstIncomingCallTime
  // (backend sends null when there's nothing to report — see
  // support-data.service.ts's ?? '' mapping) — +Infinity sorts those
  // consistently to the end in ascending order instead of letting
  // `new Date('').getTime()` (NaN) produce an unstable/undefined ordering.
  private static firstIncomingTimestamp(r: CallHistorySummaryRow): number {
    if (!r.firstIncomingCallTime) {
      return Number.POSITIVE_INFINITY;
    }
    const t = new Date(r.firstIncomingCallTime).getTime();
    return Number.isFinite(t) ? t : Number.POSITIVE_INFINITY;
  }

  // Answered/missed totals scoped to whatever's currently visible — recomputed
  // automatically (computed()) whenever Call Type, Call Status, or the
  // underlying rows change, per explicit "update dynamically whenever the
  // filter or other report filters change" requirement.
  readonly answeredTotal = computed(() => {
    const callType = this.callTypeFilter();
    return this.displayRows().reduce((sum, r) => sum + this.answeredMissedFor(r, callType).answered, 0);
  });

  readonly unansweredTotal = computed(() => {
    const callType = this.callTypeFilter();
    return this.displayRows().reduce((sum, r) => sum + this.answeredMissedFor(r, callType).missed, 0);
  });

  // Direction-scoped answered/missed for one row: within the currently
  // selected Call Type, "All" sums both directions, "Incoming"/"Outgoing"
  // restrict to just that direction's own answered/missed split.
  private answeredMissedFor(
    r: CallHistorySummaryRow,
    callType: 'all' | 'incoming' | 'outgoing'
  ): { answered: number; missed: number } {
    if (callType === 'incoming') {
      return { answered: r.answeredIncomingCalls, missed: r.missedIncomingCalls };
    }
    if (callType === 'outgoing') {
      return { answered: r.answeredOutgoingCalls, missed: r.missedOutgoingCalls };
    }
    return {
      answered: r.answeredIncomingCalls + r.answeredOutgoingCalls,
      missed: r.missedIncomingCalls + r.missedOutgoingCalls
    };
  }

  // Bound two-way ([(first)]) to <p-table> — a plain one-way [first] binding
  // meant PrimeNG's internal pagination offset only ever got INITIALIZED
  // from firstRow, never kept in sync with it: after the user paginated
  // away from page 1, our resetting `firstRow = 0` on a filter/search
  // change was a same-value no-op from Angular's change-detection
  // perspective (it was ALREADY 0 here, since one-way binding never wrote
  // the user's real current offset back into it), so PrimeNG silently kept
  // showing whatever stale page offset it was last on — genuinely blank if
  // the new, smaller filtered result set didn't reach that offset at all.
  // Two-way binding keeps firstRow truthfully in sync with whatever page
  // the user is actually on, so resetting it to 0 here is a real change
  // PrimeNG picks up every time.
  firstRow = 0;

  selectedCustomer: number | null = null;
  fromDate = new Date();
  toDate = new Date();
  mobileNo = '';
  // Two independent search fields, per explicit request — replaces an
  // earlier single auto-detecting search box that searched the internal
  // party's raw UserID instead of their real SIP extension number (see
  // support_callsip.py's _get_sip_extension_lookup for the full story on
  // why those two values genuinely differ). Both are sent alongside the
  // existing Date/Customer/Mobile filters on every show(), not a
  // client-side filter, since neither extension nor executive name exists
  // on the already-fetched summary rows to filter against locally.
  extensionSearch = '';
  executiveSearch = '';

  private readonly customerFilter$ = new Subject<string>();

  ngOnInit(): void {
    this.customersLoading.set(true);
    this.data.getCustomers().subscribe((c) => {
      this.customers.set(c);
      this.customersLoading.set(false);
    });
    this.customerFilter$
      .pipe(debounceTime(300), distinctUntilChanged(), switchMap((q) => this.data.getCustomers(q)))
      .subscribe((c) => this.customers.set(c));

    this.show();
  }

  onCustomerFilter(query: string): void {
    this.customerFilter$.next(query);
  }

  // Feeds the Entity Name -> Call History Details link's date query params.
  // Previously the link used fromDate.toISOString(), which shifts to UTC
  // and keeps whatever time-of-day the Date object holds instead of
  // midnight — SIPEventRegisterCDR.CallDate is always stored at exact
  // midnight, so that shifted, non-midnight timestamp silently failed the
  // backend's CallDate >= @FromDate check and returned zero rows (no
  // error, just an empty details grid). This mirrors the plain
  // yyyy-MM-dd the Summary grid's own request already uses safely.
  dateParam(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  onCallTypeChange(value: 'all' | 'incoming' | 'outgoing'): void {
    this.callTypeFilter.set(value);
    // Same pagination-reset reasoning as show() below — a smaller filtered
    // result set shouldn't leave the paginator sitting on a now out-of-range page.
    this.firstRow = 0;
  }

  onCallStatusChange(value: 'all' | 'answered' | 'unanswered'): void {
    this.callStatusFilter.set(value);
    this.firstRow = 0;
  }

  // Total Call Duration arrives from Proc_CallHistory as plain seconds text
  // (e.g. "1814") — display-only conversion to MM:SS / HH:MM:SS per explicit
  // request; the stored/transmitted value and the rest of the report's logic
  // are untouched, this only changes what's rendered in this one cell.
  formatDuration(totalSecondsText: string): string {
    // Number('') is 0, not NaN — without this check, a missing/empty
    // duration would render as a misleading "00:00" instead of falling
    // through to the raw (empty) value.
    if (!totalSecondsText.trim()) {
      return totalSecondsText;
    }
    const totalSeconds = Number(totalSecondsText);
    if (!Number.isFinite(totalSeconds) || totalSeconds < 0) {
      return totalSecondsText;
    }
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = Math.floor(totalSeconds % 60);
    const pad = (n: number) => String(n).padStart(2, '0');
    return hours > 0 ? `${pad(hours)}:${pad(minutes)}:${pad(seconds)}` : `${pad(minutes)}:${pad(seconds)}`;
  }

  show(): void {
    if (this.loading()) {
      return;
    }
    this.loading.set(true);
    this.loadError.set(null);
    this.firstRow = 0;
    this.data
      .getCallHistorySummary(this.fromDate, this.toDate, this.selectedCustomer ?? 0, this.mobileNo, this.extensionSearch, this.executiveSearch)
      .subscribe({
        next: (rows) => {
          this.rows.set(rows);
          this.loading.set(false);
        },
        error: () => {
          this.loading.set(false);
          this.loadError.set(
            'Could not load call history. This report depends on the SynapseCDR call-log database, which is not currently available on this server.'
          );
        }
      });
  }

  clearSearch(): void {
    this.extensionSearch = '';
    this.executiveSearch = '';
    this.show();
  }
}
