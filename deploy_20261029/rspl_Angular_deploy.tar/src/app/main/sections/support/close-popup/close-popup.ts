import { DatePipe, Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { CallCountRow, LookupOption, SupportDataService } from '../support-data.service';

/**
 * Mirrors Section_Support/ClosePopup.aspx: a RadWindow popup opened from
 * CallHistory/MissedCall to close a SIP CDR event, or (ViewMode=2) to view
 * missed-call retry attempts. query params: ViewMode, ActionstateId,
 * RecordNo, EntityID, mobileno, FromDate, ToDate, Rowindex.
 */
@Component({
  selector: 'app-close-popup',
  imports: [FormsModule, ButtonModule, CheckboxModule, SelectModule, TextareaModule, InputTextModule, TableModule, DatePipe],
  templateUrl: './close-popup.html',
  styleUrl: './close-popup.scss'
})
export class ClosePopup implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(SupportDataService);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly router = inject(Router);
  private readonly location = inject(Location);

  mode: 'view-narration' | 'view-call-count' | 'close' = 'close';
  readonly submitting = signal(false);
  readonly callCounts = signal<CallCountRow[]>([]);
  readonly callCountsLoading = signal(false);
  readonly callCountsError = signal<string | null>(null);
  readonly customers = signal<LookupOption[]>([]);
  readonly showAddDependent = signal(false);

  narration = '';
  preClosedNarration = '';
  addDependent = false;
  customerId: number | null = null;
  mobileNo = '';
  name = '';

  private recordNo = 0;
  private entityId = 0;
  private actionStateId = 0;

  ngOnInit(): void {
    // Reached repeatedly from MissedCall's rows with different
    // RecordNo/EntityID/ViewMode each time — subscribe rather than reading
    // a one-time snapshot so opening this for a different call event while
    // already mounted actually reloads instead of acting on the previous one.
    this.route.queryParamMap.subscribe((q) => {
      this.recordNo = Number(q.get('RecordNo') ?? 0);
      this.entityId = Number(q.get('EntityID') ?? 0);
      this.actionStateId = Number(q.get('ActionstateId') ?? 0);
      this.mobileNo = q.get('mobileno') ?? '';
      this.narration = '';
      this.preClosedNarration = '';
      this.addDependent = false;
      this.customerId = null;
      this.name = '';
      this.callCounts.set([]);
      this.callCountsError.set(null);

      if (q.get('ViewMode') === '1') {
        this.mode = 'view-narration';
        this.data.getEventNarration(this.recordNo).subscribe((text) => {
          this.narration = text;
          this.cdr.markForCheck();
        });
        this.cdr.markForCheck();
        return;
      }
      if (q.get('ViewMode') === '2') {
        this.mode = 'view-call-count';
        this.callCountsLoading.set(true);
        this.data.getCallAttempts(this.entityId, this.mobileNo, q.get('FromDate') ?? '', q.get('ToDate') ?? '').subscribe({
          next: (rows) => {
            this.callCounts.set(rows);
            this.callCountsLoading.set(false);
            this.cdr.markForCheck();
          },
          // Previously had no error path at all — a failed request left the
          // popup showing just the bare table headers with nothing under
          // them, indistinguishable from "no attempts recorded".
          error: () => {
            this.callCountsLoading.set(false);
            this.callCountsError.set('Could not load call attempt details. Please try again.');
            this.cdr.markForCheck();
          }
        });
        this.cdr.markForCheck();
        return;
      }

      this.mode = 'close';
      if (this.actionStateId === 2) {
        this.data.getEventNarration(this.recordNo).subscribe((text) => {
          this.preClosedNarration = text;
          this.cdr.markForCheck();
        });
      }
      // Source hardcoded a 5-userid allow-list for who could add a dependent
      // while closing. Those IDs no longer map to the same people since this
      // app switched databases (2 of the 5 aren't even enabled accounts
      // here) — opened up to every logged-in user per explicit request,
      // rather than trying to maintain a stale, DB-specific allow-list.
      this.showAddDependent.set(true);
      if (this.entityId === 0) {
        this.data.getCustomersForDependent().subscribe((c) => this.customers.set(c));
      }
      this.cdr.markForCheck();
    });
  }

  submit(): void {
    if (!this.recordNo && !this.entityId) {
      alert('Please click on right link');
      return;
    }
    if (this.addDependent) {
      if (!this.mobileNo || !this.name) {
        alert('Please enter details of customer dependent.');
        return;
      }
      if (this.entityId === 0 && !this.customerId) {
        alert('Please select customer name.');
        return;
      }
    }
    if (!this.narration.trim()) {
      alert('Please enter narration.');
      return;
    }
    this.submitting.set(true);
    const custId = this.addDependent ? (this.entityId || this.customerId || 0) : this.entityId;
    this.data.closeEvent(this.recordNo, custId, this.actionStateId, this.narration, this.addDependent, this.mobileNo, this.name).subscribe({
      next: (res) => {
        this.submitting.set(false);
        if (!res.success) {
          alert(res.message);
          return;
        }
        // The source closed the RadWindow and refreshed the parent grid.
        // Previously this just stayed here after a successful save, which
        // looked stuck — go back to the page that opened it (MissedCall /
        // CallHistory, with its own query params like ?Product intact),
        // which reloads its grid on init so the row shows the new state.
        this.goBack();
      },
      // Previously had no error path: a failed request left Submit spinning
      // forever with no message.
      error: () => {
        this.submitting.set(false);
        alert('Could not save. Please try again.');
      }
    });
  }

  private goBack(): void {
    if (window.history.length > 1) {
      this.location.back();
    } else {
      this.router.navigate(['/support/missed-call']);
    }
  }
}
