import { HttpClient, HttpParams, HttpResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, delay, map, of } from 'rxjs';

import { API_BASE_URL } from '../../../shared/api-config';

const BASE = `${API_BASE_URL}/support`;

export interface LookupOption {
  label: string;
  value: number;
}

export interface CustInfoItem {
  field: string;
  description: string;
  // webProc_TTCustInfo's own Action column ('Details' on the Status
  // panel's AMC Date row) — drives the AMC Details button next to it.
  action: string;
}

export interface AmcDetailInfo {
  custId: number;
  softwareName: string;
  amcDueDate: string | null;
  amcAmount: number;
  basicAmcAmt: number;
  assessableValue: number;
  amcPercent: number;
  serviceTax: number;
  gstTax: number;
  cessCharge: number;
  krishiCessCharge: number;
  netAmcValue: number;
  ledgerBalance: number;
  saleDate: string | null;
}

interface ApiAmcDetailInfo {
  cust_id: number;
  software_name: string;
  amc_due_date: string | null;
  amc_amount: number;
  basic_amc_amt: number;
  assessable_value: number;
  amc_percent: number;
  service_tax: number;
  gst_tax: number;
  cess_charge: number;
  krishi_cess_charge: number;
  net_amc_value: number;
  ledger_balance: number;
  sale_date: string | null;
}

function toAmcDetailInfo(r: ApiAmcDetailInfo): AmcDetailInfo {
  return {
    custId: r.cust_id,
    softwareName: r.software_name,
    amcDueDate: r.amc_due_date,
    amcAmount: r.amc_amount,
    basicAmcAmt: r.basic_amc_amt,
    assessableValue: r.assessable_value,
    amcPercent: r.amc_percent,
    serviceTax: r.service_tax,
    gstTax: r.gst_tax,
    cessCharge: r.cess_charge,
    krishiCessCharge: r.krishi_cess_charge,
    netAmcValue: r.net_amc_value,
    ledgerBalance: r.ledger_balance,
    saleDate: r.sale_date
  };
}

export interface IssueDetailRow {
  module: string;
  priority: string;
  whatNext: string;
  issue: string;
  action: string;
  exeVersionNo: string;
  closed: boolean;
  // Set on rows loaded from getTicketDetail() for an Edit — tells
  // updateTicket() whether to UPDATE this row in place (matched by module
  // name, same as the source) or INSERT it as a brand new row. Rows added
  // via the "Add Issue" button in Edit mode never have this set, so they
  // insert as new.
  isExisting?: boolean;
  // The module name as loaded from the server, captured once and left
  // untouched by further edits — lets updateTicket() detect a rename
  // (module !== originalModule) and tell the backend which row to replace.
  originalModule?: string;
  // Mirrors IssueDetail.aspx's RcbClosedby — a UserMaster picker (same
  // list as getUsers()), only relevant while closed is true. Only ever
  // actually lands on TTMaster.closedBy (TTDetails has no such column),
  // and only on whichever save happens to close every issue row on the
  // ticket at once — see the backend's WebProc_AddModifyTTDetails note.
  closedBy?: number | null;
  // Mirrors IssueDetail.aspx's rcbNarration — same getClosedNarrations()
  // list the standalone IssueDetail popup uses, and same TTMaster-level
  // (not per-row) persistence story as closedBy.
  closedNarrationId?: number | null;
  // Display text for closedNarrationId as loaded from the server — since
  // getClosedNarrations() is capped to TOP 100, a ticket's actual saved
  // narration may not be in the freshly-loaded options list. Lets the
  // component splice {label: closedNarrationLabel, value: closedNarrationId}
  // back in so the picker still shows the right text instead of going blank.
  closedNarrationLabel?: string;
  // Set instead of closedNarrationId when the user types a brand new
  // narration rather than picking an existing one — resolved/created
  // server-side (find-or-create against RSPL_TTClosedNarrationMaster) on
  // save. Mutually exclusive with closedNarrationId in practice (the
  // component clears one whenever the other is set).
  closedNarrationNewText?: string | null;
}

export interface TicketDetail {
  custId: number;
  customerName: string;
  receivedBy: number;
  nextPerson: number;
  calledBy: string;
  issues: IssueDetailRow[];
}

export interface TicketSummaryRow {
  voucherNo: number;
  productName: string;
  date: string;
  userName: string;
  closedNarration?: string;
}

export interface AttachmentRow {
  filename: string;
  url: string;
}

interface ApiTicketSummaryRow {
  voucher_no: number;
  product_name: string;
  date: string;
  user_name: string;
  closed_narration?: string | null;
}

function toTicketSummaryRow(r: ApiTicketSummaryRow): TicketSummaryRow {
  return {
    voucherNo: r.voucher_no,
    productName: r.product_name,
    date: r.date,
    userName: r.user_name,
    closedNarration: r.closed_narration ?? undefined
  };
}

export interface TicketHistoryRow {
  voucherNo: number;
  date: string;
  userName: string;
  customerName: string;
  module: string;
  priority: string;
  whatNext: string;
  issue: string;
  action: string;
  closed: boolean;
  closedNarration?: string;
}

interface ApiTicketHistoryRow {
  voucher_no: number;
  date: string;
  user_name: string;
  customer_name: string;
  module: string;
  priority: string;
  what_next: string;
  issue: string;
  action: string;
  closed: boolean;
  closed_narration?: string | null;
}

function toTicketHistoryRow(r: ApiTicketHistoryRow): TicketHistoryRow {
  return {
    voucherNo: r.voucher_no,
    date: r.date,
    userName: r.user_name,
    customerName: r.customer_name,
    module: r.module,
    priority: r.priority,
    whatNext: r.what_next,
    issue: r.issue,
    action: r.action,
    closed: r.closed,
    closedNarration: r.closed_narration ?? undefined
  };
}

interface ApiTicketDetailIssue {
  module: string;
  priority: string;
  what_next: string;
  issue: string;
  action: string;
  exe_version_no: string;
  closed: boolean;
  closed_by: number;
  closed_narration_id: number;
  closed_narration_text: string;
}

interface ApiTicketDetail {
  cust_id: number;
  customer_name: string;
  received_by: number;
  next_person: number;
  called_by: string;
  issues: ApiTicketDetailIssue[];
}

function toTicketDetail(r: ApiTicketDetail): TicketDetail {
  return {
    custId: r.cust_id,
    customerName: r.customer_name,
    receivedBy: r.received_by,
    nextPerson: r.next_person,
    calledBy: r.called_by,
    issues: r.issues.map((i) => ({
      module: i.module,
      priority: i.priority,
      whatNext: i.what_next,
      issue: i.issue,
      action: i.action,
      exeVersionNo: i.exe_version_no,
      closed: i.closed,
      closedBy: i.closed_by || null,
      closedNarrationId: i.closed_narration_id || null,
      closedNarrationLabel: i.closed_narration_text || undefined,
      originalModule: i.module,
      isExisting: true
    }))
  };
}

interface ApiTtActionRow {
  sr_no: number;
  tt_date: string;
  received_by: string;
  issue: string;
  action_id: number;
  action_date: string;
  action_details: string;
  action_by: string;
  action_on: string;
}

interface ApiIssueDetailFull {
  module: string;
  priority: string;
  what_next: string;
  issue: string;
  action: string;
  exe_version_no: string;
  closed: boolean;
  closed_by: number;
  closed_narration_id: number;
  closed_narration_text: string;
}

interface ApiVisitLogRecord {
  log_id: number;
  ref_no: number;
  client_id: number;
  client_representative: string;
  salesman_id: number;
  product_id: number;
  date: string;
  cause_id: number;
  support_reason: string;
  modules: string;
  lock: 0 | 1 | 2 | 3;
  lock_sr_no: string;
  other_modules: string;
  remark: string;
  within_warranty: boolean;
  amc: boolean;
  chargeable: boolean;
  charges: number;
  core_products_tested: boolean;
  reports_tested: boolean;
  client_address: string;
}

function toVisitLogRecord(r: ApiVisitLogRecord): VisitLogRecord {
  return {
    logId: r.log_id,
    refNo: r.ref_no,
    clientId: r.client_id,
    clientRepresentative: r.client_representative,
    salesmanId: r.salesman_id,
    productId: r.product_id,
    date: r.date,
    causeId: r.cause_id,
    supportReason: r.support_reason,
    modules: r.modules,
    lock: r.lock,
    lockSrNo: r.lock_sr_no,
    otherModules: r.other_modules,
    remark: r.remark,
    withinWarranty: r.within_warranty,
    amc: r.amc,
    chargeable: r.chargeable,
    charges: r.charges,
    coreProductsTested: r.core_products_tested,
    reportsTested: r.reports_tested,
    clientAddress: r.client_address
  };
}

interface ApiPendingIssueRow {
  narration: string;
  employee_name: string;
  responded_by: string;
  responded_to: string;
  responded_date: string | null;
  closed: boolean;
  response: string;
}

interface ApiVisitLogRegisterRow {
  log_id: number;
  date: string;
  ref_no: string;
  client_name: string;
  product_name: string;
  cause_of_visit: string;
  support_reason: string;
  modules: string;
  other_modules: string;
  within_warranty: boolean;
  amc: boolean;
  attended_by: string;
  remark: string;
}

interface ApiCallHistorySummaryRow {
  entity_id: number;
  entity_name: string;
  entity_phone: string;
  no_of_incoming_call: number;
  no_of_outgoing_call: number;
  first_incoming_call_time: string | null;
  last_incoming_call_time: string | null;
  total_call_duration: string;
  answered_incoming_calls: number;
  missed_incoming_calls: number;
  answered_outgoing_calls: number;
  missed_outgoing_calls: number;
}

interface ApiCallHistoryDetailRow {
  record_no: number;
  source_name: string;
  call_time: string;
  source_no: string;
  duration: string;
  bill_seconds: number;
  call_type: string;
  received_by: string;
  recording_path: string;
}

interface ApiMissedCallRow {
  record_no: number;
  entity_id: number;
  entity_name: string;
  entity_phone: string;
  call_date: string;
  min_call_time: string;
  call_time: string;
  attempt_count: number;
  executive_name: string;
  amc_amount: number;
  amc_expiry_date: string;
  ledger_balance: number;
  action_state_id: number;
  processed: number;
  software_name: string;
  installed_within_one_month: boolean;
  advance_amc: boolean;
}

interface ApiAmcRow {
  cust_id: number;
  display_name: string;
  area: string;
  city: string;
  mobile_no: string;
  email: string;
  creation_date: string | null;
  ledger_balance: number;
  ledger_group_balance: number;
  action_date: string | null;
  amc_amount: number;
  amc_due_date: string | null;
  action_stage_id: number;
  ass_value: number;
  amc_per: number;
  basic_amc_amt: number;
  service_tax: number;
}

interface ApiAmcCoordPendingRow {
  action_date: string | null;
  customer: string;
  action_taken_by: string;
  action_on: string;
  action_description: string;
  action_remark: string;
  cust_id: number;
}

interface ApiAmcCoordAmcRow {
  cust_id: number;
  mobile_no: string;
  area: string;
  customer: string;
  amc_per: number;
  expiry_date: string | null;
  city: string;
  assessable_amt: number;
  last_letter_date: string | null;
  last_letter_value: number;
  last_letter_no: number;
  tt_after_expiry: number;
  calls_after_expiry: number;
}

interface ApiAmcActionRow {
  action_id: number;
  creation_date: string | null;
  creation_time: string;
  follow_up_by: string;
  follow_up_remark: string;
  completion_date: string;
  completion_time: string;
  completed_by: string;
  assigned_to: string;
  action_description: string;
  action_remark: string;
  next_action: string;
}

interface ApiEinvoiceStatusRow {
  cust_id: number;
  customer_name: string;
  date: string | null;
  response: string;
}

interface ApiTtModifyRow {
  tt_no: number;
  name: string;
  date: string | null;
  description: string;
  rw_remarks: string;
  latest_owner: string;
  priority: string;
  internal_dead_line: string | null;
  product_name: string;
  status: string;
  internal_reference_user: string;
}

interface ApiVideoHistoryRow {
  menu_id: number;
  sr_no: number;
  menu_name: string;
  video_description: string;
  client: string;
  date: string | null;
  video_link_url: string;
  video_training_mode_status: string;
  user_name: string;
  counter_name: string;
}

function toVisitLogRegisterRow(r: ApiVisitLogRegisterRow): VisitLogRegisterRow {
  return {
    logId: r.log_id,
    date: r.date,
    refNo: r.ref_no,
    clientName: r.client_name,
    productName: r.product_name,
    causeOfVisit: r.cause_of_visit,
    supportReason: r.support_reason,
    modules: r.modules,
    otherModules: r.other_modules,
    withinWarranty: r.within_warranty,
    amc: r.amc,
    attendedBy: r.attended_by,
    remark: r.remark
  };
}

export interface VisitLogRecord {
  logId: number;
  refNo: number;
  clientId: number;
  clientRepresentative: string;
  salesmanId: number;
  productId: number;
  date: string;
  causeId: number;
  supportReason: string;
  modules: string;
  lock: 0 | 1 | 2 | 3; // 0=Present, 1=Delivered, 2=NotPresent, 3=No hardware lock
  lockSrNo: string;
  otherModules: string;
  remark: string;
  withinWarranty: boolean;
  amc: boolean;
  chargeable: boolean;
  charges: number;
  coreProductsTested: boolean;
  reportsTested: boolean;
  clientAddress: string;
}

export interface PendingIssueRow {
  narration: string;
  employeeName: string;
  respondedBy: string;
  respondedTo: string;
  respondedDate: string;
  closed: boolean;
  response: string;
}

export interface CallCountRow {
  attemptTime: string;
  duration: string;
  status: string;
}

export interface CallHistorySummaryRow {
  entityId: number;
  entityName: string;
  // Always populated — needed for the "unregistered number" rows (entityId
  // 0, entityName "Unregistered"; see support_callsip.py's 2026-08-04
  // update note) since they have no real entity to key the Call History
  // Details drill-down link off of; that link falls back to matching by
  // this number instead.
  entityPhone: string;
  noOfIncomingCall: number;
  noOfOutgoingCall: number;
  firstIncomingCallTime: string;
  lastIncomingCallTime: string;
  totalCallDuration: string;
  answeredIncomingCalls: number;
  missedIncomingCalls: number;
  answeredOutgoingCalls: number;
  missedOutgoingCalls: number;
}

export interface CallHistoryDetailRow {
  recordNo: number;
  sourceName: string;
  callTime: string;
  sourceNo: string;
  duration: string;
  billSeconds: number;
  callType: string;
  receivedBy: string;
  recordingPath: string;
}

export interface MissedCallRow {
  recordNo: number;
  entityId: number;
  entityName: string;
  entityPhone: string;
  callDate: string;
  minCallTime: string;
  callTime: string;
  attemptCount: number;
  executiveName: string;
  amcAmount: number;
  amcExpiryDate: string;
  ledgerBalance: number;
  actionStateId: number;
  processed: number;
  softwareName: string;
  installedWithinOneMonth: boolean;
  advanceAmc: boolean;
}

/** Mirrors Modules.aspx.vb's DisplayInfo — one grid, many shapes keyed by ?FieldName=. */
export type ModulesFieldName = 'Modules' | 'Invoices' | 'VisitLog' | 'AMCDate' | 'ViewAction' | 'Notification' | 'ExeVersion';

/** Mirrors clsDBLayer calls from Section_Support/TroubleTicket.aspx.vb (webProc_TTDetails, webProc_TTCustInfo, WebProc_AddTTMaster). */
@Injectable({ providedIn: 'root' })
export class SupportDataService {
  private readonly http = inject(HttpClient);

  /** Top 100, re-queried by name as the user types — same load-on-demand shape as Advance's customer picker. */
  getCustomers(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/customers`, { params: { search } });
  }

  getSalesmen(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/salesmen`);
  }

  getNextPersons(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/next-persons`);
  }

  getUsers(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/users`);
  }

  getCustomerInfo(custId: number): Observable<{ general: CustInfoItem[]; status: CustInfoItem[]; report: CustInfoItem[]; disabled: boolean }> {
    const params = new HttpParams().set('cust_id', custId);
    return this.http.get<{ general: CustInfoItem[]; status: CustInfoItem[]; report: CustInfoItem[]; disabled: boolean }>(`${BASE}/customer-info`, { params });
  }

  /** Feeds the "Details" button next to the Status panel's AMC Date row (CustInfoItem.action === 'Details'). */
  getAmcDetails(custId: number): Observable<AmcDetailInfo | null> {
    const params = new HttpParams().set('cust_id', custId);
    return this.http.get<ApiAmcDetailInfo | null>(`${BASE}/amc-details`, { params }).pipe(map((r) => (r ? toAmcDetailInfo(r) : null)));
  }

  getPendingTickets(custId: number): Observable<TicketSummaryRow[]> {
    const params = new HttpParams().set('cust_id', custId);
    return this.http.get<ApiTicketSummaryRow[]>(`${BASE}/pending-tickets`, { params }).pipe(map((rows) => rows.map(toTicketSummaryRow)));
  }

  getClosedTickets(custId: number): Observable<TicketSummaryRow[]> {
    const params = new HttpParams().set('cust_id', custId);
    return this.http.get<ApiTicketSummaryRow[]>(`${BASE}/closed-tickets`, { params }).pipe(map((rows) => rows.map(toTicketSummaryRow)));
  }

  /** Feeds the Edit-mode Ticket No. picker — pending (unclosed) tickets across all customers, not just the currently selected one. */
  getAllPendingTickets(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/pending-tickets/all`);
  }

  /** Ticket History panel's TT Number search — every issue/action row for tickets matching ttNo (partial or full), across all customers. */
  searchTicketHistory(ttNo: string): Observable<TicketHistoryRow[]> {
    const params = new HttpParams().set('tt_no', ttNo);
    return this.http.get<ApiTicketHistoryRow[]>(`${BASE}/ticket-history/search`, { params }).pipe(map((rows) => rows.map(toTicketHistoryRow)));
  }

  /** Fetches an existing ticket's master + issue-detail rows to auto-populate the form when a Ticket No. is selected in Edit mode. */
  getTicketDetail(ttNo: number): Observable<TicketDetail | null> {
    return this.http.get<ApiTicketDetail | null>(`${BASE}/tickets/${ttNo}`).pipe(map((r) => (r ? toTicketDetail(r) : null)));
  }

  updateTicket(ttNo: number, calledBy: string, issues: IssueDetailRow[]): Observable<{ voucherNo: number; message: string }> {
    return this.http.put<{ voucherNo: number; message: string }>(`${BASE}/tickets/${ttNo}`, {
      called_by: calledBy,
      issues: issues.map((i) => ({
        module: i.module,
        priority: i.priority,
        what_next: i.whatNext,
        issue: i.issue,
        action: i.action,
        exe_version_no: i.exeVersionNo,
        closed: i.closed,
        closed_by: i.closedBy ?? 0,
        closed_narration_id: i.closedNarrationId ?? 0,
        closed_narration_text: i.closedNarrationNewText?.trim() || undefined,
        is_existing: i.isExisting ?? false,
        original_module: i.originalModule ?? null
      }))
    });
  }

  createTicket(custId: number, receivedBy: number, nextPerson: number, calledBy: string, issues: IssueDetailRow[]): Observable<{ voucherNo: number; message: string }> {
    return this.http
      .post<{ voucherNo: number; message: string }>(`${BASE}/tickets`, {
        cust_id: custId,
        received_by: receivedBy,
        next_person: nextPerson,
        called_by: calledBy,
        issues: issues.map((i) => ({
          module: i.module,
          priority: i.priority,
          what_next: i.whatNext,
          issue: i.issue,
          action: i.action,
          exe_version_no: i.exeVersionNo,
          closed: i.closed,
          closed_by: i.closedBy ?? 0,
          closed_narration_id: i.closedNarrationId ?? 0,
          closed_narration_text: i.closedNarrationNewText?.trim() || undefined
        }))
      });
  }

  // Backend returns `url` as a path relative to the API host (e.g.
  // "/support/tickets/123/attachments/photo.png") — resolved against
  // API_BASE_URL here, not BASE (which already has "/support" baked in and
  // would double it up). Left unresolved, [href]="row.url" in a template
  // would silently resolve against the ANGULAR APP's own origin instead of
  // the API's, since they run on different ports.
  private toAbsoluteAttachment(row: { filename: string; url: string }): AttachmentRow {
    return { filename: row.filename, url: `${API_BASE_URL}${row.url}` };
  }

  /** Mirrors TroubleTicket.aspx.vb's UploadFiles — see support.py's module docstring for the full storage-location writeup. */
  getAttachments(voucherNo: number): Observable<AttachmentRow[]> {
    const params = new HttpParams().set('voucher_no', voucherNo);
    return this.http
      .get<AttachmentRow[]>(`${BASE}/attachments`, { params })
      .pipe(map((rows) => rows.map((r) => this.toAbsoluteAttachment(r))));
  }

  uploadAttachments(voucherNo: number, files: File[]): Observable<AttachmentRow[]> {
    const form = new FormData();
    for (const file of files) {
      form.append('files', file, file.name);
    }
    return this.http
      .post<AttachmentRow[]>(`${BASE}/tickets/${voucherNo}/attachments`, form)
      .pipe(map((rows) => rows.map((r) => this.toAbsoluteAttachment(r))));
  }


  // Every lookup below used to load its full unbounded list on every page
  // visit — Products (2,222 rows), CauseMaster (219), the free-text
  // SupportReason history (5,700 distinct values), VisitLogMaster's log
  // IDs (23,615), and Client Name (CustDependents, 86,433 rows). All five
  // now take an optional `search` and are capped to the top 100 server-side.
  // `id` resolves one specific option regardless of the top-100/search
  // window — used when loading an existing record for Modify, since that
  // record's referenced row may not appear in either.
  getVisitLogProducts(search = '', id = 0): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/visit-log/products`, { params: { search, id } });
  }

  getVisitLogCauses(search = '', id = 0): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/visit-log/causes`, { params: { search, id } });
  }

  getSupportReasons(search = ''): Observable<string[]> {
    return this.http.get<string[]>(`${BASE}/visit-log/support-reasons`, { params: { search } });
  }

  getVisitLogClients(search = '', id = 0): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/visit-log/clients`, { params: { search, id } });
  }

  getClientAddress(clientId: number): Observable<string> {
    const params = new HttpParams().set('client_id', clientId);
    return this.http.get<string>(`${BASE}/visit-log/client-address`, { params });
  }

  getLastLogId(): Observable<number | null> {
    return this.http.get<number | null>(`${BASE}/visit-log/last-log-id`);
  }

  getLogIds(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/visit-log/log-ids`, { params: { search } });
  }

  getVisitLog(logId: number): Observable<VisitLogRecord | null> {
    return this.http.get<ApiVisitLogRecord | null>(`${BASE}/visit-log/${logId}`).pipe(map((r) => (r ? toVisitLogRecord(r) : null)));
  }

  saveVisitLog(record: VisitLogRecord, isNew: boolean): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/visit-log`, {
      record: {
        log_id: record.logId,
        ref_no: record.refNo,
        client_id: record.clientId,
        client_representative: record.clientRepresentative,
        salesman_id: record.salesmanId,
        product_id: record.productId,
        date: record.date,
        cause_id: record.causeId,
        support_reason: record.supportReason,
        modules: record.modules,
        lock: record.lock,
        lock_sr_no: record.lockSrNo,
        other_modules: record.otherModules,
        remark: record.remark,
        within_warranty: record.withinWarranty,
        amc: record.amc,
        chargeable: record.chargeable,
        charges: record.charges,
        core_products_tested: record.coreProductsTested,
        reports_tested: record.reportsTested,
        client_address: record.clientAddress
      },
      is_new: isNew
    });
  }

  getPendingIssues(logId: number): Observable<PendingIssueRow[]> {
    return this.http.get<ApiPendingIssueRow[]>(`${BASE}/visit-log/${logId}/pending-issues`).pipe(
      map((rows) =>
        rows.map((r) => ({
          narration: r.narration,
          employeeName: r.employee_name,
          respondedBy: r.responded_by,
          respondedTo: r.responded_to,
          respondedDate: r.responded_date ?? '',
          closed: r.closed,
          response: r.response
        }))
      )
    );
  }

  /** Mirrors ClosePopup.aspx.vb's Showdata (readonly narration) for ViewMode=1. NOTE: reads SynapseCDR — not testable, see support_callsip.py module docstring. */
  getEventNarration(recordNo: number): Observable<string> {
    const params = new HttpParams().set('record_no', recordNo);
    return this.http.get<string>(`${BASE}/close-popup/narration`, { params });
  }

  /**
   * Mirrors ClosePopup.aspx.vb's ShowCallCount for ViewMode=2 — fetches this
   * customer's full missed-call attempt history. Was keyed off a single
   * RecordNo (proc_SIPMissCallAttemptList resolved direction/entity from just
   * that one record), now keyed off EntityID/mobileNo directly so it covers
   * that customer's whole history in both call directions instead of
   * whichever one the single RecordNo happened to represent (see
   * get_call_attempts's own docstring in support_callsip.py for the full
   * story — confirmed live this was silently dropping data for real
   * customers, not just an edge case).
   */
  getCallAttempts(entityId: number, mobileNo: string, fromDate: string, toDate: string): Observable<CallCountRow[]> {
    const params = new HttpParams()
      .set('entity_id', entityId)
      .set('mobile_no', mobileNo)
      .set('from_date', fromDate)
      .set('to_date', toDate);
    return this.http.get<CallCountRow[]>(`${BASE}/close-popup/call-attempts`, { params });
  }

  /** Mirrors ClosePopup.aspx.vb's btnSave_Click (WebProc_UpdateSIPEventRegisterCDR). NOTE: reads/writes SynapseCDR — not testable. */
  closeEvent(recordNo: number, custId: number, actionStateId: number, narration: string, addDependent: boolean, mobileNo: string, name: string): Observable<{ success: boolean; message: string }> {
    return this.http.post<{ success: boolean; message: string }>(`${BASE}/close-popup/close`, {
      record_no: recordNo,
      cust_id: custId,
      action_state_id: actionStateId,
      narration,
      add_dependent: addDependent,
      mobile_no: mobileNo,
      name
    });
  }

  getCustomersForDependent(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/customers`);
  }

  /** Mirrors AttachmentDownload.aspx.vb — lists files under Uploads/{logid}. */
  getUploadedFiles(logId: number): Observable<string[]> {
    return of([]).pipe(delay(150));
  }

  /** Mirrors CallHistory.aspx.vb / CallHistoryDetails.aspx.vb — Proc_CallHistory (Summary=1 vs Detail=0). NOTE: reads SynapseCDR — not testable. */
  getCallHistorySummary(
    fromDate: Date,
    toDate: Date,
    customerId: number,
    mobileNo: string,
    extensionSearch: string = '',
    executiveSearch: string = ''
  ): Observable<CallHistorySummaryRow[]> {
    const params = new HttpParams()
      .set('from_date', this.toDateParam(fromDate))
      .set('to_date', this.toDateParam(toDate))
      .set('customer_id', customerId)
      .set('mobile_no', mobileNo)
      .set('extension_search', extensionSearch)
      .set('executive_search', executiveSearch);
    return this.http.get<ApiCallHistorySummaryRow[]>(`${BASE}/call-history/summary`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          entityId: r.entity_id,
          entityName: r.entity_name,
          entityPhone: r.entity_phone,
          noOfIncomingCall: r.no_of_incoming_call,
          noOfOutgoingCall: r.no_of_outgoing_call,
          firstIncomingCallTime: r.first_incoming_call_time ?? '',
          lastIncomingCallTime: r.last_incoming_call_time ?? '',
          totalCallDuration: r.total_call_duration,
          answeredIncomingCalls: r.answered_incoming_calls,
          missedIncomingCalls: r.missed_incoming_calls,
          answeredOutgoingCalls: r.answered_outgoing_calls,
          missedOutgoingCalls: r.missed_outgoing_calls
        }))
      )
    );
  }

  /** SynapseCDR-backed — confirmed live and working (see support_callsip.py's module docstring). */
  getCallHistoryDetail(fromDate: string, toDate: string, entityId: number, mobileNo: string): Observable<CallHistoryDetailRow[]> {
    const params = new HttpParams().set('from_date', fromDate).set('to_date', toDate).set('entity_id', entityId).set('mobile_no', mobileNo);
    return this.http.get<ApiCallHistoryDetailRow[]>(`${BASE}/call-history/detail`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          recordNo: r.record_no,
          sourceName: r.source_name,
          callTime: r.call_time,
          sourceNo: r.source_no,
          duration: r.duration,
          billSeconds: r.bill_seconds,
          callType: r.call_type,
          receivedBy: r.received_by,
          recordingPath: r.recording_path
        }))
      )
    );
  }

  // Downloads via HttpClient (not a plain <a href>) for two reasons: (1) the
  // JWT bearer token this app uses for auth is only ever attached by
  // auth.interceptor.ts to HttpClient requests, never to a raw browser
  // navigation — a plain link to this endpoint would just 401; (2) the
  // backend proxies the recording server-side specifically so this becomes
  // a same-origin blob response with a real Content-Disposition: attachment
  // header, guaranteeing a reliable forced download in every browser
  // regardless of what the upstream PBX server itself sends (it sends
  // neither Content-Disposition nor CORS headers — see support_callsip.py's
  // download_call_recording docstring).
  // observe: 'response' (not the plain Blob body) so the component can read
  // the real filename back out of Content-Disposition rather than inventing
  // its own — see main.py's CORS expose_headers, required for this header
  // to actually be readable cross-origin.
  downloadCallRecording(recordNo: number): Observable<HttpResponse<Blob>> {
    return this.http.get(`${BASE}/call-recording/download`, {
      params: new HttpParams().set('record_no', recordNo),
      responseType: 'blob',
      observe: 'response'
    });
  }

  /** Mirrors WebProc_SIPMissedCalls (?Product=Retailware|Jewelsoft|Marketing|DONAR MANAGEMENT SYSTEM). NOTE: reads SynapseCDR — not testable. */
  getMissedCalls(product: string, fromDate: Date, toDate: Date): Observable<MissedCallRow[]> {
    const params = new HttpParams().set('product', product).set('from_date', this.toDateParam(fromDate)).set('to_date', this.toDateParam(toDate));
    return this.http.get<ApiMissedCallRow[]>(`${BASE}/missed-calls`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          recordNo: r.record_no,
          entityId: r.entity_id,
          entityName: r.entity_name,
          entityPhone: r.entity_phone,
          callDate: r.call_date,
          minCallTime: r.min_call_time,
          callTime: r.call_time,
          attemptCount: r.attempt_count,
          executiveName: r.executive_name,
          amcAmount: r.amc_amount,
          amcExpiryDate: r.amc_expiry_date,
          ledgerBalance: r.ledger_balance,
          actionStateId: r.action_state_id,
          processed: r.processed,
          softwareName: r.software_name,
          installedWithinOneMonth: r.installed_within_one_month,
          advanceAmc: r.advance_amc
        }))
      )
    );
  }

  /**
   * Mirrors MissedCall.aspx.vb's lnkbtnattempt_Click, which does
   * `UPDATE synapsecdr.dbo.SIPEventRegisterCDR SET ExecutiveName=...`.
   * SynapseCDR now exists on this instance (confirmed live via
   * sys.databases — it didn't when this was first stubbed as an
   * always-succeeds no-op), so this now calls the real endpoint.
   * phoneNo isn't needed by the write itself (only RecordNo + the executive
   * name are), kept in the signature so missed-call.ts's attempt() call site
   * didn't need to change.
   */
  attemptCall(recordNo: number, phoneNo: string, executiveName: string): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/missed-calls/attempt`, {
      record_no: recordNo,
      executive_name: executiveName
    });
  }

  getAmcProducts(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/amc/products`);
  }

  /** AMC Followup Customer Name type-ahead (names present in VWAMCForAllCustomers). */
  searchAmcCustomers(q: string): Observable<string[]> {
    return this.http.get<string[]>(`${BASE}/amc/customer-search`, { params: { q } });
  }

  /** Mirrors VWAMCForAllCustomers (FromMenu=AMCPending) / WebProc_GetLastAMCAction (FromMenu=AMCLastAction). */
  getAmcRows(
    mode: 'AMCPending' | 'AMCLastAction',
    filters: {
      customer?: string;
      productId?: number | null;
      sign?: string;
      amount?: string;
      fromExpiryDate?: Date | null;
      toExpiryDate?: Date | null;
      userId?: number | null;
      limit?: number;
    }
  ): Observable<AmcRow[]> {
    let params = new HttpParams().set('mode', mode);
    if (filters.customer) {
      params = params.set('customer', filters.customer);
    }
    if (filters.productId) {
      params = params.set('product_id', filters.productId);
    }
    if (filters.sign) {
      params = params.set('sign', filters.sign);
    }
    if (filters.amount) {
      params = params.set('amount', filters.amount);
    }
    if (filters.fromExpiryDate) {
      params = params.set('from_expiry_date', this.toDateParam(filters.fromExpiryDate));
    }
    if (filters.toExpiryDate) {
      params = params.set('to_expiry_date', this.toDateParam(filters.toExpiryDate));
    }
    if (filters.userId) {
      params = params.set('user_id', filters.userId);
    }
    if (filters.limit) {
      params = params.set('limit', filters.limit);
    }
    return this.http.get<ApiAmcRow[]>(`${BASE}/amc/rows`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          custId: r.cust_id,
          displayName: r.display_name,
          area: r.area,
          city: r.city,
          mobileNo: r.mobile_no,
          email: r.email,
          creationDate: r.creation_date ?? '',
          ledgerBalance: r.ledger_balance,
          ledgerGroupBalance: r.ledger_group_balance,
          actionDate: r.action_date ?? '',
          amcAmount: r.amc_amount,
          amcDueDate: r.amc_due_date ?? '',
          actionStageId: r.action_stage_id,
          assValue: r.ass_value,
          amcPer: r.amc_per,
          basicAmcAmt: r.basic_amc_amt,
          serviceTax: r.service_tax
        }))
      )
    );
  }

  /** Mirrors Modules.aspx.vb's DisplayInfo — one grid, many shapes keyed by ?FieldName=. NOTE: ExeVersion shape reads [License] linked server — not testable, see support_modules.py module docstring. */
  getModulesData(fieldName: ModulesFieldName, custId: number): Observable<{ title: string; rows: Record<string, unknown>[] }> {
    const params = new HttpParams().set('field_name', fieldName).set('cust_id', custId);
    return this.http.get<{ title: string; rows: Record<string, unknown>[] }>(`${BASE}/modules-data`, { params });
  }

  /** NOTE: reads [License] linked server — not testable, see support_modules.py module docstring. */
  getPiratedModules(custId: number): Observable<Record<string, unknown>[]> {
    const params = new HttpParams().set('cust_id', custId);
    return this.http.get<Record<string, unknown>[]>(`${BASE}/pirated-modules`, { params });
  }

  /** Mirrors CustDependent.aspx.vb (webProc_GetCustDepdetails). */
  getCustomerDependents(custId: number): Observable<{ name: string; mobileNo: string; email: string }[]> {
    const params = new HttpParams().set('cust_id', custId);
    return this.http.get<{ name: string; mobile_no: string; email: string }[]>(`${BASE}/customer-dependents`, { params }).pipe(
      map((rows) => rows.map((r) => ({ name: r.name, mobileNo: r.mobile_no, email: r.email })))
    );
  }

  // New capability, not present in the source's read-only CustDependent.aspx
  // — see support_modules.py's add_customer_dependent docstring for the
  // reused duplicate-mobile-check/DepID-assignment logic this is built on.
  addCustomerDependent(custId: number, name: string, mobileNo: string, email: string): Observable<{ success: boolean; message: string }> {
    return this.http.post<{ success: boolean; message: string }>(`${BASE}/customer-dependents`, {
      cust_id: custId,
      name,
      mobile_no: mobileNo,
      email
    });
  }

  /** Mirrors EinvoiceStatus.aspx.vb (vw_web_Einvoice). NOTE: reads [License] linked server — not testable, see support_modules.py module docstring. */
  getEinvoiceStatus(custId: number): Observable<{ custId: number; customerName: string; date: string; response: string }[]> {
    const params = new HttpParams().set('cust_id', custId);
    return this.http.get<ApiEinvoiceStatusRow[]>(`${BASE}/einvoice-status`, { params }).pipe(
      map((rows) => rows.map((r) => ({ custId: r.cust_id, customerName: r.customer_name, date: r.date ?? '', response: r.response })))
    );
  }

  /** Mirrors PayBank.aspx.vb (webProc_GetPayBankDetails / webproc_InsertPayBankMaster / Proc_AddModifyCustAttribute). */
  getBankCards(custId: number): Observable<{ options: LookupOption[]; checked: number[] }> {
    const params = new HttpParams().set('cust_id', custId);
    return this.http.get<{ options: LookupOption[]; checked: number[] }>(`${BASE}/bank-cards`, { params });
  }

  addBankCard(name: string): Observable<{ success: boolean }> {
    const params = new HttpParams().set('name', name);
    return this.http.post<{ success: boolean }>(`${BASE}/bank-cards`, null, { params });
  }

  saveCustBankCards(custId: number, checkedValues: number[]): Observable<{ success: boolean; message: string }> {
    return this.http.post<{ success: boolean; message: string }>(`${BASE}/bank-cards/apply`, {
      cust_id: custId,
      checked_values: checkedValues
    });
  }

  /** Mirrors CustAMCFollowUp.aspx.vb's btnSubmit_Click (webProc_AddEnquiryAction, ActionStageID=18). */
  addAmcFollowUp(custId: number, followUpBy: number, followUpDate: Date, followUpTime: string, contactPerson: string, remark: string): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/amc/followup`, {
      cust_id: custId,
      follow_up_by: followUpBy,
      follow_up_date: this.toDateParam(followUpDate),
      follow_up_time: followUpTime,
      contact_person: contactPerson,
      remark
    });
  }

  getLedgerGroups(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/amc/ledger-groups`);
  }

  /** Mirrors AMCCo-OrdinatorDashBoard.aspx.vb's rcbActionOn source (distinct AssignedTo users on Web_EnquiryAction) — real values are names, not synthetic IDs. */
  getAmcCoordActionOnUsers(): Observable<string[]> {
    return this.http.get<string[]>(`${BASE}/amc/coord/action-on-users`);
  }

  /** Mirrors AMCCo-OrdinatorDashBoard.aspx.vb's fillgrid() for rcbReportName="AMC Pending Action" (Web_EnquiryAction, ActionStageId=18). */
  getAmcCoordPendingRows(filters: { actionOn?: string; remark?: string; customer?: string }): Observable<AmcCoordPendingRow[]> {
    let params = new HttpParams();
    if (filters.actionOn) {
      params = params.set('action_on', filters.actionOn);
    }
    if (filters.remark) {
      params = params.set('remark', filters.remark);
    }
    if (filters.customer) {
      params = params.set('customer', filters.customer);
    }
    return this.http.get<ApiAmcCoordPendingRow[]>(`${BASE}/amc/coord/pending`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          actionDate: r.action_date ?? '',
          customer: r.customer,
          actionTakenBy: r.action_taken_by,
          actionOn: r.action_on,
          actionDescription: r.action_description,
          actionRemark: r.action_remark,
          custId: r.cust_id
        }))
      )
    );
  }

  /** Mirrors AMCCo-OrdinatorDashBoard.aspx.vb's fillgrid() for rcbReportName="AMC" (Web_View_CustomerAMCList). */
  getAmcCoordAmcRows(filters: {
    productId?: number | null;
    ledgerGroupId?: number | null;
    fromExpiryDate?: Date | null;
    toExpiryDate?: Date | null;
    customer?: string;
  }): Observable<AmcCoordAmcRow[]> {
    let params = new HttpParams();
    if (filters.productId) {
      params = params.set('product_id', filters.productId);
    }
    if (filters.ledgerGroupId) {
      params = params.set('ledger_group_id', filters.ledgerGroupId);
    }
    if (filters.fromExpiryDate) {
      params = params.set('from_expiry_date', this.toDateParam(filters.fromExpiryDate));
    }
    if (filters.toExpiryDate) {
      params = params.set('to_expiry_date', this.toDateParam(filters.toExpiryDate));
    }
    if (filters.customer) {
      params = params.set('customer', filters.customer);
    }
    return this.http.get<ApiAmcCoordAmcRow[]>(`${BASE}/amc/coord/amc-rows`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          custId: r.cust_id,
          mobileNo: r.mobile_no,
          area: r.area,
          customer: r.customer,
          amcPer: r.amc_per,
          expiryDate: r.expiry_date ?? '',
          city: r.city,
          assessableAmt: r.assessable_amt,
          lastLetterDate: r.last_letter_date ?? '',
          lastLetterValue: r.last_letter_value,
          lastLetterNo: r.last_letter_no,
          ttAfterExpiry: r.tt_after_expiry,
          callsAfterExpiry: r.calls_after_expiry
        }))
      )
    );
  }

  /** Mirrors Web_EnquiryActionStage (used by AddNewAction.aspx's ddlActionStage/2/3). */
  getActionStages(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/amc/action-stages`);
  }

  /** Mirrors Web_LittleMaster join on the selected stage's ActionStageStatusMaster. */
  getActionStageStatuses(actionStageId: number): Observable<LookupOption[]> {
    const params = new HttpParams().set('action_stage_id', actionStageId);
    return this.http.get<LookupOption[]>(`${BASE}/amc/action-stage-statuses`, { params });
  }

  /** Mirrors AddNewAction.aspx.vb's btnAddAction_Click (webProc_AddEnquiryAction). */
  addEnquiryAction(payload: {
    custId: number;
    refActionId: number;
    actionStageId: number;
    actionDate: Date;
    actionTime: string;
    description: string;
    assignedTo: number;
    remark: string;
    closeAction: boolean;
    salesPersonId: number;
    actionStageStatusId: number;
  }): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/amc/enquiry-action`, {
      cust_id: payload.custId,
      ref_action_id: payload.refActionId,
      action_stage_id: payload.actionStageId,
      action_date: this.toDateParam(payload.actionDate),
      action_time: payload.actionTime,
      description: payload.description,
      assigned_to: payload.assignedTo,
      remark: payload.remark,
      close_action: payload.closeAction,
      sales_person_id: payload.salesPersonId,
      action_stage_status_id: payload.actionStageStatusId
    });
  }

  /** Mirrors AddNewAction.aspx.vb's btnCloseAction_Click (webProc_CloseEnquiryAction, + optional chained webProc_AddEnquiryAction). */
  closeEnquiryAction(payload: {
    custId: number;
    refActionId: number;
    completedBy: number;
    completedDate: Date;
    completedTime: string;
    salesmanId: number;
    narration: string;
    actionStageId: number;
    addNewAction?: {
      actionStageId: number;
      actionDate: Date;
      actionTime: string;
      description: string;
      assignedTo: number;
      remark: string;
      salesPersonId: number;
      actionStageStatusId: number;
    };
  }): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/amc/enquiry-action/close`, {
      cust_id: payload.custId,
      ref_action_id: payload.refActionId,
      completed_by: payload.completedBy,
      completed_date: this.toDateParam(payload.completedDate),
      completed_time: payload.completedTime,
      salesman_id: payload.salesmanId,
      narration: payload.narration,
      action_stage_id: payload.actionStageId,
      add_new_action: payload.addNewAction
        ? {
            action_stage_id: payload.addNewAction.actionStageId,
            action_date: this.toDateParam(payload.addNewAction.actionDate),
            action_time: payload.addNewAction.actionTime,
            description: payload.addNewAction.description,
            assigned_to: payload.addNewAction.assignedTo,
            remark: payload.addNewAction.remark,
            sales_person_id: payload.addNewAction.salesPersonId,
            action_stage_status_id: payload.addNewAction.actionStageStatusId
          }
        : null
    });
  }

  /** Mirrors TTAction.aspx.vb's ShowTTNo (webProc_TTDetails, DisplayName/Issue only). */
  getTicketBrief(ttNo: number): Observable<{ customer: string; issue: string } | null> {
    return this.http.get<{ customer: string; issue: string } | null>(`${BASE}/tt-action/brief/${ttNo}`);
  }

  /** Mirrors TTAction.aspx.vb's btnSave_Click (webproc_AddTTAction). */
  addTtAction(payload: {
    ttNo: number;
    actionDetails: string;
    actionTakenBy: number;
    callBack: boolean;
    actionOn: number;
    callBackDate: Date;
    callBackTime: string;
  }): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/tt-action`, {
      tt_no: payload.ttNo,
      action_details: payload.actionDetails,
      action_taken_by: payload.actionTakenBy,
      call_back: payload.callBack,
      action_on: payload.actionOn,
      call_back_date: this.toDateParam(payload.callBackDate),
      call_back_time: payload.callBackTime
    });
  }

  /** Mirrors TTAction.aspx.vb's ShowActions (webproc_GetTTAction). */
  getTtActions(ttNo: number, custId: number): Observable<TtActionRow[]> {
    const params = new HttpParams().set('tt_no', ttNo).set('cust_id', custId);
    return this.http.get<ApiTtActionRow[]>(`${BASE}/tt-action/history`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          srNo: r.sr_no,
          ttDate: r.tt_date,
          receivedBy: r.received_by,
          issue: r.issue,
          actionId: r.action_id,
          actionDate: r.action_date,
          actionDetails: r.action_details,
          actionBy: r.action_by,
          actionOn: r.action_on
        }))
      )
    );
  }

  /** Mirrors IssueDetail.aspx.vb's rcbPriority source (distinct TTDetails.Priority). */
  getPriorities(): Observable<string[]> {
    return this.http.get<string[]>(`${BASE}/priorities`);
  }

  /** Distinct TTProducts.ProductName — the maintained module/feature list for the Module field (TTDetails.ProductName itself is unfiltered free text, not usable as a picklist). */
  getModules(): Observable<string[]> {
    return this.http.get<string[]>(`${BASE}/modules`);
  }

  /** Mirrors RSPL_TTClosedNarrationMaster. Top 100, re-queried by text as the user types — same load-on-demand shape as the Customer picker. */
  getClosedNarrations(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/closed-narrations`, { params: { search } });
  }

  /** Mirrors IssueDetail.aspx.vb's DisplayInfoForEdit (webProc_TTDetails, single-issue view). */
  getIssueDetailFull(ttNo: number): Observable<{
    module: string;
    priority: string;
    whatNext: string;
    issue: string;
    action: string;
    exeVersionNo: string;
    closed: boolean;
    closedBy: number;
    closedNarrationId: number;
    closedNarrationLabel: string;
  } | null> {
    return this.http.get<ApiIssueDetailFull | null>(`${BASE}/issue-detail/${ttNo}`).pipe(
      map((r) =>
        r
          ? {
              module: r.module,
              priority: r.priority,
              whatNext: r.what_next,
              issue: r.issue,
              action: r.action,
              exeVersionNo: r.exe_version_no,
              closed: r.closed,
              closedBy: r.closed_by,
              closedNarrationId: r.closed_narration_id,
              closedNarrationLabel: r.closed_narration_text
            }
          : null
      )
    );
  }

  /** Mirrors IssueDetail.aspx.vb's btnAddAction_Click (Session("TempTT") row add/update — see IssueDetail component doc comment). */
  saveIssueDetail(payload: {
    ttNo: number;
    module: string;
    priority: string;
    whatNext: string;
    issue: string;
    action: string;
    exeVersionNo: string;
    closed: boolean;
    closedBy: number;
    closedNarrationId: number;
  }): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/issue-detail`, {
      tt_no: payload.ttNo,
      module: payload.module,
      priority: payload.priority,
      what_next: payload.whatNext,
      issue: payload.issue,
      action: payload.action,
      exe_version_no: payload.exeVersionNo,
      closed: payload.closed,
      closed_by: payload.closedBy,
      closed_narration_id: payload.closedNarrationId
    });
  }

  private toDateParam(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  /**
   * Mirrors SupportCoOrdinatorDashboard.aspx.vb's createGrid — reads
   * RSPL_SupportCoOrdinatorDashboard (Report_enabled=1) and runs each row's
   * Report_Query into its own auto-column mini-grid. The source page itself
   * displays "This Report is Under Construction"; kept as a simplified
   * report-engine-family rebuild (dynamic tiles, no runtime control-tree
   * generation) rather than fully building out an admittedly unfinished
   * source feature.
   */
  getSupportCoordinatorReports(): Observable<{ reportId: number; title: string; rows: Record<string, unknown>[] }[]> {
    return this.http
      .get<{ report_id: number; title: string; rows: Record<string, unknown>[] }[]>(`${BASE}/coordinator-dashboard`)
      .pipe(map((tiles) => tiles.map((t) => ({ reportId: t.report_id, title: t.title, rows: t.rows }))));
  }


  /** Mirrors VideoHistory.aspx.vb's FillGV. NOTE: the source's cross-database License-server sync step on page load is not replicated (no such connection in this stack) — only the read-only grid query is wired, see support_modules.py module docstring. */
  getVideoHistory(custId: number): Observable<VideoHistoryRow[]> {
    const params = new HttpParams().set('cust_id', custId);
    return this.http.get<ApiVideoHistoryRow[]>(`${BASE}/video-history`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          menuId: r.menu_id,
          srNo: r.sr_no,
          menuName: r.menu_name,
          videoDescription: r.video_description,
          client: r.client,
          date: r.date ?? '',
          videoLinkUrl: r.video_link_url,
          videoTrainingModeStatus: r.video_training_mode_status,
          userName: r.user_name,
          counterName: r.counter_name
        }))
      )
    );
  }

  /** Mirrors TroubleTicket_Modify.aspx.vb's Page_Load filter-source lookups. */
  getTtModifyFilters(): Observable<{ products: string[]; users: LookupOption[] }> {
    return this.http.get<{ products: string[]; users: LookupOption[] }>(`${BASE}/tt-modify/filters`);
  }

  /**
   * Mirrors TroubleTicket_Modify.aspx.vb's FilteringMdethod. The source's
   * per-row Edit-button enable/disable rule (only enabled for the
   * requesting user's reporting-chain seniors over a Pending ticket's
   * LatestOwner, via GetParentEmpid) has no clean equivalent without a real
   * org-hierarchy backend call — simplified to always-editable rows here,
   * noted in the migration checklist.
   */
  getTtModifyRows(filters: {
    custId?: number | null;
    productName?: string;
    latestOwnerId?: number;
    internalReferenceUserId?: number;
    priority?: string;
    status?: string;
    fromDate?: Date | null;
    toDate?: Date | null;
  }): Observable<TtModifyRow[]> {
    let params = new HttpParams();
    if (filters.custId) {
      params = params.set('cust_id', filters.custId);
    }
    if (filters.productName) {
      params = params.set('product_name', filters.productName);
    }
    if (filters.latestOwnerId) {
      params = params.set('latest_owner_id', filters.latestOwnerId);
    }
    if (filters.internalReferenceUserId) {
      params = params.set('internal_reference_user_id', filters.internalReferenceUserId);
    }
    if (filters.priority) {
      params = params.set('priority', filters.priority);
    }
    if (filters.status) {
      params = params.set('status', filters.status);
    }
    if (filters.fromDate) {
      params = params.set('from_date', this.toDateParam(filters.fromDate));
    }
    if (filters.toDate) {
      params = params.set('to_date', this.toDateParam(filters.toDate));
    }
    return this.http.get<ApiTtModifyRow[]>(`${BASE}/tt-modify/rows`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          ttNo: r.tt_no,
          name: r.name,
          date: r.date ?? '',
          description: r.description,
          rwRemarks: r.rw_remarks,
          latestOwner: r.latest_owner,
          priority: r.priority as 'High' | 'Medium' | 'Low',
          internalDeadLine: r.internal_dead_line,
          productName: r.product_name,
          status: r.status as 'Pending' | 'Closed',
          internalReferenceUser: r.internal_reference_user
        }))
      )
    );
  }

  /** Mirrors TroubleTicket_Modify.aspx.vb's rgvTTinfo_UpdateCommand (TTDetails.Priority/InternalDeadLine). */
  updateTtModifyRow(ttNo: number, priority: string, internalDeadLine: string | null): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${BASE}/tt-modify/${ttNo}`, {
      priority,
      internal_dead_line: internalDeadLine
    });
  }

  /** Mirrors VisitLogRegister.aspx.vb's FillGV (VisitLogMaster joined with Products/CauseMaster/CustDependents/Salesman). */
  getVisitLogRegisterRows(filters: {
    useDateFilter?: boolean;
    fromDate?: Date | null;
    toDate?: Date | null;
    customerId?: number | null;
    personId?: number | null;
    productId?: number | null;
    causeId?: number | null;
    narration?: string;
    fromRef?: string;
    toRef?: string;
  }): Observable<VisitLogRegisterRow[]> {
    let params = new HttpParams().set('narration', filters.narration ?? '');
    if (filters.useDateFilter && filters.fromDate && filters.toDate) {
      params = params.set('from_date', this.toDateParam(filters.fromDate)).set('to_date', this.toDateParam(filters.toDate));
    }
    if (filters.customerId) {
      params = params.set('client_id', filters.customerId);
    }
    if (filters.personId) {
      params = params.set('person_id', filters.personId);
    }
    if (filters.productId) {
      params = params.set('product_id', filters.productId);
    }
    if (filters.causeId) {
      params = params.set('cause_id', filters.causeId);
    }
    if (filters.fromRef) {
      params = params.set('from_ref', filters.fromRef);
    }
    if (filters.toRef) {
      params = params.set('to_ref', filters.toRef);
    }
    return this.http.get<ApiVisitLogRegisterRow[]>(`${BASE}/visit-log-register`, { params }).pipe(map((rows) => rows.map(toVisitLogRegisterRow)));
  }

  /** Mirrors VisitLogReport.aspx.vb's FillGV — same join as VisitLogRegister, unfiltered, ordered by Date. */
  getVisitLogReportRows(): Observable<VisitLogRegisterRow[]> {
    return this.http.get<ApiVisitLogRegisterRow[]>(`${BASE}/visit-log-report`).pipe(map((rows) => rows.map(toVisitLogRegisterRow)));
  }

  getAmcActionHistory(custId: number): Observable<AmcActionRow[]> {
    const params = new HttpParams().set('cust_id', custId);
    return this.http.get<ApiAmcActionRow[]>(`${BASE}/amc/action-history`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          actionId: r.action_id,
          creationDate: r.creation_date ?? '',
          creationTime: r.creation_time,
          followUpBy: r.follow_up_by,
          followUpRemark: r.follow_up_remark,
          completionDate: r.completion_date,
          completionTime: r.completion_time,
          completedBy: r.completed_by,
          assignedTo: r.assigned_to,
          actionDescription: r.action_description,
          actionRemark: r.action_remark,
          nextAction: r.next_action as 'Add' | 'Close' | 'Closed'
        }))
      )
    );
  }
}

export interface AmcRow {
  custId: number;
  displayName: string;
  area: string;
  city: string;
  mobileNo: string;
  email: string;
  creationDate: string;
  ledgerBalance: number;
  ledgerGroupBalance: number;
  actionDate: string;
  amcAmount: number;
  amcDueDate: string;
  actionStageId: number;
  assValue: number;
  amcPer: number;
  basicAmcAmt: number;
  serviceTax: number;
}

export interface AmcCoordPendingRow {
  actionDate: string;
  customer: string;
  actionTakenBy: string;
  actionOn: string;
  actionDescription: string;
  actionRemark: string;
  custId: number;
}

export interface AmcCoordAmcRow {
  custId: number;
  mobileNo: string;
  area: string;
  customer: string;
  amcPer: number;
  expiryDate: string;
  city: string;
  assessableAmt: number;
  lastLetterDate: string;
  lastLetterValue: number;
  lastLetterNo: number;
  ttAfterExpiry: number;
  callsAfterExpiry: number;
}

export interface TtActionRow {
  srNo: number;
  ttDate: string;
  receivedBy: string;
  issue: string;
  actionId: number;
  actionDate: string;
  actionDetails: string;
  actionBy: string;
  actionOn: string;
}

export interface VideoHistoryRow {
  menuId: number;
  srNo: number;
  menuName: string;
  videoDescription: string;
  client: string;
  date: string;
  videoLinkUrl: string;
  videoTrainingModeStatus: string;
  userName: string;
  counterName: string;
}

export interface TtModifyRow {
  ttNo: number;
  name: string;
  date: string;
  description: string;
  rwRemarks: string;
  latestOwner: string;
  priority: 'High' | 'Medium' | 'Low';
  internalDeadLine: string | null;
  productName: string;
  status: 'Pending' | 'Closed';
  internalReferenceUser: string;
}

export interface VisitLogRegisterRow {
  logId: number;
  date: string;
  refNo: string;
  clientName: string;
  productName: string;
  causeOfVisit: string;
  supportReason: string;
  modules: string;
  otherModules: string;
  withinWarranty: boolean;
  amc: boolean;
  attendedBy: string;
  remark: string;
}

export interface AmcActionRow {
  actionId: number;
  creationDate: string;
  creationTime: string;
  followUpBy: string;
  followUpRemark: string;
  completionDate: string;
  completionTime: string;
  completedBy: string;
  assignedTo: string;
  actionDescription: string;
  actionRemark: string;
  nextAction: 'Add' | 'Close' | 'Closed';
}
