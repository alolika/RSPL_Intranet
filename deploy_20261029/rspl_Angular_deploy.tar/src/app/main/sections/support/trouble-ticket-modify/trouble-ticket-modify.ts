import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { LookupOption, SupportDataService, TtModifyRow } from '../support-data.service';

const ALL_USERS_OPTION: LookupOption = { label: 'All', value: 0 };

/**
 * Mirrors Section_Support/TroubleTicket_Modify.aspx ("Pending TT Register"):
 * multi-filter grid of trouble tickets with inline-editable Priority and
 * Internal DeadLine per row. The source's per-row Edit-button gating
 * (enabled only for a user's reporting-chain seniors over a pending
 * ticket's current owner) is simplified to always-editable — see the data
 * service doc comment.
 *
 * The Customer filter was a plain free-text box matched against
 * DisplayName with a fuzzy LIKE — no picker ever "opened", and a fuzzy name
 * match could silently span multiple similarly-named customers. Replaced
 * with the same top-100/type-to-search customer picker used on the Trouble
 * Ticket page (exact CustID match once selected), and the shared
 * `/support/customers` lookup now also matches by CustID so the same box
 * works whether staff type a name or a customer code.
 */
@Component({
  selector: 'app-trouble-ticket-modify',
  imports: [FormsModule, ButtonModule, SelectModule, DatePickerModule, TableModule, DatePipe],
  templateUrl: './trouble-ticket-modify.html',
  styleUrl: './trouble-ticket-modify.scss'
})
export class TroubleTicketModify implements OnInit {
  private readonly data = inject(SupportDataService);

  readonly products = signal<string[]>([]);
  readonly users = signal<LookupOption[]>([ALL_USERS_OPTION]);
  readonly customers = signal<LookupOption[]>([]);
  readonly customersLoading = signal(false);
  readonly rows = signal<TtModifyRow[]>([]);
  readonly loading = signal(false);
  readonly savingTtNo = signal<number | null>(null);

  // PrimeNG's built-in row editing tracks only which rows are "in edit
  // mode" — it never clones the original values, so without this, clicking
  // Cancel closed the edit UI but silently left whatever had already been
  // typed in place (the [(ngModel)] on each editable column mutates the
  // row object directly, live, as you type). Snapshotted per-TTNo so
  // Cancel can actually restore the pre-edit values, and so a failed save
  // can revert too instead of leaving the grid showing unsaved-but-looks-
  // saved data.
  private readonly editSnapshots = new Map<number, { priority: TtModifyRow['priority']; internalDeadLine: string | null }>();

  // The Internal DeadLine datepicker used to bind [ngModel]="parseDeadline(row.internalDeadLine)"
  // directly in the template — parseDeadline() does `new Date(value)`, so
  // every change-detection pass (and PrimeNG's Calendar triggers plenty of
  // those while its overlay is open: hover states, the clock/view flipping
  // above vs. below, etc.) handed the datepicker a *new* Date object even
  // though the underlying value hadn't changed. PrimeNG then treated that as
  // a real model change and redid internal work it didn't need to, which is
  // what actually read as "date selection is slow" — nothing here ever made
  // a network call on selection, only on Save. Parsing once into this map
  // when a row enters edit mode, and returning that same cached reference
  // until the user actually picks a new date, removes the churn entirely.
  private readonly editingDeadlines = new Map<number, Date | null>();

  readonly priorityOptions = [
    { label: 'All', value: 'All' },
    { label: 'High', value: 'High' },
    { label: 'Medium', value: 'Medium' },
    { label: 'Low', value: 'Low' }
  ];
  readonly statusOptions = [
    { label: 'All', value: 'All' },
    { label: 'Closed', value: 'Closed' },
    { label: 'Pending', value: 'Pending' }
  ];

  // Bound one-way to <p-table>'s [first] — plain field rather than a signal
  // since it only ever needs to be force-set to 0 on a new search; PrimeNG
  // manages page-to-page navigation internally without writing this back.
  firstRow = 0;

  selectedCustomer: number | null = null;
  productName = 'All';
  latestOwnerId = 0;
  internalReferenceUserId = 0;
  priority = 'All';
  status = 'Pending';
  fromDate: Date | null = null;
  toDate: Date | null = null;

  // Same debounced-search shape as every other customer picker in this app
  // (Trouble Ticket, Advance, Add Tag) — re-queries the server once typing
  // pauses instead of firing a request per keystroke.
  private readonly customerFilter$ = new Subject<string>();

  ngOnInit(): void {
    this.data.getTtModifyFilters().subscribe((f) => {
      this.products.set(['All', ...f.products]);
      this.users.set([ALL_USERS_OPTION, ...f.users]);
    });

    this.customersLoading.set(true);
    this.data.getCustomers().subscribe((c) => {
      this.customers.set(c);
      this.customersLoading.set(false);
    });
    this.customerFilter$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((query) => this.data.getCustomers(query))
      )
      .subscribe((c) => this.customers.set(c));

    this.show();
  }

  onCustomerFilter(query: string): void {
    this.customerFilter$.next(query);
  }

  show(): void {
    this.loading.set(true);
    // Every search replaces the full result set, so the paginator must jump
    // back to page 1 — otherwise a filter that returns fewer results than
    // the page the user was already on (e.g. page 3 of an old 1,315-row set
    // narrowed down to 5 rows) left them stranded on a blank page with no
    // rows and pagination controls that no longer matched the real count.
    this.firstRow = 0;
    this.data
      .getTtModifyRows({
        custId: this.selectedCustomer,
        productName: this.productName,
        latestOwnerId: this.latestOwnerId,
        internalReferenceUserId: this.internalReferenceUserId,
        priority: this.priority,
        status: this.status,
        fromDate: this.fromDate,
        toDate: this.toDate
      })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      });
  }

  resetFilters(): void {
    this.selectedCustomer = null;
    this.productName = 'All';
    this.latestOwnerId = 0;
    this.internalReferenceUserId = 0;
    this.priority = 'All';
    this.status = 'Pending';
    this.fromDate = null;
    this.toDate = null;
    this.show();
  }

  // The Internal DeadLine editor used to be a free-text input with a
  // "dd-MMM-yyyy" placeholder, but the backend's PUT endpoint takes a real
  // ISO date — typing a date in the exact format the placeholder suggested
  // (e.g. "25-Dec-2026") failed backend validation every time. Swapped for
  // a real date picker; these two just bridge the row's ISO string field
  // to/from the Date object the picker needs.
  parseDeadline(value: string | null): Date | null {
    return value ? new Date(value) : null;
  }

  formatDeadline(value: Date | null): string | null {
    if (!value) {
      return null;
    }
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, '0');
    const d = String(value.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  // Template reads through this (not parseDeadline directly) so the
  // datepicker gets the same cached Date reference on every change-detection
  // pass instead of a freshly-allocated one — see editingDeadlines' doc
  // comment above.
  getEditingDeadline(row: TtModifyRow): Date | null {
    return this.editingDeadlines.get(row.ttNo) ?? null;
  }

  onDeadlineChange(row: TtModifyRow, value: Date | null): void {
    this.editingDeadlines.set(row.ttNo, value);
    row.internalDeadLine = this.formatDeadline(value);
  }

  onEditInit(row: TtModifyRow): void {
    this.editSnapshots.set(row.ttNo, { priority: row.priority, internalDeadLine: row.internalDeadLine });
    this.editingDeadlines.set(row.ttNo, this.parseDeadline(row.internalDeadLine));
  }

  onEditCancel(row: TtModifyRow): void {
    const snapshot = this.editSnapshots.get(row.ttNo);
    if (snapshot) {
      row.priority = snapshot.priority;
      row.internalDeadLine = snapshot.internalDeadLine;
      this.editSnapshots.delete(row.ttNo);
    }
    this.editingDeadlines.delete(row.ttNo);
  }

  saveRow(row: TtModifyRow): void {
    this.savingTtNo.set(row.ttNo);
    this.data.updateTtModifyRow(row.ttNo, row.priority, row.internalDeadLine).subscribe({
      next: () => {
        this.savingTtNo.set(null);
        this.editSnapshots.delete(row.ttNo);
        this.editingDeadlines.delete(row.ttNo);
        alert('Record updated successfully.');
      },
      // pSaveEditableRow closes the row's edit UI the instant it's clicked,
      // independent of whether this request succeeds — without an error
      // path, a failed save left the grid silently showing the unsaved
      // typed values as if they'd been persisted. Revert to the pre-edit
      // snapshot so the grid never displays data that isn't actually saved.
      error: (err) => {
        this.savingTtNo.set(null);
        const snapshot = this.editSnapshots.get(row.ttNo);
        if (snapshot) {
          row.priority = snapshot.priority;
          row.internalDeadLine = snapshot.internalDeadLine;
          this.editSnapshots.delete(row.ttNo);
        }
        this.editingDeadlines.delete(row.ttNo);
        alert(err?.error?.detail ?? 'Failed to update the record. Please try again.');
      }
    });
  }
}
