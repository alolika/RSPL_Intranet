import { DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { TableModule } from 'primeng/table';

import { PortalAuthService } from '../../../../core/auth/portal-auth.service';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import { MissedCallRow, SupportDataService } from '../support-data.service';

interface DisplayRow extends MissedCallRow {
  color: string;
  textColor: string;
  actionLabel: string;
  actionCommand: 'preclose' | 'close' | 'closed' | '';
  attemptLabel: string;
  attemptClickable: boolean;
}

// Requested display order, latest revision: Blue, Dark Yellow, Light Yellow
// (split back into two separate tiers — previously combined into one
// "Yellow" tier), Pink, White (Attempted), Unregistered last. Green/Orchid
// weren't named in this revision either — per the prior explicit
// confirmation (still in effect, unchanged by this request), fitted around
// the named tiers keeping their established relative order: Green stays
// right after White, Orchid stays right before Unregistered.
//
// Advance AMC (Cyan, #E0FFFF) removed per explicit request — see
// displayRows()'s own comment on why it was retired; there is no longer any
// path that produces that color, so it has no rank entry here either.
//
// Pink here (#FFB6C1) means only registered-but-flagged entities — the
// *same* color also gets forced onto unregistered rows further down in
// displayRows(), but those are pulled into their own always-last tier by the
// entityId===0 check in sortedRows() below, ahead of this rank lookup, so
// they never actually land in the Pink tier despite sharing its color.
const COLOR_RANK: Record<string, number> = {
  '#4682B4': 0, // Installed within one month (Blue)
  '#FFD801': 1, // AMC valid, call not attempted (Gold/Mustard — was dark Gold #FFD700, then #FFECB3, then #FFD858, per explicit follow-up requests; kept visually distinct from the #FFFF00 tier below)
  '#FFFF00': 2, // AMC not valid, call not attempted (Light Yellow) — its own tier again, after Pale Yellow
  '#FFB6C1': 3, // Flagged entity (Pink)
  '#FFFFFF': 4, // AMC valid, call attempted (White / Attempted)
  '#90EE90': 5, // AMC not valid, call attempted (Green)
  '#DA70D6': 6 // Pre-closed action (Orchid)
};

/**
 * Mirrors Section_Support/MissedCall.aspx (reused for all four
 * "Pending MissedCall" menu items via ?Product=). The row-coloring rules
 * from ItemDataBound (known-entity + AMC-active combinations, installed
 * within one month) are reproduced in the `displayRows` computed below.
 * Advance AMC was also one of these rules originally but has since been
 * retired per explicit request — see displayRows()'s own comment.
 *
 * NOTE: this entire page's data source (WebProc_SIPMissedCalls) and both
 * of its write actions (Attempt, and the Close/PreClose popup this links
 * to) read/write `synapsecdr.dbo.SIPEventRegisterCDR` — confirmed live
 * (again, 2026-07) that the `SynapseCDR` database does not exist on this
 * SQL instance, so `show()` below will 500 every time until that changes
 * at the infrastructure level. That's why `attemptCall()` in
 * SupportDataService is a client-side stub rather than a real endpoint —
 * there's no table to write to. Unlike the Google Sheets integration on
 * the Executive Schedule page (whose upstream API Google discontinued
 * years ago, making it permanently unreachable), this one is plausibly
 * just "not configured on this instance yet" — worth re-checking
 * `SELECT name FROM sys.databases` next time this comes up, same as the
 * Section_Support Call/SIP family and Section_GST's missing linked server.
 *
 * One real discrepancy against the source found and fixed while reviewing
 * this (can't live-test given the above, but unambiguous from a direct
 * line-by-line read of ItemDataBound):
 * - For the Yellow row case (not a known/starred entity, AMC amount > 0),
 *   the source unconditionally shows "Click to Attempt" regardless of any
 *   existing ExecutiveName value. The previous version showed the
 *   existing executiveName instead whenever one was present, which would
 *   have made that row's attempt link permanently unreachable once any
 *   name was ever recorded against it.
 *
 * (Historical note: the source also had an Advance AMC/LightCyan rule here,
 * which won over "installed within one month" whenever a row matched both.
 * That rule has since been retired outright per explicit request — its
 * underlying flag was a manually-assigned customer CLASS tag completely
 * decoupled from the customer's actual AMC amount/expiry, so a customer
 * tagged that way once kept the color forever even after their AMC lapsed.
 * Rows that would have matched it now simply fall through to whichever
 * other rule already applies.)
 *
 * Pagination removed and rows sorted by triage priority per explicit
 * request — see `sortedRows`/`COLOR_RANK` below: Installed within one month
 * > Dark Yellow > Light Yellow > White > Green > Flagged >
 * Pre-closed, with unregistered calls (no matched customer/software record)
 * always last regardless of color.
 */
@Component({
  selector: 'app-missed-call',
  imports: [FormsModule, ButtonModule, DatePickerModule, InputTextModule, TableModule, MessageModule, DatePipe, IndianNumberPipe],
  templateUrl: './missed-call.html',
  styleUrl: './missed-call.scss'
})
export class MissedCall implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(SupportDataService);
  private readonly auth = inject(PortalAuthService);
  private readonly cdr = inject(ChangeDetectorRef);
  private router = inject(Router);

  readonly rows = signal<MissedCallRow[]>([]);
  readonly loading = signal(false);
  readonly loadError = signal<string | null>(null);
  readonly lastRefreshed = signal('');
  readonly searchText = signal('');
  // Hidden by default per explicit request — the grid still loads
  // immediately on open (ngOnInit already calls show()), this only hides
  // the filter controls themselves until the user wants to change them.
  readonly showFilters = signal(false);
  // Same treatment as the filter panel, and for the same reason — every
  // panel that isn't the grid itself is vertical space the grid doesn't
  // get, per the explicit "grid should occupy almost the entire form"
  // request.
  readonly showLegend = signal(false);

  product = '';

  sipExtNo = this.auth.currentUser()?.sipExtNo ?? '';
  fromDate = new Date();
  toDate = new Date();

  readonly canClose = computed(() => [2, 7, 22, 25, 32].includes(this.auth.currentUser()?.userId ?? -1));

  readonly displayRows = computed<DisplayRow[]>(() => {
    return this.rows().map((r) => {
      const known = r.entityName.endsWith('*');
      const flagged = r.entityName.endsWith(';');
      let color = '';
      let textColor = 'inherit';

      // Base rules, in the source's own precedence (each is an
      // unconditional `If`, later ones overwrite earlier ones on the same
      // row rather than being mutually exclusive branches).
      if (!known && r.amcAmount === 0) {
        // Per explicit request (was dark gold #FFD700, then #FFECB3, then
        // #FFD858) — kept visually distinct from the brighter #FFFF00
        // used by the "AMC not valid" tier just below.
        color = '#FFD801';
      }
      if (!known && r.amcAmount > 0) {
        color = '#FFFF00';
      }
      if (known && r.amcAmount === 0) {
        color = '#FFFFFF';
      }
      if (known && r.amcAmount > 0) {
        color = '#90EE90';
      }
      if (flagged && r.amcAmount === 0) {
        color = '#FFB6C1';
      }
      if (r.installedWithinOneMonth) {
        color = '#4682B4';
        textColor = '#fff';
      }
      // Advance AMC (Cyan) intentionally retired per explicit request: the
      // source's `AdvanceAMC` flag came from a manually-assigned customer
      // CLASS tag (CustomerAttributes.AttributeID=37) completely decoupled
      // from the customer's actual current AMCAmount/AMCExpiryDate — a
      // customer tagged that way once kept the color forever even after
      // their AMC amount dropped to 0 or their AMC expired, which is what
      // was being reported as "customers without Advance AMC still showing
      // the Advance AMC color." Rather than patch the tag with an
      // amount/expiry condition, these rows now simply fall through to
      // whichever rule above already applies (the known/flagged/AMC-amount
      // rules, or "installed within one month") — i.e. treated as regular.
      // r.advanceAmc itself is left alone in the data model; it's just no
      // longer consulted here.

      let actionLabel: DisplayRow['actionCommand'] = '';
      let label = '';
      if (r.actionStateId === 2) {
        label = 'Closed';
        actionLabel = 'closed';
      } else if (r.processed === 0 && r.actionStateId === 0) {
        label = this.canClose() ? 'Close' : 'PreClose';
        actionLabel = this.canClose() ? 'close' : 'preclose';
      } else if (r.actionStateId === 0) {
        label = this.canClose() ? 'Close' : 'PreClosed';
        actionLabel = this.canClose() ? 'close' : 'preclose';
        color = '#DA70D6';
      }

      // Unregistered calls (no matched customer/software record at all) —
      // checked last so it always wins, per explicit request to color these
      // pink regardless of whatever the AMC-based rules above computed.
      // Doesn't collide with the existing "flagged entity" pink above: a
      // flagged row requires a real EntityName ending in ';', which only
      // exists for a matched (registered) entity in the first place.
      if (r.entityId === 0) {
        color = '#FFB6C1';
        textColor = 'inherit';
      }

      let attemptLabel = '';
      let attemptClickable = false;
      if (!known && r.amcAmount === 0) {
        // Source: only offers the attempt link when nothing's been
        // recorded yet; otherwise shows the existing name, un-clickable.
        if (!r.executiveName) {
          attemptLabel = 'Click to Attempt';
          attemptClickable = true;
        } else {
          attemptLabel = r.executiveName;
        }
      } else if (!known && r.amcAmount > 0) {
        // Source: always offers the attempt link here, even if a name is
        // already recorded.
        attemptLabel = 'Click to Attempt';
        attemptClickable = true;
      } else {
        attemptLabel = r.executiveName || '';
      }

      return {
        ...r,
        color,
        textColor,
        actionLabel: label,
        actionCommand: actionLabel,
        attemptLabel,
        attemptClickable
      };
    });
  });

  readonly filteredRows = computed<DisplayRow[]>(() => {
    const q = this.searchText().trim().toLowerCase();
    if (!q) {
      return this.displayRows();
    }
    return this.displayRows().filter((r) => r.entityName.toLowerCase().includes(q) || r.entityPhone.toLowerCase().includes(q) || r.softwareName.toLowerCase().includes(q));
  });

  // Top-level: unregistered calls (EntityID = 0 — no matched
  // customer/software record at all) always last, regardless of color —
  // checked before color rank so these don't land in the Pink tier despite
  // displayRows() coloring them pink too (see COLOR_RANK's own comment).
  //
  // Then: color-priority tier per COLOR_RANK above (Blue > Cyan > Yellow >
  // Pink > White > Green > Orchid).
  //
  // Within each tier: First Call Time ascending (earliest first), by actual
  // time value — not the ISO string's text — so rows are ordered correctly
  // regardless of formatting. Rows with no parseable time sort last within
  // their tier rather than corrupting the whole sort with NaN.
  //
  // Array.sort is a stable sort in all evergreen engines, so rows sharing
  // every key keep their original relative order (by call date, as returned
  // by the API) rather than being shuffled.
  readonly sortedRows = computed<DisplayRow[]>(() => {
    return [...this.filteredRows()].sort((a, b) => {
      const unregA = a.entityId === 0 ? 1 : 0;
      const unregB = b.entityId === 0 ? 1 : 0;
      if (unregA !== unregB) {
        return unregA - unregB;
      }

      const rankDiff = this.colorRank(a.color) - this.colorRank(b.color);
      if (rankDiff !== 0) {
        return rankDiff;
      }

      const timeA = a.minCallTime ? new Date(a.minCallTime).getTime() : Number.POSITIVE_INFINITY;
      const timeB = b.minCallTime ? new Date(b.minCallTime).getTime() : Number.POSITIVE_INFINITY;
      return timeA - timeB;
    });
  });

  private colorRank(color: string): number {
    return COLOR_RANK[color] ?? 99;
  }

  readonly totalRecords = computed(() => this.rows().length);
  readonly attemptedRecords = computed(() => this.rows().filter((r) => r.entityName.endsWith('*')).length);

  ngOnInit(): void {
    // All four "Pending MissedCall" menu items route to this same component
    // (only ?Product differs) — subscribe rather than reading a one-time
    // snapshot so switching between them while mounted actually reloads.
    this.route.queryParamMap.subscribe((q) => {
      this.product = q.get('Product') ?? '';
      this.cdr.markForCheck();
      this.show();
    });
  }

  toggleFilters(): void {
    this.showFilters.update((v) => !v);
  }

  toggleLegend(): void {
    this.showLegend.update((v) => !v);
  }

  show(): void {
    this.loading.set(true);
    this.loadError.set(null);
    this.data.getMissedCalls(this.product, this.fromDate, this.toDate).subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
        this.lastRefreshed.set(`Last Refreshed on: ${new Date().toLocaleString()}`);
      },
      // Previously had no error path at all — a failed request (guaranteed
      // today, see the class doc comment) left `loading` stuck true
      // forever with no indication anything had gone wrong.
      error: (err: unknown) => {
        this.loading.set(false);
        const busy = err instanceof HttpErrorResponse && (err.status === 503 || err.status === 504);
        this.loadError.set(
          busy
            ? 'The server is busy right now. Please wait a minute and click Show again.'
            : 'Could not load missed calls. Please try again.'
        );
      }
    });
  }

  attempt(row: DisplayRow): void {
    if (!row.attemptClickable) {
      return;
    }
    this.data.attemptCall(row.recordNo, row.entityPhone, this.auth.currentUser()?.userName ?? '').subscribe({
      next: () => this.show(),
      error: (err: unknown) => {
        // The backend's UPDATE only succeeds while ExecutiveName is still
        // blank (see attempt_missed_call's own comment) — a 409 here means
        // someone else's attempt on this exact call landed first since this
        // grid was last loaded (two people can have the same
        // not-yet-attempted row open at once). Refresh so the grid picks up
        // whatever the real current state is (their recorded name, no
        // longer "Click to Attempt") instead of leaving this row looking
        // stuck or silently overwriting their attempt.
        if (err instanceof HttpErrorResponse && err.status === 409) {
          alert('This call has already been attempted.');
          this.show();
        } else {
          alert('Could not record this attempt. Please try again.');
        }
      }
    });
  }

  callNow(row: DisplayRow): void {
    alert(`Dialing ${row.entityPhone} via SIP extension ${this.sipExtNo} (external Asterisk/Synapse call — not wired up without a backend)`);
  }

  openAction(row: DisplayRow): void {
    if (row.actionCommand === 'closed') {
      return;
    }
    const viewMode = row.actionCommand === 'preclose' && row.processed === 1 ? 1 : 0;
    this.router.navigate(['/support/close-popup'], {
      queryParams: {
        ViewMode: viewMode,
        RecordNo: row.recordNo,
        EntityID: row.entityId,
        ActionstateId: row.actionCommand === 'close' ? 2 : 1,
        mobileno: row.entityPhone
      }
    });
  }

  viewAttempts(row: DisplayRow): void {
    // Was missing FromDate/ToDate entirely — close-popup.ts's getCallAttempts()
    // call always received '' for both (its query-param read defaults to '' when
    // the param is absent), so proc_SIPMissCallAttemptList's @FromDate/@ToDate
    // datetime parameters got blank strings regardless of whatever range the
    // user had actually searched with here, which is why the popup always came
    // back empty. Passing the real searched range through fixes that.
    this.router.navigate(['/support/close-popup'], {
      queryParams: {
        ViewMode: 2,
        RecordNo: row.recordNo,
        EntityID: row.entityId,
        ActionstateId: 2,
        mobileno: row.entityPhone,
        FromDate: this.toIsoDate(this.fromDate),
        ToDate: this.toIsoDate(this.toDate)
      }
    });
  }

  private toIsoDate(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }
}
