import { Location } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';

import { LookupOption, SupportDataService } from '../support-data.service';

/**
 * Mirrors Section_Support/PayBank.aspx: a RadWindow popup to assign bank
 * cards to a customer (?CustID=). The source's RadWindow had its own close
 * chrome; here it's a real route, so it needs its own Back control to
 * return to wherever it was opened from (e.g. Trouble Ticket) — that
 * caller's own in-progress state is preserved separately, see
 * TroubleTicketDraftService.
 */
@Component({
  selector: 'app-pay-bank',
  imports: [FormsModule, ButtonModule, CheckboxModule, DialogModule, InputTextModule],
  templateUrl: './pay-bank.html',
  styleUrl: './pay-bank.scss'
})
export class PayBank implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(SupportDataService);
  private readonly location = inject(Location);

  readonly bankCards = signal<LookupOption[]>([]);
  readonly checkedSet = signal<Set<number>>(new Set());
  readonly addDialogVisible = signal(false);
  readonly saving = signal(false);

  newBankName = '';
  private custId = 0;

  ngOnInit(): void {
    // Reached repeatedly with a different ?CustID each time — subscribe
    // rather than reading a one-time snapshot so opening this for a
    // different customer while already mounted actually reloads.
    this.route.queryParamMap.subscribe((q) => {
      this.custId = Number(q.get('CustID') ?? 0);
      this.refresh();
    });
  }

  private refresh(): void {
    this.data.getBankCards(this.custId).subscribe((res) => {
      this.bankCards.set(res.options);
      this.checkedSet.set(new Set(res.checked));
    });
  }

  isChecked(value: number): boolean {
    return this.checkedSet().has(value);
  }

  toggle(value: number): void {
    const next = new Set(this.checkedSet());
    if (next.has(value)) {
      next.delete(value);
    } else {
      next.add(value);
    }
    this.checkedSet.set(next);
  }

  openAddBank(): void {
    this.newBankName = '';
    this.addDialogVisible.set(true);
  }

  addBank(): void {
    if (!this.newBankName.trim()) {
      return;
    }
    this.data.addBankCard(this.newBankName).subscribe(() => {
      this.refresh();
      this.addDialogVisible.set(false);
    });
  }

  save(): void {
    this.saving.set(true);
    this.data.saveCustBankCards(this.custId, [...this.checkedSet()]).subscribe((res) => {
      this.saving.set(false);
      alert(res.message);
    });
  }

  goBack(): void {
    this.location.back();
  }
}
