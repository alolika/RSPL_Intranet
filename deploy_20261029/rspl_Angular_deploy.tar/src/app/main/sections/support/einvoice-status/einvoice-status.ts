import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MessageModule } from 'primeng/message';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { LookupOption, SupportDataService } from '../support-data.service';

interface EinvoiceRow {
  custId: number;
  customerName: string;
  date: string;
  response: string;
}

const SELECT_OPTION: LookupOption = { label: 'Select', value: 0 };

/**
 * Mirrors Section_Support/EinvoiceStatus.aspx.
 *
 * NOTE: the data source, vw_web_Einvoice, reads `[License].[license_Retailware]`
 * via a linked server that does not exist on this SQL instance (confirmed
 * live, same gap as Section_GST and Modules.aspx's ExeVersion/Show Pirated
 * shapes) — `show()` 500s every time, confirmed in ~0.3s, not a slow query.
 *
 * Two real bugs found and fixed here (same shape as Call History Report,
 * checked independently against this page's own legacy source):
 * - The customer filter was wired to `getVisitLogClients()` (CustDependents
 *   — a dependents/contacts list used by the Visit Log pages), but the
 *   source's own customer combo is filled from
 *   `select distinct C.CustID, c.displayname from CustomerMaster C where
 *   C.Disabled=0 and C.Groupid=1` — the exact same query the standard
 *   top-100/search customer picker (SupportDataService.getCustomers) is
 *   already built on. Switched to that, which also gives this page real
 *   search-as-you-type for the first time (previously `filter="true"` with
 *   no debounced search behind it, over a dependents list that wasn't
 *   even the right one).
 * - No error handling on `show()` — a guaranteed-to-fail request left the
 *   page with no rows and no indication anything had gone wrong.
 */
@Component({
  selector: 'app-einvoice-status',
  imports: [FormsModule, SelectModule, TableModule, MessageModule, DatePipe],
  templateUrl: './einvoice-status.html',
  styleUrl: './einvoice-status.scss'
})
export class EinvoiceStatus implements OnInit {
  private readonly data = inject(SupportDataService);

  readonly customers = signal<LookupOption[]>([]);
  readonly customersLoading = signal(false);
  readonly rows = signal<EinvoiceRow[]>([]);
  readonly loading = signal(false);
  readonly loadError = signal<string | null>(null);
  selectedCustomer: number | null = 0;

  // Bound one-way to <p-table>'s [first] — same fix as the other report
  // pages: PrimeNG otherwise keeps stale page/total-record state once a
  // new, smaller result set replaces the current one.
  firstRow = 0;

  private readonly customerFilter$ = new Subject<string>();

  ngOnInit(): void {
    this.customersLoading.set(true);
    this.data.getCustomers().subscribe((c) => {
      this.customers.set([SELECT_OPTION, ...c]);
      this.customersLoading.set(false);
    });
    this.customerFilter$
      .pipe(debounceTime(300), distinctUntilChanged(), switchMap((q) => this.data.getCustomers(q)))
      .subscribe((c) => this.customers.set([SELECT_OPTION, ...c]));

    this.show();
  }

  onCustomerFilter(query: string): void {
    this.customerFilter$.next(query);
  }

  onCustomerChange(): void {
    this.show();
  }

  show(): void {
    if (this.loading()) {
      return;
    }
    this.loading.set(true);
    this.loadError.set(null);
    this.firstRow = 0;
    this.data.getEinvoiceStatus(this.selectedCustomer ?? 0).subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
        this.loadError.set(
          'Could not load e-invoice status. This report depends on the License database linked server, which is not currently configured on this server.'
        );
      }
    });
  }
}
