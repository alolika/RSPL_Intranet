import { Component, OnInit, inject, signal } from '@angular/core';
import { TableModule } from 'primeng/table';

import { SupportDataService } from '../support-data.service';

interface ReportTile {
  reportId: number;
  title: string;
  rows: Record<string, unknown>[];
  columns: string[];
}

/**
 * Mirrors Section_Support/SupportCoOrdinatorDashboard.aspx: a grid of small
 * report tiles built from RSPL_SupportCoOrdinatorDashboard's config rows,
 * each with its own auto-generated-column mini-grid (same dynamic-column
 * approach as the Modules/report-viewer pages). The source page itself is
 * labeled "This Report is Under Construction" — preserved here as-is rather
 * than inventing finished functionality the source never had.
 */
@Component({
  selector: 'app-support-coordinator-dashboard',
  imports: [TableModule],
  templateUrl: './support-coordinator-dashboard.html',
  styleUrl: './support-coordinator-dashboard.scss'
})
export class SupportCoOrdinatorDashboard implements OnInit {
  private readonly data = inject(SupportDataService);

  readonly tiles = signal<ReportTile[]>([]);

  ngOnInit(): void {
    this.data.getSupportCoordinatorReports().subscribe((reports) => {
      this.tiles.set(
        reports.map((r) => ({ ...r, columns: r.rows.length > 0 ? Object.keys(r.rows[0]) : [] }))
      );
    });
  }
}
