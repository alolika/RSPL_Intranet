import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelectModule } from 'primeng/multiselect';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { exportToExcel } from '../../../../shared/export-excel';
import { LookupOption as CustomerOption, SupportDataService } from '../support-data.service';
import {
  LookupOption,
  OwnerHistoryRow,
  TtDetailRow,
  TtRegisterDataService,
  TtRegisterFilters,
  TtRegisterRow
} from './tt-register-data.service';

const ALL = 'ALL';

/**
 * Mirrors Section_Support/TTRegister.aspx. The source's "Select Action"
 * RadWindow (a checklist-with-select-all/deselect-all popup) is just a
 * WhatNext multi-filter — replaced with a PrimeNG MultiSelect directly in
 * the filter bar instead of a separate modal, since MultiSelect already
 * provides select-all/none.
 *
 * Customer used to be its own TOP-500 list with no server search — swapped
 * for the same top-100/type-to-search picker used on Trouble Ticket and
 * Pending TT Register (SupportDataService.getCustomers), filtering the
 * view by an exact CustID match instead of a display-name string.
 *
 * The default "TT Action (What Next)" filter used to pre-select every
 * known WhatNext value as a stand-in for "no filter" — but ~3,450 rows in
 * the underlying view have a blank WhatNext, which was never one of the
 * pre-selected values, so those rows were silently excluded from the very
 * first page load before a user touched anything. Defaulting to an empty
 * selection (which the backend already treats as "no filter") fixes that.
 *
 * Ledger Group used to load all 786 LedgerGroupMaster rows in one shot as
 * part of getFilterOptions and render them into a single non-virtualized
 * <p-select> — the DB query was fast, but the browser laying out 786 DOM
 * option nodes on open was not. Same top-100/type-to-search treatment as
 * Customer now, via its own dedicated endpoint.
 */
@Component({
  selector: 'app-tt-register',
  imports: [FormsModule, ButtonModule, SelectModule, MultiSelectModule, DatePickerModule, InputTextModule, CheckboxModule, TableModule, DialogModule, DatePipe],
  templateUrl: './tt-register.html',
  styleUrl: './tt-register.scss'
})
export class TtRegister implements OnInit {
  private readonly data = inject(TtRegisterDataService);
  private readonly customerData = inject(SupportDataService);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly products = signal<LookupOption[]>([]);
  readonly actionTakenByOptions = signal<LookupOption[]>([]);
  readonly receivedByOptions = signal<LookupOption[]>([]);
  readonly latestOwnerOptions = signal<LookupOption[]>([]);
  readonly ledgerGroupOptions = signal<LookupOption[]>([]);
  readonly ledgerGroupsLoading = signal(false);
  readonly whatNextOptions = signal<LookupOption[]>([]);
  readonly ttStatusOptions = [
    { label: 'ALL', value: ALL },
    { label: 'Pending', value: 'Open' },
    { label: 'Closed', value: 'Closed' }
  ];

  readonly customers = signal<CustomerOption[]>([]);
  readonly customersLoading = signal(false);

  readonly rows = signal<TtRegisterRow[]>([]);
  readonly loading = signal(false);
  readonly pendingCount = signal<number | null>(null);
  readonly expandedRow = signal<number | null>(null);
  readonly detailLoading = signal(false);
  readonly detailRows = signal<TtDetailRow[]>([]);
  readonly historyVisible = signal(false);
  readonly historyLoading = signal(false);
  readonly historyRows = signal<OwnerHistoryRow[]>([]);
  readonly historyTitle = signal('');

  readonly ticketNoError = signal<string | null>(null);
  readonly dateError = signal<string | null>(null);

  // Bound one-way to <p-table>'s [first] — see Pending TT Register's same
  // fix: PrimeNG's paginator otherwise keeps stale page/total-record state
  // from the previous search once a new, smaller result set replaces it.
  firstRow = 0;

  filters: TtRegisterFilters = this.defaultFilters();

  // Same debounced-search shape as every other customer picker in this app.
  private readonly customerFilter$ = new Subject<string>();
  private readonly ledgerGroupFilter$ = new Subject<string>();

  private defaultFilters(): TtRegisterFilters {
    return {
      product: ALL,
      actionTakenBy: ALL,
      receivedBy: ALL,
      ttStatus: ALL,
      latestOwner: ALL,
      ledgerGroup: ALL,
      custId: null,
      fromDate: null,
      toDate: null,
      ticketNo: '',
      excludeAction: false,
      whatNext: []
    };
  }

  ngOnInit(): void {
    this.data.getFilterOptions().subscribe((opts) => {
      this.products.set([{ label: ALL, value: ALL }, ...opts.products]);
      this.actionTakenByOptions.set([{ label: ALL, value: ALL }, ...opts.actionTakenBy]);
      this.receivedByOptions.set([{ label: ALL, value: ALL }, ...opts.receivedBy]);
      this.latestOwnerOptions.set([{ label: ALL, value: ALL }, ...opts.latestOwner]);
      this.whatNextOptions.set(opts.whatNext);
      this.cdr.markForCheck();
    });

    this.customersLoading.set(true);
    this.customerData.getCustomers().subscribe((c) => {
      this.customers.set(c);
      this.customersLoading.set(false);
    });
    this.customerFilter$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((query) => this.customerData.getCustomers(query))
      )
      .subscribe((c) => this.customers.set(c));

    this.ledgerGroupsLoading.set(true);
    this.data.getLedgerGroups().subscribe((g) => {
      this.ledgerGroupOptions.set([{ label: ALL, value: ALL }, ...g]);
      this.ledgerGroupsLoading.set(false);
    });
    this.ledgerGroupFilter$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((query) => this.data.getLedgerGroups(query))
      )
      .subscribe((g) => this.ledgerGroupOptions.set([{ label: ALL, value: ALL }, ...g]));

    this.show();
  }

  onCustomerFilter(query: string): void {
    this.customerFilter$.next(query);
  }

  onLedgerGroupFilter(query: string): void {
    this.ledgerGroupFilter$.next(query);
  }

  onTicketNoInput(): void {
    if (this.filters.ticketNo && !/^\d*$/.test(this.filters.ticketNo)) {
      this.ticketNoError.set('Ticket No must contain digits only.');
      this.filters.ticketNo = '';
    } else {
      this.ticketNoError.set(null);
    }
  }

  onDateChange(): void {
    if (this.filters.fromDate && this.filters.toDate && this.filters.toDate < this.filters.fromDate) {
      this.dateError.set('To Date must be on or after From Date.');
      return;
    }
    this.dateError.set(null);
  }

  show(): void {
    // Filters can fire show() in quick succession (several dropdowns changed
    // one after another); without this guard each one kicked off its own
    // overlapping request against a view that's already slow (~4-5s for the
    // default action-joined view), piling up redundant load instead of just
    // waiting for the in-flight one.
    if (this.loading()) {
      return;
    }
    this.onDateChange();
    if (this.dateError()) {
      return;
    }
    if (!this.filters.fromDate && this.filters.toDate) {
      this.dateError.set('Please enter From Date.');
      return;
    }
    if (!this.filters.toDate && this.filters.fromDate) {
      this.dateError.set('Please enter To Date.');
      return;
    }
    this.pendingCount.set(null);
    this.loading.set(true);
    this.firstRow = 0;
    this.data.search(this.filters).subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
        if (this.filters.latestOwner !== ALL) {
          this.pendingCount.set(rows.filter((r) => !r.dueDaysByTT || r.dueDaysByTT >= 0).length);
        }
      },
      error: () => {
        this.loading.set(false);
      }
    });
  }

  export(): void {
    exportToExcel('TTRegister', this.rows());
  }

  toggleExpand(row: TtRegisterRow): void {
    if (this.expandedRow() === row.voucherNo) {
      this.expandedRow.set(null);
      return;
    }
    this.expandedRow.set(row.voucherNo);
    this.detailLoading.set(true);
    this.data.getTicketDetail(row.voucherNo).subscribe((rows) => {
      this.detailRows.set(rows);
      this.detailLoading.set(false);
    });
  }

  showHistory(row: TtRegisterRow): void {
    this.historyTitle.set(`History of TTNo. ${row.voucherNo}`);
    this.historyLoading.set(true);
    this.historyVisible.set(true);
    this.data.getOwnerHistory(row.voucherNo).subscribe((rows) => {
      this.historyRows.set(rows);
      this.historyLoading.set(false);
    });
  }
}
