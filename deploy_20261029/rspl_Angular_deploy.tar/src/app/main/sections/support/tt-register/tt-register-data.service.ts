import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../../../../shared/api-config';

const BASE = `${API_BASE_URL}/support`;

export interface LookupOption {
  label: string;
  value: string;
}

export interface TtRegisterFilters {
  product: string;
  actionTakenBy: string;
  receivedBy: string;
  ttStatus: string;
  latestOwner: string;
  ledgerGroup: string;
  custId: number | null;
  fromDate: Date | null;
  toDate: Date | null;
  ticketNo: string;
  excludeAction: boolean;
  whatNext: string[];
}

export interface TtRegisterRow {
  voucherNo: number;
  customer: string;
  calledBy: string;
  date: string;
  latestOwner: string;
  whatNext: string;
  issue: string;
  actionDate: string;
  actionTakenBy: string;
  actionDetails: string;
  actionOn: string;
  ttEnteredBy: string;
  nextPerson: string;
  dueDaysByTT: number;
  dueDaysByAction: number;
}

export interface TtDetailRow {
  voucherNo: number;
  productName: string;
  issue: string;
  action: string;
  whatNext: string;
  calledBy: string;
  closingDate: string;
  closingTime: string;
}

export interface OwnerHistoryRow {
  srNo: number;
  previousOwner: string;
  date: string;
  latestOwner: string;
}

interface ApiFilterOptions {
  products: LookupOption[];
  action_taken_by: LookupOption[];
  received_by: LookupOption[];
  latest_owner: LookupOption[];
  what_next: LookupOption[];
}

interface ApiTtRegisterRow {
  voucher_no: number;
  customer: string;
  called_by: string;
  date: string | null;
  latest_owner: string;
  what_next: string;
  issue: string;
  action_date: string | null;
  action_taken_by: string;
  action_details: string;
  action_on: string | null;
  tt_entered_by: string;
  next_person: string;
  due_days_by_tt: number;
  due_days_by_action: number;
}

interface ApiTtDetailRow {
  voucher_no: number;
  product_name: string;
  issue: string;
  action: string;
  what_next: string;
  called_by: string;
  closing_date: string;
  closing_time: string;
}

interface ApiOwnerHistoryRow {
  sr_no: number;
  previous_owner: string;
  date: string | null;
  latest_owner: string;
}

/** Calls the FastAPI backend (D:\Maruti_workspace\rspl_Api\app\routers\support_tt.py). Mirrors Section_Support/TTRegister.aspx.vb's VW_TT_Report / VW_TT_And_Action_Report views. */
@Injectable({ providedIn: 'root' })
export class TtRegisterDataService {
  private readonly http = inject(HttpClient);

  getFilterOptions(): Observable<{
    products: LookupOption[];
    actionTakenBy: LookupOption[];
    receivedBy: LookupOption[];
    latestOwner: LookupOption[];
    whatNext: LookupOption[];
  }> {
    return this.http.get<ApiFilterOptions>(`${BASE}/tt-register/filter-options`).pipe(
      map((r) => ({
        products: r.products,
        actionTakenBy: r.action_taken_by,
        receivedBy: r.received_by,
        latestOwner: r.latest_owner,
        whatNext: r.what_next
      }))
    );
  }

  /** Top-100 + type-to-search, same shape as SupportDataService.getCustomers — LedgerGroupMaster has 786 rows, too many to load and render in one shot. */
  getLedgerGroups(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/tt-register/ledger-groups`, { params: { search } });
  }

  search(filters: TtRegisterFilters): Observable<TtRegisterRow[]> {
    let params = new HttpParams()
      .set('product', filters.product)
      .set('action_taken_by', filters.actionTakenBy)
      .set('received_by', filters.receivedBy)
      .set('tt_status', filters.ttStatus)
      .set('latest_owner', filters.latestOwner)
      .set('ledger_group', filters.ledgerGroup)
      .set('ticket_no', filters.ticketNo)
      .set('exclude_action', filters.excludeAction);
    if (filters.custId) {
      params = params.set('cust_id', filters.custId);
    }
    if (filters.fromDate) {
      params = params.set('from_date', this.toDateParam(filters.fromDate));
    }
    if (filters.toDate) {
      params = params.set('to_date', this.toDateParam(filters.toDate));
    }
    for (const w of filters.whatNext) {
      params = params.append('what_next', w);
    }
    return this.http.get<ApiTtRegisterRow[]>(`${BASE}/tt-register/search`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          voucherNo: r.voucher_no,
          customer: r.customer,
          calledBy: r.called_by,
          date: r.date ?? '',
          latestOwner: r.latest_owner,
          whatNext: r.what_next,
          issue: r.issue,
          actionDate: r.action_date ?? '',
          actionTakenBy: r.action_taken_by,
          actionDetails: r.action_details,
          actionOn: r.action_on ?? '',
          ttEnteredBy: r.tt_entered_by,
          nextPerson: r.next_person,
          dueDaysByTT: r.due_days_by_tt,
          dueDaysByAction: r.due_days_by_action
        }))
      )
    );
  }

  getTicketDetail(voucherNo: number): Observable<TtDetailRow[]> {
    return this.http.get<ApiTtDetailRow[]>(`${BASE}/tt-register/ticket-detail/${voucherNo}`).pipe(
      map((rows) =>
        rows.map((r) => ({
          voucherNo: r.voucher_no,
          productName: r.product_name,
          issue: r.issue,
          action: r.action,
          whatNext: r.what_next,
          calledBy: r.called_by,
          closingDate: r.closing_date,
          closingTime: r.closing_time
        }))
      )
    );
  }

  getOwnerHistory(voucherNo: number): Observable<OwnerHistoryRow[]> {
    return this.http.get<ApiOwnerHistoryRow[]>(`${BASE}/tt-register/owner-history/${voucherNo}`).pipe(
      map((rows) =>
        rows.map((r) => ({
          srNo: r.sr_no,
          previousOwner: r.previous_owner,
          date: r.date ?? '',
          latestOwner: r.latest_owner
        }))
      )
    );
  }

  private toDateParam(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }
}
