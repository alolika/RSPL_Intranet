import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../../../../shared/api-config';

const BASE = `${API_BASE_URL}/support/executive-schedule`;

export interface Team {
  teamId: number;
  teamCode: string;
  teamName: string;
}

export interface Executive {
  executiveId: number;
  teamId: number;
  executiveName: string;
  sortOrder: number;
  rowColor: string | null;
  // Independent of rowColor — background for just this executive's own
  // Executive (name) column cell, never the row's day cells.
  columnColor: string | null;
}

export interface Cell {
  executiveId: number;
  day: number;
  text: string;
  color: string | null;
  // Independent of `color` (the box's own background) — the entered
  // text/number's own color, per explicit request to let a user color the
  // content without changing the box color.
  textColor: string | null;
}

export interface CellsResult {
  executives: Executive[];
  days: number[];
  cells: Cell[];
}

export interface UserState {
  teamId: number;
  year: number;
  month: number;
}

interface ApiTeam {
  team_id: number;
  team_code: string;
  team_name: string;
}

interface ApiExecutive {
  executive_id: number;
  team_id: number;
  executive_name: string;
  sort_order: number;
  row_color: string | null;
  column_color: string | null;
}

interface ApiCell {
  executive_id: number;
  day: number;
  text: string;
  color: string | null;
  text_color: string | null;
}

interface ApiCellsResult {
  executives: ApiExecutive[];
  days: number[];
  cells: ApiCell[];
}

interface ApiUserState {
  team_id: number;
  year: number;
  month: number;
}

function toExecutive(r: ApiExecutive): Executive {
  return {
    executiveId: r.executive_id,
    teamId: r.team_id,
    executiveName: r.executive_name,
    sortOrder: r.sort_order,
    rowColor: r.row_color,
    columnColor: r.column_color
  };
}

/**
 * Calls the FastAPI backend (D:\Maruti_workspace\rspl_Api\app\routers\support_executive_schedule.py) —
 * a brand-new, database-backed feature with no legacy source page to mirror. Replaces the retired
 * support_schedule.py (Power Automate -> Outlook -> Schedule.xlsx snapshot import, itself standing in
 * for a defunct Google Sheets integration) — the schedule now lives in RSPL_ExecSchedule* tables and is
 * edited directly here.
 *
 * The executive roster's NAMES are not edited here — they're derived live from UserMaster (Enabled=1,
 * matching the team's UserTypeID) on the backend, per explicit request to retire the old, separately
 * maintained RSPL_ExecScheduleExecutive roster. Row order and row color, however, ARE user-editable —
 * per-team presentation state stored in RSPL_ExecScheduleExecutiveMeta — hence reorderExecutives() and
 * setExecutiveColor() below.
 */
@Injectable({ providedIn: 'root' })
export class ExecutiveScheduleDataService {
  private readonly http = inject(HttpClient);

  getTeams(): Observable<Team[]> {
    return this.http
      .get<ApiTeam[]>(`${BASE}/teams`)
      .pipe(map((rows) => rows.map((r) => ({ teamId: r.team_id, teamCode: r.team_code, teamName: r.team_name }))));
  }

  // Remembers the last Team/Year/Month a given user had open — server-side
  // (not localStorage), so reopening the form on ANY device/browser, even
  // after a full system restart, lands back exactly where they left off.
  getUserState(): Observable<UserState | null> {
    return this.http
      .get<ApiUserState | null>(`${BASE}/user-state`)
      .pipe(map((r) => (r ? { teamId: r.team_id, year: r.year, month: r.month } : null)));
  }

  saveUserState(teamId: number, year: number, month: number): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${BASE}/user-state`, { team_id: teamId, year, month });
  }

  getExecutives(teamId: number): Observable<Executive[]> {
    const params = new HttpParams().set('team_id', teamId);
    return this.http.get<ApiExecutive[]>(`${BASE}/executives`, { params }).pipe(map((rows) => rows.map(toExecutive)));
  }

  reorderExecutives(teamId: number, orderedExecutiveIds: number[]): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/executives/reorder`, {
      team_id: teamId,
      ordered_executive_ids: orderedExecutiveIds
    });
  }

  setExecutiveColor(teamId: number, executiveId: number, color: string | null): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${BASE}/executives/${executiveId}/color`, { team_id: teamId, color });
  }

  // Independent counterpart to setExecutiveColor above — colors only the
  // Executive (name) column cell, never that row's day cells.
  setExecutiveColumnColor(teamId: number, executiveId: number, color: string | null): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${BASE}/executives/${executiveId}/column-color`, { team_id: teamId, color });
  }

  getCells(teamId: number, year: number, month: number): Observable<CellsResult> {
    const params = new HttpParams().set('team_id', teamId).set('year', year).set('month', month);
    return this.http.get<ApiCellsResult>(`${BASE}/cells`, { params }).pipe(
      map((r) => ({
        executives: r.executives.map(toExecutive),
        days: r.days,
        cells: r.cells.map((c) => ({ executiveId: c.executive_id, day: c.day, text: c.text, color: c.color, textColor: c.text_color }))
      }))
    );
  }

  saveCells(teamId: number, year: number, month: number, cells: Cell[]): Observable<{ success: boolean; saved_count: number }> {
    return this.http.post<{ success: boolean; saved_count: number }>(`${BASE}/cells/save`, {
      team_id: teamId,
      year,
      month,
      cells: cells.map((c) => ({ executive_id: c.executiveId, day: c.day, text: c.text, color: c.color, text_color: c.textColor }))
    });
  }

  copyMonth(
    teamId: number,
    sourceYear: number,
    sourceMonth: number,
    targetYear: number,
    targetMonth: number
  ): Observable<{ success: boolean; copied_count: number }> {
    return this.http.post<{ success: boolean; copied_count: number }>(`${BASE}/copy-month`, {
      team_id: teamId,
      source_year: sourceYear,
      source_month: sourceMonth,
      target_year: targetYear,
      target_month: targetMonth
    });
  }
}
