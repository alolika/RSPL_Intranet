import { DatePipe } from '@angular/common';
import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, OnDestroy, OnInit, ViewChild, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import * as XLSX from 'xlsx';

import { FORM_EXEC_SCHEDULE, UserRightsService } from '../../../../core/auth/user-rights.service';
import { exportToExcel } from '../../../../shared/export-excel';
import { Cell, ExecutiveScheduleDataService, Team } from './executive-schedule-data.service';

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];
// Fixed range per explicit request — the Year dropdown always shows exactly
// 2025-2050 (scrolling within the dropdown itself for the longer list),
// regardless of what the real current year is.
const MIN_YEAR = 2025;
const MAX_YEAR = 2050;
// Above this length (or containing a manual line break), a cell switches
// its edit textarea into wrap-and-scroll mode instead of the default
// grow-wider single-line mode — see isLongText() and the .scss's
// `.long-text` focus rule for the full rationale.
const LONG_TEXT_THRESHOLD = 20;
const YEARS = Array.from({ length: MAX_YEAR - MIN_YEAR + 1 }, (_, i) => MIN_YEAR + i);

interface GridCell {
  day: number;
  text: string;
  color: string | null;
  // Independent of `color` (the box's own background) — see Cell in the
  // data service for the full rationale.
  textColor: string | null;
}

interface GridRow {
  executiveId: number;
  executiveName: string;
  rowColor: string | null;
  // Independent of rowColor — the Executive (name) column's own background
  // for this row, never applied to that row's day cells (and vice versa).
  columnColor: string | null;
  cells: GridCell[];
}

interface CellEdit {
  executiveId: number;
  day: number;
  field: 'text' | 'color' | 'textColor';
  oldValue: string | null;
  newValue: string | null;
}

// Full-fidelity copy/paste payload (text + box color + text color) carried
// on the system clipboard alongside the existing plain-text format — see
// onCopy()/onPaste().
interface ClipboardCell {
  text: string;
  color: string | null;
  textColor: string | null;
}

type UndoCommand =
  | { type: 'cell-batch'; edits: CellEdit[] }
  | { type: 'reorder'; beforeOrder: number[]; afterOrder: number[] };

interface SelRange {
  r0: number;
  r1: number;
  c0: number;
  c1: number;
}

/**
 * Executive Schedule — a brand-new, database-backed, Excel-style editable
 * grid (executives x days-of-month, per-cell text + color). Replaces the
 * retired read-only g-schedule page. No grid library is used — cell
 * navigation, range copy/paste, and undo/redo are hand-built on a plain
 * table, matching this app's zero-extra-dependency convention (see
 * D:\Maruti_workspace\.claude\plans\toasty-beaming-sloth.md for the full
 * design rationale).
 *
 * The executive roster's NAMES (rows()) are read-only here — loaded straight
 * from UserMaster on the backend (Enabled=1, UserTypeID matching the
 * selected team) per explicit request to retire manual roster upkeep
 * (no add/rename/remove-executive UI). Row ORDER and row COLOR, however,
 * are still user-editable per-team presentation state (move up/down, drag
 * & drop, and a background color per executive) — persisted separately in
 * RSPL_ExecScheduleExecutiveMeta, independent of the per-CELL text/color
 * this component was already editing.
 *
 * Update (2026-08-05): single-click-selects / double-click-to-edit, per
 * explicit request — every cell used to render as an always-editable
 * <textarea>, so a single click (which focuses a textarea) was already
 * indistinguishable from "start editing." Cells now default to a
 * read-only display <div> (editingCell above tracks the ONE cell, if any,
 * currently swapped for the real <textarea> — see the .html's
 * @if (isEditingCell(ri, ci))); a single click (onCellMouseDown, unchanged)
 * only sets selection, and onCellDoubleClick is the sole entry point into
 * edit mode. Arrow-key navigation (moveFocus(), unchanged — it was already
 * just "focus by element id" and doesn't care whether that id currently
 * belongs to a div or a textarea), range selection/highlighting
 * (isSelected(), unchanged), copy/paste (onCopy/onPaste, unchanged — they
 * already operated on rows()/selectedRange() data, never on DOM textarea
 * elements), color apply, undo/redo, and autosave are all untouched by
 * this change; only how a cell ENTERS edit mode changed. New
 * isRowSelected() highlights the row's Executive Name to match, per
 * explicit request.
 *
 * Update (2026-08-05, later same day): F2 is now a second entry point into
 * edit mode, per explicit request (spreadsheet convention: select a cell,
 * press F2 to edit it, same as double-click) — see the 'F2' case in
 * onKeyDown, which just calls the exact same onCellDoubleClick(ri, ci, row,
 * cell) a double-click does, so its no-op guards (already editing this
 * cell, or !canEdit()) and its focus/autoResize behavior are identical
 * either way. Everything else in onKeyDown (Tab/Enter/Arrow navigation) is
 * unchanged.
 */
@Component({
  selector: 'app-executive-schedule',
  imports: [FormsModule, ButtonModule, SelectModule, InputTextModule, DatePipe],
  templateUrl: './executive-schedule.html',
  styleUrl: './executive-schedule.scss'
})
export class ExecutiveSchedule implements OnInit, AfterViewInit, OnDestroy {
  private readonly data = inject(ExecutiveScheduleDataService);
  // No zone.js in this app — plain (non-signal) properties mutated inside
  // subscribe callbacks or plain event handlers that affect OTHER template
  // regions (not just the element the event fired on) need an explicit
  // markForCheck() to actually get on screen.
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly rights = inject(UserRightsService);

  // User Rights: 'view'-only users can open/see this form (route guard
  // already handles 'none') but every add/edit/save/color/reorder action is
  // blocked — both hidden in the template (via this signal) and re-checked
  // at the top of each mutating method below, since a readonly textarea
  // alone doesn't stop the (paste)/(keydown) handlers bound on the table.
  readonly canEdit = computed(() => this.rights.canEdit(FORM_EXEC_SCHEDULE));

  readonly months = MONTHS;
  readonly monthOptions = MONTHS.map((label, value) => ({ label, value }));
  readonly yearOptions = YEARS.map((y) => ({ label: String(y), value: y }));
  readonly minYear = MIN_YEAR;
  readonly maxYear = MAX_YEAR;
  // Kept as-is: still used by the per-executive row-color popup below
  // (toggleRowColorPicker/setRowColor), which this request doesn't touch.
  readonly colorSwatches = ['#90ee90', '#ffff00', '#ff6b6b', '#6ea8fe', '#ffa94d', '#b197fc'];

  // The Box/Text Color picker's palette — a much larger fixed set standing
  // in for "all available colors", opened from a single button instead of
  // showing every swatch inline. True arbitrary color selection still comes
  // from the native <input type="color"> inside that same popup (see the
  // .html), which covers any color the 31 swatches here don't.
  readonly colorPalette = [
    '#000000', '#495057', '#7f7f7f', '#adb5bd', '#ced4da', '#f1f3f5', '#ffffff',
    '#c00000', '#ff0000', '#ff6b6b', '#e64980', '#f783ac',
    '#ffa94d', '#ff922b', '#ffc000', '#ffd43b', '#ffff00',
    '#92d050', '#90ee90', '#63e6be', '#00b050', '#20c997',
    '#00b0f0', '#6ea8fe', '#4dabf7', '#0070c0', '#002060',
    '#7030a0', '#845ef7', '#b197fc', '#69db7c', '#fab005',
  ];

  readonly teams = signal<Team[]>([]);
  readonly rows = signal<GridRow[]>([]);
  readonly days = signal<number[]>([]);
  readonly loading = signal(false);
  readonly saving = signal(false);
  readonly canUndo = signal(false);
  readonly canRedo = signal(false);
  readonly dirtyKeys = signal<Set<string>>(new Set());
  readonly searchTerm = signal('');
  readonly showSaveAs = signal(false);
  readonly expanded = signal(false);
  // Collapses just the Team/Month/Year filter row (independent of
  // `expanded` above, which is the existing full-screen-grid toggle) — per
  // explicit request, to free up even more vertical space once a team/month
  // is already picked and the user is just working the grid.
  readonly filtersExpanded = signal(true);
  readonly colorPickerForExecutiveId = signal<number | null>(null);
  // Mirrors colorPickerForExecutiveId above, but for the independent
  // Column Color popup (see the "executive column color" section below).
  readonly columnColorPickerForExecutiveId = signal<number | null>(null);

  // Single-scrollbar sticky architecture. .grid-scroll is a REAL bounded
  // scroll container (max-height + overflow: auto, sized by
  // --grid-max-height below) — thead th / .capacity-row stick with plain
  // `top` values relative to THAT box (see the .scss), which is the
  // standard, reliably-supported sticky pattern.
  //
  // "Single scrollbar" (per explicit request) comes from sizing that box,
  // LIVE, to exactly fill the remaining viewport below it — top +=
  // getBoundingClientRect().top (brand header + nav + page padding + this
  // form's own toolbar, whatever its current height is) + a fixed reserve
  // for the footer below — so the outer page itself never needs to grow
  // past 100vh and never has its own competing scrollbar. This is also why
  // an earlier version of this fix (offsetting thead/.capacity-row's own
  // `top` by the toolbar height, sticky relative to the page) broke down on
  // long scrolls: .grid-scroll's own `overflow-x: auto` implicitly computes
  // `overflow-y: auto` too (CSS overflow-x/-y interop rule), which silently
  // makes .grid-scroll itself — not the page — the nearest scroll-container
  // ancestor for its sticky children, no matter what `top` value they use.
  // Measuring THIS box's own real position sidesteps that entirely: sticky
  // works correctly relative to whatever the true container is.
  readonly gridMaxHeightPx = signal(0);
  // Live-measured height of the <thead> row itself (was a hardcoded 3.4rem
  // guess before — any drift between that guess and the row's real
  // rendered height left a gap or overlap between the Date Header and
  // Installation Capacity sticky rows).
  readonly theadHeightPx = signal(0);
  @ViewChild('stickyWrap') private stickyWrapRef?: ElementRef<HTMLElement>;
  @ViewChild('theadRow') private theadRowRef?: ElementRef<HTMLElement>;
  @ViewChild('gridScroll') private gridScrollRef?: ElementRef<HTMLElement>;
  private stickyResizeObserver?: ResizeObserver;
  private readonly onWindowResize = (): void => this.recomputeGridMaxHeight();

  // Per-day-column summary rows. Cells hold free-text (shift codes/notes,
  // not a dedicated numeric field — see GridCell above), so a cell counts
  // toward the total only when its text parses as a number; anything else
  // (blank, a shift code) contributes 0. computed() over rows()/days()
  // means both rows recalculate automatically on every path that already
  // calls rows.set(...) — blur, paste, color apply, undo/redo, import —
  // with no new wiring needed per edit path.
  //
  // Index-based (row.cells[ci] against days()[ci]), not a `.find()` by day,
  // since loadMonth() always builds each row's cells in the same order as
  // days() — matches the indexing the rest of this component already
  // assumes (see moveFocus()'s day/ci handling).
  readonly columnTotals = computed<number[]>(() => {
    const rows = this.rows();
    return this.days().map((_, ci) => rows.reduce((sum, row) => sum + ExecutiveSchedule.parseCellNumber(row.cells[ci]?.text ?? ''), 0));
  });

  // Installation Capacity = Total - 7 (fixed weekly baseline of 7 per day
  // column, per explicit request — not configurable per team/executive).
  // e.g. Total 18 -> 11, Total 10 -> 3, Total 7 -> 0. The Total - 7 math
  // still runs in full internally; only the displayed/summed result is
  // floored at 0 (Total < 7 shows 0, never -6/-7/etc.) per explicit request
  // — clamped here at the computed-signal level rather than just in the
  // template, so the floor applies consistently everywhere this value
  // feeds into (the per-day cell, and grandTotalCapacity() below).
  readonly installationCapacity = computed<number[]>(() => this.columnTotals().map((total) => Math.max(0, total - 7)));

  // Grand Total column at the right of both summary rows — plain sums of
  // the already-reactive per-day arrays above, so these need no separate
  // wiring to onCellValueChange(): they recompute whenever columnTotals()/
  // installationCapacity() do, which is already real-time on every keystroke.
  readonly grandTotal = computed<number>(() => this.columnTotals().reduce((sum, n) => sum + n, 0));
  readonly grandTotalCapacity = computed<number>(() => this.installationCapacity().reduce((sum, n) => sum + n, 0));

  // Same Grand Total / Percentage columns, per executive row this time
  // (rows()-indexed instead of days()-indexed) — each executive's own row
  // total across every date column, and that total's share of the same
  // totalDaysInMonth() denominator used by the two summary rows below.
  // Templated via [ri] against rows() the same way columnTotals()[ci] is
  // already templated against days() — one computed() per column, indexed
  // by the @for loop's own $index, rather than a method call per row.
  readonly executiveGrandTotals = computed<number[]>(() =>
    this.rows().map((row) => row.cells.reduce((sum, cell) => sum + ExecutiveSchedule.parseCellNumber(cell.text), 0))
  );
  readonly executivePercentages = computed<number[]>(() => {
    const max = this.totalDaysInMonth();
    return this.executiveGrandTotals().map((total) => ExecutiveSchedule.percentOf(total, max));
  });

  // Percentage (%) = Grand Total / Total Days in Month x 100, per explicit
  // request (e.g. a 31-day month with Grand Total 31 -> 100%; this replaced
  // an earlier "x 7 baseline capacity per day" denominator). days().length
  // is exactly that month's real day count (28-31, whatever loadMonth()
  // actually loaded for the selected month/year), so this already tracks
  // month length correctly with no separate lookup needed. Both summary
  // rows share this one denominator — only the numerator differs (each
  // row's own Grand Total). Guards max <= 0 (no days loaded yet) to show
  // 0% instead of dividing by zero.
  readonly totalDaysInMonth = computed<number>(() => this.days().length);
  readonly totalPercentage = computed<number>(() => ExecutiveSchedule.percentOf(this.grandTotal(), this.totalDaysInMonth()));
  readonly capacityPercentage = computed<number>(() => ExecutiveSchedule.percentOf(this.grandTotalCapacity(), this.totalDaysInMonth()));

  // Rounded to at most 1 decimal place (e.g. 75, 92.5) — the template
  // appends the literal "%" sign, and a plain number binding already drops
  // a trailing ".0" on its own (75 renders "75", not "75.0").
  private static percentOf(value: number, max: number): number {
    if (max <= 0) {
      return 0;
    }
    return Math.round((value / max) * 1000) / 10;
  }

  private static parseCellNumber(text: string): number {
    const n = Number(text);
    return Number.isFinite(n) ? n : 0;
  }

  selectedTeamId: number | null = null;
  // Clamped into [MIN_YEAR, MAX_YEAR] — if the real current year ever falls
  // outside that fixed range, the form opens on the nearest in-range
  // year/current-month rather than a year that isn't even in the dropdown.
  selectedYear = ExecutiveSchedule.clampYear(new Date().getFullYear());
  selectedMonth = new Date().getMonth();
  saveAsYear = ExecutiveSchedule.clampYear(new Date().getFullYear());
  saveAsMonth = new Date().getMonth();

  // Which single cell (if any) is currently in EDIT mode — per explicit
  // request, a single click only selects a cell (see onCellMouseDown/
  // onCellSelect below); only a double-click (onCellDoubleClick) enters
  // edit mode, which swaps that one cell's read-only display div for the
  // real <textarea> in the template. A signal (not a plain property) since
  // it's read directly inside the template's @if per cell — Angular's
  // zoneless signal reactivity re-renders the affected @if branch on its
  // own, no markForCheck() needed here unlike the plain
  // selectionAnchor/Focus properties below.
  readonly editingCell = signal<{ ri: number; ci: number } | null>(null);

  private undoStack: UndoCommand[] = [];
  private redoStack: UndoCommand[] = [];
  private editOriginalText = new Map<string, string>();
  private selectionAnchor: { ri: number; ci: number } | null = null;
  private selectionFocus: { ri: number; ci: number } | null = null;
  private dragging = false;
  private rowDragSourceIndex: number | null = null;

  private static clampYear(year: number): number {
    return Math.min(Math.max(year, MIN_YEAR), MAX_YEAR);
  }

  // Was previously always reset to teams[0] (Jwellsoft) on every fresh
  // mount — since Angular destroys/recreates this component on route
  // re-entry (and always on a full page reload), any executive added while
  // viewing the OTHER team appeared to "disappear" on refresh/reopen: the
  // row was correctly persisted the whole time, it was just hidden behind
  // the wrong team filter.
  //
  // Restores whichever Team/Year/Month was last viewed, per explicit
  // request that this survive not just a refresh but reopening the app on
  // a different device or after a system restart — hence a server-side
  // lookup (RSPL_ExecScheduleUserState, per user) rather than the
  // browser-local localStorage this used before, which only ever worked on
  // one machine/browser profile.
  ngOnInit(): void {
    this.data.getTeams().subscribe((teams) => {
      this.teams.set(teams);
      if (teams.length && !this.selectedTeamId) {
        const fallback = teams.find((t) => t.teamCode === 'RETAILWARE') ?? teams[0];
        this.data.getUserState().subscribe({
          next: (state) => {
            if (state && teams.some((t) => t.teamId === state.teamId)) {
              this.selectedTeamId = state.teamId;
              this.selectedYear = ExecutiveSchedule.clampYear(state.year);
              this.selectedMonth = state.month - 1;
            } else {
              this.selectedTeamId = fallback.teamId;
            }
            this.loadMonth();
            this.cdr.markForCheck();
          },
          error: () => {
            // No saved state yet (or a transient failure reading it) —
            // fall back to the same default a first-ever open would use.
            this.selectedTeamId = fallback.teamId;
            this.loadMonth();
            this.cdr.markForCheck();
          }
        });
      }
      this.cdr.markForCheck();
    });
  }

  // Fire-and-forget, same pattern as cell autosave — called after every
  // user-initiated team/month/year change so the next time this form opens
  // (this session or any other) it resumes here.
  private persistUserState(): void {
    const teamId = this.selectedTeamId;
    if (!teamId) {
      return;
    }
    this.data.saveUserState(teamId, this.selectedYear, this.selectedMonth + 1).subscribe();
  }

  cellId(executiveId: number, day: number): string {
    return `cell-${executiveId}-${day}`;
  }

  // Drives the [class.long-text] binding on the edit textarea (see the
  // .html/.scss). Evaluated against the cell's CURRENT text, so a
  // double-click on already-long content opens straight into wrap/scroll
  // mode — the actual reported problem — and typing/pasting past the
  // threshold switches into it live too.
  isLongText(text: string): boolean {
    return text.length > LONG_TEXT_THRESHOLD || text.includes('\n');
  }

  // Backs the column header's date pipe bindings (see the .html) — a plain
  // method, not a memoized signal, since it's cheap and the header only
  // ever re-renders when days()/selectedYear/selectedMonth change together
  // via loadMonth() anyway.
  dateForDay(day: number): Date {
    return new Date(this.selectedYear, this.selectedMonth, day);
  }

  get dirtyCount(): number {
    return this.dirtyKeys().size;
  }

  onTeamChange(): void {
    this.loadMonth();
    this.persistUserState();
  }

  toggleExpanded(): void {
    this.expanded.update((v) => !v);
  }

  toggleFilters(): void {
    this.filtersExpanded.update((v) => !v);
  }

  // Compact "Retailware · August 2026" summary shown in place of the full
  // Team/Month/Year controls when filtersExpanded() is false. A plain
  // method (not computed()) — selectedTeamId/selectedMonth/selectedYear are
  // plain properties, not signals, same as dateForDay() above, so this is
  // re-evaluated by Angular's own template change detection instead.
  filtersSummary(): string {
    const team = this.teams().find((t) => t.teamId === this.selectedTeamId);
    const monthLabel = this.months[this.selectedMonth] ?? '';
    return `${team?.teamName ?? 'No team selected'} · ${monthLabel} ${this.selectedYear}`;
  }

  onMonthYearChange(): void {
    this.loadMonth();
    this.persistUserState();
  }

  prevMonth(): void {
    if (this.selectedMonth === 0) {
      // Never go back past January of MIN_YEAR — the Year dropdown has
      // nothing before it to land on.
      if (this.selectedYear <= MIN_YEAR) {
        return;
      }
      this.selectedMonth = 11;
      this.selectedYear--;
    } else {
      this.selectedMonth--;
    }
    this.loadMonth();
    this.persistUserState();
  }

  nextMonth(): void {
    if (this.selectedMonth === 11) {
      // Never advance past December of MAX_YEAR — the Year dropdown has
      // nothing beyond it to land on.
      if (this.selectedYear >= MAX_YEAR) {
        return;
      }
      this.selectedMonth = 0;
      this.selectedYear++;
    } else {
      this.selectedMonth++;
    }
    this.loadMonth();
    this.persistUserState();
  }

  goToCurrentMonth(): void {
    this.selectedYear = ExecutiveSchedule.clampYear(new Date().getFullYear());
    this.selectedMonth = new Date().getMonth();
    this.loadMonth();
    this.persistUserState();
  }

  private loadMonth(): void {
    const teamId = this.selectedTeamId;
    if (!teamId) {
      return;
    }
    this.loading.set(true);
    this.undoStack = [];
    this.redoStack = [];
    this.canUndo.set(false);
    this.canRedo.set(false);
    this.dirtyKeys.set(new Set());
    this.editOriginalText.clear();
    this.selectionAnchor = null;
    this.selectionFocus = null;
    this.editingCell.set(null);
    this.data.getCells(teamId, this.selectedYear, this.selectedMonth + 1).subscribe((result) => {
      this.days.set(result.days);
      this.rows.set(
        result.executives.map((exec) => ({
          executiveId: exec.executiveId,
          executiveName: exec.executiveName,
          rowColor: exec.rowColor,
          columnColor: exec.columnColor,
          cells: result.days.map((day) => {
            const found = result.cells.find((c) => c.executiveId === exec.executiveId && c.day === day);
            return { day, text: found?.text ?? '', color: found?.color ?? null, textColor: found?.textColor ?? null };
          })
        }))
      );
      this.loading.set(false);
      this.cdr.markForCheck();
      this.resizeAllCellsSoon();
    });
  }

  // ---------- auto-resize (cell wraps + row height grows with content) ----------

  // Called directly from the textarea's (input) event for live typing, and
  // from the bulk-resize paths below (month load, paste, undo/redo, color
  // changes) — height-only, since those bulk paths touch cells that are
  // NOT currently focused and must never change column-affecting width.
  autoResize(el: HTMLTextAreaElement): void {
    el.style.height = 'auto';
    el.style.height = `${el.scrollHeight}px`;
  }

  // Companion to autoResize() above, width instead of height — grows the
  // box live to fit whatever's typed/pasted so the full value is always on
  // screen (per explicit request), without ever changing the table's own
  // column widths. Only ever called while the field is actively focused
  // (see onCellInput()/the .html) — the :focus rule in the .scss
  // absolutely-positions the textarea so it floats above neighboring cells
  // while expanded, rather than pushing the real table column wider.
  // onCellBlur() reverts the inline width the instant editing ends, so
  // every other row/column stays exactly as wide as it always was.
  private autoResizeWidth(el: HTMLTextAreaElement): void {
    el.style.width = 'auto';
    el.style.width = `${el.scrollWidth + 2}px`;
  }

  // Bound to (input) instead of autoResize() directly, so live typing gets
  // both the existing height growth AND the new width growth — every other
  // caller of autoResize() (bulk resize paths, see above) still only ever
  // touches height.
  onCellInput(el: HTMLTextAreaElement): void {
    this.autoResize(el);
    if (el.classList.contains('long-text')) {
      // CSS now owns width (wrap + capped max-width, see .long-text in the
      // .scss) for long content — clear any inline width a shorter earlier
      // draft of this same edit may have left behind via autoResizeWidth()
      // below, since an inline style always outranks a CSS class rule
      // regardless of specificity and would otherwise silently pin the box
      // to a stale single-line width.
      el.style.removeProperty('width');
    } else {
      this.autoResizeWidth(el);
    }
  }

  // Called once after a full month/team load or a bulk import — these are
  // the only cases where genuinely every cell's height may need
  // recalculating from scratch. Deferred one tick so the DOM reflects the
  // new text before scrollHeight is read.
  private resizeAllCellsSoon(): void {
    setTimeout(() => {
      document.querySelectorAll<HTMLTextAreaElement>('.cell textarea').forEach((el) => this.autoResize(el));
    });
  }

  // Targeted resize for a normal edit (single-cell blur, paste of a range,
  // a color change, an undo/redo) — only the cells actually touched.
  //
  // Previously every one of those calls went through resizeAllCellsSoon(),
  // which re-measures EVERY textarea in the whole grid via
  // querySelectorAll('.cell textarea'). With many rows (the 15-per-team
  // test dataset, 15 x 31 = 465 cells) that's 465 forced
  // height='auto' + scrollHeight reads in a tight loop — a classic
  // layout-thrash pattern (each write invalidates layout, forcing the next
  // read to trigger a synchronous reflow). That's what was actually behind
  // the reported "colors/formatting glitch when editing near the bottom
  // after scrolling": editing ONE cell was silently re-touching every
  // other row's DOM nodes too, which is also a literal violation of
  // "editing a cell should not affect any other visible rows." Resizing
  // only the cells that actually changed removes the thrash entirely and
  // means an edit genuinely never touches unrelated rows.
  private resizeCellsSoon(cells: { executiveId: number; day: number }[]): void {
    if (cells.length === 0) {
      return;
    }
    setTimeout(() => {
      for (const c of cells) {
        const el = document.getElementById(this.cellId(c.executiveId, c.day)) as HTMLTextAreaElement | null;
        if (el) {
          this.autoResize(el);
        }
      }
    });
  }

  // ---------- keyboard navigation ----------

  onKeyDown(event: KeyboardEvent): void {
    const target = event.target as HTMLElement;
    const parsed = this.parseCellId(target.id);
    if (!parsed) {
      return;
    }
    const ri = this.rows().findIndex((r) => r.executiveId === parsed.executiveId);
    const ci = this.days().indexOf(parsed.day);
    if (ri < 0 || ci < 0) {
      return;
    }
    switch (event.key) {
      case 'Tab':
        event.preventDefault();
        this.moveFocus(ri, ci, event.shiftKey ? -1 : 1, 0, true);
        break;
      case 'Enter':
        event.preventDefault();
        this.moveFocus(ri, ci, 0, 1, false);
        break;
      case 'ArrowLeft':
        event.preventDefault();
        this.moveFocus(ri, ci, -1, 0, false);
        break;
      case 'ArrowRight':
        event.preventDefault();
        this.moveFocus(ri, ci, 1, 0, false);
        break;
      case 'ArrowUp':
        event.preventDefault();
        this.moveFocus(ri, ci, 0, -1, false);
        break;
      case 'ArrowDown':
        event.preventDefault();
        this.moveFocus(ri, ci, 0, 1, false);
        break;
      case 'F2': {
        // Spreadsheet-style "enter edit mode on the selected cell," per
        // explicit request — the same entry point as a double-click
        // (onCellDoubleClick already no-ops if this cell is already being
        // edited, or if !canEdit()), just triggered from the keyboard
        // instead of the mouse. Works whether the keydown's target is
        // currently the read-only display div (the normal "just selected"
        // case) or, harmlessly, the textarea itself (already editing —
        // the no-op guard catches that).
        event.preventDefault();
        const row = this.rows()[ri];
        const cell = row?.cells[ci];
        if (row && cell) {
          this.onCellDoubleClick(ri, ci, row, cell);
        }
        break;
      }
    }
  }

  private parseCellId(id: string): { executiveId: number; day: number } | null {
    const match = /^cell-(\d+)-(\d+)$/.exec(id);
    if (!match) {
      return null;
    }
    return { executiveId: Number(match[1]), day: Number(match[2]) };
  }

  private moveFocus(ri: number, ci: number, dCol: number, dRow: number, wrap: boolean): void {
    const rows = this.rows();
    const days = this.days();
    let newRi = ri + dRow;
    let newCi = ci + dCol;
    if (wrap) {
      if (newCi >= days.length) {
        newCi = 0;
        newRi = ri + 1;
      } else if (newCi < 0) {
        newCi = days.length - 1;
        newRi = ri - 1;
      }
    }
    newRi = Math.max(0, Math.min(rows.length - 1, newRi));
    newCi = Math.max(0, Math.min(days.length - 1, newCi));
    const row = rows[newRi];
    const day = days[newCi];
    if (!row) {
      return;
    }
    document.getElementById(this.cellId(row.executiveId, day))?.focus();
  }

  // ---------- selection + copy/paste ----------

  onCellMouseDown(ri: number, ci: number): void {
    this.dragging = true;
    this.selectionAnchor = { ri, ci };
    this.selectionFocus = { ri, ci };
    this.cdr.markForCheck();
  }

  onCellMouseEnter(ri: number, ci: number): void {
    if (!this.dragging) {
      return;
    }
    this.selectionFocus = { ri, ci };
    this.cdr.markForCheck();
  }

  onGridMouseUp(): void {
    this.dragging = false;
  }

  onCellFocus(ri: number, ci: number, row: GridRow, cell: GridCell): void {
    if (!this.dragging) {
      this.selectionAnchor = { ri, ci };
      this.selectionFocus = { ri, ci };
      this.cdr.markForCheck();
    }
    const key = `${row.executiveId}:${cell.day}`;
    if (!this.editOriginalText.has(key)) {
      this.editOriginalText.set(key, cell.text);
    }
  }

  // Focus handler for a cell's READ-ONLY display div (the default state —
  // see editingCell above) — a single click (via onCellMouseDown, which
  // fires first) or arrow-key navigation (moveFocus()'s .focus() call)
  // lands here. Deliberately a lighter version of onCellFocus above: it
  // only tracks selection, not editOriginalText (that snapshot belongs to
  // an actual edit session — see onCellDoubleClick — not to merely
  // selecting a cell, which would otherwise leak an entry into
  // editOriginalText every time a user clicks around without ever editing
  // anything, since a plain display div has no (blur) handler to clear it).
  onCellSelect(ri: number, ci: number): void {
    if (!this.dragging) {
      this.selectionAnchor = { ri, ci };
      this.selectionFocus = { ri, ci };
      this.cdr.markForCheck();
    }
  }

  isEditingCell(ri: number, ci: number): boolean {
    const e = this.editingCell();
    return !!e && e.ri === ri && e.ci === ci;
  }

  // Executive Name highlight companion to isSelected() below — true for
  // every row touched by the current selection range (matches multi-row
  // drag-selections the same way isSelected() already does per-cell), per
  // explicit request that the row's Executive Name stays identifiable
  // alongside whichever of its cells is selected.
  isRowSelected(ri: number): boolean {
    const range = this.selectedRange();
    return !!range && ri >= range.r0 && ri <= range.r1;
  }

  // Double-click ONLY entry point into edit mode, per explicit request — a
  // single click (onCellMouseDown/onCellSelect above) must never do this.
  // Swaps the cell's display div for the real <textarea> (see the .html's
  // @if (isEditingCell(ri, ci))) and focuses it once Angular has rendered
  // that swap (same deferred-setTimeout pattern this file already uses for
  // post-render DOM work, e.g. resizeCellsSoon()). autoResize() is called
  // once right after focusing so a cell whose existing text wraps to
  // multiple lines starts the textarea at the correct height immediately,
  // matching how the display div was already showing it, rather than
  // starting collapsed to a single line (rows="1") until the next
  // keystroke recalculates it.
  onCellDoubleClick(ri: number, ci: number, row: GridRow, cell: GridCell): void {
    if (this.isEditingCell(ri, ci) || !this.canEdit()) {
      return;
    }
    this.editingCell.set({ ri, ci });
    setTimeout(() => {
      const el = document.getElementById(this.cellId(row.executiveId, cell.day)) as HTMLTextAreaElement | null;
      if (el) {
        el.focus();
        this.autoResize(el);
      }
    });
  }

  // Fires on every keystroke ([(ngModel)]'s default updateOn is "change",
  // which for a textarea is the native 'input' event) — after cell.text has
  // already been written, per ngModelChange's own contract. Purely a signal
  // "touch": a new outer array so columnTotals()/installationCapacity()
  // (both computed() over rows()) notice and recompute immediately, without
  // waiting for the next rows.set(...) call from blur/paste/etc. The row and
  // cell objects themselves are the same references, so @for's track
  // functions correctly skip re-rendering every other cell — this only
  // touches the Total/Installation Capacity row's cells, not autosave or
  // dirty-tracking (still blur-only, unchanged).
  onCellValueChange(): void {
    this.rows.set([...this.rows()]);
  }

  onCellBlur(row: GridRow, cell: GridCell, el: HTMLTextAreaElement): void {
    // Reverts the live-typing width expansion from onCellInput() back to
    // the grid's normal, column-safe wrapped display — remeasures height
    // afterwards since text that fit on one un-wrapped line while editing
    // may now need more vertical room once it wraps again at the column's
    // normal fixed width.
    el.style.removeProperty('width');
    this.autoResize(el);

    const key = `${row.executiveId}:${cell.day}`;
    const original = this.editOriginalText.get(key);
    this.editOriginalText.delete(key);
    if (original !== undefined && original !== cell.text) {
      this.pushUndo({ type: 'cell-batch', edits: [{ executiveId: row.executiveId, day: cell.day, field: 'text', oldValue: original, newValue: cell.text }] });
      this.markDirty(row.executiveId, cell.day);
      this.autoSaveCells([{ executiveId: row.executiveId, day: cell.day, text: cell.text, color: cell.color, textColor: cell.textColor }]);
    }

    // Exit edit mode — only one cell is ever in edit mode at a time (see
    // editingCell above), and this blur always belongs to whichever cell
    // that currently is, so it's always correct to clear it unconditionally
    // here rather than checking it's THIS specific cell.
    this.editingCell.set(null);
  }

  isSelected(ri: number, ci: number): boolean {
    const range = this.selectedRange();
    return !!range && ri >= range.r0 && ri <= range.r1 && ci >= range.c0 && ci <= range.c1;
  }

  private selectedRange(): SelRange | null {
    if (!this.selectionAnchor || !this.selectionFocus) {
      return null;
    }
    return {
      r0: Math.min(this.selectionAnchor.ri, this.selectionFocus.ri),
      r1: Math.max(this.selectionAnchor.ri, this.selectionFocus.ri),
      c0: Math.min(this.selectionAnchor.ci, this.selectionFocus.ci),
      c1: Math.max(this.selectionAnchor.ci, this.selectionFocus.ci)
    };
  }

  onCopy(event: ClipboardEvent): void {
    const range = this.selectedRange();
    if (!range) {
      return;
    }
    event.preventDefault();
    const rows = this.rows();
    const lines: string[] = [];
    const structuredRows: ClipboardCell[][] = [];
    for (let ri = range.r0; ri <= range.r1; ri++) {
      const cols: string[] = [];
      const structuredCols: ClipboardCell[] = [];
      for (let ci = range.c0; ci <= range.c1; ci++) {
        const cell = rows[ri]?.cells[ci];
        cols.push(cell?.text ?? '');
        structuredCols.push({ text: cell?.text ?? '', color: cell?.color ?? null, textColor: cell?.textColor ?? null });
      }
      lines.push(cols.join('\t'));
      structuredRows.push(structuredCols);
    }
    // text/plain: unchanged from before this feature existed — what a paste
    // into Excel/Notepad/another app sees. application/json rides alongside
    // it as a full-fidelity side channel (text + box color + text color)
    // that only this grid's own onPaste() below understands, so copying to
    // and pasting from anywhere else is completely unaffected.
    event.clipboardData?.setData('text/plain', lines.join('\n'));
    event.clipboardData?.setData('application/json', JSON.stringify(structuredRows));
  }

  onPaste(event: ClipboardEvent): void {
    if (!this.canEdit()) {
      return;
    }
    const range = this.selectedRange();
    if (!range) {
      return;
    }
    event.preventDefault();

    const structuredRows = this.parseClipboardJson(event.clipboardData?.getData('application/json') ?? '');
    if (structuredRows) {
      this.pasteStructuredCells(range, structuredRows);
      return;
    }

    // Fallback — no (or unrecognized) application/json payload, e.g. a
    // paste sourced from Excel/Notepad/another app: exact same text-only
    // behavior this already had before Copy/Paste carried color.
    const text = event.clipboardData?.getData('text/plain') ?? '';
    if (!text) {
      return;
    }
    const lines = text.replace(/\r/g, '').split('\n');
    while (lines.length && lines[lines.length - 1] === '') {
      lines.pop();
    }
    const rows = this.rows();
    const days = this.days();
    const edits: CellEdit[] = [];
    const cellsToSave: Cell[] = [];
    lines.forEach((line, li) => {
      const ri = range.r0 + li;
      if (ri >= rows.length) {
        return;
      }
      const cols = line.split('\t');
      cols.forEach((val, ci_offset) => {
        const ci = range.c0 + ci_offset;
        if (ci >= days.length) {
          return;
        }
        const cell = rows[ri].cells[ci];
        if (cell.text !== val) {
          edits.push({ executiveId: rows[ri].executiveId, day: cell.day, field: 'text', oldValue: cell.text, newValue: val });
          cell.text = val;
          this.markDirty(rows[ri].executiveId, cell.day);
          cellsToSave.push({ executiveId: rows[ri].executiveId, day: cell.day, text: cell.text, color: cell.color, textColor: cell.textColor });
        }
      });
    });
    if (edits.length) {
      this.pushUndo({ type: 'cell-batch', edits });
      this.rows.set([...rows]);
      this.resizeCellsSoon(cellsToSave);
      this.autoSaveCells(cellsToSave);
    }
  }

  // Validates the parsed shape defensively before trusting it — some other
  // app/extension could in principle have written its own unrelated JSON to
  // the clipboard's application/json slot; anything that doesn't look like
  // our own [[{text,color,textColor}]] shape falls through to the plain-text
  // path instead of being treated as valid cell data.
  private parseClipboardJson(raw: string): ClipboardCell[][] | null {
    if (!raw) {
      return null;
    }
    try {
      const parsed: unknown = JSON.parse(raw);
      if (!Array.isArray(parsed) || !parsed.every((row) => Array.isArray(row) && row.every(this.isClipboardCell))) {
        return null;
      }
      return parsed as ClipboardCell[][];
    } catch {
      return null;
    }
  }

  private isClipboardCell(value: unknown): value is ClipboardCell {
    if (typeof value !== 'object' || value === null) {
      return false;
    }
    const v = value as Record<string, unknown>;
    return typeof v['text'] === 'string' && (v['color'] === null || typeof v['color'] === 'string') && (v['textColor'] === null || typeof v['textColor'] === 'string');
  }

  // Pastes text + box color + text color together — the paste equivalent of
  // typing a value AND picking both colors by hand, going through the exact
  // same markDirty/undo/autosave pipeline as every other edit path here.
  private pasteStructuredCells(range: SelRange, structuredRows: ClipboardCell[][]): void {
    const rows = this.rows();
    const days = this.days();
    const edits: CellEdit[] = [];
    const cellsToSave: Cell[] = [];
    structuredRows.forEach((line, li) => {
      const ri = range.r0 + li;
      if (ri >= rows.length) {
        return;
      }
      line.forEach((copied, ciOffset) => {
        const ci = range.c0 + ciOffset;
        if (ci >= days.length) {
          return;
        }
        const cell = rows[ri].cells[ci];
        let changed = false;
        if (cell.text !== copied.text) {
          edits.push({ executiveId: rows[ri].executiveId, day: cell.day, field: 'text', oldValue: cell.text, newValue: copied.text });
          cell.text = copied.text;
          changed = true;
        }
        if (cell.color !== copied.color) {
          edits.push({ executiveId: rows[ri].executiveId, day: cell.day, field: 'color', oldValue: cell.color, newValue: copied.color });
          cell.color = copied.color;
          changed = true;
        }
        if (cell.textColor !== copied.textColor) {
          edits.push({ executiveId: rows[ri].executiveId, day: cell.day, field: 'textColor', oldValue: cell.textColor, newValue: copied.textColor });
          cell.textColor = copied.textColor;
          changed = true;
        }
        if (changed) {
          this.markDirty(rows[ri].executiveId, cell.day);
          cellsToSave.push({ executiveId: rows[ri].executiveId, day: cell.day, text: cell.text, color: cell.color, textColor: cell.textColor });
        }
      });
    });
    if (edits.length) {
      this.pushUndo({ type: 'cell-batch', edits });
      this.rows.set([...rows]);
      this.resizeCellsSoon(cellsToSave);
      this.autoSaveCells(cellsToSave);
    }
  }

  // ---------- color ----------

  // Single button + popup replaces the old always-visible row of swatches —
  // clicking either button opens its own palette (colorPalette above) plus
  // the "any color" native picker; applyColor()/applyTextColor()/
  // onCustomColor()/onCustomTextColor() below are unchanged, only how a
  // color gets chosen before reaching them is different.
  readonly showBoxColorPicker = signal(false);
  readonly showTextColorPicker = signal(false);

  toggleBoxColorPicker(): void {
    this.showTextColorPicker.set(false);
    this.showBoxColorPicker.update((v) => !v);
  }

  toggleTextColorPicker(): void {
    this.showBoxColorPicker.set(false);
    this.showTextColorPicker.update((v) => !v);
  }

  closeColorPickers(): void {
    this.showBoxColorPicker.set(false);
    this.showTextColorPicker.set(false);
  }

  applyColor(hex: string | null): void {
    if (!this.canEdit()) {
      return;
    }
    const range = this.selectedRange();
    if (!range) {
      return;
    }
    const rows = this.rows();
    const edits: CellEdit[] = [];
    const cellsToSave: Cell[] = [];
    for (let ri = range.r0; ri <= range.r1; ri++) {
      for (let ci = range.c0; ci <= range.c1; ci++) {
        const cell = rows[ri]?.cells[ci];
        if (cell && cell.color !== hex) {
          edits.push({ executiveId: rows[ri].executiveId, day: cell.day, field: 'color', oldValue: cell.color, newValue: hex });
          cell.color = hex;
          this.markDirty(rows[ri].executiveId, cell.day);
          cellsToSave.push({ executiveId: rows[ri].executiveId, day: cell.day, text: cell.text, color: hex, textColor: cell.textColor });
        }
      }
    }
    if (edits.length) {
      this.pushUndo({ type: 'cell-batch', edits });
      this.rows.set([...rows]);
      this.autoSaveCells(cellsToSave);
    }
  }

  onCustomColor(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.applyColor(value);
  }

  // Mirrors applyColor()/onCustomColor() exactly, but sets cell.textColor
  // instead of cell.color — the box's own background (applyColor above) is
  // completely untouched here, and vice versa, per explicit request that
  // the two customize independently of each other.
  applyTextColor(hex: string | null): void {
    if (!this.canEdit()) {
      return;
    }
    const range = this.selectedRange();
    if (!range) {
      return;
    }
    const rows = this.rows();
    const edits: CellEdit[] = [];
    const cellsToSave: Cell[] = [];
    for (let ri = range.r0; ri <= range.r1; ri++) {
      for (let ci = range.c0; ci <= range.c1; ci++) {
        const cell = rows[ri]?.cells[ci];
        if (cell && cell.textColor !== hex) {
          edits.push({ executiveId: rows[ri].executiveId, day: cell.day, field: 'textColor', oldValue: cell.textColor, newValue: hex });
          cell.textColor = hex;
          this.markDirty(rows[ri].executiveId, cell.day);
          cellsToSave.push({ executiveId: rows[ri].executiveId, day: cell.day, text: cell.text, color: cell.color, textColor: hex });
        }
      }
    }
    if (edits.length) {
      this.pushUndo({ type: 'cell-batch', edits });
      this.rows.set([...rows]);
      this.autoSaveCells(cellsToSave);
    }
  }

  onCustomTextColor(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.applyTextColor(value);
  }

  private markDirty(executiveId: number, day: number): void {
    this.dirtyKeys.update((set) => {
      const next = new Set(set);
      next.add(`${executiveId}:${day}`);
      return next;
    });
  }

  // Real-time per-cell persistence: called immediately after any cell
  // text/color mutation (blur, paste, color-apply, undo/redo) instead of
  // waiting for the user to press Save. On success the touched cells are
  // cleared from dirtyKeys; on failure they stay dirty so the Save button
  // (kept as a manual retry/backup, not the primary save path anymore) can
  // flush them later.
  private autoSaveCells(cells: Cell[]): void {
    const teamId = this.selectedTeamId;
    if (!teamId || cells.length === 0) {
      return;
    }
    this.data.saveCells(teamId, this.selectedYear, this.selectedMonth + 1, cells).subscribe({
      next: () => {
        const keys = new Set(cells.map((c) => `${c.executiveId}:${c.day}`));
        this.dirtyKeys.update((set) => {
          const next = new Set(set);
          keys.forEach((k) => next.delete(k));
          return next;
        });
      },
      error: () => {
        // Left dirty deliberately — no alert per keystroke/blur would be
        // excessive; the persistent dirty-count badge next to Save is the
        // signal that something still needs to be flushed.
      }
    });
  }

  private collectDirtyCells(): Cell[] {
    const dirty = this.dirtyKeys();
    const cellsToSave: Cell[] = [];
    for (const row of this.rows()) {
      for (const cell of row.cells) {
        if (dirty.has(`${row.executiveId}:${cell.day}`)) {
          cellsToSave.push({ executiveId: row.executiveId, day: cell.day, text: cell.text, color: cell.color, textColor: cell.textColor });
        }
      }
    }
    return cellsToSave;
  }

  ngAfterViewInit(): void {
    const wrapEl = this.stickyWrapRef?.nativeElement;
    const theadEl = this.theadRowRef?.nativeElement;
    this.stickyResizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.target === theadEl) {
          const height = Math.round(entry.contentRect?.height ?? (entry.target as HTMLElement).offsetHeight);
          this.theadHeightPx.set(height);
        }
      }
      // Any observed element resizing (toolbar collapsing/expanding, the
      // Save As panel opening, the thead row itself wrapping to a
      // different height, etc.) can shift .grid-scroll's own position or
      // available room, so recompute on every callback regardless of which
      // element fired it.
      this.recomputeGridMaxHeight();
    });
    if (wrapEl) {
      this.stickyResizeObserver.observe(wrapEl);
    }
    if (theadEl) {
      this.stickyResizeObserver.observe(theadEl);
    }
    window.addEventListener('resize', this.onWindowResize);
    this.recomputeGridMaxHeight();
  }

  private recomputeGridMaxHeight(): void {
    const el = this.gridScrollRef?.nativeElement;
    if (!el) {
      return;
    }
    // getBoundingClientRect().top + window.scrollY is scroll-position
    // independent (both terms move opposite and equal amounts as the page
    // scrolls) — the true distance from the document top to this box,
    // covering the brand header, top nav, page padding, and this form's own
    // toolbar in one live measurement, however tall any of those currently
    // are.
    const top = el.getBoundingClientRect().top + window.scrollY;
    // Reserves only the two bottom paddings that sit directly below
    // .grid-scroll before anything else: .page-card's own bottom padding
    // (1.5rem, styles.scss) and .page-content's bottom padding (1.5rem,
    // main-layout.scss) — 24px + 24px. Per explicit request to maximize
    // visible grid height / minimize empty space, this deliberately does
    // NOT also reserve room for the brand footer beneath those paddings
    // (previously 120px, which left a visible gap most viewports never
    // needed). The footer still renders exactly as before; on a shorter
    // viewport reaching it may now cost a small page-level scroll, which
    // the sticky toolbar and .grid-scroll's own sticky rows already handle
    // correctly regardless (see recomputeGridMaxHeight()'s siblings above).
    const BOTTOM_CHROME_PX = 48;
    const available = window.innerHeight - top - BOTTOM_CHROME_PX;
    // Floor so a very short/zoomed viewport still leaves a usable grid
    // instead of collapsing to near-zero height.
    this.gridMaxHeightPx.set(Math.max(320, Math.round(available)));
  }

  ngOnDestroy(): void {
    this.stickyResizeObserver?.disconnect();
    window.removeEventListener('resize', this.onWindowResize);
    // Safety net for the rare case a cell is mid-edit (focused, changed,
    // never blurred) when the user navigates away — Angular destroys this
    // component on route change, which wouldn't otherwise fire a blur in
    // time to trigger the normal autosave path.
    this.autoSaveCells(this.collectDirtyCells());
  }

  // ---------- undo/redo ----------

  private pushUndo(cmd: UndoCommand): void {
    this.undoStack.push(cmd);
    this.redoStack = [];
    this.canUndo.set(true);
    this.canRedo.set(false);
  }

  undo(): void {
    if (!this.canEdit()) {
      return;
    }
    const cmd = this.undoStack.pop();
    if (!cmd) {
      return;
    }
    this.applyInverse(cmd);
    this.redoStack.push(cmd);
    this.canUndo.set(this.undoStack.length > 0);
    this.canRedo.set(true);
  }

  redo(): void {
    if (!this.canEdit()) {
      return;
    }
    const cmd = this.redoStack.pop();
    if (!cmd) {
      return;
    }
    this.applyForward(cmd);
    this.undoStack.push(cmd);
    this.canRedo.set(this.redoStack.length > 0);
    this.canUndo.set(true);
  }

  private applyCellEdits(edits: { executiveId: number; day: number; field: 'text' | 'color' | 'textColor'; value: string | null }[]): void {
    const rows = this.rows();
    const touched = new Map<string, Cell>();
    for (const e of edits) {
      const row = rows.find((r) => r.executiveId === e.executiveId);
      const cell = row?.cells.find((c) => c.day === e.day);
      if (!cell) {
        continue;
      }
      if (e.field === 'text') {
        cell.text = e.value ?? '';
      } else if (e.field === 'color') {
        cell.color = e.value;
      } else {
        cell.textColor = e.value;
      }
      this.markDirty(e.executiveId, e.day);
      touched.set(`${e.executiveId}:${e.day}`, { executiveId: e.executiveId, day: e.day, text: cell.text, color: cell.color, textColor: cell.textColor });
    }
    this.rows.set([...rows]);
    this.cdr.markForCheck();
    this.resizeCellsSoon([...touched.values()]);
    // Undo/redo of a cell edit must persist immediately too, same as any
    // other edit — otherwise an undo would look applied on screen but
    // silently revert back to the pre-undo value on next reload.
    this.autoSaveCells([...touched.values()]);
  }

  private applyInverse(cmd: UndoCommand): void {
    const teamId = this.selectedTeamId;
    if (cmd.type === 'cell-batch') {
      this.applyCellEdits(cmd.edits.map((e) => ({ executiveId: e.executiveId, day: e.day, field: e.field, value: e.oldValue })));
      return;
    }
    this.applyOrderLocal(cmd.beforeOrder);
    if (teamId) {
      this.data.reorderExecutives(teamId, cmd.beforeOrder).subscribe();
    }
  }

  private applyForward(cmd: UndoCommand): void {
    const teamId = this.selectedTeamId;
    if (cmd.type === 'cell-batch') {
      this.applyCellEdits(cmd.edits.map((e) => ({ executiveId: e.executiveId, day: e.day, field: e.field, value: e.newValue })));
      return;
    }
    this.applyOrderLocal(cmd.afterOrder);
    if (teamId) {
      this.data.reorderExecutives(teamId, cmd.afterOrder).subscribe();
    }
  }

  private applyOrderLocal(order: number[]): void {
    const byId = new Map(this.rows().map((r) => [r.executiveId, r]));
    this.rows.set(order.map((id) => byId.get(id)).filter((r): r is GridRow => !!r));
    this.cdr.markForCheck();
  }

  // ---------- executive row order (move up/down, drag & drop) ----------

  moveUp(index: number): void {
    this.swapRows(index, index - 1);
  }

  moveDown(index: number): void {
    this.swapRows(index, index + 1);
  }

  private swapRows(i: number, j: number): void {
    if (!this.canEdit()) {
      return;
    }
    const rows = this.rows();
    if (j < 0 || j >= rows.length) {
      return;
    }
    const next = [...rows];
    [next[i], next[j]] = [next[j], next[i]];
    this.commitReorder(rows.map((r) => r.executiveId), next);
  }

  onRowDragStart(event: DragEvent, ri: number): void {
    this.rowDragSourceIndex = ri;
    event.dataTransfer?.setData('text/plain', String(ri));
    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = 'move';
    }
  }

  onRowDragOver(event: DragEvent): void {
    // Required so the browser actually fires a 'drop' event here instead of
    // rejecting the drag — native HTML5 drag & drop treats every drop
    // target as invalid unless dragover explicitly opts in.
    event.preventDefault();
  }

  onRowDrop(event: DragEvent, targetIndex: number): void {
    event.preventDefault();
    if (!this.canEdit()) {
      return;
    }
    const sourceIndex = this.rowDragSourceIndex;
    this.rowDragSourceIndex = null;
    if (sourceIndex === null || sourceIndex === targetIndex) {
      return;
    }
    const rows = this.rows();
    const next = [...rows];
    const [moved] = next.splice(sourceIndex, 1);
    next.splice(targetIndex, 0, moved);
    this.commitReorder(rows.map((r) => r.executiveId), next);
  }

  private commitReorder(beforeOrder: number[], next: GridRow[]): void {
    const teamId = this.selectedTeamId;
    const afterOrder = next.map((r) => r.executiveId);
    this.rows.set(next);
    this.cdr.markForCheck();
    if (teamId) {
      this.data.reorderExecutives(teamId, afterOrder).subscribe();
    }
    this.pushUndo({ type: 'reorder', beforeOrder, afterOrder });
  }

  // ---------- executive row color ----------

  // A single shared popup (rendered once, outside the table — see the
  // .html) rather than one nested per row: the row it would otherwise live
  // in (.name-col) is `position: sticky`, and every OTHER row's sticky
  // .name-col sits at the same stacking level as siblings — an
  // absolutely-positioned popup nested inside one row's cell was getting
  // painted BEHIND the next row's cell instead of above it, silently
  // eating clicks. Positioning one shared popup with `position: fixed` at
  // the clicked swatch's actual viewport coordinates sidesteps table
  // stacking-context quirks entirely.
  colorPickerRow: GridRow | null = null;
  colorPickerPosition: { top: number; left: number } | null = null;

  toggleRowColorPicker(row: GridRow, event: MouseEvent): void {
    if (!this.canEdit()) {
      return;
    }
    const alreadyOpenForThisRow = this.colorPickerForExecutiveId() === row.executiveId;
    if (alreadyOpenForThisRow) {
      this.closeRowColorPicker();
      return;
    }
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    this.colorPickerRow = row;
    this.colorPickerPosition = { top: rect.bottom + 4, left: rect.left };
    this.colorPickerForExecutiveId.set(row.executiveId);
    this.cdr.markForCheck();
  }

  closeRowColorPicker(): void {
    this.colorPickerForExecutiveId.set(null);
    this.colorPickerRow = null;
    this.colorPickerPosition = null;
    this.cdr.markForCheck();
  }

  setRowColor(row: GridRow, hex: string | null): void {
    row.rowColor = hex;
    this.rows.set([...this.rows()]);
    this.closeRowColorPicker();
    const teamId = this.selectedTeamId;
    if (teamId) {
      this.data.setExecutiveColor(teamId, row.executiveId, hex).subscribe();
    }
  }

  onRowCustomColor(event: Event, row: GridRow): void {
    const value = (event.target as HTMLInputElement).value;
    this.setRowColor(row, value);
  }

  // ---------- executive column color ----------

  // Mirrors the row-color popup above exactly (same shared-popup-with-fixed-
  // positioning approach, same reasoning about sticky .name-col stacking
  // contexts) — a fully independent second picker, per explicit request
  // that Column Color and Row Color never interfere with each other. This
  // one colors only the Executive (name) column cell for a row
  // (columnColor), never the row's day cells (rowColor, untouched here).
  columnColorPickerRow: GridRow | null = null;
  columnColorPickerPosition: { top: number; left: number } | null = null;

  toggleColumnColorPicker(row: GridRow, event: MouseEvent): void {
    if (!this.canEdit()) {
      return;
    }
    const alreadyOpenForThisRow = this.columnColorPickerForExecutiveId() === row.executiveId;
    if (alreadyOpenForThisRow) {
      this.closeColumnColorPicker();
      return;
    }
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    this.columnColorPickerRow = row;
    this.columnColorPickerPosition = { top: rect.bottom + 4, left: rect.left };
    this.columnColorPickerForExecutiveId.set(row.executiveId);
    this.cdr.markForCheck();
  }

  closeColumnColorPicker(): void {
    this.columnColorPickerForExecutiveId.set(null);
    this.columnColorPickerRow = null;
    this.columnColorPickerPosition = null;
    this.cdr.markForCheck();
  }

  setColumnColor(row: GridRow, hex: string | null): void {
    row.columnColor = hex;
    this.rows.set([...this.rows()]);
    this.closeColumnColorPicker();
    const teamId = this.selectedTeamId;
    if (teamId) {
      this.data.setExecutiveColumnColor(teamId, row.executiveId, hex).subscribe();
    }
  }

  onColumnCustomColor(event: Event, row: GridRow): void {
    const value = (event.target as HTMLInputElement).value;
    this.setColumnColor(row, value);
  }

  // ---------- search ----------

  searchExecutive(): void {
    const term = this.searchTerm().trim().toLowerCase();
    if (!term) {
      return;
    }
    const match = this.rows().find((r) => r.executiveName.toLowerCase().includes(term));
    if (match) {
      document.getElementById(`name-${match.executiveId}`)?.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }
  }

  isSearchMatch(row: GridRow): boolean {
    const term = this.searchTerm().trim().toLowerCase();
    return !!term && row.executiveName.toLowerCase().includes(term);
  }

  // ---------- save / save as ----------

  // Every cell edit, paste, color change, and undo/redo already
  // autosaves itself the instant it happens (see autoSaveCells()) — this
  // button is now a manual backup/retry, not the primary save path.
  // Normally a no-op (dirtyKeys is already empty), except when a prior
  // autosave call genuinely failed (e.g. a network blip) and left some
  // cells dirty, in which case this retries exactly those.
  save(): void {
    if (!this.canEdit()) {
      return;
    }
    const teamId = this.selectedTeamId;
    const cellsToSave = this.collectDirtyCells();
    if (!teamId || cellsToSave.length === 0) {
      return;
    }
    this.saving.set(true);
    this.data.saveCells(teamId, this.selectedYear, this.selectedMonth + 1, cellsToSave).subscribe({
      next: () => {
        this.saving.set(false);
        const keys = new Set(cellsToSave.map((c) => `${c.executiveId}:${c.day}`));
        this.dirtyKeys.update((set) => {
          const next = new Set(set);
          keys.forEach((k) => next.delete(k));
          return next;
        });
        alert('Schedule saved successfully.');
      },
      error: () => {
        this.saving.set(false);
        alert('Could not save. Please try again.');
      }
    });
  }

  openSaveAs(): void {
    if (!this.canEdit()) {
      return;
    }
    let targetMonth = this.selectedMonth + 1;
    let targetYear = this.selectedYear;
    if (targetMonth > 11) {
      targetMonth = 0;
      // Clamped the same way as nextMonth() — the Year dropdown has
      // nothing past MAX_YEAR to default this suggestion to.
      targetYear = Math.min(targetYear + 1, MAX_YEAR);
    }
    this.saveAsMonth = targetMonth;
    this.saveAsYear = targetYear;
    this.showSaveAs.set(true);
  }

  confirmSaveAs(): void {
    if (!this.canEdit()) {
      return;
    }
    const teamId = this.selectedTeamId;
    if (!teamId) {
      return;
    }
    if (this.saveAsYear === this.selectedYear && this.saveAsMonth === this.selectedMonth) {
      alert('Target month must be different from the current month.');
      return;
    }
    if (!confirm(`This will overwrite any existing schedule for ${this.months[this.saveAsMonth]} ${this.saveAsYear}. Continue?`)) {
      return;
    }
    this.data.copyMonth(teamId, this.selectedYear, this.selectedMonth + 1, this.saveAsYear, this.saveAsMonth + 1).subscribe((res) => {
      this.showSaveAs.set(false);
      alert(`Copied ${res.copied_count} cell(s) to ${this.months[this.saveAsMonth]} ${this.saveAsYear}.`);
    });
  }

  // ---------- print / export / import ----------

  print(): void {
    window.print();
  }

  exportExcel(): void {
    const rowsForExport = this.rows().map((row) => {
      const obj: Record<string, string> = { Executive: row.executiveName };
      for (const cell of row.cells) {
        obj[`Day ${cell.day}`] = cell.text;
      }
      return obj;
    });
    exportToExcel(`ExecutiveSchedule_${this.months[this.selectedMonth]}_${this.selectedYear}`, rowsForExport);
  }

  onImportFileSelected(event: Event): void {
    if (!this.canEdit()) {
      return;
    }
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    const teamId = this.selectedTeamId;
    if (!file || !teamId) {
      return;
    }
    file.arrayBuffer().then((buffer) => {
      const workbook = XLSX.read(buffer, { type: 'array' });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const data = XLSX.utils.sheet_to_json(sheet, { header: 1 }) as unknown[][];
      if (!data.length) {
        return;
      }
      const header = data[0];
      const dayForColumn = new Map<number, number>();
      for (let c = 1; c < header.length; c++) {
        const day = Number(String(header[c] ?? '').replace(/[^0-9]/g, ''));
        if (day >= 1 && day <= 31) {
          dayForColumn.set(c, day);
        }
      }

      const nameToRow = new Map(this.rows().map((r) => [r.executiveName.trim().toLowerCase(), r]));
      // The roster itself is read-only here (derived from UserMaster) — an
      // imported name that isn't an active executive on this team's roster
      // today can't be auto-created any more; it's skipped and reported
      // rather than silently ignored, since that's most likely a spelling
      // mismatch against UserMaster.Name the user will want to fix.
      const skipped: string[] = [];

      for (let r = 1; r < data.length; r++) {
        const line = data[r];
        const name = String(line[0] ?? '').trim();
        if (!name) {
          continue;
        }
        const values = new Map<number, string>();
        dayForColumn.forEach((day, col) => values.set(day, String(line[col] ?? '')));
        const existing = nameToRow.get(name.toLowerCase());
        if (existing) {
          this.applyImportedRow(existing, values);
        } else {
          skipped.push(name);
        }
      }
      this.rows.set([...this.rows()]);
      this.cdr.markForCheck();
      this.resizeAllCellsSoon();
      // Same real-time persistence as any other edit — the imported values
      // are saved immediately rather than left pending on a manual Save click.
      this.autoSaveCells(this.collectDirtyCells());
      alert(
        skipped.length
          ? `Import complete — schedule saved. ${skipped.length} name(s) not found on this team's current roster were skipped: ${skipped.join(', ')}`
          : 'Import complete — schedule saved.'
      );
    });
  }

  private applyImportedRow(row: GridRow, values: Map<number, string>): void {
    for (const cell of row.cells) {
      const value = values.get(cell.day);
      if (value !== undefined && value !== cell.text) {
        cell.text = value;
        this.markDirty(row.executiveId, cell.day);
      }
    }
  }
}
