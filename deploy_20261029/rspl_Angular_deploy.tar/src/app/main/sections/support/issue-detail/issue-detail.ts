import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { LookupOption, SupportDataService } from '../support-data.service';

export const ACTION_TAKEN_OPTIONS = [
  'Online Support',
  'In Person Support',
  'Requirement',
  'Forwarded',
  'Telephonic',
  'Bug',
  'Developer Assistance Required',
  'YT',
  'Visit Required',
  'Other',
  'Call Back',
  'Courtesy Call',
  'Courtesy Visit',
  'Google Drive Enabled',
  'GSTR2A Outgoing',
  'Happiness Call',
  'RSPL-Hardware Issue'
];

/**
 * Mirrors Section_Support/IssueDetail.aspx: single-issue add/edit form used
 * by TroubleTicket's issue-detail workflow. The source's Session("TempTT")
 * staging-row mechanics (used only when adding issues to a brand-new,
 * not-yet-saved ticket) are covered by TroubleTicket's own inline
 * add-issue-row form; this standalone route covers the AddEdit=1/View=1
 * case — editing or viewing a single issue on an existing ticket
 * (webProc_TTDetails), reached from wherever a ticket's issue rows are
 * listed. Submit persists via the same clsDBLayer call the source used to
 * stage or apply; on success, returns to the previous page.
 */
@Component({
  selector: 'app-issue-detail',
  imports: [FormsModule, ButtonModule, SelectModule, InputTextModule, TextareaModule, CheckboxModule],
  templateUrl: './issue-detail.html',
  styleUrl: './issue-detail.scss'
})
export class IssueDetail implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(SupportDataService);
  private readonly location = inject(Location);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly actionTakenOptions = ACTION_TAKEN_OPTIONS;
  readonly priorities = signal<string[]>([]);
  readonly closedByUsers = signal<LookupOption[]>([]);
  readonly narrations = signal<LookupOption[]>([]);
  readonly saving = signal(false);
  readonly errorMessage = signal<string | null>(null);
  readonly readOnly = signal(false);

  ttNo = 0;
  module = '';
  priority = '';
  whatNext = '';
  issue = '';
  action = '';
  exeVersionNo = '';
  closed = false;
  closedBy: number | null = null;
  closedNarrationId: number | null = null;

  // Debounces the narration-search-as-you-type filter so it re-queries the
  // server once typing pauses — getClosedNarrations() is capped to TOP 100
  // (see the backend note), so typing is how the rest become reachable.
  private readonly narrationFilter$ = new Subject<string>();

  ngOnInit(): void {
    this.data.getPriorities().subscribe((p) => this.priorities.set(p));
    this.data.getUsers().subscribe((u) => this.closedByUsers.set(u));
    this.data.getClosedNarrations().subscribe((n) => this.narrations.set(n));

    this.narrationFilter$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((query) => this.data.getClosedNarrations(query))
      )
      .subscribe((n) => this.narrations.set(n));

    // Reached from wherever a ticket's issue rows are listed, with a
    // different ?ttno each time — subscribe rather than reading a one-time
    // snapshot so editing/viewing a different issue while already mounted
    // actually reloads instead of showing the previous issue's data.
    this.route.queryParamMap.subscribe((q) => {
      this.ttNo = Number(q.get('ttno') ?? 0);
      const addEdit = q.get('AddEdit') === '1' || q.get('AddEdit') === 'True';
      const view = q.get('View') === '1' || q.get('View') === 'True';
      this.readOnly.set(!addEdit && view);

      this.module = '';
      this.priority = '';
      this.whatNext = '';
      this.issue = '';
      this.action = '';
      this.exeVersionNo = '';
      this.closed = false;
      this.closedBy = null;
      this.closedNarrationId = null;

      if (addEdit || view) {
        this.data.getIssueDetailFull(this.ttNo).subscribe((info) => {
          if (!info) {
            return;
          }
          this.module = info.module;
          this.priority = info.priority;
          this.whatNext = info.whatNext;
          this.issue = info.issue;
          this.action = info.action;
          this.exeVersionNo = info.exeVersionNo;
          this.closed = info.closed;
          this.closedBy = info.closedBy || null;
          this.closedNarrationId = info.closedNarrationId || null;
          // A saved narration can easily fall outside the TOP 100 slice
          // getClosedNarrations() now returns — splice it back in so the
          // picker shows its actual text instead of going blank.
          if (this.closedNarrationId && info.closedNarrationLabel && !this.narrations().some((n) => n.value === this.closedNarrationId)) {
            this.narrations.update((rows) => [{ label: info.closedNarrationLabel, value: this.closedNarrationId! }, ...rows]);
          }
          this.cdr.markForCheck();
        });
      }
      this.cdr.markForCheck();
    });
  }

  onNarrationFilter(query: string): void {
    this.narrationFilter$.next(query);
  }

  submit(): void {
    if (!this.module.trim() || !this.priority || !this.whatNext || !this.issue.trim() || !this.action.trim()) {
      this.errorMessage.set('Please fill Module, Priority, Action taken, Issue and Remark.');
      return;
    }
    if (this.closed && !this.closedBy) {
      this.errorMessage.set('Please select closed by');
      return;
    }
    this.errorMessage.set(null);
    this.saving.set(true);
    this.data
      .saveIssueDetail({
        ttNo: this.ttNo,
        module: this.module,
        priority: this.priority,
        whatNext: this.whatNext,
        issue: this.issue,
        action: this.action,
        exeVersionNo: this.exeVersionNo || '0',
        closed: this.closed,
        closedBy: this.closedBy ?? 0,
        closedNarrationId: this.closedNarrationId ?? 0
      })
      .subscribe(() => {
        this.saving.set(false);
        this.location.back();
      });
  }

  cancel(): void {
    this.location.back();
  }
}
