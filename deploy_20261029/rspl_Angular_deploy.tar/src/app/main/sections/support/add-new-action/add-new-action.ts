import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';

import { LookupOption, SupportDataService } from '../support-data.service';

/**
 * Mirrors Section_Support/AddNewAction.aspx: a single popup reused for two
 * modes — ActionType=1 shows the "Add New Action" panel, ActionType=2 shows
 * "Close Existing Action" (with an optional "Add Next Action" sub-panel).
 * A "Call Action Using SIP" panel appears if a MobileNo/PhoneNo query param
 * was passed; the actual SIP dial is stubbed (needs a real backend/Synapse
 * integration), same treatment as MissedCall's click-to-call. When arriving
 * from AMCCo-OrdinatorDashboard, the action-stage fields are locked to 18
 * (AMC Followup), matching the source's FromAMCCo-OrdinatorDashboard=1 flag.
 */
@Component({
  selector: 'app-add-new-action',
  imports: [FormsModule, ButtonModule, SelectModule, DatePickerModule, InputTextModule, TextareaModule, CheckboxModule],
  templateUrl: './add-new-action.html',
  styleUrl: './add-new-action.scss'
})
export class AddNewAction implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(SupportDataService);
  private readonly location = inject(Location);
  private readonly cdr = inject(ChangeDetectorRef);

  actionType = 1;
  custId = 0;
  refActionId = 0;
  callPanelVisible = false;
  stageLocked = false;

  mobileNo = '';
  phoneNo = '';
  sipExtMobile = '';
  sipExtPhone = '';

  readonly actionStages = signal<LookupOption[]>([]);
  readonly stageStatuses1 = signal<LookupOption[]>([]);
  readonly stageStatuses2 = signal<LookupOption[]>([]);
  readonly stageStatuses3 = signal<LookupOption[]>([]);
  readonly users = signal<LookupOption[]>([]);
  readonly salesmen = signal<LookupOption[]>([]);
  readonly saving = signal(false);
  readonly errorMessage = signal<string | null>(null);

  // Add Action panel (ActionType=1)
  actionStageId: number | null = null;
  actionStageStatusId: number | null = null;
  assignedTo: number | null = null;
  salesPersonId: number | null = null;
  actionDate: Date | null = new Date();
  actionTime = '';
  desc = '';
  actionRemark = '';
  closeAction = false;

  // Close Action panel (ActionType=2)
  completedBy: number | null = null;
  actionStage3Id: number | null = null;
  salesmanId: number | null = null;
  completedDate: Date | null = new Date();
  completedTime = '';
  narration = '';
  addNewAction = false;

  // Sub-panel: next action on close
  actionStage2Id: number | null = null;
  actionStageStatus2Id: number | null = null;
  assignedTo2: number | null = null;
  salesPerson2Id: number | null = null;
  actionDate2: Date | null = new Date();
  actionTime2 = '';
  desc2 = '';
  actionRemark2 = '';

  ngOnInit(): void {
    this.data.getUsers().subscribe((u) => {
      this.users.set(u);
      this.assignedTo = this.assignedTo2 = this.completedBy = u[0]?.value ?? null;
      this.cdr.markForCheck();
    });
    this.data.getSalesmen().subscribe((s) => this.salesmen.set(s));

    // Reached from many different launch points (AmcPending,
    // CustomerLicenseViolation, AMCCo-OrdinatorDashboard, etc.) with
    // different CustID/RefActionID each time — subscribe rather than
    // reading a one-time snapshot so opening this for a different
    // customer/action while already mounted actually reloads instead of
    // carrying over the previous one's typed-in fields.
    this.route.queryParamMap.subscribe((q) => {
      this.resetFormState();
      this.actionType = Number(q.get('ActionType') ?? 1);
      this.custId = Number(q.get('CustID') ?? 0);
      this.refActionId = Number(q.get('RefActionID') ?? 0);
      this.mobileNo = q.get('MobileNo') ?? '';
      this.phoneNo = q.get('PhoneNo') ?? '';
      this.callPanelVisible = this.mobileNo.trim() !== '' || this.phoneNo.trim() !== '';
      this.stageLocked = q.get('FromAMCCo-OrdinatorDashboard') === '1';
      this.cdr.markForCheck();

      this.data.getActionStages().subscribe((stages) => {
        this.actionStages.set(stages);
        if (this.stageLocked) {
          this.actionStageId = this.actionStage2Id = this.actionStage3Id = 18;
          this.onStageChange(1);
          this.onStageChange(2);
        } else if (this.refActionId > 1) {
          this.actionStageId = this.actionStage3Id = this.refActionId;
          this.actionStage2Id = this.refActionId;
          this.onStageChange(1);
          this.onStageChange(2);
        }
        this.cdr.markForCheck();
      });
    });
  }

  private resetFormState(): void {
    this.actionStageId = null;
    this.actionStageStatusId = null;
    this.assignedTo = this.users()[0]?.value ?? null;
    this.salesPersonId = null;
    this.actionDate = new Date();
    this.actionTime = '';
    this.desc = '';
    this.actionRemark = '';
    this.closeAction = false;

    this.completedBy = this.users()[0]?.value ?? null;
    this.actionStage3Id = null;
    this.salesmanId = null;
    this.completedDate = new Date();
    this.completedTime = '';
    this.narration = '';
    this.addNewAction = false;

    this.actionStage2Id = null;
    this.actionStageStatus2Id = null;
    this.assignedTo2 = this.users()[0]?.value ?? null;
    this.salesPerson2Id = null;
    this.actionDate2 = new Date();
    this.actionTime2 = '';
    this.desc2 = '';
    this.actionRemark2 = '';
    this.errorMessage.set(null);
  }

  onStageChange(panel: 1 | 2 | 3): void {
    const stageId = panel === 1 ? this.actionStageId : panel === 2 ? this.actionStage2Id : this.actionStage3Id;
    if (!stageId) {
      return;
    }
    this.data.getActionStageStatuses(stageId).subscribe((statuses) => {
      if (panel === 1) {
        this.stageStatuses1.set(statuses);
      } else if (panel === 2) {
        this.stageStatuses2.set(statuses);
      } else {
        this.stageStatuses3.set(statuses);
      }
      this.cdr.markForCheck();
    });
  }

  callNow(contactNo: string, sipExt: string): void {
    alert(`Dialing ${contactNo} via SIP ext ${sipExt} (external Synapse integration — not wired up without a backend)`);
  }

  submitAdd(): void {
    if (!this.actionStageId || !this.assignedTo || !this.actionDate || !this.actionTime || !this.desc.trim()) {
      this.errorMessage.set('Please fill Action Stage, Assigned To, Action Date, Action Time and Action Description.');
      return;
    }
    this.errorMessage.set(null);
    this.saving.set(true);
    this.data
      .addEnquiryAction({
        custId: this.custId,
        refActionId: this.refActionId,
        actionStageId: this.actionStageId,
        actionDate: this.actionDate,
        actionTime: this.actionTime,
        description: this.desc,
        assignedTo: this.assignedTo,
        remark: this.actionRemark,
        closeAction: this.closeAction,
        salesPersonId: this.salesPersonId ?? 0,
        actionStageStatusId: this.actionStageStatusId ?? 0
      })
      .subscribe(() => {
        this.saving.set(false);
        this.location.back();
      });
  }

  submitClose(): void {
    if (!this.completedBy || !this.actionStage3Id || !this.completedDate || !this.completedTime || !this.narration.trim()) {
      this.errorMessage.set('Please fill Completed By, Action Stage, Completed Date, Completed Time and Completed Remark.');
      return;
    }
    this.errorMessage.set(null);
    this.saving.set(true);
    this.data
      .closeEnquiryAction({
        custId: this.custId,
        refActionId: this.refActionId,
        completedBy: this.completedBy,
        completedDate: this.completedDate,
        completedTime: this.completedTime,
        salesmanId: this.salesmanId ?? 0,
        narration: this.narration,
        actionStageId: this.actionStage3Id,
        addNewAction: this.addNewAction
          ? {
              actionStageId: this.actionStage2Id ?? 0,
              actionDate: this.actionDate2 ?? new Date(),
              actionTime: this.actionTime2,
              description: this.desc2,
              assignedTo: this.assignedTo2 ?? 0,
              remark: this.actionRemark2,
              salesPersonId: this.salesPerson2Id ?? 0,
              actionStageStatusId: this.actionStageStatus2Id ?? 0
            }
          : undefined
      })
      .subscribe(() => {
        this.saving.set(false);
        this.location.back();
      });
  }

  cancel(): void {
    this.location.back();
  }
}
