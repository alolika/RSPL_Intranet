import { DatePipe, DecimalPipe } from '@angular/common';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ChangeDetectorRef, Component, ElementRef, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';

import { API_BASE_URL } from '../../../../shared/api-config';
import { ExcelColumn, exportToExcel } from '../../../../shared/export-excel';

interface CallRow {
  id: number;
  call_date: string | null;
  executive_name: string | null;
  customer_name: string | null;
  software_name: string | null;
  customer_mood: string | null;
  keywords: string | null;
  call_duration: number | null;
  mood_reason: string | null;
}

interface ExecutiveSummary {
  name: string;
  calls: number;
  totalSeconds: number;
}

interface ExecutiveMood {
  name: string;
  calls: number;
  moods: Record<string, number>;
  segments: { mood: string; count: number; pct: number; color: string }[];
}

interface KeywordAgg {
  name: string;
  count: number;
  calls: CallRow[];
  moods: Record<string, number>;
}

interface Bubble extends KeywordAgg {
  x: number;
  y: number;
  r: number;
  color: string;
  dominant: string;
}

const MOOD_COLORS: Record<string, string> = {
  positive: '#16a34a',
  neutral: '#eab308',
  negative: '#dc2626',
  other: '#64748b'
};

function moodGroup(m: string | null): string {
  const s = (m ?? '').toLowerCase();
  if (/positive|happy|satisfied|good|excited|delighted/.test(s)) return 'positive';
  if (/negative|angry|frustrat|sad|unhappy|disappoint|upset/.test(s)) return 'negative';
  if (/neutral|mixed|normal|okay|ok/.test(s)) return 'neutral';
  return 'other';
}

function splitKeywords(s: string | null): string[] {
  if (!s) return [];
  return s.split(',').map((k) => k.trim()).filter((k) => k && k.toLowerCase() !== 'none detected');
}

// Must match the mobile breakpoint in sentimeter.scss.
const MOBILE_QUERY = '(max-width: 768px)';

@Component({
  selector: 'app-sentimeter',
  imports: [FormsModule, ButtonModule, DatePickerModule, InputTextModule, SelectModule, DatePipe, DecimalPipe],
  templateUrl: './sentimeter.html',
  styleUrl: './sentimeter.scss'
})
export class Sentimeter implements OnInit {
  private readonly http = inject(HttpClient);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef);
  private readonly base = `${API_BASE_URL}/support/sentimeter`;

  readonly loading = signal(false);
  readonly error = signal<string | null>(null);
  readonly rows = signal<CallRow[]>([]);
  readonly softwareOptions = signal<string[]>([]);
  readonly moodOptions = signal<string[]>([]);

  // Filters
  dateFrom: Date | null = null;
  dateTo: Date | null = null;
  customer = '';
  executive = '';
  software = '';
  mood = '';
  keyword = '';

  // Detail panel
  selectedKeyword: KeywordAgg | null = null;

  // SVG viewport
  readonly SVG_W = 1200;
  readonly SVG_H = 1200;

  ngOnInit(): void {
    const now = new Date();
    const prior = new Date();
    prior.setDate(now.getDate() - 90);
    this.dateFrom = prior;
    this.dateTo = now;

    this.http.get<{ software: string[]; moods: string[] }>(`${this.base}/options`).subscribe({
      next: (d) => {
        this.softwareOptions.set(d.software);
        this.moodOptions.set(d.moods);
        this.cdr.markForCheck();
      }
    });
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.error.set(null);
    let params = new HttpParams();
    if (this.dateFrom) params = params.set('date_from', this.toDateStr(this.dateFrom));
    if (this.dateTo) params = params.set('date_to', this.toDateStr(this.dateTo));
    if (this.customer.trim()) params = params.set('customer', this.customer.trim());
    if (this.executive.trim()) params = params.set('executive', this.executive.trim());
    if (this.software) params = params.set('software', this.software);
    if (this.mood) params = params.set('mood', this.mood);
    if (this.keyword.trim()) params = params.set('keyword', this.keyword.trim());

    this.http.get<{ rows: CallRow[] }>(`${this.base}/data`, { params }).subscribe({
      next: (d) => {
        this.rows.set(d.rows);
        this.loading.set(false);
        // Update selected keyword detail if one was open
        if (this.selectedKeyword) {
          const agg = this.aggregated().find((a) => a.name === this.selectedKeyword!.name);
          this.selectedKeyword = agg ?? null;
        }
        this.cdr.markForCheck();
      },
      error: (err) => {
        this.error.set(err.error?.detail ?? 'Failed to load data.');
        this.loading.set(false);
        this.cdr.markForCheck();
      }
    });
  }

  reset(): void {
    const now = new Date();
    const prior = new Date();
    prior.setDate(now.getDate() - 90);
    this.dateFrom = prior;
    this.dateTo = now;
    this.customer = '';
    this.executive = '';
    this.software = '';
    this.mood = '';
    this.keyword = '';
    this.load();
  }

  readonly aggregated = computed<KeywordAgg[]>(() => {
    const map = new Map<string, KeywordAgg>();
    for (const row of this.rows()) {
      for (const kw of splitKeywords(row.keywords)) {
        const key = kw.toLowerCase();
        if (!map.has(key)) {
          map.set(key, { name: kw, count: 0, calls: [], moods: { positive: 0, neutral: 0, negative: 0, other: 0 } });
        }
        const agg = map.get(key)!;
        agg.count++;
        agg.calls.push(row);
        agg.moods[moodGroup(row.customer_mood)]++;
      }
    }
    return [...map.values()].sort((a, b) => b.count - a.count);
  });

  readonly bubbles = computed<Bubble[]>(() => {
    const data = this.aggregated().slice(0, 60);
    if (!data.length) return [];
    const max = Math.max(1, ...data.map((d) => d.count));
    const positions: { x: number; y: number; r: number }[] = [];
    let seed = 17;
    const rnd = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };

    return data.map((d, i) => {
      const r = 40 + Math.sqrt(d.count / max) * 90;
      let x = 0, y = 0, tries = 0;
      do {
        x = r + 10 + rnd() * (this.SVG_W - 2 * r - 20);
        y = r + 10 + rnd() * (this.SVG_H - 2 * r - 20);
        tries++;
      } while (tries < 400 && positions.some((p) => Math.hypot(p.x - x, p.y - y) < p.r + r + 22));
      if (tries >= 200) {
        const cellSize = 150;
        const cols = Math.max(1, Math.floor(this.SVG_W / cellSize));
        x = (i % cols) * cellSize + cellSize / 2;
        y = Math.floor(i / cols) * cellSize + cellSize / 2;
      }
      positions.push({ x, y, r });

      const dominant = Object.entries(d.moods).sort((a, b) => b[1] - a[1])[0][0];
      return { ...d, x, y, r, dominant, color: MOOD_COLORS[dominant] };
    });
  });

  readonly totalMentions = computed(() => this.aggregated().reduce((s, a) => s + a.count, 0));

  readonly customerMoodBreakdown = computed<ExecutiveMood[]>(() => {
    const map = new Map<string, { calls: number; moods: Record<string, number> }>();
    for (const r of this.rows()) {
      const name = r.customer_name?.trim() || '(Unknown)';
      if (!map.has(name)) map.set(name, { calls: 0, moods: { positive: 0, neutral: 0, negative: 0, other: 0 } });
      const e = map.get(name)!;
      e.calls++;
      e.moods[moodGroup(r.customer_mood)]++;
    }
    const MOOD_ORDER = ['positive', 'neutral', 'negative', 'other'];
    return [...map.entries()]
      .sort((a, b) => b[1].calls - a[1].calls)
      .map(([name, { calls, moods }]) => ({
        name,
        calls,
        moods,
        segments: MOOD_ORDER
          .filter((m) => moods[m] > 0)
          .map((m) => ({ mood: m, count: moods[m], pct: (moods[m] / calls) * 100, color: MOOD_COLORS[m] }))
      }));
  });

  readonly executiveMoodBreakdown = computed<ExecutiveMood[]>(() => {
    const map = new Map<string, { calls: number; moods: Record<string, number> }>();
    for (const r of this.rows()) {
      const name = r.executive_name?.trim() || '(Unknown)';
      if (!map.has(name)) map.set(name, { calls: 0, moods: { positive: 0, neutral: 0, negative: 0, other: 0 } });
      const e = map.get(name)!;
      e.calls++;
      e.moods[moodGroup(r.customer_mood)]++;
    }
    const MOOD_ORDER = ['positive', 'neutral', 'negative', 'other'];
    return [...map.entries()]
      .sort((a, b) => b[1].calls - a[1].calls)
      .map(([name, { calls, moods }]) => ({
        name,
        calls,
        moods,
        segments: MOOD_ORDER
          .filter((m) => moods[m] > 0)
          .map((m) => ({ mood: m, count: moods[m], pct: (moods[m] / calls) * 100, color: MOOD_COLORS[m] }))
      }));
  });

  readonly executiveSummary = computed<ExecutiveSummary[]>(() => {
    const map = new Map<string, ExecutiveSummary>();
    for (const r of this.rows()) {
      const name = r.executive_name?.trim() || '(Unknown)';
      if (!map.has(name)) map.set(name, { name, calls: 0, totalSeconds: 0 });
      const e = map.get(name)!;
      e.calls++;
      e.totalSeconds += r.call_duration ?? 0;
    }
    return [...map.values()].sort((a, b) => b.totalSeconds - a.totalSeconds);
  });

  exportCustomerMoodBreakdown(): void {
    const cols: ExcelColumn<ExecutiveMood>[] = [
      { header: 'Customer', value: (r) => r.name },
      { header: 'Total Calls', value: (r) => r.calls },
      { header: 'Positive', value: (r) => r.moods['positive'] ?? 0 },
      { header: 'Neutral', value: (r) => r.moods['neutral'] ?? 0 },
      { header: 'Negative', value: (r) => r.moods['negative'] ?? 0 },
      { header: 'Other', value: (r) => r.moods['other'] ?? 0 },
      { header: 'Positive %', value: (r) => +((r.moods['positive'] / r.calls) * 100).toFixed(1) },
      { header: 'Neutral %', value: (r) => +((r.moods['neutral'] / r.calls) * 100).toFixed(1) },
      { header: 'Negative %', value: (r) => +((r.moods['negative'] / r.calls) * 100).toFixed(1) },
    ];
    exportToExcel('mood-breakdown-per-customer', this.customerMoodBreakdown(), cols);
  }

  exportMoodBreakdown(): void {
    const cols: ExcelColumn<ExecutiveMood>[] = [
      { header: 'Executive', value: (r) => r.name },
      { header: 'Total Calls', value: (r) => r.calls },
      { header: 'Positive', value: (r) => r.moods['positive'] ?? 0 },
      { header: 'Neutral', value: (r) => r.moods['neutral'] ?? 0 },
      { header: 'Negative', value: (r) => r.moods['negative'] ?? 0 },
      { header: 'Other', value: (r) => r.moods['other'] ?? 0 },
      { header: 'Positive %', value: (r) => +((r.moods['positive'] / r.calls) * 100).toFixed(1) },
      { header: 'Neutral %', value: (r) => +((r.moods['neutral'] / r.calls) * 100).toFixed(1) },
      { header: 'Negative %', value: (r) => +((r.moods['negative'] / r.calls) * 100).toFixed(1) },
    ];
    exportToExcel('mood-breakdown-per-executive', this.executiveMoodBreakdown(), cols);
  }

  exportExecutiveSummary(): void {
    const cols: ExcelColumn<ExecutiveSummary>[] = [
      { header: 'Executive', value: (r) => r.name },
      { header: 'Calls', value: (r) => r.calls },
      { header: 'Total Time', value: (r) => this.fmtDuration(r.totalSeconds) },
      { header: 'Total Seconds', value: (r) => r.totalSeconds },
    ];
    exportToExcel('time-spent-per-executive', this.executiveSummary(), cols);
  }

  exportCalls(): void {
    const cols: ExcelColumn<CallRow>[] = [
      { header: 'Date', value: (r) => r.call_date?.slice(0, 10) ?? '' },
      { header: 'Customer', value: (r) => r.customer_name ?? '' },
      { header: 'Executive', value: (r) => r.executive_name ?? '' },
      { header: 'Mood', value: (r) => r.customer_mood ?? '' },
      { header: 'Mood Reason', value: (r) => r.mood_reason ?? '' },
      { header: 'Duration (sec)', value: (r) => r.call_duration ?? '' },
      { header: 'Software', value: (r) => r.software_name ?? '' },
      { header: 'Keywords', value: (r) => r.keywords ?? '' },
    ];
    exportToExcel('call-summaries', this.rows(), cols);
  }

  fmtDuration(seconds: number): string {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) return `${h}h ${m}m`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
  }

  selectBubble(b: Bubble): void {
    this.selectedKeyword = b;
    this.cdr.markForCheck();
    // On phones/tablets the detail panel stacks below the chart, off-screen —
    // bring it into view (the chart stays right above it, so another bubble
    // is one scroll up, or one tap on "Change keyword").
    if (window.matchMedia(MOBILE_QUERY).matches) {
      setTimeout(() => this.scrollToEl('.detail-panel'));
    }
  }

  closeDetail(): void {
    this.selectedKeyword = null;
    this.cdr.markForCheck();
  }

  scrollToChart(): void {
    this.scrollToEl('.chart-panel');
  }

  private scrollToEl(selector: string): void {
    this.host.nativeElement.querySelector(selector)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  private toDateStr(d: Date): string {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  labelFontSize(r: number): number {
    return Math.max(11, Math.min(16, r / 3));
  }

  truncate(s: string, max: number): string {
    return s.length > max ? s.slice(0, max - 1) + '…' : s;
  }

  moodEntries(moods: Record<string, number>): { key: string; val: number }[] {
    return Object.entries(moods).map(([key, val]) => ({ key, val }));
  }

  readonly softwareSelectOptions = computed(() => [
    { label: 'All software', value: '' },
    ...this.softwareOptions().map((s) => ({ label: s, value: s }))
  ]);

  readonly moodSelectOptions = computed(() => [
    { label: 'All moods', value: '' },
    ...this.moodOptions().map((m) => ({ label: m, value: m }))
  ]);
}
