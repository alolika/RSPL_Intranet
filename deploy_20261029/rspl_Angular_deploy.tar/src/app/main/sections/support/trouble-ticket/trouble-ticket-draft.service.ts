import { Injectable } from '@angular/core';

import { IssueDetailRow } from '../support-data.service';

export interface TroubleTicketDraft {
  mode: 'add' | 'edit';
  selectedCustomer: number | null;
  // The customer picker only ever holds a top-100/search-matched slice, not
  // every customer — if the selection came from a search, a fresh restore
  // could otherwise land on an ID absent from the freshly re-fetched list
  // and render blank, which reads exactly like the selection was lost even
  // though it technically wasn't. Carrying the label lets ngOnInit splice
  // it back into the options so it still displays correctly.
  selectedCustomerLabel: string | null;
  ticketNo: number | null;
  calledBy: string;
  receivedBy: number | null;
  nextPerson: number | null;
  showDependent: boolean;
  activeTab: 'pending' | 'closed' | 'search';
  issueRows: IssueDetailRow[];
  newIssue: IssueDetailRow;
}

/**
 * Holds the in-progress Create/Edit Trouble Ticket form across navigation
 * to one of its related pages (Pay Bank, Modules, Customer Dependent,
 * Visit Log). Those were RadWindow modal popups in the legacy app, so the
 * underlying ticket form never unmounted while one was open; here they're
 * real routes, so Angular destroys and recreates the TroubleTicket
 * component on every round trip. Without somewhere outside the component
 * to hold the draft, everything the user had typed or staged (customer,
 * assignees, not-yet-submitted issue rows) was silently wiped each time
 * they used one of those links and came back.
 *
 * `providedIn: 'root'` makes this a single app-wide instance that outlives
 * any one component, which is exactly what's needed here — it is NOT a
 * general-purpose store, just a one-slot pocket for this one form.
 */
@Injectable({ providedIn: 'root' })
export class TroubleTicketDraftService {
  private draft: TroubleTicketDraft | null = null;

  save(draft: TroubleTicketDraft): void {
    this.draft = draft;
  }

  take(): TroubleTicketDraft | null {
    const draft = this.draft;
    this.draft = null;
    return draft;
  }

  clear(): void {
    this.draft = null;
  }
}
