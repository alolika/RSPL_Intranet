import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, ElementRef, OnDestroy, OnInit, inject, signal, viewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { RadioButtonModule } from 'primeng/radiobutton';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TabsModule } from 'primeng/tabs';
import { TextareaModule } from 'primeng/textarea';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { ACTION_TAKEN_OPTIONS } from '../issue-detail/issue-detail';
import {
  AmcDetailInfo,
  AttachmentRow,
  CustInfoItem,
  IssueDetailRow,
  LookupOption,
  SupportDataService,
  TicketHistoryRow,
  TicketSummaryRow
} from '../support-data.service';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import { TroubleTicketDraftService } from './trouble-ticket-draft.service';

const MAX_ATTACHMENT_SIZE_BYTES = 5 * 1024 * 1024;
const ALLOWED_IMAGE_TYPES = new Set(['image/jpeg', 'image/png', 'image/gif', 'image/bmp', 'image/webp']);

type Mode = 'add' | 'edit';

/**
 * Mirrors Section_Support/TroubleTicket.aspx: create/modify a trouble
 * ticket, stage issue-detail rows before submit (source used
 * Session("TempTT")), view pending/closed tickets for the selected
 * customer, and jump to related customer info (PayBank/Modules/
 * CustDependent/TTAction). Those cross-links were RadWindow popups
 * loading a whole other page in the source — simplified here to plain
 * navigation to those pages/routes rather than embedding them as dialogs,
 * since each target is itself a full page being migrated in this same
 * phase.
 *
 * Priority and "Action taken" (whatNext) reuse the exact field types the
 * source's IssueDetail.aspx enforces (a dropdown of distinct existing
 * priorities, and a fixed 17-item action-taken list) — the original
 * inline version of this form left both as free-text inputs, which let
 * typos silently create priorities/action-taken values that would never
 * match reporting elsewhere in the app.
 */
@Component({
  selector: 'app-trouble-ticket',
  imports: [
    FormsModule,
    RouterLink,
    ButtonModule,
    RadioButtonModule,
    SelectModule,
    InputTextModule,
    TextareaModule,
    CheckboxModule,
    TableModule,
    TabsModule,
    MessageModule,
    DialogModule,
    DatePipe,
    IndianNumberPipe
  ],
  templateUrl: './trouble-ticket.html',
  styleUrl: './trouble-ticket.scss'
})
export class TroubleTicket implements OnInit, OnDestroy {
  private readonly data = inject(SupportDataService);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly draftService = inject(TroubleTicketDraftService);

  readonly actionTakenOptions = ACTION_TAKEN_OPTIONS;

  mode: Mode = 'add';
  // Default changed from 'closed' to 'pending' per explicit request — the
  // History section should open on Pending by default; still just a plain
  // property the user can freely switch away from via the tab UI itself.
  // 'search' (the new TT Number search tab) is never a default, only ever
  // reached by the user clicking it.
  activeTab: 'pending' | 'closed' | 'search' = 'pending';

  readonly customers = signal<LookupOption[]>([]);
  readonly salesmen = signal<LookupOption[]>([]);
  readonly nextPersons = signal<LookupOption[]>([]);
  // Mirrors IssueDetail.aspx's RcbClosedby combo — same UserMaster list as
  // Next Person, shown only once an issue row's Closed checkbox is ticked.
  readonly closedByUsers = signal<LookupOption[]>([]);
  // Tracks the getUsers() fetch this list depends on — without this, a slow
  // or failed request left the required Closed By picker looking empty and
  // broken the moment "Closed" was ticked, with no indication anything was
  // still loading (this is what made the popup look unreliable/"occasional"
  // in practice, rather than the *ngIf itself ever failing to fire).
  readonly closedByUsersLoading = signal(false);
  readonly closedByUsersError = signal<string | null>(null);
  // Mirrors IssueDetail.aspx's rcbNarration combo — shown alongside Closed
  // By, same existing-options-only picklist getClosedNarrations() already
  // feeds the standalone IssueDetail popup with.
  readonly closedNarrations = signal<LookupOption[]>([]);
  readonly priorities = signal<string[]>([]);
  readonly moduleOptions = signal<string[]>([]);
  readonly generalInfo = signal<CustInfoItem[]>([]);
  readonly statusInfo = signal<CustInfoItem[]>([]);
  readonly reportInfo = signal<CustInfoItem[]>([]);
  // AMC Date's "Details" button (Status panel) — CustInfoItem.action ===
  // 'Details' on that row, per webProc_TTCustInfo's own signal.
  readonly amcDetails = signal<AmcDetailInfo | null>(null);
  readonly amcDetailsLoading = signal(false);
  readonly amcDetailsError = signal<string | null>(null);
  readonly amcDetailsDialogVisible = signal(false);
  readonly pendingTickets = signal<TicketSummaryRow[]>([]);
  readonly closedTickets = signal<TicketSummaryRow[]>([]);
  // Ticket History panel's TT Number search — deliberately independent of
  // pendingTickets()/closedTickets() above (its own tab, own signals, own
  // loading/error state) so it can never affect their existing behavior.
  // Not customer-scoped: searches across every customer by voucher number.
  ticketHistorySearchTerm = '';
  private readonly historyPanel = viewChild<ElementRef<HTMLElement>>('historyPanel');
  readonly ticketHistoryResults = signal<TicketHistoryRow[]>([]);
  readonly ticketHistoryLoading = signal(false);
  readonly ticketHistorySearched = signal(false);
  readonly issueRows = signal<IssueDetailRow[]>([]);
  readonly submitting = signal(false);
  readonly customerDisabled = signal(false);
  readonly customerInfoLoading = signal(false);
  readonly customersLoading = signal(false);

  // Edit mode: mirrors the source's rcbTTNo combo — every pending ticket
  // number, across all customers, so staff can pull up a ticket to modify
  // without needing to already know/select its customer first (selecting a
  // number fills the customer in, not the other way around).
  readonly allPendingTicketNumbers = signal<LookupOption[]>([]);
  readonly ticketDetailLoading = signal(false);

  readonly submitError = signal<string | null>(null);
  readonly submitSuccess = signal<string | null>(null);
  readonly issueError = signal<string | null>(null);
  readonly customerTouched = signal(false);
  readonly assigneesTouched = signal(false);

  // The ticket's VoucherNo doesn't exist until it's actually saved — mirrors
  // the source's own sequencing (TroubleTicket.aspx.vb calls UploadFiles
  // only after WebProc_AddTTMaster returns the new number). Files picked
  // before Submit sit in stagedFiles (with local object-URL previews) and
  // upload right after a successful create; uploadedAttachments holds
  // whatever's already been saved to that ticket.
  readonly stagedFiles = signal<{ file: File; previewUrl: string }[]>([]);
  readonly uploadedAttachments = signal<AttachmentRow[]>([]);
  readonly attachmentError = signal<string | null>(null);
  readonly uploadingAttachments = signal(false);

  selectedCustomer: number | null = null;
  ticketNo: number | null = null;
  calledBy = '';
  receivedBy: number | null = null;
  nextPerson: number | null = null;
  showDependent = false;

  newIssue: IssueDetailRow = this.blankIssue();
  // Index into issueRows() currently loaded into newIssue for editing —
  // null means the fields above are for a brand new row. Set by
  // editIssueRow(), consumed (and cleared) by addIssueRow().
  editingIndex: number | null = null;

  // Debounces the customer-search-as-you-type filter so it re-queries the
  // server once typing pauses, instead of firing one HTTP request per
  // keystroke (PrimeNG's p-select onFilter emits immediately, with no
  // built-in delay).
  private readonly customerFilter$ = new Subject<string>();
  private readonly closedNarrationFilter$ = new Subject<string>();
  private successTimer?: ReturnType<typeof setTimeout>;

  ngOnInit(): void {
    // Restore whatever the user had in progress if we're arriving back from
    // Pay Bank / Modules / Customer Dependent / Visit Log rather than a
    // fresh visit — see TroubleTicketDraftService for why this is needed.
    // Read before the customers() fetch below so that callback can splice
    // a search-only selection back into the freshly loaded options.
    const draft = this.draftService.take();

    this.customersLoading.set(true);
    this.data.getCustomers().subscribe((c) => {
      if (draft?.selectedCustomer && draft.selectedCustomerLabel && !c.some((o) => o.value === draft.selectedCustomer)) {
        c = [{ label: draft.selectedCustomerLabel, value: draft.selectedCustomer }, ...c];
      }
      this.customers.set(c);
      this.customersLoading.set(false);
    });
    this.data.getSalesmen().subscribe((s) => this.salesmen.set(s));
    this.data.getNextPersons().subscribe((p) => this.nextPersons.set(p));
    this.loadClosedByUsers();
    this.data.getClosedNarrations().subscribe((n) => this.closedNarrations.set(n));
    this.data.getPriorities().subscribe((p) => this.priorities.set(p));
    this.data.getModules().subscribe((m) => this.moduleOptions.set(m));
    this.data.getAllPendingTickets().subscribe((t) => this.allPendingTicketNumbers.set(t));

    this.customerFilter$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((query) => this.data.getCustomers(query))
      )
      .subscribe((c) => this.customers.set(c));

    this.closedNarrationFilter$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap((query) => this.data.getClosedNarrations(query))
      )
      .subscribe((n) => this.closedNarrations.set(n));

    if (draft) {
      this.mode = draft.mode;
      this.selectedCustomer = draft.selectedCustomer;
      this.ticketNo = draft.ticketNo;
      this.calledBy = draft.calledBy;
      this.receivedBy = draft.receivedBy;
      this.nextPerson = draft.nextPerson;
      this.showDependent = draft.showDependent;
      // Pending should always be what greets the user when the History
      // section (re)opens — per explicit request. The 'search' tab is
      // available whenever they want it, but never sticks as the restored
      // default the way Pending/Closed legitimately do across a draft
      // restore (e.g. navigating to Pay Bank and back).
      this.activeTab = draft.activeTab === 'search' ? 'pending' : draft.activeTab;
      this.issueRows.set(draft.issueRows);
      this.newIssue = draft.newIssue;
      this.refreshForCustomer(this.selectedCustomer ?? 0);
    } else {
      this.loadCustomerInfo(0);
    }
  }

  ngOnDestroy(): void {
    const selectedOption = this.customers().find((c) => c.value === this.selectedCustomer);
    this.draftService.save({
      mode: this.mode,
      selectedCustomer: this.selectedCustomer,
      selectedCustomerLabel: selectedOption?.label ?? null,
      ticketNo: this.ticketNo,
      calledBy: this.calledBy,
      receivedBy: this.receivedBy,
      nextPerson: this.nextPerson,
      showDependent: this.showDependent,
      activeTab: this.activeTab,
      issueRows: this.issueRows(),
      newIssue: this.newIssue
    });
  }

  // Bound to <p-select>'s (onFilter) — pushes into the debounced pipeline set
  // up in ngOnInit instead of calling the server directly on every keystroke.
  onCustomerFilter(query: string): void {
    this.customerFilter$.next(query);
  }

  onClosedNarrationFilter(query: string): void {
    this.closedNarrationFilter$.next(query);
  }

  // getClosedNarrations() is now capped to TOP 100 (see the backend note),
  // so a ticket's actual saved narration can easily fall outside that
  // slice — the picker would show no label at all for an already-selected
  // value it's never seen. Splices it back in, same defensive pattern as
  // the customer picker's draft-restore in ngOnInit.
  private spliceInLoadedNarration(issues: IssueDetailRow[]): void {
    const missing = issues.filter(
      (i) => i.closedNarrationId && i.closedNarrationLabel && !this.closedNarrations().some((n) => n.value === i.closedNarrationId)
    );
    if (missing.length === 0) {
      return;
    }
    const additions = missing.map((i) => ({ label: i.closedNarrationLabel!, value: i.closedNarrationId! }));
    this.closedNarrations.update((rows) => [...additions, ...rows]);
  }

  // moduleOptions() is the curated TTProducts master list (~460 trimmed,
  // deduped names) — but a ticket's actually-saved Module comes from
  // TTDetails.ProductName, which is unfiltered free text with 6,000+
  // accumulated legacy values (typos, stray whitespace, one-off notes) that
  // don't all appear in that curated list. When a loaded issue's module
  // isn't an exact match, PrimeNG's p-select has nothing to pre-select and
  // silently shows blank, even though newIssue.module already holds the
  // correct value — same class of gap spliceInLoadedNarration already
  // covers for Closed Narration, fixed the same way here.
  private spliceInLoadedModules(issues: IssueDetailRow[]): void {
    const missing = Array.from(new Set(issues.map((i) => i.module).filter((m) => m && !this.moduleOptions().includes(m))));
    if (missing.length === 0) {
      return;
    }
    this.moduleOptions.update((opts) => [...missing, ...opts]);
  }

  // Feeds the View Actions link's CustName param — mirrors ShowAddTTAction()
  // reading $find(rcbCustomer).get_text() for the same purpose.
  selectedCustomerName(): string {
    return this.customers().find((c) => c.value === this.selectedCustomer)?.label ?? '';
  }

  private blankIssue(): IssueDetailRow {
    return {
      module: '',
      priority: '',
      whatNext: '',
      issue: '',
      action: '',
      exeVersionNo: '',
      closed: false,
      closedBy: null,
      closedNarrationId: null,
      closedNarrationNewText: null
    };
  }

  // Closed By and Closing Narration only make sense while Closed is ticked
  // — mirrors chkCloseAction_CheckedChanged toggling PnlClose.Visible, and
  // clears any stale selection left over from a previous edit so an
  // unchecked row never silently carries either value forward.
  onIssueClosedChange(): void {
    if (!this.newIssue.closed) {
      this.newIssue.closedBy = null;
      this.newIssue.closedNarrationId = null;
      this.newIssue.closedNarrationNewText = null;
    }
  }

  // Picking an existing narration and typing a brand new one are two
  // mutually exclusive ways to fill the same field — selecting one clears
  // whatever was typed/picked in the other, so a save can never send both
  // (or silently keep a stale one of the two around).
  onClosedNarrationSelected(): void {
    if (this.newIssue.closedNarrationId) {
      this.newIssue.closedNarrationNewText = null;
    }
  }

  onClosedNarrationTyped(): void {
    if (this.newIssue.closedNarrationNewText?.trim()) {
      this.newIssue.closedNarrationId = null;
    }
  }

  // Closed By is a required field the instant Closed is ticked — an empty
  // or still-loading list at that moment is exactly what made the popup
  // look broken/inconsistent rather than the panel failing to render at
  // all. Split out from ngOnInit so a failed fetch can be retried from the
  // template instead of leaving the picker permanently empty for the rest
  // of the session.
  loadClosedByUsers(): void {
    this.closedByUsersLoading.set(true);
    this.closedByUsersError.set(null);
    this.data.getUsers().subscribe({
      next: (u) => {
        this.closedByUsersLoading.set(false);
        this.closedByUsers.set(u);
        this.cdr.markForCheck();
      },
      error: () => {
        this.closedByUsersLoading.set(false);
        this.closedByUsersError.set('Could not load the Closed By list. Please retry.');
        this.cdr.markForCheck();
      }
    });
  }

  onModeChange(): void {
    this.clearControl();
  }

  onCustomerChange(): void {
    this.customerTouched.set(true);
    this.submitError.set(null);
    if (!this.selectedCustomer) {
      this.customerDisabled.set(false);
      this.loadCustomerInfo(0);
      this.pendingTickets.set([]);
      this.closedTickets.set([]);
      return;
    }
    this.calledBy = '';
    this.ticketNo = null;
    this.refreshForCustomer(this.selectedCustomer);
  }

  // Mirrors rcbTTNo_SelectedIndexChanged -> ShowTTdetails(): selecting a
  // pending ticket number pulls its customer, assignees and issue rows in
  // and populates the form, ready to modify and Update.
  onTicketNoChange(): void {
    this.submitError.set(null);
    this.submitSuccess.set(null);
    this.editingIndex = null;
    this.newIssue = this.blankIssue();
    if (!this.ticketNo) {
      return;
    }
    const ttNo = this.ticketNo;
    this.ticketDetailLoading.set(true);
    this.data.getTicketDetail(ttNo).subscribe({
      next: (detail) => {
        this.ticketDetailLoading.set(false);
        if (!detail) {
          this.submitError.set(`Ticket ${ttNo} could not be found.`);
          this.cdr.markForCheck();
          return;
        }
        this.selectedCustomer = detail.custId;
        this.receivedBy = detail.receivedBy;
        this.nextPerson = detail.nextPerson;
        this.calledBy = detail.calledBy;
        this.issueRows.set(detail.issues);
        this.spliceInLoadedNarration(detail.issues);
        this.spliceInLoadedModules(detail.issues);
        this.customerTouched.set(true);
        this.assigneesTouched.set(true);
        this.refreshForCustomer(detail.custId);
        this.cdr.markForCheck();
      },
      error: () => {
        this.ticketDetailLoading.set(false);
        this.submitError.set(`Failed to load ticket ${ttNo}. Please check your connection and try again.`);
        this.cdr.markForCheck();
      }
    });
  }

  // Ticket History panel's TT Number search — supports partial matches (the
  // backend does a LIKE-style search against VoucherNo) and is intentionally
  // NOT scoped to the currently selected customer, so staff can pull up a
  // ticket's complete history from just its number alone.
  searchTicketHistory(): void {
    const term = this.ticketHistorySearchTerm.trim();
    this.ticketHistorySearched.set(true);
    // The search box lives at the top (beside Customer); its results still
    // show in Ticket History's "Search by TT No" tab — switch to it and
    // bring it into view.
    this.activeTab = 'search';
    this.cdr.markForCheck();
    setTimeout(() => this.historyPanel()?.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start' }));
    if (!term) {
      this.ticketHistoryResults.set([]);
      return;
    }
    this.ticketHistoryLoading.set(true);
    this.data.searchTicketHistory(term).subscribe({
      next: (rows) => {
        this.ticketHistoryLoading.set(false);
        this.ticketHistoryResults.set(rows);
        this.cdr.markForCheck();
      },
      error: () => {
        this.ticketHistoryLoading.set(false);
        this.ticketHistoryResults.set([]);
        this.cdr.markForCheck();
      }
    });
  }

  private refreshForCustomer(custId: number): void {
    this.loadCustomerInfo(custId);
    if (!custId) {
      return;
    }
    this.data.getPendingTickets(custId).subscribe((t) => this.pendingTickets.set(t));
    this.data.getClosedTickets(custId).subscribe((t) => this.closedTickets.set(t));
  }

  private loadCustomerInfo(custId: number): void {
    this.customerInfoLoading.set(true);
    this.data.getCustomerInfo(custId).subscribe((info) => {
      this.generalInfo.set(info.general);
      this.statusInfo.set(info.status);
      this.reportInfo.set(info.report);
      this.customerDisabled.set(info.disabled);
      this.customerInfoLoading.set(false);
      this.cdr.markForCheck();
    });
  }

  openAmcDetails(): void {
    if (!this.selectedCustomer) {
      return;
    }
    this.amcDetailsDialogVisible.set(true);
    this.loadAmcDetails(this.selectedCustomer);
  }

  private loadAmcDetails(custId: number): void {
    this.amcDetailsLoading.set(true);
    this.amcDetailsError.set(null);
    this.amcDetails.set(null);
    this.data.getAmcDetails(custId).subscribe({
      next: (info) => {
        this.amcDetailsLoading.set(false);
        if (!info) {
          this.amcDetailsError.set('No AMC record found for this customer.');
        } else {
          this.amcDetails.set(info);
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.amcDetailsLoading.set(false);
        this.amcDetailsError.set('Could not load AMC details. Please retry.');
        this.cdr.markForCheck();
      }
    });
  }

  retryAmcDetails(): void {
    if (this.selectedCustomer) {
      this.loadAmcDetails(this.selectedCustomer);
    }
  }

  closeAmcDetailsDialog(): void {
    this.amcDetailsDialogVisible.set(false);
  }

  addIssueRow(): void {
    const i = this.newIssue;
    if (!i.module.trim() || !i.priority || !i.whatNext || !i.issue.trim() || !i.action.trim()) {
      this.issueError.set('Please fill Module, Priority, Action Taken, Issue and Remark before adding.');
      return;
    }
    // Mirrors btnAddAction_Click's own guard: "If chkCloseAction.Checked = True And RcbClosedby.Text = '' Then alert('Please select closed by')".
    if (i.closed && !i.closedBy) {
      this.issueError.set('Please select Closed By.');
      return;
    }
    this.issueError.set(null);
    if (this.editingIndex !== null) {
      const idx = this.editingIndex;
      const wasExisting = i.isExisting === true;
      const updatedRows = this.issueRows().map((r, index) => (index === idx ? i : r));
      this.issueRows.set(updatedRows);
      this.editingIndex = null;
      // Per explicit request: editing an already-saved row of an existing
      // ticket now persists to the database the moment "Save Changes" is
      // clicked, instead of only updating the local table and silently
      // relying on the user to separately remember the page-level Update
      // button afterward — that gap is exactly why Module edits looked like
      // they "weren't saving". Brand-new rows (isExisting false/undefined,
      // "Add Issue") are untouched — they still only stage locally here and
      // go live together with the rest of the ticket on Update/Submit, same
      // as before.
      if (this.mode === 'edit' && wasExisting) {
        this.persistExistingRowEdit(updatedRows);
      }
    } else {
      this.issueRows.update((rows) => [...rows, i]);
    }
    this.newIssue = this.blankIssue();
  }

  // Saves an existing row's edit (e.g. a Module rename) immediately,
  // without resetting the rest of the form — unlike onSaveSuccess() (used by
  // the page-level Update/Submit button), this deliberately leaves
  // ticketNo/selectedCustomer/issueRows in place so the user can keep
  // reviewing or editing other rows on the same ticket afterward.
  private persistExistingRowEdit(rows: IssueDetailRow[]): void {
    if (!this.ticketNo) {
      return;
    }
    this.submitError.set(null);
    this.submitting.set(true);
    this.data.updateTicket(this.ticketNo, this.calledBy, rows).subscribe({
      next: (res) => {
        this.submitting.set(false);
        this.showSuccess(res.message || `Module updated for ticket ${res.voucherNo}.`);
        this.cdr.markForCheck();
      },
      error: (err) => this.onSaveError(err)
    });
  }

  // Loads an already-added row back into the fields above for editing.
  // Existing (server-loaded) rows keep isExisting (and originalModule) on
  // the copy — the Module field itself stays fully editable; changing it
  // and saving is exactly how a rename is meant to work (see update_ticket's
  // renamed-row DELETE+re-INSERT handling in support.py, keyed off
  // module !== originalModule), not something that needs preventing.
  editIssueRow(index: number): void {
    const row = this.issueRows()[index];
    if (!row) {
      return;
    }
    this.newIssue = { ...row };
    this.editingIndex = index;
    this.issueError.set(null);
  }

  cancelEditIssueRow(): void {
    this.editingIndex = null;
    this.newIssue = this.blankIssue();
    this.issueError.set(null);
  }

  removeIssueRow(index: number): void {
    if (this.editingIndex === index) {
      this.cancelEditIssueRow();
    }
    this.issueRows.update((rows) => rows.filter((_, i) => i !== index));
  }

  submit(): void {
    this.customerTouched.set(true);
    this.assigneesTouched.set(true);
    this.submitSuccess.set(null);

    if (this.customerDisabled()) {
      this.submitError.set('This customer is disabled — a trouble ticket cannot be created or modified for them.');
      return;
    }

    if (this.mode === 'edit') {
      if (!this.ticketNo) {
        this.submitError.set('Please select a Ticket No. to modify.');
        return;
      }
      if (this.issueRows().length === 0) {
        this.submitError.set('Please add at least one issue detail before updating.');
        return;
      }
      this.submitError.set(null);
      this.submitting.set(true);
      this.data.updateTicket(this.ticketNo, this.calledBy, this.issueRows()).subscribe({
        next: (res) => this.onSaveSuccess(res),
        error: (err) => this.onSaveError(err)
      });
      return;
    }

    if (!this.selectedCustomer) {
      this.submitError.set('Please select a customer.');
      return;
    }
    if (!this.receivedBy) {
      this.submitError.set('Please select Received By.');
      return;
    }
    if (!this.nextPerson) {
      this.submitError.set('Please select Next Person.');
      return;
    }
    if (this.issueRows().length === 0) {
      this.submitError.set('Please add at least one issue detail before submitting.');
      return;
    }

    this.submitError.set(null);
    this.submitting.set(true);
    this.data
      .createTicket(this.selectedCustomer, this.receivedBy, this.nextPerson, this.calledBy, this.issueRows())
      .subscribe({
        next: (res) => this.onSaveSuccess(res),
        // Without this, an HTTP failure (expired session, validation
        // rejected server-side, network hiccup) left `submitting` stuck at
        // true forever — the Submit button shows its loading spinner and
        // PrimeNG disables it while loading, so it looks permanently
        // unresponsive with no way to retry short of reloading the page.
        error: (err) => this.onSaveError(err)
      });
  }

  private onSaveSuccess(res: { voucherNo: number; message: string }): void {
    this.submitting.set(false);
    const baseMessage = res.message || `Ticket ${res.voucherNo} saved successfully.`;
    // Mirrors the source's own sequencing (UploadFiles runs only after
    // WebProc_AddTTMaster returns the new VoucherNo, since the files are
    // named/stored per-ticket) — any images picked before Submit upload now
    // that a real ticket number exists. The success banner (and its
    // clear-after-5s timer) is deferred until the attachment upload itself
    // finishes, not fired here — starting it early would let
    // uploadedAttachments get cleared by the timer before the upload had
    // even set it.
    const staged = this.stagedFiles();
    if (staged.length > 0 && res.voucherNo) {
      this.uploadStagedFiles(res.voucherNo, staged, baseMessage);
    } else {
      this.showSuccess(baseMessage);
      this.clearControl();
    }
    this.cdr.markForCheck();
  }

  private onSaveError(err: unknown): void {
    this.submitting.set(false);
    const detail = (err as { error?: { detail?: string } })?.error?.detail;
    this.submitError.set(detail ?? 'Failed to save the ticket. Please check your connection and try again.');
    this.cdr.markForCheck();
  }

  private uploadStagedFiles(voucherNo: number, staged: { file: File; previewUrl: string }[], baseMessage: string): void {
    this.uploadingAttachments.set(true);
    this.data.uploadAttachments(voucherNo, staged.map((s) => s.file)).subscribe({
      next: (saved) => {
        this.uploadingAttachments.set(false);
        this.uploadedAttachments.set(saved);
        const suffix = saved.length === 1 ? '1 image attached.' : `${saved.length} images attached.`;
        this.showSuccess(`${baseMessage} ${suffix}`);
        this.clearControl();
        this.cdr.markForCheck();
      },
      // The ticket itself already saved successfully at this point — an
      // attachment upload failure shouldn't read as "the ticket save
      // failed" (submitSuccess below still fires for the ticket itself),
      // so this surfaces as its own, separate message instead of
      // overwriting submitError.
      error: () => {
        this.uploadingAttachments.set(false);
        this.showSuccess(baseMessage);
        this.clearControl();
        this.attachmentError.set(`Ticket ${voucherNo} was saved, but the attached images could not be uploaded. Please try attaching them again.`);
        this.cdr.markForCheck();
      }
    });
  }

  onFilesSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const files = input.files ? Array.from(input.files) : [];
    input.value = '';
    if (files.length === 0) {
      return;
    }
    this.attachmentError.set(null);
    const accepted: { file: File; previewUrl: string }[] = [];
    for (const file of files) {
      if (!ALLOWED_IMAGE_TYPES.has(file.type)) {
        this.attachmentError.set(`"${file.name}" isn't a supported image type.`);
        continue;
      }
      if (file.size > MAX_ATTACHMENT_SIZE_BYTES) {
        this.attachmentError.set(`"${file.name}" is larger than 5 MB.`);
        continue;
      }
      accepted.push({ file, previewUrl: URL.createObjectURL(file) });
    }
    if (accepted.length > 0) {
      this.stagedFiles.update((rows) => [...rows, ...accepted]);
    }
  }

  removeStagedFile(index: number): void {
    this.stagedFiles.update((rows) => {
      URL.revokeObjectURL(rows[index].previewUrl);
      return rows.filter((_, i) => i !== index);
    });
  }

  cancel(): void {
    this.clearControl();
  }

  private showSuccess(message: string): void {
    this.submitSuccess.set(message);
    if (this.successTimer) {
      clearTimeout(this.successTimer);
    }
    // uploadedAttachments deliberately survives clearControl() below (which
    // resets everything else right away) so the just-uploaded images stay
    // visible as confirmation — cleared on the same timer as the success
    // banner instead, rather than disappearing the instant the form resets.
    this.successTimer = setTimeout(() => {
      this.submitSuccess.set(null);
      this.uploadedAttachments.set([]);
    }, 5000);
  }

  private clearControl(): void {
    this.calledBy = '';
    this.ticketNo = null;
    this.receivedBy = null;
    this.nextPerson = null;
    this.selectedCustomer = null;
    this.issueRows.set([]);
    this.newIssue = this.blankIssue();
    this.editingIndex = null;
    this.customerDisabled.set(false);
    this.customerTouched.set(false);
    this.assigneesTouched.set(false);
    this.issueError.set(null);
    this.submitError.set(null);
    this.pendingTickets.set([]);
    this.closedTickets.set([]);
    this.draftService.clear();
    this.loadCustomerInfo(0);

    for (const staged of this.stagedFiles()) {
      URL.revokeObjectURL(staged.previewUrl);
    }
    this.stagedFiles.set([]);
    this.attachmentError.set(null);
  }
}
