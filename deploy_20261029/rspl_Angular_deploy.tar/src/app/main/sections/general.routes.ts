import { Routes } from '@angular/router';

import { formAccessGuard } from '../../core/auth/form-access.guard';
import { FORM_EMPLOYEE_ATTENDANCE_SHEET } from '../../core/auth/user-rights.service';
import { placeholderRoutes } from '../../shared/placeholder-routes';

export const generalRoutes: Routes = [
  {
    path: 'feedback',
    loadComponent: () => import('./general/feedback/feedback').then((m) => m.Feedback)
  },
  {
    path: 'emp-attendance',
    loadComponent: () => import('./general/emp-attendance/emp-attendance').then((m) => m.EmpAttendance)
  },
  {
    // New, independent module — see
    // app/routers/general_attendance_sheet.py. Deliberately a distinct
    // route/component from 'emp-attendance' above, not a replacement.
    path: 'employee-attendance-sheet',
    canActivate: [formAccessGuard(FORM_EMPLOYEE_ATTENDANCE_SHEET)],
    loadComponent: () =>
      import('./general/employee-attendance-sheet/employee-attendance-sheet').then((m) => m.EmployeeAttendanceSheet)
  },
  {
    path: 'face-attendance',
    loadComponent: () =>
      import('./general/face-attendance/face-attendance').then((m) => m.FaceAttendance),
  },
  {
    path: 'leave-application',
    loadComponent: () => import('./general/leave-application/leave-application').then((m) => m.LeaveApplication)
  },
  {
    path: 'leave-cancellation',
    loadComponent: () => import('./general/leave-cancellation/leave-cancellation').then((m) => m.LeaveCancellation)
  },
  {
    // LeaveCancel.aspx in the source is only ever opened as a RadWindow popup
    // from LeaveCancellation.aspx — folded into that component's dialog here.
    path: 'leave-cancel',
    redirectTo: 'leave-cancellation'
  },
  {
    path: 'ceo-leave-sanction',
    loadComponent: () => import('./general/ceo-leave-sanction/ceo-leave-sanction').then((m) => m.CeoLeaveSanction)
  },
  {
    // LeaveSanction.aspx / LeaveSanctionCancellation.aspx in the source use
    // Index.master (no login, no nav) — moved to top-level unauthenticated
    // routes at /leave-sanction and /leave-sanction-cancellation instead of
    // living under the guarded main shell. See app.routes.ts.
    path: 'leave-sanction',
    redirectTo: '/leave-sanction'
  },
  {
    path: 'leave-sanction-cancellation',
    redirectTo: '/leave-sanction-cancellation'
  },
  {
    path: 'asset-track',
    loadComponent: () => import('./general/asset-track/asset-track').then((m) => m.AssetTrack)
  },
  {
    path: 'schedule',
    loadComponent: () => import('./general/schedule/schedule').then((m) => m.Schedule)
  },
  {
    path: 'manage-chart',
    loadComponent: () => import('./general/manage-chart/manage-chart').then((m) => m.ManageChart)
  },
  {
    path: 'dynamic-reports',
    loadComponent: () => import('./general/dynamic-reports/dynamic-reports').then((m) => m.DynamicReports)
  },
  // ReportNew / ReportViewer / webDashboard are historically separate entry
  // points into the same ad-hoc report engine in the source (see
  // feedback_report_engine_simplification memory) — unified into one
  // generic ReportViewer component here.
  {
    path: 'report-viewer',
    loadComponent: () => import('./general/report-viewer/report-viewer').then((m) => m.ReportViewer)
  },
  {
    path: 'report-new',
    loadComponent: () => import('./general/report-viewer/report-viewer').then((m) => m.ReportViewer)
  },
  {
    path: 'web-dashboard',
    loadComponent: () => import('./general/report-viewer/report-viewer').then((m) => m.ReportViewer)
  },
  {
    path: 'my-caller',
    loadComponent: () => import('./general/my-caller/my-caller').then((m) => m.MyCaller)
  },
  {
    path: 'organizational-chart',
    loadComponent: () =>
      import('./general/organizational-chart/organizational-chart').then((m) => m.OrganizationalChart)
  },
  {
    path: 'sales-team-dashboard',
    loadComponent: () => import('./general/sales-team-dashboard/sales-team-dashboard').then((m) => m.SalesTeamDashboard)
  },
  {
    path: 'amc-dashboard',
    loadComponent: () => import('./general/amc-dashboard/amc-dashboard').then((m) => m.AmcDashboard)
  },
  ...placeholderRoutes([
    // Home.master's Help > Download menu item points at Section_General/Downloads.aspx,
    // which does not exist in the source project (dead link, preserved rather than invented).
    ['downloads', 'Download (dead link in source app)']
  ])
];
