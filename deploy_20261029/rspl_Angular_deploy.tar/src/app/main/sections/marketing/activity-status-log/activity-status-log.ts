import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { LookupOption, MarketingDataService } from '../marketing-data.service';

/** Mirrors Section_Marketing/ActivityStatuslog.aspx: multi-filter (action stage/date-range/user) dynamic-column activity log grid. */
@Component({
  selector: 'app-activity-status-log',
  imports: [FormsModule, ButtonModule, DatePickerModule, SelectModule, TableModule],
  templateUrl: './activity-status-log.html',
  styleUrl: './activity-status-log.scss'
})
export class ActivityStatusLog implements OnInit {
  private readonly data = inject(MarketingDataService);

  readonly users = signal<LookupOption[]>([]);
  readonly actionStages = signal<LookupOption[]>([]);
  readonly columns = signal<string[]>([]);
  readonly rows = signal<Record<string, unknown>[]>([]);
  readonly loading = signal(false);

  actionStageId = 0;
  fromDate: Date | null = new Date();
  toDate: Date | null = new Date();
  userId = 0;

  ngOnInit(): void {
    this.data.getActivityStatusLogFilters().subscribe((f) => {
      this.users.set(f.users);
      this.actionStages.set(f.actionStages);
    });
  }

  show(): void {
    if (!this.fromDate || !this.toDate) {
      return;
    }
    const actionStage = this.actionStages().find((s) => s.value === this.actionStageId)?.label ?? '';
    const userName = this.users().find((u) => u.value === this.userId)?.label ?? '';
    this.loading.set(true);
    this.data.getActivityStatusLogRows(this.fromDate, this.toDate, actionStage, userName).subscribe((res) => {
      this.columns.set(res.columns);
      this.rows.set(res.rows);
      this.loading.set(false);
    });
  }
}
