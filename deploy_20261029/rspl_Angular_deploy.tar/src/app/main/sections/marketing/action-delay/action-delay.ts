import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { LookupOption, MarketingDataService } from '../marketing-data.service';

/**
 * Mirrors Section_Marketing/ActionDelay.aspx: salesman-filtered
 * dynamic-column delay report, with a checkbox toggle to switch to "Next
 * Action Not Taken" data. CustID links to CustEnquiryRegister
 * (?Auto=0&CustID=...) — the same route/mode the main menu's own
 * "Enquiry-Action" item opens (see main-nav.ts), just pre-filled with the
 * clicked customer instead of landing on a blank search form. That page
 * already auto-runs the search the instant a real CustID query param is
 * present (see cust-enquiry-register.ts's ngOnInit) and shows the Customer
 * Information panel, the full action-history register grid, and "Next
 * Step" links into the Add/Close Customer Enquiry Action popup for any
 * pending action — the complete experience, not just a bare add-mode form.
 * An earlier version of this fix pointed straight at
 * /marketing/cust-enquiry-action (the Add/Close popup itself, normally
 * only reached via a specific action's "Next Step" link) — wrong target,
 * corrected per explicit follow-up clarifying what "the same way as when
 * it's opened from the menu" actually meant.
 *
 * Also fixed a real pre-existing bug found while wiring this: the
 * template's column check compared against 'custId' (camelCase), but both
 * underlying procs (Proc_WebEnquiryActionDelayReport,
 * Webproc_NextActionNotDecided) return the raw SQL column name 'CustID'
 * unchanged (_dynamic() in marketing_reports.py does no camelCasing,
 * confirmed live) — so the comparison never matched anything and this
 * column has likely never actually rendered as a link at all, contrary to
 * what an even earlier version of this doc comment claimed.
 */
@Component({
  selector: 'app-action-delay',
  imports: [FormsModule, RouterLink, ButtonModule, CheckboxModule, SelectModule, TableModule],
  templateUrl: './action-delay.html',
  styleUrl: './action-delay.scss'
})
export class ActionDelay implements OnInit {
  private readonly data = inject(MarketingDataService);

  readonly salesmen = signal<LookupOption[]>([]);
  readonly columns = signal<string[]>([]);
  readonly rows = signal<Record<string, unknown>[]>([]);
  readonly loading = signal(false);

  salesmanId = 0;
  nextActionNotTaken = false;

  ngOnInit(): void {
    this.data.getActionDelaySalesmen().subscribe((s) => this.salesmen.set(s));
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.data.getActionDelayRows(this.salesmanId, this.nextActionNotTaken).subscribe((res) => {
      this.columns.set(res.columns);
      this.rows.set(res.rows);
      this.loading.set(false);
    });
  }
}
