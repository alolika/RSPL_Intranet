import { DecimalPipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { TableModule } from 'primeng/table';

import { GOOGLE_MAPS_API_KEY } from '../../../../shared/google-maps-key';
import { CustGeoRow, MarketingDataService } from '../marketing-data.service';

/**
 * Mirrors Section_Marketing/CustMapLocation.aspx ("Customer Geo Location" /
 * menu "CustomerMap-Pin"): same App_Service/CRMMAP.asmx/GetLatLong data as
 * CustHeatMap but with individual (unclustered) pins in the source — a
 * distinct menu item/page, kept as its own route even though the data and
 * fallback table view are identical, since real map rendering is unavailable
 * either way in this frontend-only phase (see shared/google-maps-key.ts).
 */
@Component({
  selector: 'app-cust-map-location',
  imports: [TableModule, DecimalPipe],
  templateUrl: './cust-map-location.html',
  styleUrl: './cust-map-location.scss'
})
export class CustMapLocation implements OnInit {
  private readonly data = inject(MarketingDataService);

  readonly rows = signal<CustGeoRow[]>([]);
  readonly hasMapsKey = !!GOOGLE_MAPS_API_KEY;

  ngOnInit(): void {
    this.data.getCustGeoLocations().subscribe((rows) => this.rows.set(rows));
  }
}
