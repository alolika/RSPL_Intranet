import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { LookupOption, MarketingDataService } from '../marketing-data.service';

/** Mirrors Section_Marketing/NextActionNotTaken.aspx ("Next Action Not Decided"): Assigned To filter + dynamic-column grid. */
@Component({
  selector: 'app-next-action-not-taken',
  imports: [FormsModule, ButtonModule, SelectModule, TableModule],
  templateUrl: './next-action-not-taken.html',
  styleUrl: './next-action-not-taken.scss'
})
export class NextActionNotTaken implements OnInit {
  private readonly data = inject(MarketingDataService);

  readonly assignedToUsers = signal<LookupOption[]>([]);
  readonly columns = signal<string[]>([]);
  readonly rows = signal<Record<string, unknown>[]>([]);
  readonly loading = signal(false);

  assignedTo = 0;

  ngOnInit(): void {
    this.data.getAssignedToUsers().subscribe((u) => this.assignedToUsers.set(u));
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.data.getNextActionNotTakenRows(this.assignedTo).subscribe((res) => {
      this.columns.set(res.columns);
      this.rows.set(res.rows);
      this.loading.set(false);
    });
  }
}
