import { DecimalPipe } from '@angular/common';
import { AfterViewInit, Component, ElementRef, HostListener, OnInit, ViewChild, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { DialogModule } from 'primeng/dialog';
import { MultiSelectModule } from 'primeng/multiselect';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { ActionStageDetailParams, ActionStageDetailReport } from '../action-stage-detail-report/action-stage-detail-report';
import { LookupOption, MarketingDataService } from '../marketing-data.service';
import { ExcelColumn, exportToExcel } from '../../../../shared/export-excel';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';

/**
 * Mirrors Section_Marketing/ActionStageSummaryReport.aspx ("Enquiry Stage
 * Report"): a dynamic-column executive-summary report (EXEC
 * WebProc_GetActionStagesSummary) with a multi-select Action Stage
 * combobox filter (checkbox items in the dropdown panel) and per-column
 * drill-down links, same simplified report-engine treatment as CRMReview.
 */
@Component({
  selector: 'app-action-stage-summary-report',
  imports: [FormsModule, ButtonModule, DatePickerModule, DialogModule, MultiSelectModule, SelectModule, TableModule, DecimalPipe, IndianNumberPipe, ActionStageDetailReport],
  providers: [DecimalPipe],
  templateUrl: './action-stage-summary-report.html',
  styleUrl: './action-stage-summary-report.scss'
})
export class ActionStageSummaryReport implements OnInit, AfterViewInit {
  private readonly data = inject(MarketingDataService);
  private readonly router = inject(Router);
  private readonly decimalPipe = inject(DecimalPipe);

  @ViewChild('tableScroll') private tableScrollRef?: ElementRef<HTMLElement>;

  // Only the grid body should scroll — the filter bar/buttons above and the
  // app's own header/menubar/footer around this page must never need the
  // whole document to scroll. Rather than guess a fixed px/vh budget for
  // "everything else on the page" (fragile — header/menubar/footer heights
  // aren't constants, they wrap differently across screen sizes), this
  // measures the real rendered gap between the grid's own top edge and the
  // page footer's top edge and sizes the scroll box to exactly fill it, so
  // the grid plus everything around it always adds up to one viewport with
  // nothing left over to scroll.
  readonly scrollBoxHeight = signal(500);

  ngAfterViewInit(): void {
    // One tick after the initial render so layout (including web-font
    // metrics affecting header height) has settled before the first
    // measurement — mirrors the AMC Dashboard chart's same deferred-first-
    // paint precedent.
    setTimeout(() => this.recomputeScrollHeight());
  }

  @HostListener('window:resize')
  onWindowResize(): void {
    this.recomputeScrollHeight();
  }

  private recomputeScrollHeight(): void {
    const el = this.tableScrollRef?.nativeElement;
    if (!el) {
      return;
    }
    const top = el.getBoundingClientRect().top;
    const footer = document.querySelector<HTMLElement>('.brand-footer');
    const footerHeight = footer?.getBoundingClientRect().height ?? 0;
    // 16px breathing room so the box's own border doesn't sit flush against
    // the footer.
    const available = window.innerHeight - top - footerHeight - 16;
    // Floor raised from 220 to 500 — this report's own row height plus
    // header meant a 220px box only ever showed ~2 rows, which read as
    // broken rather than "the page just doesn't scroll." Favoring a
    // usable, mostly-full grid over strict zero-page-scroll on unusually
    // short windows: on a normal-height screen this still just returns the
    // full available fill-to-footer space (typically well over 500px), the
    // floor only kicks in on short viewports where a small trade-off (a
    // little page scroll) is preferable to a near-unusable 2-row grid.
    this.scrollBoxHeight.set(Math.max(500, Math.round(available)));
  }

  readonly actionStages = signal<LookupOption[]>([]);
  readonly columns = signal<string[]>([]);
  readonly linkColumns = signal<string[]>([]);
  readonly rows = signal<Record<string, unknown>[]>([]);
  readonly loading = signal(false);
  // Non-null only while the drill-down dialog is open — a fresh
  // <app-action-stage-detail-report> instance is created each time it goes
  // null-to-non-null (see the @if in the template), so the child always
  // starts clean without needing its own change-detection-on-input-change
  // handling. Kept as a dialog instead of a route navigation specifically so
  // closing it never touches this component: previously "Order Value" (and
  // every stage column except "Received By Count") routed to a full
  // /marketing/action-stage-detail-report page, and Location.back() on
  // close destroyed and recreated this whole report — resetting the date
  // range/stage filter/loaded rows/scroll position every single time.
  readonly detailParams = signal<ActionStageDetailParams | null>(null);
  readonly detailDialogVisible = signal(false);

  fromDate: Date | null = new Date();
  toDate: Date | null = new Date();
  selectedStages: number[] = [];

  // Columns are server-driven (16 of them, only 3 are ever text — Executive/
  // Demo Segment/Demo City), so totals are computed generically rather than
  // hardcoding one column per name: a column is "totalable" only if every
  // row's value for it is either a number or absent — the moment any row
  // holds a real string there (Executive always does; Demo Segment/Demo City
  // do whenever an executive has a demoed segment/city on file), it's
  // excluded rather than risk concatenating/mis-summing text.
  readonly totals = computed<Record<string, number | null>>(() => {
    const result: Record<string, number | null> = {};
    for (const col of this.columns()) {
      let sum = 0;
      let hasNumber = false;
      let hasText = false;
      for (const row of this.rows()) {
        const v = row[col];
        if (v === null || v === undefined) {
          continue;
        }
        if (typeof v === 'number') {
          sum += v;
          hasNumber = true;
        } else {
          hasText = true;
          break;
        }
      }
      result[col] = hasNumber && !hasText ? sum : null;
    }
    return result;
  });

  ngOnInit(): void {
    this.data.getActionStages2().subscribe((s) => this.actionStages.set(s));
  }

  show(): void {
    this.loading.set(true);
    const stageNames = this.actionStages()
      .filter((s) => this.selectedStages.includes(s.value))
      .map((s) => s.label);
    this.data.getActionStageSummaryRows(this.fromDate, this.toDate, stageNames).subscribe((res) => {
      this.columns.set(res.columns);
      this.linkColumns.set(res.linkColumns);
      this.rows.set(res.rows);
      this.loading.set(false);
      // The multiselect's chip row (and the "Total" footer appearing/
      // disappearing) can change the grid's own top offset — re-measure
      // after this render settles rather than only once on load.
      setTimeout(() => this.recomputeScrollHeight());
    });
  }

  // columns() is the exact same header list/order the table itself renders
  // from (see the template's two @for (col of columns()) loops), so driving
  // the export off it — rather than letting exportToExcel() infer headers
  // from whatever keys happen to be present on the row objects — guarantees
  // the workbook's column order and headings always match the grid exactly,
  // including for rows that might be missing an occasional key. Exports the
  // raw underlying value per cell (not formatCell()'s comma-grouped display
  // string) so numeric columns land as real, sortable/summable Excel
  // numbers — only dates get re-formatted, via exportToExcel()'s own
  // project-wide dd-mmm-yyyy handling, matching what was actually asked for.
  // rows() already holds only the current filtered/searched result set (Show
  // replaces it wholesale), so this never exports more than what's on screen.
  export(): void {
    const columns: ExcelColumn<Record<string, unknown>>[] = this.columns().map((col) => ({
      header: col,
      value: (row) => (row[col] as string | number | null) ?? null
    }));
    exportToExcel('EnquiryStageReport', this.rows(), columns);
  }

  isLink(col: string): boolean {
    return this.linkColumns().includes(col);
  }

  // "Order Value" and "Quotation Amt" are this report's two genuine money
  // columns (everything else is a plain integer count) — formatted with 2
  // decimals, standard thousand separators (1,25,000.00 -> 125,000.00), and
  // right-aligned, instead of a raw unformatted number.
  isAmountColumn(col: string): boolean {
    return col === 'Order Value' || col === 'Quotation Amt';
  }

  // "Demo Segment"/"Demo City" hold comma-joined lists (every segment/city an
  // executive has ever demoed, sometimes dozens of entries) — the only two
  // columns whose content length isn't bounded by being a count/amount.
  // Capping their width (CSS below) and letting them wrap onto multiple
  // lines keeps that content fully visible without widening the whole
  // table or needing horizontal scroll.
  isLongTextColumn(col: string): boolean {
    return col === 'Demo Segment' || col === 'Demo City';
  }

  isTotalableColumn(col: string): boolean {
    return this.totals()[col] !== null;
  }

  // Most numeric columns here (all the stage-count columns, not just Order
  // Value/Quotation Amt) are rendered as drill-down links, not plain text —
  // formatting only the non-link branch previously meant Received By Count/
  // Pending Demo/Demo Count/etc. showed as raw unformatted numbers inside
  // their <a> links. Centralizing the formatting here (called from both the
  // link and plain-text branches in the template) applies thousand
  // separators consistently regardless of whether a cell happens to be
  // clickable. Amount columns get 2 decimals; every other numeric column
  // still gets standard thousand separators as a whole number; text
  // columns pass through unchanged.
  formatCell(value: unknown, col: string): string {
    if (typeof value !== 'number') {
      return value == null ? '' : String(value);
    }
    if (this.isAmountColumn(col)) {
      // Indian lakh/crore grouping for genuine money columns (Order Value,
      // Quotation Amt) — decimalPipe below stays Western since it only ever
      // formats plain integer counts, not currency.
      return value.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    if (this.isTotalableColumn(col)) {
      return this.decimalPipe.transform(value, '1.0-0') ?? '';
    }
    return String(value);
  }

  drillDown(row: Record<string, unknown>, col: string): void {
    // "Received By Count" is a genuinely separate report (Lead Record) —
    // still a real navigation, unlike every other stage column below.
    if (col === 'Received By Count') {
      this.router.navigate(['/marketing/lead-record'], {
        queryParams: {
          ExecutiveName: row['Executive'] as string,
          ActionStageName: col,
          FromDate: (this.fromDate ?? new Date()).toISOString(),
          ToDate: (this.toDate ?? new Date()).toISOString()
        }
      });
      return;
    }
    this.detailParams.set({
      executiveName: row['Executive'] as string,
      actionStageName: col,
      fromDate: this.fromDate,
      toDate: this.toDate
    });
    this.detailDialogVisible.set(true);
  }

  closeDetailDialog(): void {
    // Deliberately NOT clearing detailParams here — leaving it set keeps the
    // child component mounted (rather than the @if in the template tearing
    // it down) so the dialog's own close/fade animation doesn't reveal an
    // empty body mid-transition. Its ngOnChanges reloads correctly the next
    // time drillDown() sets a new value, whether or not this one lingers.
    this.detailDialogVisible.set(false);
  }
}
