import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import {
  EnquiryRegisterActionRow,
  LookupOption,
  MarketingDataService,
  OutstandingFollowupRow
} from '../marketing-data.service';

/**
 * Mirrors Section_Marketing/OutstandingFollowup.aspx: a salesman/customer/
 * ledger-group-filtered AMC-outstanding grid with expandable Add/Close
 * next-step rows locked to ActionStageID=27 (same pattern as AmcPending/
 * AMCCo-OrdinatorDashboard), a click-to-call MobileNo link, and a
 * Customer-Module drill-down popup (simplified to an inline expand rather
 * than the source's nested RadGrid edit-form).
 */
@Component({
  selector: 'app-outstanding-followup',
  imports: [FormsModule, ButtonModule, InputTextModule, SelectModule, TableModule, DatePipe, IndianNumberPipe],
  templateUrl: './outstanding-followup.html',
  styleUrl: './outstanding-followup.scss'
})
export class OutstandingFollowup implements OnInit {
  private readonly data = inject(MarketingDataService);
  private readonly router = inject(Router);

  readonly salesmen = signal<string[]>([]);
  readonly customers = signal<string[]>([]);
  readonly ledgerGroups = signal<LookupOption[]>([]);
  readonly rows = signal<OutstandingFollowupRow[]>([]);
  readonly loading = signal(false);
  readonly expandedCustId = signal<number | null>(null);
  readonly actionHistory = signal<EnquiryRegisterActionRow[]>([]);
  readonly modulesCustId = signal<number | null>(null);
  readonly modules = signal<Record<string, unknown>[]>([]);

  // PrimeNG's [showClear] resets a <p-select> to null (not '' / 0) when its
  // clear icon is clicked — widened to accept that so the field can actually
  // be cleared from the UI instead of only resetting on a full page refresh.
  salesman: string | null = '';
  amount = '1';
  customer: string | null = '';
  ledgerGroupId: number | null = 0;

  ngOnInit(): void {
    this.data.getOutstandingFollowupFilters().subscribe((f) => {
      this.salesmen.set(f.salesmen);
      this.customers.set(f.customers);
      this.ledgerGroups.set(f.ledgerGroups);
    });
    this.show();
  }

  onCustomerFilter(query: string): void {
    this.data.getOutstandingFollowupCustomers(query).subscribe((c) => this.customers.set(c));
  }

  show(): void {
    if (Number(this.amount) < 1) {
      return;
    }
    this.loading.set(true);
    this.data.getOutstandingFollowupRows(this.salesman ?? '', Number(this.amount), this.customer ?? '', this.ledgerGroupId ?? 0).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }

  toggleExpand(row: OutstandingFollowupRow): void {
    if (this.expandedCustId() === row.custId) {
      this.expandedCustId.set(null);
      return;
    }
    this.expandedCustId.set(row.custId);
    this.data.getOutstandingFollowupActions(row.custId).subscribe((rows) => this.actionHistory.set(rows));
  }

  nextStep(row: OutstandingFollowupRow, action: EnquiryRegisterActionRow): void {
    if (action.nextAction === 'Closed') {
      return;
    }
    this.router.navigate(['/marketing/cust-enquiry-action'], {
      queryParams: { ActionStageID: 27, FromAMCPending: 0, CustID: row.custId, RefActionID: action.actionId, ActionType: action.nextAction === 'Add' ? 1 : 2 }
    });
  }

  callNow(mobileNo: string): void {
    alert(`Dialing ${mobileNo} (external Synapse integration — not wired up without a backend)`);
  }

  viewModules(custId: number): void {
    if (this.modulesCustId() === custId) {
      this.modulesCustId.set(null);
      return;
    }
    this.modulesCustId.set(custId);
    this.data.getOutstandingCustomerModules(custId).subscribe((rows) => this.modules.set(rows));
  }

  export(): void {
    exportToExcel('Outstanding', this.rows());
  }
}
