import { ChangeDetectorRef, Component, ElementRef, OnInit, inject, signal, viewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelectModule } from 'primeng/multiselect';
import { SelectModule } from 'primeng/select';
import { StepperModule } from 'primeng/stepper';
import { TextareaModule } from 'primeng/textarea';
import { shareReplay, switchMap } from 'rxjs';

import { WizardStep, goToStep } from '../../../../shared/wizard-step';
import { CustEnquiryAction } from '../cust-enquiry-action/cust-enquiry-action';
import { CustRegistrationDetail, CustRegistrationLookups, LookupOption, MarketingDataService } from '../marketing-data.service';

type Mode = 'new' | 'modify';

// Enquiry Source 2 Date's own date<->string conversion — NOT shared with
// enquiryDate's existing `.toISOString()`/`new Date(str)` pattern above,
// deliberately: `.toISOString()` converts through UTC, so a date picked as
// local midnight (e.g. 12-Sep in IST, UTC+5:30) becomes the PREVIOUS day
// once shifted back 5:30 hours to UTC — `toApiRegistrationDetail()`'s
// `.slice(0, 10)` then truncates that already-wrong UTC date, so the
// backend silently receives one day earlier than what was actually
// selected. These two helpers read/write the picked calendar day using the
// Date object's LOCAL components only, so no timezone conversion ever
// happens for this field. (enquiryDate is left exactly as-is — this fix is
// scoped to Enquiry Source 2 Date only, per explicit instruction.)
function toLocalDateString(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function fromLocalDateString(value: string): Date {
  const [y, m, d] = value.slice(0, 10).split('-').map(Number);
  return new Date(y, m - 1, d);
}

/**
 * Mirrors Section_Marketing/CustRegistration.aspx ("Customer Registration
 * New/Modify" — flagged as the most complex form in the app), driven by
 * ?ActionType= (1=new, 2=modify) and ?CustID=. Two panels: customer master
 * data (left) + enquiry/geographic details (right), matching the source's
 * table layout. The source's hidden-by-default extra-mobile-numbers grid
 * (rgvMobileno, Visible="False") is not replicated — it was never shown in
 * the base UI. Campaign selection (a RadComboBox with an embedded checkbox
 * template, effectively multi-select) is replaced with a standard PrimeNG
 * MultiSelect. GST verification, mobile-availability check, and pincode
 * lookup are mocked service calls mirroring their respective source
 * web-service/stored-proc calls.
 */
@Component({
  selector: 'app-cust-registration',
  imports: [
    FormsModule,
    ButtonModule,
    CheckboxModule,
    DatePickerModule,
    DialogModule,
    InputTextModule,
    MultiSelectModule,
    SelectModule,
    StepperModule,
    TextareaModule,
    CustEnquiryAction
  ],
  templateUrl: './cust-registration.html',
  styleUrl: './cust-registration.scss'
})
export class CustRegistration implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly data = inject(MarketingDataService);
  // This app runs without zone.js — plain (non-signal) properties like `form`/`mode`/
  // `custId`/`enquiryDate`/`selectedCustomerId` below don't trigger a
  // re-render on their own when mutated inside an RxJS subscribe callback. markForCheck()
  // after each such mutation is what actually gets the new values on screen.
  private readonly cdr = inject(ChangeDetectorRef);

  mode: Mode = 'new';
  custId: number | null = null;
  readonly activeStep = signal(0);
  readonly steps: WizardStep[] = [
    { value: 0, label: 'Basic Info', validate: () => this.validateBasicInfoStep() },
    { value: 1, label: 'Additional Details' },
    { value: 2, label: 'Enquiry & Classification' },
    { value: 3, label: 'Geographic Location', validate: () => this.validateGeographicStep() }
  ];

  readonly customers = signal<LookupOption[]>([]);
  readonly lookups = signal<CustRegistrationLookups | null>(null);
  readonly saving = signal(false);
  readonly gstVerifying = signal(false);
  readonly gstMessage = signal('');
  readonly mobileMessage = signal('');
  readonly pincodeMessage = signal('');
  readonly creatingCity = signal(false);
  readonly newCityName = signal('');
  readonly assignedToName = signal('');
  // Assign To lives on the last step (Geographic Location); after a
  // successful Save the field is focused/highlighted and its popup opens.
  readonly assignDialogVisible = signal(false);
  readonly assignHighlight = signal(false);
  private readonly assignLink = viewChild<ElementRef<HTMLAnchorElement>>('assignLink');
  // "Referred By Customer" (rcbRefferedBy/rcbrefcust in the source) was a genuinely
  // load-on-demand RadComboBox — capped to the first 100 customers alphabetically and
  // re-queried by name as the user types, never the full CustomerMaster list. Which one
  // of these two is shown/active depends on the potentialCustomer checkbox above.
  readonly referredByOptions = signal<LookupOption[]>([]);
  readonly potentialCustomerOptions = signal<LookupOption[]>([]);

  selectedCustomerId: number | null = null;
  potentialCustomer = false;
  selectedCampaignIds: number[] = [];
  // The real fix for "Referral card generated but referral customer not
  // selected." (see marketing_registration.py's 2026-08-04 update note):
  // this ID was never actually sent to the backend at all before — only a
  // derived display-name string was — even though the stored procs gate
  // their whole referral-card validation on THIS id being > 0, not on the
  // name. Now sent straight through in save() below.
  referredByCustomerId: number | null = null;
  // Track's the currently-selected option's LABEL, captured directly at
  // selection time (see onReferredByChange()) rather than re-derived later
  // from referredByOptions()/potentialCustomerOptions() at save time. Those
  // lists are load-on-demand search results that get REPLACED as the user
  // types in the filter box (see onReferredByFilter()/
  // onPotentialCustomerFilter()) — a stale re-derivation could send an empty
  // name even with a valid ID selected. Cosmetic mainly now that the real ID
  // above is sent (the backend re-derives the authoritative name itself once
  // it has a valid ID — see webProc_ModifyCustomer/webProc_AddCustomer),
  // but still worth getting right so the UI's own state stays consistent.
  referredByCustomerLabel: string | null = null;
  // Tracks whichever synthetic option loadCustomer() last injected into
  // referredByOptions()/potentialCustomerOptions() (see below), so the next
  // load can remove exactly that one instead of letting them pile up.
  private lastSyntheticReferredById: number | null = null;
  enquiryDate: Date | null = new Date();
  // Enquiry Source 2's own date — kept as a separate Date-typed property, same
  // pattern as enquiryDate above (form.enquirySource2Date stays the ISO string
  // the backend actually sends/receives). Unlike Received On, this one has no
  // sensible default — it's optional, so it starts unset rather than "today".
  enquirySource2Date: Date | null = null;

  form: CustRegistrationDetail = this.blankForm();

  // The lookups call (groups/states/cities/zones/enquiry-source/business-
  // nature/segment/provider — everything every <p-select> on this form
  // needs) and the per-customer detail call are independent HTTP requests
  // with no guaranteed ordering. If the customer's saved values got
  // assigned to `form` before their dropdowns' own [options] lists had
  // finished loading, PrimeNG has nothing to match those values against
  // yet and renders them blank — it doesn't reliably retry the match once
  // options arrive later, which is exactly the "some fields blank until
  // you click elsewhere" symptom. shareReplay(1) caches the one fetch so
  // loadCustomer() (via switchMap below) reuses it near-instantly once
  // already resolved, while still *guaranteeing* — not just usually
  // arranging — that lookups are populated before any value that depends
  // on them is ever set.
  private readonly lookups$ = this.data.getCustRegistrationLookups().pipe(shareReplay(1));

  ngOnInit(): void {
    this.lookups$.subscribe((lookups) => this.lookups.set(lookups));
    this.data.getReferredByCustomers().subscribe((c) => this.referredByOptions.set(c));
    this.data.getPotentialCustomers().subscribe((c) => this.potentialCustomerOptions.set(c));

    // Customer-Create (/cust-registration-new) and Customer-Modify
    // (/cust-registration-modify) are two distinct routes — see
    // marketing.routes.ts — so a fresh component instance (and a fresh
    // ngOnInit) is guaranteed every time either is navigated to, making a
    // plain snapshot read of route `data` safe here (unlike a query param
    // that can change while the SAME route instance stays mounted).
    this.mode = (this.route.snapshot.data['mode'] as Mode) ?? 'new';

    // CustID can still change while staying on the modify route (e.g.
    // deep-linking to a different customer from CRM Activity without
    // leaving this route in between), so that part still needs to be
    // reactive rather than a one-time snapshot read.
    this.route.queryParamMap.subscribe((q) => {
      this.custId = q.get('CustID') ? Number(q.get('CustID')) : null;
      this.activeStep.set(0);

      if (this.mode === 'modify') {
        // Same load-on-demand pattern as Referred By Customer/Potential Customer:
        // top 100 alphabetically on load, re-queried by name as the user types
        // (onCustomerNameFilter below) instead of one full CustomerMaster fetch.
        this.data.searchCustomerName().subscribe((c) => this.customers.set(c));
        if (this.custId) {
          this.selectedCustomerId = this.custId;
          this.loadCustomer();
        } else {
          this.selectedCustomerId = null;
          this.form = this.blankForm();
        }
      } else {
        this.selectedCustomerId = null;
        this.custId = null;
        this.form = this.blankForm();
      }
      this.cdr.markForCheck();
    });
  }

  private blankForm(): CustRegistrationDetail {
    return {
      custId: 0,
      groupId: 0,
      name: '',
      lastName: '',
      mobileNo: '',
      telephoneNo: '',
      email: '',
      address1: '',
      address2: '',
      area: '',
      pinCode: '',
      contactPerson: '',
      gstin: '',
      arn: '',
      caseType: '',
      hardwarePartner: '',
      narration: '',
      continentId: 1,
      countryId: 91,
      stateId: 15,
      districtId: 0,
      cityId: 0,
      zoneId: 0,
      enquiryDate: new Date().toISOString(),
      receivedBy: 0,
      enquirySource: 0,
      enquirySource2: 0,
      enquirySource2Date: null,
      sourceDetail: '',
      businessNature: 0,
      segment: 0,
      provider: 0,
      referralCardNo: '',
      hardware: '',
      campaignId: 0,
      referredByName: '',
      referredByCustomerId: 0,
      assignedToName: ''
    };
  }

  onCustomerSelected(): void {
    if (!this.selectedCustomerId) {
      return;
    }
    this.custId = this.selectedCustomerId;
    this.loadCustomer();
  }

  private loadCustomer(): void {
    if (!this.custId) {
      return;
    }
    // Wait for lookups$ (cached after the first load, so this costs nothing
    // once it's already resolved) before applying the saved customer —
    // guarantees every <p-select> already has real [options] to match the
    // incoming value against, instead of racing it.
    this.lookups$
      .pipe(switchMap(() => this.data.getCustRegistrationDetail(this.custId!)))
      .subscribe((detail) => {
        this.form = detail;
        this.enquiryDate = new Date(detail.enquiryDate);
        this.enquirySource2Date = detail.enquirySource2Date ? fromLocalDateString(detail.enquirySource2Date) : null;
        this.assignedToName.set(detail.assignedToName);
        this.onStateChange();
        // The saved referral's REAL customer ID (see marketing_registration.py's
        // 2026-08-04 update note) — the picker's own [options] list is
        // load-on-demand/capped, so the referred customer won't generally
        // be in it yet. A synthetic option (real id, real label) makes the
        // dropdown show the correct selection regardless; save() sends this
        // same id straight through rather than re-deriving anything from
        // whatever the options list happens to hold by then. Removes
        // whichever synthetic entry a PREVIOUS loadCustomer() call injected
        // (tracked in lastSyntheticReferredById) before adding this one, so
        // repeated loads in the same session don't pile up stale entries.
        if (detail.referredByName && detail.referredByCustomerId) {
          const synthetic = { label: detail.referredByName, value: detail.referredByCustomerId };
          const strip = (opts: LookupOption[]) => opts.filter((o) => o.value !== this.lastSyntheticReferredById);
          if (this.potentialCustomer) {
            this.potentialCustomerOptions.update((opts) => [synthetic, ...strip(opts)]);
          } else {
            this.referredByOptions.update((opts) => [synthetic, ...strip(opts)]);
          }
          this.lastSyntheticReferredById = detail.referredByCustomerId;
          this.referredByCustomerId = detail.referredByCustomerId;
          this.referredByCustomerLabel = detail.referredByName;
        } else {
          this.referredByCustomerId = null;
          this.referredByCustomerLabel = null;
        }
        // The Customer Name picker is also capped to a top-100/search-narrowed list —
        // deep-linking here (e.g. from CRM Activity, or a customer outside that window)
        // can land on a custId that isn't in the currently loaded options at all, which
        // would otherwise render the dropdown blank despite a real selection existing.
        const customerLabel = `${detail.name} ${detail.lastName}`.trim();
        this.customers.update((opts) =>
          opts.some((o) => o.value === this.custId) ? opts : [{ label: customerLabel || `Customer ${this.custId}`, value: this.custId! }, ...opts]
        );
        this.cdr.markForCheck();
      });
  }

  onStateChange(): void {
    this.data.getCitiesAndDistricts(this.form.stateId).subscribe((r) => {
      const lookups = this.lookups();
      if (lookups) {
        this.lookups.set({ ...lookups, cities: r.cities, districts: r.districts });
      }
    });
  }

  // Bound to <p-select>'s (onFilter) — re-queries the server with whatever the
  // user has typed so far instead of just filtering the already-loaded top 100
  // client-side, which would silently miss any customer outside that window.
  onReferredByFilter(query: string): void {
    this.data.getReferredByCustomers(query).subscribe((c) => this.referredByOptions.set(c));
  }

  // Bound to <p-select>'s (onChange) — captures the selected option's label
  // right now, while it's still guaranteed to be in whichever options list
  // (referredByOptions()/potentialCustomerOptions()) the selection just came
  // from, rather than re-deriving it later at save time from a list that may
  // have since been replaced by a filter search. See referredByCustomerLabel.
  onReferredByChange(): void {
    if (this.referredByCustomerId == null) {
      this.referredByCustomerLabel = null;
      return;
    }
    const options = this.potentialCustomer ? this.potentialCustomerOptions() : this.referredByOptions();
    this.referredByCustomerLabel = options.find((o) => o.value === this.referredByCustomerId)?.label ?? null;
  }

  onPotentialCustomerFilter(query: string): void {
    this.data.getPotentialCustomers(query).subscribe((c) => this.potentialCustomerOptions.set(c));
  }

  onCustomerNameFilter(query: string): void {
    this.data.searchCustomerName(query).subscribe((c) => this.customers.set(c));
  }

  checkMobile(): void {
    if (this.form.mobileNo.trim().length < 10) {
      this.mobileMessage.set('invalid mobile');
      return;
    }
    this.data.checkMobileAvailability(this.form.mobileNo).subscribe((r) => {
      if (r.available) {
        this.mobileMessage.set('Available');
      } else {
        this.mobileMessage.set('Already registered');
        this.router.navigate(['/admin/customer-info'], { queryParams: { CustID: r.custId } });
      }
    });
  }

  verifyGstin(): void {
    if (!this.form.gstin.trim()) {
      return;
    }
    this.gstVerifying.set(true);
    this.data.verifyGstin(this.form.gstin).subscribe((r) => {
      this.gstVerifying.set(false);
      if (r.verified) {
        this.gstMessage.set(r.gstApiError ? `Verified (${r.gstApiError})` : 'Verification done');
        this.form.name = r.name ?? this.form.name;
        this.form.address1 = r.address1 ?? this.form.address1;
        this.form.pinCode = r.pinCode ?? this.form.pinCode;
        this.form.area = r.area ?? this.form.area;
        // State/District come back as real internal StateID/DistrictID
        // (resolved backend-side from the GST service's name strings), not
        // free text — same p-select-bound fields the user could otherwise
        // pick by hand. onStateChange() reloads the City/District options
        // for the new state, same as when the user changes State manually.
        if (r.stateId) {
          this.form.stateId = r.stateId;
          this.onStateChange();
        }
        if (r.districtId) {
          this.form.districtId = r.districtId;
        }
      } else {
        this.gstMessage.set('Invalid GSTN No');
      }
      this.cdr.markForCheck();
    });
  }

  verifyPincode(): void {
    if (!this.form.pinCode.trim()) {
      return;
    }
    this.data.lookupPincode(this.form.pinCode).subscribe((r) => {
      if (r) {
        this.form.stateId = r.stateId;
        this.form.districtId = r.districtId;
        this.onStateChange();
        // State/District/City live on the Enquiry Details tab, so without a
        // message here on the Customer Details tab (where Pin Code and Verify
        // are), clicking Verify has no visible effect at all.
        this.pincodeMessage.set('Verified — State & District updated (see Enquiry Details tab)');
      } else {
        this.pincodeMessage.set('Invalid PIN Code');
      }
      this.cdr.markForCheck();
    });
  }

  toggleCreateCity(): void {
    if (this.creatingCity()) {
      if (!this.newCityName().trim()) {
        return;
      }
      this.data.createCity(this.form.stateId, this.newCityName()).subscribe((r) => {
        alert(r.message);
        this.creatingCity.set(false);
        this.form.cityId = r.cityId;
        this.onStateChange();
        this.cdr.markForCheck();
      });
    } else {
      this.creatingCity.set(true);
      this.newCityName.set('');
    }
  }

  goNext(): void {
    goToStep(this.activeStep, this.steps, this.activeStep() + 1);
  }

  goPrev(): void {
    goToStep(this.activeStep, this.steps, this.activeStep() - 1);
  }

  private validateBasicInfoStep(): boolean {
    if (this.mode === 'modify' && !this.selectedCustomerId) {
      alert('Please Select Customer Name.');
      return false;
    }
    if (!this.form.groupId) {
      alert('Please Select Group Name.');
      return false;
    }
    if (!this.form.name.trim()) {
      alert('Please Fill Customer Name.');
      return false;
    }
    // Moved here (same rule, same message) since Mobile No's input field now
    // lives on this tab — was checked in validateContactStep, which no
    // longer has anything to validate now that Case Type replaced it there.
    if (this.form.mobileNo.trim().length < 10) {
      alert('Please Fill Mobile No.');
      return false;
    }
    // Pin Code moved here from the Address tab along with its input field —
    // required per the (*) marker, same pattern as Group/Customer Name/Mobile No above.
    if (!this.form.pinCode.trim()) {
      alert('Please Fill Pin Code.');
      return false;
    }
    return true;
  }

  private validateGeographicStep(): boolean {
    if (!this.form.cityId) {
      alert('Please Select valid City Name.');
      return false;
    }
    return true;
  }

  save(): void {
    if (!this.validateBasicInfoStep()) {
      this.activeStep.set(0);
      return;
    }
    if (!this.validateGeographicStep()) {
      this.activeStep.set(3);
      return;
    }

    this.saving.set(true);
    this.form.enquiryDate = (this.enquiryDate ?? new Date()).toISOString();
    this.form.enquirySource2Date = this.enquirySource2Date ? toLocalDateString(this.enquirySource2Date) : null;
    this.form.campaignId = this.selectedCampaignIds[0] ?? 0;
    // The real fix: send the actual customer ID, which the backend's stored
    // procs gate their whole referral-card validation on (previously never
    // sent at all — see marketing_registration.py's 2026-08-04 update note).
    // 0 means "no referral selected", the same default the backend uses.
    this.form.referredByCustomerId = this.referredByCustomerId ?? 0;
    // Uses the label captured at selection time (onReferredByChange()/
    // loadCustomer()) instead of re-deriving it here from
    // referredByOptions()/potentialCustomerOptions() — that list is a
    // load-on-demand search result that can no longer contain the selected
    // customer by the time Save is clicked, which could silently send an
    // empty referred_by_name. Mostly cosmetic now (the backend re-derives
    // the authoritative name itself whenever referredByCustomerId > 0), but
    // kept correct for consistency. See referredByCustomerLabel's comment.
    this.form.referredByName = this.referredByCustomerId != null ? this.referredByCustomerLabel ?? '' : '';

    const save$ =
      this.mode === 'new' ? this.data.addCustomerRegistration(this.form) : this.data.modifyCustomerRegistration(this.form);

    save$.subscribe((res) => {
      this.saving.set(false);
      alert(res.message);
      if (res.success) {
        if (this.mode === 'new') {
          const custId = (res as { custId?: number }).custId ?? 0;
          this.assignedToName.set('UnAssigned');
          // Per explicit request: matches Modify mode exactly now — after a
          // successful save, the form/custId are NOT reset (previously this
          // blanked the form, cleared custId, and jumped back to step 0
          // immediately, so there was no way to reach Enquiry &
          // Classification for the customer just created; even after fixing
          // custId's discard bug, the user would only ever see a blank form
          // there). The user stays on the just-created customer with every
          // tab still populated, exactly like arriving here via Modify, so
          // Assign To/Unassigned works immediately. startNewCustomer() below
          // now owns the explicit reset for starting the next entry.
          this.custId = custId || null;
        }
        // Per explicit request: refresh after a successful save — re-fetches
        // the just-saved customer from the server instead of continuing to
        // show whatever was in `form` right before Save was clicked. Some
        // fields aren't a plain echo of what was sent (e.g. referred_by_name
        // is re-derived server-side from CustomerMaster.displayName once a
        // real referredByCustomerId is set — see webProc_ModifyCustomer),
        // so this is what actually guarantees the screen shows the true
        // saved state, not just an optimistic assumption that the request
        // body became the database row verbatim.
        this.loadCustomer();
        if (this.custId) {
          this.focusAndOpenAssign();
        }
      }
      this.cdr.markForCheck();
    });
  }

  private focusAndOpenAssign(): void {
    this.activeStep.set(3);
    this.assignHighlight.set(true);
    this.cdr.markForCheck();
    // Let the step panel / @if (custId) render the link first.
    setTimeout(() => {
      const link = this.assignLink()?.nativeElement;
      link?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      link?.focus();
      this.assignDialogVisible.set(true);
      this.cdr.markForCheck();
    });
    setTimeout(() => {
      this.assignHighlight.set(false);
      this.cdr.markForCheck();
    }, 3000);
  }

  onAssignSaved(): void {
    this.assignDialogVisible.set(false);
    // Refresh so the link shows the newly assigned user.
    this.loadCustomer();
  }

  // Replaces the auto-reset that used to run immediately after every
  // successful new-customer save (see save()'s comment) — now an explicit
  // action so the user can stay on the just-created customer (Enquiry &
  // Classification's Assign To included) for as long as they need before
  // starting the next entry. Mirrors ngOnInit's own 'new'-mode reset.
  startNewCustomer(): void {
    this.selectedCustomerId = null;
    this.custId = null;
    this.form = this.blankForm();
    this.assignedToName.set('');
    this.potentialCustomer = false;
    this.selectedCampaignIds = [];
    this.referredByCustomerId = null;
    this.referredByCustomerLabel = null;
    this.enquiryDate = new Date();
    this.enquirySource2Date = null;
    this.activeStep.set(0);
    this.cdr.markForCheck();
  }

  openAssignedAction(): void {
    if (!this.custId) {
      return;
    }
    this.assignDialogVisible.set(true);
  }
}
