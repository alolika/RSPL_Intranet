import { DatePipe, DecimalPipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import {
  EnquiryStatusDetailRow,
  EnquiryStatusRow,
  MarketingDataService
} from '../marketing-data.service';

/**
 * Mirrors Section_Marketing/CustEnquiryStatus.aspx ("Customer Enquiry
 * Progress Chart" / menu label "Lead Pending Status"): per-assigned-user
 * summary (pending enquiry count, average progress %) expandable to a
 * per-customer detail grid with its own progress bar, CustID linking to
 * CustEnquiryRegister. Employee photo assets are unavailable — placeholder
 * avatar shown, same as CRMActivity.
 */
@Component({
  selector: 'app-cust-enquiry-status',
  imports: [RouterLink, TableModule, ButtonModule, DatePipe, DecimalPipe],
  templateUrl: './cust-enquiry-status.html',
  styleUrl: './cust-enquiry-status.scss'
})
export class CustEnquiryStatus implements OnInit {
  private readonly data = inject(MarketingDataService);

  readonly rows = signal<EnquiryStatusRow[]>([]);
  readonly expandedUserId = signal<number | null>(null);
  readonly detailRows = signal<EnquiryStatusDetailRow[]>([]);
  readonly detailLoading = signal(false);
  readonly exportingUserId = signal<number | null>(null);

  ngOnInit(): void {
    this.data.getEnquiryStatusRows().subscribe((rows) => this.rows.set(rows));
  }

  toggleExpand(row: EnquiryStatusRow): void {
    if (this.expandedUserId() === row.assignedToUserId) {
      this.expandedUserId.set(null);
      return;
    }
    const userId = row.assignedToUserId;
    this.expandedUserId.set(userId);
    // Clear the previous executive's cases so they never flash under the
    // newly expanded row, and ignore a slow response for an executive the
    // user has already collapsed/switched away from.
    this.detailRows.set([]);
    this.detailLoading.set(true);
    this.data.getEnquiryStatusDetail(userId).subscribe({
      next: (rows) => {
        if (this.expandedUserId() !== userId) {
          return;
        }
        this.detailRows.set(rows);
        this.detailLoading.set(false);
      },
      error: () => {
        if (this.expandedUserId() === userId) {
          this.detailLoading.set(false);
        }
      }
    });
  }

  // Always fetches this row's own detail via its assignedToUserId — never
  // reads the shared `detailRows` signal above, which only ever holds
  // whichever single row is currently expanded and would export the wrong
  // (or empty) data for every row except the one last expanded.
  exportRow(row: EnquiryStatusRow): void {
    this.exportingUserId.set(row.assignedToUserId);
    this.data.getEnquiryStatusDetail(row.assignedToUserId).subscribe({
      next: (detail) => {
        exportToExcel(`EnquiryStatus_${row.assignedTo}`, detail);
        this.exportingUserId.set(null);
      },
      error: () => this.exportingUserId.set(null)
    });
  }
}
