import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { ActionSearchRow, LookupOption, MarketingDataService } from '../marketing-data.service';

/** Mirrors Section_Marketing/ActionSearchReport.aspx: multi-filter enquiry-action search grid. */
@Component({
  selector: 'app-action-search-report',
  imports: [FormsModule, ButtonModule, CheckboxModule, DatePickerModule, InputTextModule, SelectModule, TableModule, DatePipe],
  templateUrl: './action-search-report.html',
  styleUrl: './action-search-report.scss'
})
export class ActionSearchReport implements OnInit {
  private readonly data = inject(MarketingDataService);

  readonly salesmen = signal<LookupOption[]>([]);
  readonly segments = signal<LookupOption[]>([]);
  readonly cities = signal<LookupOption[]>([]);
  readonly rows = signal<ActionSearchRow[]>([]);
  readonly loading = signal(false);

  salesmanId = 0;
  segmentId = 0;
  actionDesc = '';
  fromDate: Date | null = null;
  toDate: Date | null = null;
  cityId = 0;
  customerOnly = false;

  ngOnInit(): void {
    this.data.getActionSearchFilters().subscribe((f) => {
      this.salesmen.set(f.salesmen);
      this.segments.set(f.segments);
      this.cities.set(f.cities);
    });
  }

  onSalesmanFilter(query: string): void {
    this.data.getActionSearchSalesmen(query).subscribe((s) => this.salesmen.set(s));
  }

  onSegmentFilter(query: string): void {
    this.data.getActionSearchSegments(query).subscribe((s) => this.segments.set(s));
  }

  onCityFilter(query: string): void {
    this.data.getActionSearchCities(query).subscribe((c) => this.cities.set(c));
  }

  show(): void {
    this.loading.set(true);
    this.data
      .getActionSearchRows({
        salesmanId: this.salesmanId,
        segmentId: this.segmentId,
        actionDesc: this.actionDesc,
        fromDate: this.fromDate,
        toDate: this.toDate,
        cityId: this.cityId,
        customerOnly: this.customerOnly
      })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      });
  }

  export(): void {
    exportToExcel('ActionReport', this.rows());
  }
}
