import { DatePipe, Location } from '@angular/common';
import { ChangeDetectorRef, Component, DestroyRef, OnInit, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, NavigationEnd, Router, RouterLink } from '@angular/router';
import { filter } from 'rxjs';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { DialogModule } from 'primeng/dialog';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { RadioButtonModule } from 'primeng/radiobutton';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { ClockTimeInput } from '../../../../shared/clock-time-input/clock-time-input';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import { CustEnquiryRegisterRow, CustomerRegisterInfo, EnquiryActionEdit, EnquiryRegisterActionRow, LookupOption, MarketingDataService } from '../marketing-data.service';

type SearchMode = 'shop_id' | 'cust_id' | 'contact_person' | 'mobile' | 'gst';

/**
 * Mirrors Section_Marketing/CustEnquiryRegister.aspx ("Customer Enquiry -
 * Action" / "Customer Existing - Action" depending on ?Auto=): a
 * search-driven single-customer view — pick one of 5 search modes, Show
 * resolves that customer, filling both the Customer Information panel and
 * the enquiry grid below (with an expandable per-row action-history
 * sub-grid, same Add/Close next-step pattern as AmcPending). Restored to
 * this search-driven shape per the reference screenshot; an earlier version
 * of this component showed an unfiltered all-customers register instead —
 * see marketing_register.py's docstring for that history.
 */
@Component({
  selector: 'app-cust-enquiry-register',
  imports: [
    FormsModule, RouterLink, ButtonModule, DatePickerModule, DialogModule, InputNumberModule, InputTextModule, RadioButtonModule,
    SelectModule, TableModule, TextareaModule, DatePipe, IndianNumberPipe, ClockTimeInput
  ],
  templateUrl: './cust-enquiry-register.html',
  styleUrl: './cust-enquiry-register.scss'
})
export class CustEnquiryRegister implements OnInit {
  private readonly data = inject(MarketingDataService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly location = inject(Location);
  // This app runs without zone.js — plain (non-signal) properties like
  // `isExistingCustomerMode`/`whatsAppMobile` below don't trigger a re-render on
  // their own when mutated inside an RxJS subscribe callback. markForCheck()
  // after each such mutation is what actually gets the new values on screen.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly shopOptions = signal<LookupOption[]>([]);
  readonly contactPersonOptions = signal<{ label: string; value: string }[]>([]);
  readonly customerInfo = signal<CustomerRegisterInfo | null>(null);
  readonly rows = signal<CustEnquiryRegisterRow[]>([]);
  readonly loading = signal(false);
  readonly searched = signal(false);
  readonly notFound = signal(false);
  readonly errorMessage = signal<string | null>(null);
  // Mirrors the source's MasterTableView HierarchyDefaultExpanded="true" —
  // every row's action-history detail grid is loaded and shown right away,
  // not one at a time on click. Keyed by custId (webproc_showenquiryaction
  // takes only CustID, so every row for the same customer shares one
  // fetch/result rather than re-querying per row).
  readonly expandedCustIds = signal<Set<number>>(new Set());
  readonly actionHistoryByCustId = signal<Record<number, EnquiryRegisterActionRow[]>>({});
  readonly whatsAppOpen = signal(false);

  // Edit-action popup (Edit button beside each row of the action sub-grid).
  readonly editVisible = signal(false);
  readonly editLoading = signal(false);
  readonly editSaving = signal(false);
  readonly editError = signal<string | null>(null);
  readonly editTitle = signal('');
  readonly actionStages = signal<LookupOption[]>([]);
  readonly users = signal<LookupOption[]>([]);
  readonly salesmen = signal<LookupOption[]>([]);
  editForm: EnquiryActionEdit | null = null;
  private editKey: { custId: number; actionId: number } | null = null;

  isExistingCustomerMode = false;

  searchMode: SearchMode = 'shop_id';
  shopId: number | null = null;
  contactPerson: string | null = null;
  mobileNo = '';
  custIdText = '';
  gstNo = '';

  // Bumped on every Show click; the search response checks it before
  // applying results, so an earlier, slower search (e.g. Show clicked for
  // one customer, then again for another before the first response
  // arrives) can never overwrite the screen with stale data after a newer
  // search has already started.
  private requestId = 0;
  private readonly destroyRef = inject(DestroyRef);
  // The search that's currently on screen (not whatever is typed in the
  // search fields now) — used to silently refresh it on return.
  private lastSearch: { mode: SearchMode; value: string } | null = null;
  private leftPage = false;

  whatsAppMobile = '';
  whatsAppMessageIndex = 0;
  readonly whatsAppMessages = [
    { label: 'Thank you for showing interest', value: 0 },
    { label: 'Call not successful, please share a convenient time', value: 1 },
    { label: 'Thank you for your time, save our sales number', value: 2 },
    { label: 'Quotation follow-up', value: 3 }
  ];

  ngOnInit(): void {
    // This page is kept alive (not destroyed) while the user goes to
    // Customer Enquiry Action via Add/Close and comes back — see
    // PreserveCustEnquiryRegisterRouteReuseStrategy. That kept the search
    // and pagination, but also kept the OLD grid, so a just-saved action
    // didn't show until Show was clicked again. On every return, re-fetch
    // the customer already on screen (keeping the page's state as is).
    this.router.events
      .pipe(
        filter((e): e is NavigationEnd => e instanceof NavigationEnd),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe((e) => {
        const onThisPage = e.urlAfterRedirects.split('?')[0].endsWith('/cust-enquiry-register');
        if (!onThisPage) {
          this.leftPage = true;
        } else if (this.leftPage) {
          this.leftPage = false;
          this.refreshCurrent();
        }
      });

    // Same load-on-demand pattern as Referred By Customer/Customer Name/Advance's
    // customer picker: top 100 initially, re-queried by name as the user types
    // (onShopFilter below). Reuses the already-fixed getCustomersForSearch()
    // (Customer Enquiry's own picker) instead of the separate /register/customers
    // endpoint, which had the same TOP-1000/no-search issue and is now unused.
    this.data.getCustomersForSearch().subscribe((c) => this.shopOptions.set(c));
    this.data.getContactPersonLookup().subscribe((c) => this.contactPersonOptions.set(c));

    // Enquiry-Action and Customer-Action both route to this same component
    // (only ?Auto differs), so Angular reuses the instance instead of
    // re-running ngOnInit when switching between them — subscribe instead of
    // reading a one-time snapshot so the title updates and any previous
    // search's leftover results are cleared instead of carrying over.
    this.route.queryParamMap.subscribe((q) => {
      this.isExistingCustomerMode = q.get('Auto') === '1';
      this.customerInfo.set(null);
      this.rows.set([]);
      this.searched.set(false);
      this.notFound.set(false);
      this.expandedCustIds.set(new Set());
      this.actionHistoryByCustId.set({});
      this.cdr.markForCheck();

      // Deep links (CRM Activity's "Click Here for Detail", Lead Record's
      // drill-down, etc.) navigate here with an already-resolved ?CustID —
      // mirrors CustEnquiryRegister.aspx.vb's own Page_Load, which calls
      // FillGV(CustID) immediately whenever one is present rather than
      // waiting for a manual search. Previously the query param was read
      // only to reset UI state, so the form opened blank until the user
      // re-entered the same CustID and clicked Show themselves.
      const custId = q.get('CustID');
      if (custId && Number(custId) > 0) {
        this.searchMode = 'cust_id';
        this.custIdText = custId;
        this.show();
      }
    });
  }

  // Mirrors the source's rbtnXxx_CheckedChanged handlers, which each clear every
  // OTHER search field's .Text when a different radio button is selected — the
  // Angular port only disabled the other inputs without clearing their values.
  onSearchModeChange(mode: SearchMode): void {
    if (mode !== 'shop_id') {
      this.shopId = null;
    }
    if (mode !== 'contact_person') {
      this.contactPerson = null;
    }
    if (mode !== 'mobile') {
      this.mobileNo = '';
    }
    if (mode !== 'cust_id') {
      this.custIdText = '';
    }
    if (mode !== 'gst') {
      this.gstNo = '';
    }
  }

  // Bound to the Shop Name <p-select>'s (onFilter) — re-queries the server with
  // whatever's typed instead of only filtering the already-loaded top 100 client-side.
  onShopFilter(query: string): void {
    this.data.getCustomersForSearch(query).subscribe((c) => this.shopOptions.set(c));
  }

  // Bound to the Contact Person <p-select>'s (onFilter) — same load-on-demand
  // re-query as onShopFilter above. getContactPersonLookup() used to load every
  // distinct Landmark value unbounded; now capped to top 100 + search like
  // every other customer/name picker in this app.
  onContactPersonFilter(query: string): void {
    this.data.getContactPersonLookup(query).subscribe((c) => this.contactPersonOptions.set(c));
  }

  get searchValue(): string {
    switch (this.searchMode) {
      case 'shop_id':
        return this.shopId ? String(this.shopId) : '';
      case 'cust_id':
        return this.custIdText.trim();
      case 'contact_person':
        return this.contactPerson ?? '';
      case 'mobile':
        return this.mobileNo.trim();
      case 'gst':
        return this.gstNo.trim();
    }
  }

  show(): void {
    const value = this.searchValue;
    if (!value) {
      return;
    }
    const requestId = ++this.requestId;
    this.loading.set(true);
    this.searched.set(true);
    this.notFound.set(false);
    this.errorMessage.set(null);
    this.expandedCustIds.set(new Set());
    this.actionHistoryByCustId.set({});
    this.whatsAppOpen.set(false);
    // Clear the previous customer's details immediately rather than leaving
    // them on screen until the new response arrives — otherwise, briefly
    // (and indefinitely if the request fails), the old customer's Name/
    // Address/Mobile/etc. and grid rows stay visible under the "loading"
    // state, which reads as showing the wrong customer's data.
    this.customerInfo.set(null);
    this.rows.set([]);
    this.lastSearch = { mode: this.searchMode, value };
    this.data.searchEnquiryRegister(this.searchMode, value).subscribe({
      next: (result) => {
        if (requestId !== this.requestId) {
          return;
        }
        this.loading.set(false);
        this.customerInfo.set(result.customerInfo);
        this.rows.set(result.rows);
        this.notFound.set(!result.customerInfo);
        this.whatsAppMobile = result.customerInfo?.mobileNo ?? '';
        this.loadAllActionHistory(requestId, result.rows);
        this.cdr.markForCheck();
      },
      error: () => {
        if (requestId !== this.requestId) {
          return;
        }
        this.loading.set(false);
        this.errorMessage.set('Could not load customer details — please try again.');
      }
    });
  }

  // Fetches each distinct customer's action history once (rows sharing a
  // custId share the same history, per webproc_showenquiryaction's
  // signature) and expands every row immediately, instead of waiting for a
  // per-row click.
  private loadAllActionHistory(requestId: number, rows: CustEnquiryRegisterRow[]): void {
    const distinctCustIds = [...new Set(rows.map((r) => r.custId))];
    this.expandedCustIds.set(new Set(distinctCustIds));
    for (const custId of distinctCustIds) {
      this.data.getEnquiryRegisterActions(custId).subscribe((actions) => {
        if (requestId !== this.requestId) {
          return;
        }
        this.actionHistoryByCustId.update((byCustId) => ({ ...byCustId, [custId]: actions }));
      });
    }
  }

  // Silent re-fetch of the search already on screen: unlike show(), it
  // doesn't blank the grid or reset which rows are expanded/collapsed.
  private refreshCurrent(): void {
    const last = this.lastSearch;
    if (!last || !this.customerInfo()) {
      return;
    }
    const requestId = ++this.requestId;
    this.data.searchEnquiryRegister(last.mode, last.value).subscribe((result) => {
      if (requestId !== this.requestId) {
        return;
      }
      this.rows.set(result.rows);
      for (const custId of new Set(result.rows.map((r) => r.custId))) {
        this.data.getEnquiryRegisterActions(custId).subscribe((actions) => {
          if (requestId !== this.requestId) {
            return;
          }
          this.actionHistoryByCustId.update((byCustId) => ({ ...byCustId, [custId]: actions }));
        });
      }
      this.cdr.markForCheck();
    });
  }

  toggleExpand(row: CustEnquiryRegisterRow): void {
    this.expandedCustIds.update((ids) => {
      const next = new Set(ids);
      if (next.has(row.custId)) {
        next.delete(row.custId);
      } else {
        next.add(row.custId);
      }
      return next;
    });
  }

  nextStep(row: CustEnquiryRegisterRow, action: EnquiryRegisterActionRow): void {
    if (action.nextAction === 'Closed') {
      return;
    }
    this.router.navigate(['/marketing/cust-enquiry-action'], {
      queryParams: {
        CustID: row.custId,
        RefActionID: action.actionId,
        ActionType: action.nextAction === 'Add' ? 1 : 2
      }
    });
  }

  // An action is editable (open or closed) only on the same day it was
  // created — yesterday's actions can't be edited today, and today's can't
  // be edited tomorrow. The backend enforces the same rule.
  isEditableToday(action: EnquiryRegisterActionRow): boolean {
    if (!action.creationDate) {
      return false;
    }
    const d = new Date();
    const today = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    return action.creationDate.slice(0, 10) === today;
  }

  editAction(row: CustEnquiryRegisterRow, action: EnquiryRegisterActionRow): void {
    this.editKey = { custId: row.custId, actionId: action.actionId };
    this.editTitle.set(`Edit Action — ${action.actionStage} (Action ID ${action.actionId})`);
    this.editForm = null;
    this.editError.set(null);
    this.editLoading.set(true);
    this.editVisible.set(true);
    // Lookups are fetched once, on the first Edit click, not on page load.
    if (this.actionStages().length === 0) {
      this.data.getActionStages().subscribe((s) => this.actionStages.set(s));
    }
    if (this.users().length === 0) {
      this.data.getUsers().subscribe((u) => this.users.set(u));
    }
    if (this.salesmen().length === 0) {
      this.data.getSalesmen().subscribe((s) => this.salesmen.set(s));
    }
    const key = this.editKey;
    this.data.getEnquiryActionForEdit(key.custId, key.actionId).subscribe({
      next: (a) => {
        if (this.editKey !== key) {
          return;
        }
        this.editForm = a;
        this.editLoading.set(false);
        this.cdr.markForCheck();
      },
      error: () => {
        if (this.editKey !== key) {
          return;
        }
        this.editLoading.set(false);
        this.editError.set("Could not load this action's details.");
      }
    });
  }

  saveEdit(): void {
    const f = this.editForm;
    const key = this.editKey;
    if (!f || !key) {
      return;
    }
    if (!f.actionStageId || !f.assignedTo || !f.actionDate || !f.description.trim()) {
      this.editError.set('Please fill Action Stage, Assigned To, Action Date and Action Description.');
      return;
    }
    this.editError.set(null);
    this.editSaving.set(true);
    this.data.updateEnquiryAction(key.custId, key.actionId, f).subscribe({
      next: () => {
        this.editSaving.set(false);
        this.editVisible.set(false);
        // Refresh just this customer's action sub-grid so the saved values show.
        this.data.getEnquiryRegisterActions(key.custId).subscribe((actions) =>
          this.actionHistoryByCustId.update((byCustId) => ({ ...byCustId, [key.custId]: actions }))
        );
      },
      error: () => {
        this.editSaving.set(false);
        this.editError.set('Could not save this action — please check the fields and try again.');
      }
    });
  }

  openWhatsApp(): void {
    if (!this.customerInfo()) {
      return;
    }
    this.whatsAppOpen.set(true);
  }

  sendWhatsApp(): void {
    const custId = this.customerInfo()?.custId;
    if (!custId) {
      return;
    }
    this.data.sendWhatsAppMessage(custId, this.whatsAppMessageIndex, this.whatsAppMobile).subscribe(() => {
      alert('Message sent.');
      this.whatsAppOpen.set(false);
    });
  }

  back(): void {
    this.location.back();
  }
}
