import { DatePipe } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import { LookupOption, MarketingDataService, TourReportRow } from '../marketing-data.service';

/**
 * Mirrors Section_Marketing/TourReport.aspx ("Tour Report"): a heavily
 * filtered (date range/visit type/mode of travel/user/city/voucher no/
 * customer) tour-expense grid with an Amount footer total. The source's
 * dynamic "Choose Column" feature (select/reorder visible columns,
 * persisted server-side to a ReportOptions table) is not replicated — this
 * report always shows all 9 columns, consistent with the report-engine
 * simplification applied throughout this app.
 */
@Component({
  selector: 'app-tour-report',
  imports: [FormsModule, ButtonModule, DatePickerModule, InputTextModule, SelectModule, TableModule, DatePipe, IndianNumberPipe],
  templateUrl: './tour-report.html',
  styleUrl: './tour-report.scss'
})
export class TourReport implements OnInit {
  private readonly data = inject(MarketingDataService);

  readonly users = signal<LookupOption[]>([]);
  readonly cities = signal<LookupOption[]>([]);
  readonly customers = signal<LookupOption[]>([]);
  readonly visitTypes = signal<string[]>([]);
  readonly modesOfTravel = signal<string[]>([]);
  readonly rows = signal<TourReportRow[]>([]);
  readonly loading = signal(false);

  readonly totalAmount = computed(() => this.rows().reduce((s, r) => s + r.amount, 0));

  fromDate: Date | null = null;
  toDate: Date | null = null;
  userName = 'All';
  city = 'All';
  customer = 'All';
  visitType = 'All';
  modeOfTravel = 'All';
  voucherNo = '';

  ngOnInit(): void {
    this.data.getTourReportFilters().subscribe((f) => {
      this.users.set(f.users);
      this.cities.set(f.cities);
      this.customers.set(f.customers);
      this.visitTypes.set(f.visitTypes);
      this.modesOfTravel.set(f.modesOfTravel);
    });
  }

  onCustomerFilter(query: string): void {
    this.data.getTourReportCustomers(query).subscribe((c) => this.customers.set(c));
  }

  show(): void {
    this.loading.set(true);
    this.data
      .getTourReportRows({
        userName: this.userName,
        city: this.city,
        customer: this.customer,
        visitType: this.visitType,
        modeOfTravel: this.modeOfTravel,
        voucherNo: this.voucherNo,
        fromDate: this.fromDate,
        toDate: this.toDate
      })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      });
  }

  export(): void {
    exportToExcel('TourReport', this.rows());
  }
}
