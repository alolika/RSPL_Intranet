import { DatePipe } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { LookupOption, MarketingDataService, TeleCallingActionRow, TeleCallingRow } from '../marketing-data.service';

/**
 * Mirrors Section_Marketing/CustTeleCallingRegister.aspx ("Customer Enquiry
 * TeleCalling" / menu "Enquiry-Telecalling"): a Customer-Group + Telecalling-
 * Stage filtered enquiry grid, expandable to a per-customer telecalling
 * action-history sub-grid, with an Add/Close "Next Step" link opening the
 * canonical CustEnquiryAction popup (same pattern as OutstandingFollowup/
 * AmcPending elsewhere in this app).
 */
@Component({
  selector: 'app-cust-tele-calling-register',
  imports: [FormsModule, ButtonModule, SelectModule, TableModule, DatePipe],
  templateUrl: './cust-tele-calling-register.html',
  styleUrl: './cust-tele-calling-register.scss'
})
export class CustTeleCallingRegister implements OnInit {
  private readonly data = inject(MarketingDataService);
  private readonly router = inject(Router);

  readonly groups = signal<LookupOption[]>([]);
  readonly stages = signal<LookupOption[]>([]);
  readonly rows = signal<TeleCallingRow[]>([]);
  readonly loading = signal(false);
  readonly expandedCustId = signal<number | null>(null);
  readonly actionRows = signal<TeleCallingActionRow[]>([]);

  groupId: number | null = null;
  stageId: number | null = null;

  // PrimeNG's built-in [paginator] (backed by a `first` model-signal input on
  // the Table) kept fighting our own attempts to reset/read it in this app's
  // zoneless setup — clicks on it stopped reliably advancing the page no
  // matter how the reset was wired. Paginating ourselves over a plain signal,
  // driven entirely by our own template click handlers (the same pattern
  // every other working signal in this component already uses), sidesteps
  // that interaction completely instead of trying to out-guess it.
  readonly pageSize = 10;
  readonly currentPage = signal(0);
  readonly totalPages = computed(() => Math.max(1, Math.ceil(this.rows().length / this.pageSize)));
  readonly pagedRows = computed(() => {
    const start = this.currentPage() * this.pageSize;
    return this.rows().slice(start, start + this.pageSize);
  });

  ngOnInit(): void {
    this.data.getTeleCallingFilters().subscribe((f) => {
      this.groups.set(f.groups);
      this.stages.set(f.stages);
    });
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.expandedCustId.set(null);
    this.currentPage.set(0);
    this.data.getTeleCallingRows(this.groupId ?? 0, this.stageId ?? 0).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }

  prevPage(): void {
    this.currentPage.update((p) => Math.max(0, p - 1));
  }

  nextPage(): void {
    this.currentPage.update((p) => Math.min(this.totalPages() - 1, p + 1));
  }

  toggleExpand(row: TeleCallingRow): void {
    if (this.expandedCustId() === row.custId) {
      this.expandedCustId.set(null);
      return;
    }
    this.expandedCustId.set(row.custId);
    this.data.getTeleCallingActions(row.custId).subscribe((rows) => this.actionRows.set(rows));
  }

  nextStep(row: TeleCallingRow): void {
    if (row.nextAction === 'Closed') {
      return;
    }
    this.router.navigate(['/marketing/cust-enquiry-action'], {
      queryParams: {
        CustID: row.custId,
        RefActionID: row.refActionId,
        ActionType: row.nextAction === 'Add' ? 1 : 2,
        MobileNo: row.mobileNo,
        PhoneNo: row.phNo
      }
    });
  }
}
