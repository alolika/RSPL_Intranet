import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { LookupOption, MarketingDataService } from '../marketing-data.service';

/** Mirrors Section_Marketing/DailyCRMActivity.aspx: user + date-range filtered dynamic-column CRM action-delay grid. */
@Component({
  selector: 'app-daily-crm-activity',
  imports: [FormsModule, ButtonModule, DatePickerModule, SelectModule, TableModule],
  templateUrl: './daily-crm-activity.html',
  styleUrl: './daily-crm-activity.scss'
})
export class DailyCrmActivity implements OnInit {
  private readonly data = inject(MarketingDataService);
  // This app runs without zone.js — the plain (non-signal) `userId` property below
  // doesn't trigger a re-render on its own when mutated inside an RxJS subscribe
  // callback. markForCheck() after that mutation is what actually gets the new
  // value on screen.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly users = signal<LookupOption[]>([]);
  readonly columns = signal<string[]>([]);
  readonly rows = signal<Record<string, unknown>[]>([]);
  readonly loading = signal(false);

  userId = 0;
  fromDate: Date | null = new Date();
  toDate: Date | null = new Date();

  ngOnInit(): void {
    this.data.getDailyCrmActivityUsers().subscribe((u) => {
      this.users.set(u);
      this.userId = u[0]?.value ?? 0;
      this.cdr.markForCheck();
    });
  }

  show(): void {
    if (!this.userId || !this.fromDate || !this.toDate) {
      return;
    }
    this.loading.set(true);
    this.data.getDailyCrmActivityRows(this.userId, this.fromDate, this.toDate).subscribe((res) => {
      this.columns.set(res.columns);
      this.rows.set(res.rows);
      this.loading.set(false);
    });
  }
}
