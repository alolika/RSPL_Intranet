import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import { LeadRecordRow, LookupOption, MarketingDataService } from '../marketing-data.service';

/** Mirrors Section_Marketing/LeadRecord.aspx: filter bar (received-by/assigned-to/salesman/city/district/date-range) + lead-record grid. */
@Component({
  selector: 'app-lead-record',
  imports: [FormsModule, ButtonModule, DatePickerModule, SelectModule, TableModule, DatePipe, IndianNumberPipe],
  templateUrl: './lead-record.html',
  styleUrl: './lead-record.scss'
})
export class LeadRecord implements OnInit {
  private readonly data = inject(MarketingDataService);

  readonly users = signal<LookupOption[]>([]);
  // Separate from `users` (still used by First Received By, unchanged) so
  // Assigned To's type-to-search can re-fetch its own options without
  // affecting First Received By's dropdown — the two fields share the same
  // underlying usermaster query but must filter independently.
  readonly assignedToOptions = signal<LookupOption[]>([]);
  readonly salesmen = signal<LookupOption[]>([]);
  readonly cities = signal<LookupOption[]>([]);
  readonly districts = signal<LookupOption[]>([]);
  readonly enquirySources = signal<string[]>([]);
  readonly enquirySources2 = signal<string[]>([]);
  readonly rows = signal<LeadRecordRow[]>([]);
  readonly loading = signal(false);

  firstReceivedBy = 0;
  assignedTo = 0;
  salesman = 0;
  city = '';
  district = '';
  enquirySource = '';
  enquirySource2 = '';
  fromDate: Date | null = new Date();
  toDate: Date | null = new Date();

  ngOnInit(): void {
    this.data.getLeadRecordFilters().subscribe((f) => {
      this.users.set(f.users);
      this.assignedToOptions.set(f.users);
      this.salesmen.set(f.salesmen);
      this.cities.set(f.cities);
      this.districts.set(f.districts);
      this.enquirySources.set(f.enquirySources);
      this.enquirySources2.set(f.enquirySources2);
    });
  }

  onAssignedToFilter(query: string): void {
    this.data.getLeadRecordAssignedToOptions(query).subscribe((u) => this.assignedToOptions.set(u));
  }

  onSalesmanFilter(query: string): void {
    this.data.getLeadRecordSalesmenOptions(query).subscribe((s) => this.salesmen.set(s));
  }

  onCityFilter(query: string): void {
    this.data.getLeadRecordCitiesOptions(query).subscribe((c) => this.cities.set(c));
  }

  show(): void {
    this.loading.set(true);
    this.data
      .getLeadRecords({
        firstReceivedBy: this.firstReceivedBy,
        assignedTo: this.assignedTo,
        salesman: this.salesman,
        city: this.city,
        district: this.district,
        enquirySource: this.enquirySource,
        enquirySource2: this.enquirySource2,
        fromDate: this.fromDate,
        toDate: this.toDate
      })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      });
  }

  export(): void {
    exportToExcel('LeadReport', this.rows());
  }
}
