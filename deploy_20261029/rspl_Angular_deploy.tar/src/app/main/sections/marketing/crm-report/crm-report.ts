import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { CrmReportRow, MarketingDataService } from '../marketing-data.service';

/** Mirrors Section_Marketing/CRMReport.aspx ("Enquiry Report"): city/date-range filtered enquiry grid; customer name links to CustEnquiryRegister. */
@Component({
  selector: 'app-crm-report',
  imports: [FormsModule, RouterLink, ButtonModule, DatePickerModule, SelectModule, TableModule, DatePipe],
  templateUrl: './crm-report.html',
  styleUrl: './crm-report.scss'
})
export class CrmReport implements OnInit {
  private readonly data = inject(MarketingDataService);

  readonly cities = signal<string[]>([]);
  readonly rows = signal<CrmReportRow[]>([]);
  readonly loading = signal(false);

  readonly sortOptions = [
    { label: 'Enquiry Date', value: 'EnquiryDate' },
    { label: 'Display Name', value: 'DisplayName' },
    { label: 'City', value: 'City' }
  ];

  fromDate: Date | null = new Date(2013, 3, 1);
  toDate: Date | null = new Date();
  city = 'All';
  sortBy = 'EnquiryDate';

  ngOnInit(): void {
    this.data.getCrmReportCities().subscribe((c) => this.cities.set(['All', ...c]));
    this.show();
  }

  // Bound to <p-select>'s (onFilter) — re-queries the server with whatever the
  // user has typed instead of only filtering the already-loaded top 100 client-side.
  onCityFilter(query: string): void {
    this.data.getCrmReportCities(query).subscribe((c) => this.cities.set(['All', ...c]));
  }

  show(): void {
    this.loading.set(true);
    this.data.getCrmReportRows(this.city, this.fromDate, this.toDate, this.sortBy).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }

  export(): void {
    exportToExcel('CRMReport', this.rows());
  }
}
