import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { TableLazyLoadEvent, TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { EReferralRow, LookupOption, MarketingDataService } from '../marketing-data.service';

/**
 * Mirrors Section_Marketing/e-ReferralRegister.aspx ("e-Referral
 * Register"): a Shop-Name filtered register of e-Referral vouchers, sourced
 * from vw_web_eReferralVoucher. Source's RadGrid AutoGenerateColumns="true"
 * is replicated as a fixed column set matching the view's actual fields.
 *
 * True server-side paging (unlike this app's other "paginated" reports,
 * which fetch the full filtered result set and page it client-side) —
 * vw_web_eReferralVoucher has no known row-count ceiling, so only one
 * page's worth of rows is ever fetched at a time via SQL Server's own
 * OFFSET/FETCH, driven by <p-table>'s (onLazyLoad).
 */
@Component({
  selector: 'app-e-referral-register',
  imports: [FormsModule, ButtonModule, SelectModule, TableModule, DatePipe],
  templateUrl: './e-referral-register.html',
  styleUrl: './e-referral-register.scss'
})
export class EReferralRegister implements OnInit {
  private readonly data = inject(MarketingDataService);

  readonly shops = signal<LookupOption[]>([]);
  readonly rows = signal<EReferralRow[]>([]);
  readonly totalRecords = signal(0);
  readonly loading = signal(false);

  shopId: number | null = null;
  private pageSize = 20;
  private first = 0;

  ngOnInit(): void {
    this.data.getEReferralShops().subscribe((s) => this.shops.set(s));
  }

  onShopFilter(query: string): void {
    this.data.getEReferralShops(query).subscribe((s) => this.shops.set(s));
  }

  // Bound to <p-table>'s (onLazyLoad) — fires on initial render and on every
  // page change, so this is the report's only load path (no separate
  // ngOnInit auto-load needed).
  onLazyLoad(event: TableLazyLoadEvent): void {
    this.first = event.first ?? 0;
    this.pageSize = event.rows ?? this.pageSize;
    this.fetchPage();
  }

  show(): void {
    this.first = 0;
    this.fetchPage();
  }

  private fetchPage(): void {
    this.loading.set(true);
    const page = Math.floor(this.first / this.pageSize);
    this.data.getEReferralRows(this.shopId ?? 0, page, this.pageSize).subscribe((result) => {
      this.rows.set(result.rows);
      this.totalRecords.set(result.total);
      this.loading.set(false);
    });
  }

  export(): void {
    exportToExcel('e-ReferralRegister', this.rows());
  }
}
