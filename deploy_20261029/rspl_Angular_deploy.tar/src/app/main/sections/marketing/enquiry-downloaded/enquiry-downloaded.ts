import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { DownloadedEnquiryRow, LookupOption, MarketingDataService } from '../marketing-data.service';

/** Mirrors Section_Marketing/EnquiryDownloaded.aspx: date-range filtered grid of website-downloaded enquiries with an inline reassign-to editor per row. */
@Component({
  selector: 'app-enquiry-downloaded',
  imports: [FormsModule, ButtonModule, DatePickerModule, SelectModule, TableModule, DatePipe],
  templateUrl: './enquiry-downloaded.html',
  styleUrl: './enquiry-downloaded.scss'
})
export class EnquiryDownloaded implements OnInit {
  private readonly data = inject(MarketingDataService);

  readonly users = signal<LookupOption[]>([]);
  readonly rows = signal<DownloadedEnquiryRow[]>([]);
  readonly loading = signal(false);
  readonly editingCustId = signal<number | null>(null);

  fromDate: Date | null = new Date();
  toDate: Date | null = new Date();
  reassignTo: number | null = null;

  ngOnInit(): void {
    this.data.getAssignedToUsers().subscribe((u) => this.users.set(u));
    this.show();
  }

  show(): void {
    if (!this.fromDate || !this.toDate) {
      return;
    }
    this.loading.set(true);
    this.data.getDownloadedEnquiryRows(this.fromDate, this.toDate).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }

  startEdit(row: DownloadedEnquiryRow): void {
    this.editingCustId.set(row.custId);
    this.reassignTo = row.assignedUserId;
  }

  cancelEdit(): void {
    this.editingCustId.set(null);
  }

  saveReassign(row: DownloadedEnquiryRow): void {
    if (!this.reassignTo) {
      return;
    }
    this.data.reassignDownloadedEnquiry(row.custId, row.assignedUserId, this.reassignTo).subscribe(() => {
      const label = this.users().find((u) => u.value === this.reassignTo)?.label ?? '';
      this.rows.update((rows) => rows.map((r) => (r.custId === row.custId ? { ...r, assignedTo: label, assignedUserId: this.reassignTo! } : r)));
      this.editingCustId.set(null);
    });
  }
}
