import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { StepperModule } from 'primeng/stepper';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';
import { shareReplay, switchMap } from 'rxjs';

import { WizardStep, goToStep } from '../../../../shared/wizard-step';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import {
  CustEnquiryForm,
  CustEnquiryHistoryRow,
  LookupOption,
  MarketingDataService
} from '../marketing-data.service';

type Mode = 'new' | 'modify' | 'view';

/**
 * Mirrors Section_Marketing/CustEnquiry.aspx: create/modify/view a
 * customer enquiry (the main lead-intake form), driven by ?ActionType=
 * (1=new, 2=modify, 3=view) and ?CustID=. The source offered four radio-
 * button search modes (Shop Name / Contact Person / Mobile No / Customer
 * ID) each backed by its own async web-service combo — simplified to one
 * customer search select here, same effective "find the customer, then
 * work on their enquiry" flow.
 */
@Component({
  selector: 'app-cust-enquiry',
  imports: [FormsModule, ButtonModule, DatePickerModule, InputTextModule, SelectModule, StepperModule, TableModule, TextareaModule, DatePipe, IndianNumberPipe],
  templateUrl: './cust-enquiry.html',
  styleUrl: './cust-enquiry.scss'
})
export class CustEnquiry implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(MarketingDataService);
  // This app runs without zone.js — plain (non-signal) properties like `form`/`enquiryDate`/
  // `selectedCustomerId` below don't trigger a re-render on their own when mutated inside an
  // RxJS subscribe callback, unlike the signals elsewhere in this component. markForCheck()
  // after each such mutation is what actually gets the new values on screen.
  private readonly cdr = inject(ChangeDetectorRef);

  mode: Mode = 'new';
  custId: number | null = null;
  readonly activeStep = signal(0);
  readonly steps: WizardStep[] = [
    { value: 0, label: 'Enquiry Basics' },
    { value: 1, label: 'Communication & Ownership' },
    { value: 2, label: 'Shop & Business Details' },
    { value: 3, label: 'Commercial Details' }
  ];

  readonly customers = signal<LookupOption[]>([]);
  readonly goodsSold = signal<LookupOption[]>([]);
  readonly natureOfBusiness = signal<LookupOption[]>([]);
  readonly methodOfSale = signal<LookupOption[]>([]);
  readonly ownership = signal<LookupOption[]>([]);
  readonly commMethod = signal<LookupOption[]>([]);
  readonly sourceType = signal<LookupOption[]>([]);
  readonly receivedByOptions = signal<LookupOption[]>([]);
  readonly segment = signal<LookupOption[]>([]);

  readonly customerInfo = signal<{ custId: number; shopName: string; address: string; contactPerson: string; mobileNo: string; telNo: string; email: string } | null>(null);
  readonly historyRows = signal<CustEnquiryHistoryRow[]>([]);
  readonly saving = signal(false);

  selectedCustomerId: number | null = null;
  enquiryDate: Date | null = new Date();
  form: CustEnquiryForm = this.blankForm();

  // Bumped every time a customer is loaded; async responses check it before
  // applying results, so clicking Show for one customer then quickly for
  // another can't let the earlier (slower) response overwrite the newer
  // customer's info/history/form with stale data after it arrives late.
  private requestId = 0;

  // The master-lists call (7 sequential DB round-trips server-side) and the
  // per-customer enquiry call are independent HTTP requests with no
  // guaranteed ordering. If the customer's saved values (e.g. receivedBy)
  // got assigned to `form` before their <p-select>'s own [options] list had
  // finished loading, PrimeNG has nothing to match that value against yet
  // and renders the dropdown blank — it doesn't reliably retry the match
  // once options arrive later, which is exactly the "some fields blank
  // until you click elsewhere" symptom. shareReplay(1) caches the one
  // fetch so every subsequent load (via switchMap below) reuses it near-
  // instantly instead of refetching, while still *guaranteeing* — not just
  // usually arranging — that options are populated before any value that
  // depends on them is ever set.
  private readonly masterLists$ = this.data.getEnquiryMasterLists().pipe(shareReplay(1));

  ngOnInit(): void {
    this.masterLists$.subscribe((lists) => {
      this.goodsSold.set(lists.goodsSold);
      this.natureOfBusiness.set(lists.natureOfBusiness);
      this.methodOfSale.set(lists.methodOfSale);
      this.ownership.set(lists.ownership);
      this.commMethod.set(lists.commMethod);
      this.sourceType.set(lists.sourceType);
      this.receivedByOptions.set(lists.receivedBy);
      this.segment.set(lists.segment);
    });
    // Top 100 initially, re-queried by name as the user types (onCustomerFilter
    // below) — same load-on-demand shape as Referred By Customer/Customer Name
    // on the Customer Registration page, instead of one large capped fetch with
    // only client-side filtering over whatever happened to load.
    this.data.getCustomersForSearch().subscribe((c) => this.customers.set(c));

    // Enquiry-Create/Modify/View all route to this same component (only
    // ?ActionType/?CustID differ), so Angular reuses the instance instead of
    // re-running ngOnInit when switching between them — subscribing to
    // queryParamMap (not reading a one-time snapshot) is what makes the form
    // actually reset/reload when navigated to again while already mounted.
    this.route.queryParamMap.subscribe((q) => {
      const actionType = Number(q.get('ActionType') ?? 1);
      this.mode = actionType === 2 ? 'modify' : actionType === 3 ? 'view' : 'new';
      this.custId = q.get('CustID') ? Number(q.get('CustID')) : null;

      this.activeStep.set(0);
      if (this.custId) {
        this.selectedCustomerId = this.custId;
        this.loadCustomer();
      } else {
        this.selectedCustomerId = null;
        this.form = this.blankForm();
        this.customerInfo.set(null);
        this.historyRows.set([]);
      }
      this.cdr.markForCheck();
    });
  }

  // Surfaces (rather than silently rendering blank) any saved dropdown
  // value that doesn't match a current option — e.g. an old enquiry
  // referencing a since-renamed/removed Web_LittleMaster entry. A p-select
  // has no built-in way to show this, so it just looks empty; this makes
  // that specific failure mode visible and diagnosable instead of
  // indistinguishable from "no value was ever saved".
  goNext(): void {
    goToStep(this.activeStep, this.steps, this.activeStep() + 1);
  }

  goPrev(): void {
    goToStep(this.activeStep, this.steps, this.activeStep() - 1);
  }

  isUnmatched(value: number | null, options: LookupOption[]): boolean {
    return value != null && options.length > 0 && !options.some((o) => o.value === value);
  }

  private blankForm(): CustEnquiryForm {
    return {
      enquiryDate: new Date().toISOString(),
      receivedBy: null,
      sourceType: null,
      sourceDetail: '',
      natureOfBusiness: null,
      segment: null,
      commMethod: null,
      commDetails: '',
      ownership: null,
      noOfOutlets: '',
      methodOfSale: null,
      sizeOfShop: '',
      goodsSold: null,
      totalItems: '',
      rushHours: '',
      salesStaff: '',
      billingSystem: '',
      transactionsPerDay: '',
      competitor: '',
      customisation: '',
      orderValue: '',
      modules: '',
      discountOffered: '',
      assignedTo: '',
      narration: ''
    };
  }

  show(): void {
    if (!this.selectedCustomerId) {
      return;
    }
    this.custId = this.selectedCustomerId;
    this.activeStep.set(0);
    this.loadCustomer();
  }

  // Bound to <p-select>'s (onFilter) — re-queries the server with whatever the
  // user has typed instead of only filtering the already-loaded top 100 client-side.
  onCustomerFilter(query: string): void {
    this.data.getCustomersForSearch(query).subscribe((c) => this.customers.set(c));
  }

  private loadCustomer(): void {
    if (!this.custId) {
      return;
    }
    const requestId = ++this.requestId;
    this.customerInfo.set(null);
    this.historyRows.set([]);

    this.data.getCustomerGeneralInfo(this.custId).subscribe((info) => {
      if (requestId === this.requestId) {
        this.customerInfo.set(info);
        // The picker is also capped to a top-100/search-narrowed list — deep-linking
        // here (e.g. View from the enquiry register) can land on a custId outside
        // that window, which would otherwise leave the dropdown showing blank.
        if (info) {
          const custId = this.custId;
          this.customers.update((opts) => (opts.some((o) => o.value === custId) ? opts : [{ label: info.shopName, value: custId! }, ...opts]));
        }
      }
    });

    // Every mode shows this customer's full enquiry history below the form
    // — View mode always did; Create/Modify previously didn't load it at
    // all, so "Show" only ever populated the single current-enquiry form
    // fields with no visibility into what was already on file for them.
    this.data.getEnquiryHistory(this.custId).subscribe((rows) => {
      if (requestId === this.requestId) {
        this.historyRows.set(rows);
      }
    });

    if (this.mode !== 'view') {
      // Wait for masterLists$ (cached after the first load, so this costs
      // nothing once it's already resolved) before applying the saved
      // form — guarantees every <p-select> already has real [options] to
      // match the incoming value against, instead of racing it.
      this.masterLists$
        .pipe(switchMap(() => this.data.getCustomerEnquiry(this.custId!)))
        .subscribe((form) => {
          if (form && requestId === this.requestId) {
            this.form = form;
            this.enquiryDate = new Date(form.enquiryDate);
            this.cdr.markForCheck();
          }
        });
    }
  }

  submit(): void {
    this.saving.set(true);
    this.form.enquiryDate = (this.enquiryDate ?? new Date()).toISOString();
    this.data.saveCustEnquiry(this.custId, this.form, this.mode === 'modify').subscribe((res) => {
      this.saving.set(false);
      alert(this.mode === 'modify' ? 'Enquiry updated successfully' : 'Enquiry submitted successfully');
      if (this.mode === 'new') {
        this.form = this.blankForm();
        this.customerInfo.set(null);
        this.selectedCustomerId = null;
        this.activeStep.set(0);
      }
      this.cdr.markForCheck();
    });
  }
}
