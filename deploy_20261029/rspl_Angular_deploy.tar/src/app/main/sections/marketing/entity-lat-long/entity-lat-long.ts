import { HttpClient } from '@angular/common/http';
import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, OnDestroy, OnInit, ViewChild, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import * as L from 'leaflet';

import { LookupOption, MarketingDataService } from '../marketing-data.service';

// Leaflet's default marker icon paths resolve relative to wherever the JS bundle
// is served from, which breaks under Angular's build output — pointed instead at
// the same icon files (copied from node_modules/leaflet/dist/images) served from
// public/assets/leaflet, a well-known Leaflet-in-a-bundler gotcha.
const MARKER_ICON = L.icon({
  iconUrl: 'assets/leaflet/marker-icon.png',
  iconRetinaUrl: 'assets/leaflet/marker-icon-2x.png',
  shadowUrl: 'assets/leaflet/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Same default center the source page used (`new google.maps.LatLng(18.52043, 73.856743)`).
const DEFAULT_CENTER: L.LatLngTuple = [18.52043, 73.856743];

/**
 * Mirrors Section_Marketing/EntityLatLong.aspx ("Assign Latitude and
 * Longitude" / menu "CustomerMap-Locate"): a customer picker (list toggled
 * by the Edit checkbox between unmapped and already-mapped customers), a
 * geocode-by-address search box, and readonly Lat/Lng fields populated
 * either by the geocode search or by clicking the map.
 *
 * The source loaded Google Maps with no API key at all (the old keyless
 * `google.load('maps', ...)` AJAX Loader from www.google.com/jsapi) — that
 * loader was shut down by Google years ago and no longer works, and every
 * current Google Maps embed requires a real, billed API key. Rebuilt here on
 * Leaflet + OpenStreetMap tiles (map display) and Nominatim (address search),
 * both free and keyless, replicating the same click-to-set-Lat/Lng and
 * address-search-to-set-Lat/Lng behavior without any external key/billing
 * dependency.
 */
@Component({
  selector: 'app-entity-lat-long',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, SelectModule],
  templateUrl: './entity-lat-long.html',
  styleUrl: './entity-lat-long.scss'
})
export class EntityLatLong implements OnInit, AfterViewInit, OnDestroy {
  private readonly data = inject(MarketingDataService);
  private readonly http = inject(HttpClient);
  // This app runs without zone.js — plain (non-signal) properties like `custId`/
  // `searchString`/`latitude`/`longitude` below don't trigger a re-render on their
  // own when mutated inside an RxJS subscribe callback. markForCheck() after each
  // such mutation is what actually gets the new values on screen.
  private readonly cdr = inject(ChangeDetectorRef);

  @ViewChild('mapCanvas', { static: true }) private readonly mapCanvasRef!: ElementRef<HTMLDivElement>;
  private map: L.Map | null = null;
  private marker: L.Marker | null = null;

  readonly customers = signal<LookupOption[]>([]);
  readonly saving = signal(false);
  readonly searching = signal(false);
  readonly locating = signal(false);

  editMode = false;
  custId: number | null = null;
  searchString = '';
  latitude = '';
  longitude = '';

  ngOnInit(): void {
    this.fillCustomers();
  }

  ngAfterViewInit(): void {
    this.map = L.map(this.mapCanvasRef.nativeElement).setView(DEFAULT_CENTER, 9);

    const streetLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19
    }).addTo(this.map);
    // Esri's World Imagery service is free and keyless (no billing/API key,
    // unlike Google's satellite tiles) — gives real aerial photography so a
    // pin can be placed against actual buildings/terrain instead of just
    // road-map symbols, for more accurate lat/lng assignment.
    const satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
      attribution: 'Tiles &copy; Esri &mdash; Source: Esri, Maxar, Earthstar Geographics, and the GIS User Community',
      maxZoom: 19
    });
    L.control.layers({ Map: streetLayer, Satellite: satelliteLayer }).addTo(this.map);

    // Mirrors the source's map click handler — clicking anywhere on the map
    // sets Lat/Lng directly, same as clicking to drop a pin in the original.
    this.map.on('click', (e: L.LeafletMouseEvent) => {
      this.setLatLng(e.latlng.lat, e.latlng.lng, false);
      this.cdr.markForCheck();
    });

    // The container's final layout size isn't guaranteed to be settled the
    // instant the view mounts (surrounding flex layout, fonts, etc.) — Leaflet
    // caches the size it sees at creation time, so if that read was stale/zero
    // the map renders at the wrong scale/position until told to re-measure.
    setTimeout(() => this.map?.invalidateSize(), 0);

    // A customer may already have resolved before the map finished mounting
    // (ngOnInit's HTTP call can, in principle, beat ngAfterViewInit) — place
    // its marker now instead of waiting for the next selection change.
    if (this.hasAssignedLocation(this.latitude, this.longitude)) {
      this.setLatLng(Number(this.latitude), Number(this.longitude));
    }
  }

  ngOnDestroy(): void {
    this.map?.remove();
  }

  onEditToggle(): void {
    this.fillCustomers();
  }

  private fillCustomers(): void {
    this.data.getEntityLatLongCustomers(this.editMode).subscribe((rows) => {
      this.customers.set(rows);
      this.custId = rows[0]?.value ?? null;
      this.fillLatLong();
      this.cdr.markForCheck();
    });
  }

  onCustomerChange(): void {
    this.fillLatLong();
  }

  // Bound to the Customer <p-select>'s (onFilter) — re-queries the server with
  // whatever's typed instead of only filtering the already-loaded top 100
  // client-side. Only updates the option list; unlike fillCustomers() this
  // must not change the current selection or reset the Lat/Lng fields.
  onCustomerFilter(query: string): void {
    this.data.getEntityLatLongCustomers(this.editMode, query).subscribe((rows) => {
      this.customers.set(rows);
      this.cdr.markForCheck();
    });
  }

  private fillLatLong(): void {
    this.searchString = '';
    this.latitude = '';
    this.longitude = '';
    this.clearMarker();
    if (this.custId == null) {
      return;
    }
    this.data.getEntityLatLong(this.custId).subscribe((r) => {
      // "Unmapped" customers (the default Edit=off list) store Latitude/Longitude
      // as the literal string '0' (see get_entity_lat_long_customers' own
      // Latitude='0' filter) — '0' is truthy in JS, so a plain `if (r.latitude...)`
      // check let it through as a "real" coordinate and centered the map on
      // (0,0), Null Island, in the ocean. hasAssignedLocation() treats '0' the
      // same as blank/null.
      if (this.hasAssignedLocation(r.latitude, r.longitude)) {
        this.latitude = r.latitude;
        this.longitude = r.longitude;
        this.setLatLng(Number(r.latitude), Number(r.longitude));
        // r.locationName is the customer's registered Road/Area/City from
        // CustomerMaster — fixed regardless of where the pin actually is, so
        // editing an already-assigned customer always showed that same
        // registered city (often "Pune" for this dataset) no matter what
        // location was really saved. Reverse-geocoding the SAVED coordinates
        // shows the address the pin is actually at.
        this.reverseGeocode(Number(r.latitude), Number(r.longitude), r.locationName);
      } else {
        // Not yet assigned — prefill with the registered address as a
        // starting point for a forward search.
        this.searchString = r.locationName;
      }
      this.cdr.markForCheck();
    });
  }

  private reverseGeocode(lat: number, lon: number, fallback: string): void {
    this.http
      .get<{ display_name: string }>('https://nominatim.openstreetmap.org/reverse', {
        params: { format: 'json', lat: String(lat), lon: String(lon) }
      })
      .subscribe({
        next: (result) => {
          this.searchString = result.display_name || fallback;
          this.cdr.markForCheck();
        },
        error: () => {
          this.searchString = fallback;
          this.cdr.markForCheck();
        }
      });
  }

  private hasAssignedLocation(lat: string, lng: string): boolean {
    return !!lat && !!lng && lat !== '0' && lng !== '0';
  }

  // Mirrors the source's showLocation() (Google Geocoder) — Nominatim is
  // OpenStreetMap's free, keyless geocoding equivalent: address in, lat/lng out.
  search(): void {
    if (!this.searchString.trim()) {
      return;
    }
    this.searching.set(true);
    this.http
      .get<{ lat: string; lon: string }[]>('https://nominatim.openstreetmap.org/search', {
        params: { format: 'json', q: this.searchString, limit: '1' }
      })
      .subscribe({
        next: (results) => {
          this.searching.set(false);
          if (!results.length) {
            alert('Geocode was not successful: no matching location found.');
            this.cdr.markForCheck();
            return;
          }
          this.setLatLng(Number(results[0].lat), Number(results[0].lon));
          this.cdr.markForCheck();
        },
        error: () => {
          this.searching.set(false);
          alert('Geocode search failed — please try again.');
          this.cdr.markForCheck();
        }
      });
  }

  // Uses the browser's own Geolocation API (device GPS/Wi-Fi/IP positioning) —
  // free, no external service or key involved. Requires a secure context
  // (HTTPS or localhost) and the user granting the browser's location prompt.
  showMyLocation(): void {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by this browser.');
      return;
    }
    this.locating.set(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        this.locating.set(false);
        this.searchString = '';
        this.setLatLng(position.coords.latitude, position.coords.longitude, false);
        this.map?.setView([position.coords.latitude, position.coords.longitude], 16);
        this.cdr.markForCheck();
      },
      (error) => {
        this.locating.set(false);
        alert(`Could not determine your location: ${error.message}`);
        this.cdr.markForCheck();
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  private setLatLng(lat: number, lng: number, recenter = true): void {
    this.latitude = String(lat);
    this.longitude = String(lng);
    if (!this.map) {
      return;
    }
    const latLng: L.LatLngTuple = [lat, lng];
    if (this.marker) {
      this.marker.setLatLng(latLng);
    } else {
      this.marker = L.marker(latLng, { icon: MARKER_ICON }).addTo(this.map);
    }
    if (recenter) {
      this.map.setView(latLng, this.map.getZoom());
    }
  }

  private clearMarker(): void {
    this.marker?.remove();
    this.marker = null;
  }

  save(): void {
    if (this.custId == null || !this.latitude) {
      return;
    }
    this.saving.set(true);
    this.data.saveEntityLatLong(this.custId, this.latitude, this.longitude).subscribe(() => {
      this.saving.set(false);
      alert(`Update Successful for CustomerID=${this.custId}`);
      this.fillCustomers();
    });
  }
}
