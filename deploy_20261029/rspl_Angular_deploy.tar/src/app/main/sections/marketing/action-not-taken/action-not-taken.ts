import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';

import { MarketingDataService } from '../marketing-data.service';

/** Mirrors Section_Marketing/ActionNotTaken.aspx ("Action Not Decided"): CustID filter + dynamic-column grid. */
@Component({
  selector: 'app-action-not-taken',
  imports: [FormsModule, ButtonModule, InputTextModule, TableModule],
  templateUrl: './action-not-taken.html',
  styleUrl: './action-not-taken.scss'
})
export class ActionNotTaken implements OnInit {
  private readonly data = inject(MarketingDataService);

  readonly columns = signal<string[]>([]);
  readonly rows = signal<Record<string, unknown>[]>([]);
  readonly loading = signal(false);

  custId = '';

  ngOnInit(): void {
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.data.getActionNotTakenRows(Number(this.custId) || 0).subscribe((res) => {
      this.columns.set(res.columns);
      this.rows.set(res.rows);
      this.loading.set(false);
    });
  }
}
