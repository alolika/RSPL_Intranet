import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { Chart, ChartConfiguration } from 'chart.js/auto';

import { LeadSummaryRow, MarketingDataService } from '../marketing-data.service';

/**
 * Mirrors Section_Marketing/CustLeadChart.aspx ("CRM Lead Summary Chart"):
 * Group-By + By-Parameter + date-range filtered doughnut chart of lead
 * summary figures. Source's asp:Chart (System.Web.DataVisualization) doughnut
 * replaced with Chart.js; reuses the same webproc_LeadChartSummaryV2-backed
 * summary rows as CustLeadReport.
 */
@Component({
  selector: 'app-cust-lead-chart',
  imports: [FormsModule, ButtonModule, DatePickerModule, SelectModule],
  templateUrl: './cust-lead-chart.html',
  styleUrl: './cust-lead-chart.scss'
})
export class CustLeadChart implements AfterViewInit, OnDestroy {
  private readonly data = inject(MarketingDataService);
  private chart: Chart | null = null;

  @ViewChild('canvas') canvasRef!: ElementRef<HTMLCanvasElement>;

  readonly groupByOptions = [
    { label: 'Vertical', value: 'Vertical' },
    { label: 'Segment', value: 'Segment' },
    { label: 'Enquiry Source', value: 'EnquirySource' },
    { label: 'Assigned To', value: 'AssignedTo' }
  ];

  readonly parameterOptions: { label: string; value: keyof LeadSummaryRow }[] = [
    { label: 'Leads Generated', value: 'leadsGenerated' },
    { label: 'Leads Converted', value: 'leadsConverted' },
    { label: 'Sale Revenue', value: 'saleRevenue' },
    { label: 'AMC/Visit Revenue', value: 'amcVisitRevenue' },
    { label: 'Total Revenue', value: 'totalRevenue' }
  ];

  readonly loading = signal(false);

  groupBy = 'Vertical';
  parameterBy: keyof LeadSummaryRow = 'leadsGenerated';
  fromDate: Date | null = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  toDate: Date | null = new Date();

  ngAfterViewInit(): void {
    this.show();
  }

  ngOnDestroy(): void {
    this.chart?.destroy();
  }

  show(): void {
    this.loading.set(true);
    this.data.getLeadSummaryRows(this.groupBy, this.fromDate, this.toDate).subscribe((rows) => {
      this.loading.set(false);
      this.draw(rows.filter((r) => (r[this.parameterBy] as number) > 0));
    });
  }

  private draw(rows: LeadSummaryRow[]): void {
    this.chart?.destroy();
    const config: ChartConfiguration<'doughnut'> = {
      type: 'doughnut',
      data: {
        labels: rows.map((r) => r.typeName),
        datasets: [
          {
            data: rows.map((r) => r[this.parameterBy] as number),
            backgroundColor: ['#7c2d12', '#f2a900', '#003057', '#7a9e9f', '#c1c6c8', '#5b2333', '#008751', '#4b3f72']
          }
        ]
      },
      options: {
        plugins: {
          legend: { position: 'bottom' },
          title: { display: true, text: this.parameterOptions.find((p) => p.value === this.parameterBy)?.label ?? '' }
        }
      }
    };
    this.chart = new Chart(this.canvasRef.nativeElement, config);
  }
}
