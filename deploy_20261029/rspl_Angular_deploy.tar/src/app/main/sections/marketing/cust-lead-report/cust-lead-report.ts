import { DatePipe, DecimalPipe } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import { LeadSummaryDetailRow, LeadSummaryRow, MarketingDataService } from '../marketing-data.service';

/**
 * Mirrors Section_Marketing/CustLeadReport.aspx ("CRM Lead Summary Report" /
 * menu "Lead Summary Report"): a Group-By (Vertical/Segment/EnquirySource/
 * AssignedTo) + date-range filtered lead generation/conversion summary.
 * Source uses a 3-level nested RadGrid (Type summary → Group breakdown →
 * customer detail); simplified here to a 2-level expandable grid (Type
 * summary → customer detail directly), consistent with every other
 * multi-level report drill-down migrated in this app. Customer rows link to
 * CustEnquiryRegister.aspx?Auto=1&CustID={id} (/marketing/cust-enquiry-register).
 */
@Component({
  selector: 'app-cust-lead-report',
  imports: [FormsModule, ButtonModule, DatePickerModule, SelectModule, TableModule, DatePipe, DecimalPipe, IndianNumberPipe],
  templateUrl: './cust-lead-report.html',
  styleUrl: './cust-lead-report.scss'
})
export class CustLeadReport implements OnInit {
  private readonly data = inject(MarketingDataService);
  private readonly router = inject(Router);

  readonly groupByOptions = [
    { label: 'Vertical', value: 'Vertical' },
    { label: 'Segment', value: 'Segment' },
    { label: 'Enquiry Source', value: 'EnquirySource' },
    { label: 'Assigned To', value: 'AssignedTo' }
  ];

  readonly rows = signal<LeadSummaryRow[]>([]);
  readonly loading = signal(false);
  readonly errorMessage = signal('');
  readonly expandedTypeId = signal<number | null>(null);
  readonly detailRows = signal<LeadSummaryDetailRow[]>([]);
  readonly detailLoading = signal(false);
  readonly detailError = signal('');

  groupBy = 'Vertical';
  fromDate: Date | null = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  toDate: Date | null = new Date();

  // leadConversionRate is deliberately excluded — it's a per-row percentage,
  // and summing percentages across groups isn't a meaningful "total" (would
  // need a weighted average instead); every other column here is a plain
  // count/amount that sums correctly.
  readonly totals = computed(() => {
    const rows = this.rows();
    return {
      leadsGenerated: rows.reduce((s, r) => s + r.leadsGenerated, 0),
      leadsConverted: rows.reduce((s, r) => s + r.leadsConverted, 0),
      noOfTransactions: rows.reduce((s, r) => s + r.noOfTransactions, 0),
      saleRevenue: rows.reduce((s, r) => s + r.saleRevenue, 0),
      amcVisitRevenue: rows.reduce((s, r) => s + r.amcVisitRevenue, 0),
      totalRevenue: rows.reduce((s, r) => s + r.totalRevenue, 0)
    };
  });

  ngOnInit(): void {
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.errorMessage.set('');
    this.expandedTypeId.set(null);
    this.data.getLeadSummaryRows(this.groupBy, this.fromDate, this.toDate).subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      // Previously had no error path at all — the underlying stored proc
      // (webproc_LeadChartSummaryV2) re-evaluates a heavy UNION view
      // (vwWeb_LeadEnquiryTrans) ~10 times per call and can take well over
      // a minute on this database; a slow or failed request left `loading`
      // stuck true forever with the grid headers visible but no rows and
      // no indication anything had gone wrong or was still working.
      error: () => {
        this.loading.set(false);
        this.errorMessage.set('Could not load the report — the underlying query is taking too long or failed. Please try a narrower date range and try again.');
      }
    });
  }

  toggleExpand(row: LeadSummaryRow): void {
    if (this.expandedTypeId() === row.typeId) {
      this.expandedTypeId.set(null);
      return;
    }
    this.expandedTypeId.set(row.typeId);
    this.detailRows.set([]);
    this.detailError.set('');
    this.detailLoading.set(true);
    this.data.getLeadSummaryDetail(row.typeId, this.groupBy, this.fromDate, this.toDate).subscribe({
      next: (rows) => {
        this.detailRows.set(rows);
        this.detailLoading.set(false);
      },
      error: () => {
        this.detailLoading.set(false);
        this.detailError.set('Could not load customer details for this row — the query is taking too long or failed. Please try again.');
      }
    });
  }

  openCustomer(custId: number): void {
    this.router.navigate(['/marketing/cust-enquiry-register'], { queryParams: { Auto: 1, CustID: custId } });
  }

  // sourceTypeName (a lookup category, e.g. "NGF July 2026"/"Facebook") and
  // sourceNarration (a free-text note) are genuinely different fields in
  // general — confirmed live that for ordinary sources like "Website" they
  // usually differ ("Website" / "Downloaded Brochure"). But for campaign-
  // style sources, staff commonly retype the same campaign name into the
  // narration field too (confirmed live: "NGF July 2026" matched on 69 of 71
  // rows) — the template was unconditionally showing both, which reads as
  // the same value duplicated whenever they happen to be identical. Only
  // appends the narration when it adds real information beyond the type.
  sourceDisplay(d: LeadSummaryDetailRow): string {
    const narration = (d.sourceNarration || '').trim();
    if (!narration || narration === d.sourceTypeName.trim()) {
      return d.sourceTypeName;
    }
    return `${d.sourceTypeName} — ${narration}`;
  }

  export(): void {
    exportToExcel('LeadSummary', this.rows());
  }
}
