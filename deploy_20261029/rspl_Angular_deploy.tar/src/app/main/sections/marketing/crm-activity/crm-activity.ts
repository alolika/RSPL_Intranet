import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';

import { CrmActivityRow, LookupOption, MarketingDataService } from '../marketing-data.service';

/**
 * Mirrors Section_Marketing/CRMActivity.aspx: a social-feed-style list of
 * the 10 most recent CRM activities, each with a "Click here for details"
 * link that routes to a different page depending on ActivityID (1-2 =
 * CustRegistration modify, 3-4 = CustEnquiry modify, 5-6 =
 * CustEnquiryRegister). Employee photos (App_Image/EMP/{UserID}.jpg in the
 * source) have no equivalent asset in this frontend-only phase — shown as
 * a placeholder avatar.
 */
@Component({
  selector: 'app-crm-activity',
  imports: [FormsModule, ButtonModule, DatePickerModule, SelectModule, DatePipe],
  templateUrl: './crm-activity.html',
  styleUrl: './crm-activity.scss'
})
export class CrmActivity implements OnInit {
  private readonly data = inject(MarketingDataService);
  private readonly router = inject(Router);

  readonly users = signal<LookupOption[]>([]);
  readonly rows = signal<CrmActivityRow[]>([]);
  readonly loading = signal(false);

  userId: number | null = null;
  fromDate: Date | null = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  toDate: Date | null = new Date();

  ngOnInit(): void {
    this.data.getCrmActivityUsers().subscribe((u) => this.users.set(u));
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.data.getCrmActivityRows(this.userId ?? 0, this.fromDate, this.toDate).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }

  openDetail(row: CrmActivityRow): void {
    if (row.activityId === 1 || row.activityId === 2) {
      this.router.navigate(['/marketing/cust-registration-modify'], { queryParams: { CustID: row.custId } });
    } else if (row.activityId === 3 || row.activityId === 4) {
      this.router.navigate(['/marketing/cust-enquiry'], { queryParams: { ActionType: 2, CustID: row.custId } });
    } else if (row.activityId === 5 || row.activityId === 6) {
      this.router.navigate(['/marketing/cust-enquiry-register'], { queryParams: { Auto: 0, CustID: row.custId } });
    }
  }
}
