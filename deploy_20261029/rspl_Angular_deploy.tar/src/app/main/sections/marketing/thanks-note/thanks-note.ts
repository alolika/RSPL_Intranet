import { ChangeDetectorRef, Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { MessageModule } from 'primeng/message';
import { TextareaModule } from 'primeng/textarea';

import { MarketingDataService } from '../marketing-data.service';

/**
 * New "Thanks Note" admin form (Marketing menu), per explicit request — a
 * single free-text reason plus a Save button, writing into the existing
 * web_ThanksNoteActionReasons table (see marketing-data.service.ts's
 * addThanksNoteReason() / support_amc.py's add_thanks_note_reason for the
 * backend). That table already had a reader (CustEnquiryAction's
 * Thanks-Note-reasons multi-select, via getThanksNoteReasons()) but no page
 * to add to it before this — a newly saved reason appears there immediately
 * since both read from the same table, no separate sync step.
 */
@Component({
  selector: 'app-thanks-note',
  imports: [FormsModule, ButtonModule, TextareaModule, MessageModule],
  templateUrl: './thanks-note.html',
  styleUrl: './thanks-note.scss'
})
export class ThanksNote {
  private readonly data = inject(MarketingDataService);
  // No zone.js in this app — `reason` (plain, non-signal) is cleared inside
  // save()'s subscribe callback, which needs an explicit markForCheck() to
  // actually reflect on screen; ngModel's own template-driven writes to it
  // while typing don't need this, since those originate from an event
  // Angular is already watching.
  private readonly cdr = inject(ChangeDetectorRef);

  reason = '';
  readonly saving = signal(false);
  readonly errorMessage = signal<string | null>(null);
  readonly successMessage = signal<string | null>(null);

  save(): void {
    const value = this.reason.trim();
    this.errorMessage.set(null);
    this.successMessage.set(null);
    if (!value) {
      this.errorMessage.set('Please enter a Thanks Note reason before saving.');
      return;
    }
    this.saving.set(true);
    this.data.addThanksNoteReason(value).subscribe({
      next: (result) => {
        this.saving.set(false);
        if (result.success) {
          // Cleared for the next entry, per explicit request — the backend
          // already re-validates non-empty/duplicate itself (see
          // add_thanks_note_reason), so this never silently loses input
          // that didn't actually save.
          this.successMessage.set(result.message || 'Saved successfully.');
          this.reason = '';
        } else {
          this.errorMessage.set(result.message || 'Could not save. Please try again.');
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.saving.set(false);
        this.errorMessage.set('Could not save. Please check your connection and try again.');
        this.cdr.markForCheck();
      }
    });
  }
}
