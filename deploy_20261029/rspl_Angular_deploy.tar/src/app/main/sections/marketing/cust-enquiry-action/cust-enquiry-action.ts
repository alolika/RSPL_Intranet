import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { InputNumberModule } from 'primeng/inputnumber';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';
import { Observable, catchError, combineLatest, of, switchMap, tap } from 'rxjs';

import { PortalAuthService } from '../../../../core/auth/portal-auth.service';
import { ClockTimeInput } from '../../../../shared/clock-time-input/clock-time-input';
import { CustomerRegisterInfo, LookupOption, MarketingDataService } from '../marketing-data.service';

/**
 * Mirrors Section_Marketing/CustEnquiryAction.aspx: the canonical "add or
 * close an enquiry action" popup, referenced from many other pages
 * (AmcPending, CustomerLicenseViolation, AMCCo-OrdinatorDashboard, etc. —
 * those use Support's simpler AddNewAction.aspx variant; this is the full
 * version with stage-specific fields: a Competitor picker when the stage is
 * "Lost", a 1-3 reason multi-select checklist when "Thanks Note", and a
 * Quotation Amount field when "Quotation". ?Ismodify=1 loads and edits an
 * existing action instead of adding a new one (some fields become
 * read-only, matching the source's Enabled=False calls). ?FromAMCPending=1
 * or ?ActionStageID=27|28 lock the stage dropdown, same as the source.
 */
@Component({
  selector: 'app-cust-enquiry-action',
  imports: [FormsModule, ButtonModule, CheckboxModule, DatePickerModule, InputTextModule, InputNumberModule, SelectModule, TextareaModule, ClockTimeInput],
  templateUrl: './cust-enquiry-action.html',
  styleUrl: './cust-enquiry-action.scss'
})
export class CustEnquiryAction implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(MarketingDataService);
  private readonly location = inject(Location);
  private readonly auth = inject(PortalAuthService);
  // This app runs without zone.js — plain (non-signal) properties assigned inside
  // RxJS subscribe callbacks below (actionStageId, assignedTo, quotationAmt1, etc.)
  // don't trigger a re-render on their own. markForCheck() after each such mutation
  // is what actually gets the new values on screen.
  private readonly cdr = inject(ChangeDetectorRef);

  /**
   * Embedded mode (e.g. Customer Create/Modify's "Assign To" popup): the
   * same query-param keys this page normally reads from the route are passed
   * in directly, and Save/Cancel emit `saved`/`cancelled` instead of
   * navigating back.
   */
  readonly embeddedParams = input<Record<string, string | number> | null>(null);
  readonly saved = output<void>();
  readonly cancelled = output<void>();

  actionType = 1;
  custId = 0;
  refActionId = 0;
  isModify = false;
  callPanelVisible = false;
  stageLocked = false;

  mobileNo = '';
  phoneNo = '';
  sipExtMobile = '';
  sipExtPhone = '';

  // Bumped on every queryParamMap emission; async callbacks capture the
  // value at fire time and check it before applying results, so a slow
  // response for a PREVIOUS customer/action (e.g. clicking "Next Step" on
  // one row, then quickly on another before the first request returns)
  // can never overwrite fields with stale data after a newer request has
  // already started.
  private requestId = 0;

  readonly actionStages = signal<LookupOption[]>([]);
  readonly competitors = signal<LookupOption[]>([]);
  readonly reasons = signal<LookupOption[]>([]);
  readonly specialRatings = signal<string[]>([]);
  readonly users = signal<LookupOption[]>([]);
  readonly salesmen = signal<LookupOption[]>([]);
  readonly saving = signal(false);
  readonly errorMessage = signal<string | null>(null);
  readonly customerInfo = signal<CustomerRegisterInfo | null>(null);
  // The Customer Information panel's @if had no loading state and no error
  // handling at all — a slow or failed request just left it silently
  // unrendered (no spinner, no message), reading as "customer details
  // aren't showing" even though the request would eventually succeed, or
  // failed with no way to know why. Same gap class as every other field
  // fixed on this form; missed here because this fetch isn't a dropdown.
  readonly customerInfoLoading = signal(false);
  readonly customerInfoError = signal<string | null>(null);

  // Action Stage / Assigned To (& Completed By, same users() list) / Sales
  // Person / Special Rating previously had no loading or error state at
  // all — a single slow or failed request on any of them left that
  // dropdown silently empty for the rest of the session (or, for salesmen/
  // specialRatings specifically, permanently broken — see the removed
  // shareReplay(1) fields this replaced) with no feedback and no way to
  // retry short of a full page reload. That's what read as "the popup
  // doesn't open" / "data sometimes fails to load": the <p-select> opens
  // fine, it's just empty. Each of these four now tracks its own
  // loading/error state, shown next to the field with a Retry link.
  readonly actionStagesLoading = signal(false);
  readonly actionStagesError = signal<string | null>(null);
  readonly usersLoading = signal(false);
  readonly usersError = signal<string | null>(null);
  readonly salesmenLoading = signal(false);
  readonly salesmenError = signal<string | null>(null);
  readonly specialRatingsLoading = signal(false);
  readonly specialRatingsError = signal<string | null>(null);
  // Thanks Note "Reason" checklist — only rendered once an Action Stage of
  // "Thanks Note" is picked (in both the Close panel and its nested
  // Add-Next-Action sub-panel), but was fetched unconditionally in
  // ngOnInit with no error handling, same gap the four fields above had.
  readonly reasonsLoading = signal(false);
  readonly reasonsError = signal<string | null>(null);
  // getEnquiryActionForModify prefills Close Existing Action's Completed
  // Remark/Date/Time (and Add's own Description/Remark/Date/Time) when
  // editing an already-logged action — previously had no error handling at
  // all, so a failed request silently left those fields at their reset
  // defaults (blank remark, today's date) instead of the action's real
  // saved values, with nothing telling the user why.
  readonly modifyPrefillError = signal<string | null>(null);

  // Action Time / Completed Time / next-action Time default to the current
  // system time (still editable).
  private nowTime(): string {
    const d = new Date();
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  }

  // Add panel (ActionType=1)
  actionStageId: number | null = null;
  competitorId: number | null = null;
  selectedReasons1: number[] = [];
  quotationAmt1: number | null = null;
  assignedTo: number | null = null;
  salesPersonId: number | null = null;
  specialRating = '';
  actionDate: Date | null = new Date();
  // Plain "HH:mm" string bound to a native <input type="time"> — replaced
  // p-datepicker[timeOnly] (a fiddly hour/minute spinner, reported hard to
  // use) and its Date-typed model. The browser's native time input already
  // produces exactly "HH:mm", which is exactly what the backend's
  // @ActionTime/@CompletedTime parameters expect, so no Date<->string
  // conversion is needed anywhere in this component anymore.
  actionTime = '';
  desc = '';
  actionRemark = '';
  closeAction = false;
  assignedToLocked = false;
  otherFieldsLocked = false;

  // Close panel (ActionType=2)
  completedBy: number | null = null;
  actionStage3Id: number | null = null;
  selectedReasonsClose: number[] = [];
  quotationAmtClose: number | null = null;
  salesmanId: number | null = null;
  specialRatingClose = '';
  completedDate: Date | null = new Date();
  completedTime = '';
  narration = '';
  addNewAction = false;
  completedByLocked = false;
  closeOtherFieldsLocked = false;

  // Sub-panel: next action on close
  actionStage2Id: number | null = null;
  selectedReasons2: number[] = [];
  quotationAmt2: number | null = null;
  assignedTo2: number | null = null;
  salesPerson2Id: number | null = null;
  actionDate2: Date | null = new Date();
  actionTime2 = '';
  desc2 = '';
  actionRemark2 = '';

  // Assigned To (Add panel), Completed By (Close panel), and Assigned To 2
  // (the Add Next Action sub-flow) all default to the logged-in user, per
  // explicit request — falls back to the first user in the list if the
  // current user isn't in it for some reason (this fallback is why Assigned
  // To 2 previously always showed "Abhijit Pathak": with no current-user
  // match applied at all, it always landed on users()[0], the alphabetically
  // first user, which reads as a hardcoded name but was really just an
  // unset default). Shared by ngOnInit's initial load and resetFormState so
  // the default doesn't revert to the first user again after the form resets.
  private defaultCurrentUser(): number | null {
    const currentUserId = this.auth.currentUser()?.userId;
    const users = this.users();
    if (currentUserId && users.some((u) => u.value === currentUserId)) {
      return currentUserId;
    }
    return users[0]?.value ?? null;
  }

  // Sales Person (Add panel) also defaults to the logged-in user, per the
  // same request as Assigned To above. Unlike Assigned To, the salesmen
  // list comes from a separate `SalesMan` table with its own SalesManId —
  // not the same ID space as UserMaster.UserID — so there's no ID to match
  // on. Matched by name instead; if the current user isn't a salesman (not
  // every logged-in user is one), no default is applied and the field stays
  // blank/editable rather than falling back to an arbitrary first entry.
  private defaultCurrentSalesman(): number | null {
    const currentUserName = this.auth.currentUser()?.userName?.trim().toLowerCase();
    if (!currentUserName) {
      return null;
    }
    return this.salesmen().find((s) => s.label.trim().toLowerCase() === currentUserName)?.value ?? null;
  }

  private resetFormState(): void {
    this.actionStageId = null;
    this.competitorId = null;
    this.selectedReasons1 = [];
    this.quotationAmt1 = null;
    this.assignedTo = this.defaultCurrentUser();
    this.salesPersonId = this.defaultCurrentSalesman();
    this.specialRating = '';
    this.actionDate = new Date();
    this.actionTime = this.nowTime();
    this.desc = '';
    this.actionRemark = '';
    this.closeAction = false;
    this.assignedToLocked = false;
    this.otherFieldsLocked = false;

    this.completedBy = this.defaultCurrentUser();
    this.actionStage3Id = null;
    this.selectedReasonsClose = [];
    this.quotationAmtClose = null;
    this.salesmanId = null;
    this.specialRatingClose = '';
    this.completedDate = new Date();
    this.completedTime = this.nowTime();
    this.narration = '';
    this.addNewAction = false;
    this.completedByLocked = false;
    this.closeOtherFieldsLocked = false;

    this.sipExtMobile = '';
    this.sipExtPhone = '';

    this.actionStage2Id = null;
    this.selectedReasons2 = [];
    this.quotationAmt2 = null;
    this.assignedTo2 = this.defaultCurrentUser();
    this.salesPerson2Id = this.defaultCurrentSalesman();
    this.actionDate2 = new Date();
    this.actionTime2 = this.nowTime();
    this.desc2 = '';
    this.actionRemark2 = '';
    this.reasonSearch1 = this.reasonSearchClose = this.reasonSearch2 = '';
    this.reasonOpen1 = this.reasonOpenClose = this.reasonOpen2 = false;
    this.errorMessage.set(null);
  }

  // getEnquiryActionForModify's ActionTime/CompletionTime columns are real
  // SQL datetime values on a dummy 1900-01-01 date — the API stringifies
  // them as-is (e.g. "1900-01-01 17:57:00"), not bare "HH:mm" as an earlier
  // version of this comment assumed. The previous parser anchored its regex
  // to the start of the string (`^(\d{1,2}):(\d{2})`), which never matched
  // that shape at all — Action Time / Completed Time silently came back
  // blank every single time an existing action was opened for modify,
  // confirmed against real saved rows. Searching for the H(H):MM pattern
  // anywhere in the string (no `^` anchor) finds it regardless of whatever
  // prefix precedes it, and zero-pads a single-digit hour so the result is
  // always valid input for a native <input type="time">.
  private normalizeTimeString(value: string | null | undefined): string {
    if (!value) {
      return '';
    }
    const match = /(\d{1,2}):(\d{2})/.exec(value);
    return match ? `${match[1].padStart(2, '0')}:${match[2]}` : '';
  }

  get actionStageLabel(): string {
    return this.actionStages().find((s) => s.value === this.actionStageId)?.label ?? '';
  }

  get actionStage2Label(): string {
    return this.actionStages().find((s) => s.value === this.actionStage2Id)?.label ?? '';
  }

  get actionStage3Label(): string {
    return this.actionStages().find((s) => s.value === this.actionStage3Id)?.label ?? '';
  }

  // Stashed so a Retry click can redo exactly the same load the initial
  // navigation attempted, without needing to re-read the route.
  private lastRequestId = 0;
  private lastLockedStageId: number | null = null;

  ngOnInit(): void {
    this.data.getCompetitors().subscribe((c) => this.competitors.set(c));
    this.loadReasons();
    this.loadUsers();

    // Reached from many different "Next Step" links across the app (the
    // register grid, AmcPending, CustomerLicenseViolation, etc.), all
    // pointing at this same route with different CustID/RefActionID — since
    // Angular reuses the component instance rather than re-running ngOnInit
    // when only query params change, reading them via a one-time snapshot
    // would keep showing the PREVIOUS customer's action after clicking
    // "Next Step" on a different row without an intervening full navigation
    // away. Subscribing to queryParamMap re-runs this init logic every time.
    const embedded = this.embeddedParams();
    if (embedded) {
      this.applyParams({ get: (k: string) => (embedded[k] == null ? null : String(embedded[k])) });
      return;
    }
    this.route.queryParamMap.subscribe((q) => this.applyParams(q));
  }

  private applyParams(q: { get(key: string): string | null }): void {
    {
      const requestId = ++this.requestId;
      this.resetFormState();
      this.actionType = Number(q.get('ActionType') ?? 1);
      this.custId = Number(q.get('CustID') ?? 0);
      this.refActionId = Number(q.get('RefActionID') ?? 0);
      this.mobileNo = q.get('MobileNo') ?? '';
      this.phoneNo = q.get('PhoneNo') ?? '';
      this.callPanelVisible = this.mobileNo.trim() !== '' || this.phoneNo.trim() !== '';
      this.isModify = q.get('Ismodify') === '1';
      this.stageLocked = q.get('FromAMCPending') === '1' || q.get('ActionStageID') === '27' || q.get('ActionStageID') === '28';
      const lockedStageId = q.get('FromAMCPending') === '1' ? 18 : q.get('ActionStageID') ? Number(q.get('ActionStageID')) : null;
      this.lastRequestId = requestId;
      this.lastLockedStageId = lockedStageId;

      this.customerInfo.set(null);
      this.customerInfoError.set(null);
      if (this.custId) {
        this.loadCustomerInfo(requestId);
      }

      this.loadActionStages(requestId, lockedStageId);

      if (this.isModify) {
        this.loadModifyPrefill(requestId);
      }
      this.cdr.markForCheck();
    }
  }

  private finish(): void {
    if (this.embeddedParams()) {
      this.saved.emit();
    } else {
      this.location.back();
    }
  }

  private loadModifyPrefill(requestId: number): void {
    this.modifyPrefillError.set(null);
    this.data.getEnquiryActionForModify(this.custId, this.refActionId).subscribe({
      next: (info) => {
        if (requestId !== this.requestId) {
          return;
        }
        if (!info) {
          this.modifyPrefillError.set(
            "Could not find this action's saved details — the fields below are blank rather than showing the real saved values."
          );
          this.cdr.markForCheck();
          return;
        }
        if (this.actionType === 1) {
          this.quotationAmt1 = info.quotationAmt;
          this.desc = info.actionDescription;
          this.actionRemark = info.actionRemark;
          this.actionDate = new Date(info.actionDate);
          this.actionTime = this.normalizeTimeString(info.actionTime);
          this.assignedToLocked = true;
          this.otherFieldsLocked = true;
        } else {
          this.quotationAmtClose = info.quotationAmt;
          this.narration = info.completedRemark;
          this.completedDate = new Date(info.completionDate);
          this.completedTime = this.normalizeTimeString(info.completionTime);
          this.completedByLocked = true;
          this.closeOtherFieldsLocked = true;
        }
        this.cdr.markForCheck();
      },
      error: () => {
        if (requestId !== this.requestId) {
          return;
        }
        this.modifyPrefillError.set(
          "Could not load this action's saved details — the fields below are blank rather than showing the real saved values."
        );
        this.cdr.markForCheck();
      }
    });
  }

  retryModifyPrefill(): void {
    this.loadModifyPrefill(this.lastRequestId);
  }

  private loadCustomerInfo(requestId: number): void {
    this.customerInfoLoading.set(true);
    this.customerInfoError.set(null);
    this.data.getCustomerRegisterInfo(this.custId).subscribe({
      next: (info) => {
        if (requestId !== this.requestId) {
          return;
        }
        this.customerInfoLoading.set(false);
        if (!info) {
          this.customerInfoError.set(`No customer found for Customer ID ${this.custId}.`);
        } else {
          this.customerInfo.set(info);
        }
        this.cdr.markForCheck();
      },
      error: () => {
        if (requestId !== this.requestId) {
          return;
        }
        this.customerInfoLoading.set(false);
        this.customerInfoError.set('Could not load Customer Information.');
        this.cdr.markForCheck();
      }
    });
  }

  retryCustomerInfo(): void {
    this.customerInfo.set(null);
    this.loadCustomerInfo(this.lastRequestId);
  }

  private loadUsers(): void {
    this.usersLoading.set(true);
    this.usersError.set(null);
    this.data.getUsers().subscribe({
      next: (u) => {
        this.usersLoading.set(false);
        this.users.set(u);
        this.assignedTo = this.defaultCurrentUser();
        this.completedBy = this.defaultCurrentUser();
        this.assignedTo2 = this.defaultCurrentUser();
        this.cdr.markForCheck();
      },
      error: () => {
        this.usersLoading.set(false);
        this.usersError.set('Could not load the Users list.');
        this.cdr.markForCheck();
      }
    });
  }

  retryUsers(): void {
    this.loadUsers();
  }

  private loadReasons(): void {
    this.reasonsLoading.set(true);
    this.reasonsError.set(null);
    this.data.getThanksNoteReasons().subscribe({
      next: (r) => {
        this.reasonsLoading.set(false);
        this.reasons.set(r);
        this.cdr.markForCheck();
      },
      error: () => {
        this.reasonsLoading.set(false);
        this.reasonsError.set('Could not load the Thanks Note reason list.');
        this.cdr.markForCheck();
      }
    });
  }

  retryReasons(): void {
    this.loadReasons();
  }

  // Fetched fresh (not cached) on every load/retry — these are small,
  // fast, single-table lookups, and a fresh call each time means one bad
  // request can never leave this permanently broken for the rest of the
  // component's lifetime the way the previous shareReplay(1)-cached
  // versions could (shareReplay does not recover after its source errors;
  // once salesmen$/specialRatings$ failed once, every later "Next Step"
  // navigation reusing this same component instance would fail forever,
  // taking the Sales Person/Special Rating dropdowns AND the
  // enquiry-action-context prefill down with it).
  private fetchSalesmen(): Observable<LookupOption[]> {
    this.salesmenLoading.set(true);
    this.salesmenError.set(null);
    return this.data.getSalesmen().pipe(
      tap((s) => {
        this.salesmenLoading.set(false);
        this.salesmen.set(s);
        // Salesmen load after resetFormState() already tried (and likely
        // failed, since the list was still empty then) to default Sales
        // Person / Sales Person 2 to the current user. Re-apply now that
        // real data is here — but only if nothing has set it since (a
        // manual pick, or a previously-saved action's context, which both
        // take precedence).
        if (this.salesPersonId === null) {
          this.salesPersonId = this.defaultCurrentSalesman();
        }
        if (this.salesPerson2Id === null) {
          this.salesPerson2Id = this.defaultCurrentSalesman();
        }
        this.cdr.markForCheck();
      }),
      catchError(() => {
        this.salesmenLoading.set(false);
        this.salesmenError.set('Could not load the Sales Person list.');
        this.cdr.markForCheck();
        return of([] as LookupOption[]);
      })
    );
  }

  private fetchSpecialRatings(): Observable<string[]> {
    this.specialRatingsLoading.set(true);
    this.specialRatingsError.set(null);
    return this.data.getSpecialRatings().pipe(
      tap((r) => {
        this.specialRatingsLoading.set(false);
        this.specialRatings.set(r);
        this.cdr.markForCheck();
      }),
      catchError(() => {
        this.specialRatingsLoading.set(false);
        this.specialRatingsError.set('Could not load the Special Rating list.');
        this.cdr.markForCheck();
        return of([] as string[]);
      })
    );
  }

  retrySalesmen(): void {
    this.fetchSalesmen().subscribe();
  }

  retrySpecialRatings(): void {
    this.fetchSpecialRatings().subscribe();
  }

  private loadActionStages(requestId: number, lockedStageId: number | null): void {
    this.actionStagesLoading.set(true);
    this.actionStagesError.set(null);
    this.data.getActionStages().subscribe({
      next: (stages) => {
        if (requestId !== this.requestId) {
          return;
        }
        this.actionStagesLoading.set(false);
        this.actionStages.set(stages);
        if (lockedStageId) {
          this.actionStageId = this.actionStage2Id = this.actionStage3Id = lockedStageId;
          this.fetchSalesmen().subscribe();
          this.fetchSpecialRatings().subscribe();
          this.cdr.markForCheck();
        } else if (this.custId && this.refActionId) {
          combineLatest([this.fetchSalesmen(), this.fetchSpecialRatings()])
            .pipe(switchMap(() => this.data.getEnquiryActionContext(this.custId, this.refActionId)))
            .subscribe({
              next: (ctx) => {
                if (requestId !== this.requestId) {
                  return;
                }
                this.actionStageId = this.actionStage3Id = ctx.actionStageId;
                this.salesPersonId = this.salesmanId = ctx.salesmanId;
                this.specialRating = this.specialRatingClose = ctx.specialRating;
                this.cdr.markForCheck();
              },
              error: () => {
                if (requestId !== this.requestId) {
                  return;
                }
                this.errorMessage.set(
                  "Could not load this action's existing stage/sales person/rating — you can still fill them in manually."
                );
                this.cdr.markForCheck();
              }
            });
        } else {
          this.fetchSalesmen().subscribe();
          this.fetchSpecialRatings().subscribe();
        }
      },
      error: () => {
        if (requestId !== this.requestId) {
          return;
        }
        this.actionStagesLoading.set(false);
        this.actionStagesError.set('Could not load the Action Stage list.');
        this.cdr.markForCheck();
      }
    });
  }

  retryActionStages(): void {
    this.loadActionStages(this.lastRequestId, this.lastLockedStageId);
  }

  // Thanks Note reasons: type-ahead that only lists reasons matching what's
  // typed (already-picked ones excluded), instead of a long checkbox list.
  // Thanks Note reasons: search box + small scrolling checkbox list that
  // opens on focus/typing and closes on Enter; picked ones show as chips.
  reasonSearch1 = '';
  reasonSearchClose = '';
  reasonSearch2 = '';
  reasonOpen1 = false;
  reasonOpenClose = false;
  reasonOpen2 = false;

  filterReasons(query: string): LookupOption[] {
    const q = query.trim().toLowerCase();
    return q ? this.reasons().filter((r) => r.label.toLowerCase().includes(q)) : this.reasons();
  }

  reasonLabel(id: number): string {
    return this.reasons().find((r) => r.value === id)?.label ?? String(id);
  }

  toggleReason(list: number[], id: number): number[] {
    return list.includes(id) ? list.filter((r) => r !== id) : [...list, id];
  }

  toggleReason1(id: number): void {
    this.selectedReasons1 = this.toggleReason(this.selectedReasons1, id);
  }

  toggleReasonClose(id: number): void {
    this.selectedReasonsClose = this.toggleReason(this.selectedReasonsClose, id);
  }

  toggleReason2(id: number): void {
    this.selectedReasons2 = this.toggleReason(this.selectedReasons2, id);
  }

  callNow(contactNo: string, sipExt: string): void {
    alert(`Dialing ${contactNo} via SIP ext ${sipExt} (external Synapse integration — not wired up without a backend)`);
  }

  private validateStageFields(stageLabel: string, quotationAmt: number | null, reasons: number[]): string | null {
    if (stageLabel === 'Quotation' && !quotationAmt) {
      return 'Please enter amount.';
    }
    if (stageLabel === 'Thanks Note' && reasons.length === 0) {
      return 'Please select minimum one Thank Note reason.';
    }
    if (stageLabel === 'Thanks Note' && reasons.length > 3) {
      return 'Maximum Three thanks note reason should be selected';
    }
    return null;
  }

  submitAdd(): void {
    // Action Time is no longer mandatory, per explicit request — scoped to
    // just this Add panel's check (Close's Completed Time and the
    // add-new-action sub-flow's Action Time are untouched).
    if (!this.actionStageId || !this.assignedTo || !this.actionDate || !this.desc.trim()) {
      this.errorMessage.set('Please fill Action Stage, Assigned To, Action Date and Action Description.');
      return;
    }
    const stageError = this.validateStageFields(this.actionStageLabel, this.quotationAmt1, this.selectedReasons1);
    if (stageError) {
      this.errorMessage.set(stageError);
      return;
    }
    this.errorMessage.set(null);
    this.saving.set(true);
    this.data
      .addEnquiryAction({
        custId: this.custId,
        refActionId: this.refActionId,
        actionStageId: this.actionStageId,
        actionDate: this.actionDate,
        // @ActionTime on the backend proc is a real SQL datetime parameter,
        // not free text — since Action Time is no longer required, default
        // to the current time when none was picked instead of sending a
        // blank/invalid value the database can't convert.
        actionTime: this.actionTime || new Date().toTimeString().slice(0, 5),
        description: this.desc,
        assignedTo: this.assignedTo,
        remark: this.actionRemark,
        closeAction: this.closeAction,
        salesPersonId: this.salesPersonId ?? 0,
        competitorId: this.competitorId ?? 0,
        specialRating: this.specialRating,
        reasons: this.selectedReasons1,
        quotationAmt: this.quotationAmt1 ?? 0,
        isModify: this.isModify
      })
      .subscribe({
        next: () => {
          this.saving.set(false);
          this.finish();
        },
        error: () => {
          this.saving.set(false);
          this.errorMessage.set('Could not save this action — please check the fields and try again.');
        }
      });
  }

  submitClose(): void {
    if (!this.completedBy || !this.actionStage3Id || !this.completedDate || !this.completedTime || !this.narration.trim()) {
      this.errorMessage.set('Please fill Completed By, Action Stage, Completed Date, Completed Time and Completed Remark.');
      return;
    }
    const stageError = this.validateStageFields(this.actionStage3Label, this.quotationAmtClose, this.selectedReasonsClose);
    if (stageError) {
      this.errorMessage.set(stageError);
      return;
    }
    if (this.addNewAction) {
      const nextError = this.validateStageFields(this.actionStage2Label, this.quotationAmt2, this.selectedReasons2);
      if (nextError) {
        this.errorMessage.set(nextError);
        return;
      }
    }
    if (this.addNewAction && !this.actionTime2) {
      this.errorMessage.set('Please fill Action Time for the next action.');
      return;
    }
    this.errorMessage.set(null);
    this.saving.set(true);
    this.data
      .closeEnquiryAction({
        custId: this.custId,
        refActionId: this.refActionId,
        completedBy: this.completedBy,
        completedDate: this.completedDate,
        completedTime: this.completedTime,
        salesmanId: this.salesmanId ?? 0,
        narration: this.narration,
        actionStageId: this.actionStage3Id,
        specialRating: this.specialRatingClose,
        reasons: this.selectedReasonsClose,
        quotationAmt: this.quotationAmtClose ?? 0,
        addNewAction: this.addNewAction
          ? {
              actionStageId: this.actionStage2Id ?? 0,
              actionDate: this.actionDate2 ?? new Date(),
              actionTime: this.actionTime2,
              description: this.desc2,
              assignedTo: this.assignedTo2 ?? 0,
              remark: this.actionRemark2,
              salesPersonId: this.salesPerson2Id ?? 0,
              reasons: this.selectedReasons2,
              quotationAmt: this.quotationAmt2 ?? 0
            }
          : undefined
      })
      .subscribe({
        next: () => {
          this.saving.set(false);
          this.finish();
        },
        error: () => {
          this.saving.set(false);
          this.errorMessage.set('Could not save this action — please check the fields and try again.');
        }
      });
  }

  cancel(): void {
    if (this.embeddedParams()) {
      this.cancelled.emit();
    } else {
      this.location.back();
    }
  }
}
