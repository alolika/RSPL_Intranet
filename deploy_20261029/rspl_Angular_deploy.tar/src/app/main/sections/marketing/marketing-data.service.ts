import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map, timeout } from 'rxjs';

import { API_BASE_URL } from '../../../shared/api-config';

const BASE = API_BASE_URL;
const AMC = `${API_BASE_URL}/support/amc`;
const ENQ = `${API_BASE_URL}/marketing/enquiry`;
const REG = `${API_BASE_URL}/marketing/register`;
const REGN = `${API_BASE_URL}/marketing/registration`;
const RPT = `${API_BASE_URL}/marketing/reports`;
const OPS = `${API_BASE_URL}/marketing/ops`;
const LEAD = `${API_BASE_URL}/marketing/lead`;
const GEO = `${API_BASE_URL}/marketing/geo`;
const TOUR = `${API_BASE_URL}/marketing/tour`;
const REFERRAL = `${API_BASE_URL}/marketing/referral`;

interface ApiCustEnquiryRegisterRow {
  cust_id: number;
  enquiry_date: string | null;
  stage_percent: number;
  received_by: string;
  narration: string;
  segment_name: string;
  business_nature_name: string;
  source_type_name: string;
  source_narration: string;
  introduced_by_name: string;
  referred_by_name: string;
  current_software: string;
  campaign_name: string;
  case_type: string;
  hardware_partner: string;
  source_type_2_name: string;
  source_date_2: string | null;
}

function toCustEnquiryRegisterRow(r: ApiCustEnquiryRegisterRow): CustEnquiryRegisterRow {
  return {
    custId: r.cust_id,
    enquiryDate: r.enquiry_date ?? '',
    stagePercent: r.stage_percent,
    receivedBy: r.received_by,
    narration: r.narration,
    segmentName: r.segment_name,
    businessNatureName: r.business_nature_name,
    sourceTypeName: r.source_type_name,
    sourceNarration: r.source_narration,
    introducedByName: r.introduced_by_name,
    referredByName: r.referred_by_name,
    currentSoftware: r.current_software,
    campaignName: r.campaign_name,
    caseType: r.case_type,
    hardwarePartner: r.hardware_partner,
    sourceType2Name: r.source_type_2_name,
    // Already ISO "YYYY-MM-DD" (or null) from the backend — bound straight
    // into the template's DatePipe, same as enquiryDate above, so there's no
    // Date object round-trip here to risk a timezone-driven day shift.
    sourceDate2: r.source_date_2
  };
}

interface ApiEnquiryRegisterActionRow {
  action_id: number;
  action_stage: string;
  creation_date: string | null;
  creation_time: string;
  created_by: string;
  action_date: string | null;
  action_time: string;
  assigned_to: string;
  action_description: string;
  action_remark: string;
  completion_date: string | null;
  completion_time: string;
  completed_by: string;
  completed_remark: string;
  sales_person: string;
  voucher_no: string;
  to_do_voucher_no: string;
  action_stage_status: string;
  quotation_amt: number;
  next_action: string;
}

function toEnquiryRegisterActionRow(r: ApiEnquiryRegisterActionRow): EnquiryRegisterActionRow {
  return {
    actionId: r.action_id,
    actionStage: r.action_stage,
    creationDate: r.creation_date ?? '',
    creationTime: r.creation_time,
    createdBy: r.created_by,
    actionDate: r.action_date ?? '',
    actionTime: r.action_time,
    assignedTo: r.assigned_to,
    actionDescription: r.action_description,
    actionRemark: r.action_remark,
    completionDate: r.completion_date ?? '',
    completionTime: r.completion_time,
    completedBy: r.completed_by,
    completedRemark: r.completed_remark,
    salesPerson: r.sales_person,
    voucherNo: r.voucher_no,
    toDoVoucherNo: r.to_do_voucher_no,
    actionStageStatus: r.action_stage_status,
    quotationAmt: r.quotation_amt,
    nextAction: r.next_action as EnquiryRegisterActionRow['nextAction']
  };
}

interface ApiActionStageDetailRow {
  cust_id: number;
  date: string | null;
  name: string;
  segment: string;
  source_detail: string;
  city: string;
  salesman: string;
  order_value: number;
  area: string;
}

function toActionStageDetailRow(r: ApiActionStageDetailRow): ActionStageDetailRow {
  return {
    custId: r.cust_id,
    date: r.date ?? '',
    name: r.name,
    segment: r.segment,
    sourceDetail: r.source_detail,
    city: r.city,
    salesman: r.salesman,
    orderValue: r.order_value,
    area: r.area
  };
}

interface ApiActionSearchRow {
  cust_id: number;
  cust_name: string;
  city: string;
  action_stage: string;
  action_description: string;
  action_date: string | null;
  action_time: string;
  completed_remark: string;
  assigned_to: string;
  created_by: string;
  action_remark: string;
  action_completed: boolean;
  completed_by: string;
  sales_person: string;
  action_stage_status: string;
}

function toActionSearchRow(r: ApiActionSearchRow): ActionSearchRow {
  return {
    custId: r.cust_id,
    custName: r.cust_name,
    city: r.city,
    actionStage: r.action_stage,
    actionDescription: r.action_description,
    actionDate: r.action_date ?? '',
    actionTime: r.action_time,
    completedRemark: r.completed_remark,
    assignedTo: r.assigned_to,
    createdBy: r.created_by,
    actionRemark: r.action_remark,
    actionCompleted: r.action_completed,
    completedBy: r.completed_by,
    salesPerson: r.sales_person,
    actionStageStatus: r.action_stage_status
  };
}

interface ApiCrmReportRow {
  cust_id: number;
  enquiry_date: string | null;
  display_name: string;
  city: string;
  mobile_no: string;
  email: string;
  contact_person: string;
  address: string;
  source_narration: string;
  received_by: string;
  communication_details: string;
  salesman: string;
}

function toCrmReportRow(r: ApiCrmReportRow): CrmReportRow {
  return {
    custId: r.cust_id,
    enquiryDate: r.enquiry_date ?? '',
    displayName: r.display_name,
    city: r.city,
    mobileNo: r.mobile_no,
    email: r.email,
    contactPerson: r.contact_person,
    address: r.address,
    sourceNarration: r.source_narration,
    receivedBy: r.received_by,
    communicationDetails: r.communication_details,
    salesman: r.salesman
  };
}

interface ApiCrmActivityRow {
  user_id: number;
  cust_id: number;
  activity_id: number;
  crm_activity: string;
  activity_date_time: string;
}

function toCrmActivityRow(r: ApiCrmActivityRow): CrmActivityRow {
  return {
    userId: r.user_id,
    custId: r.cust_id,
    activityId: r.activity_id,
    crmActivity: r.crm_activity,
    activityDateTime: r.activity_date_time
  };
}

interface ApiLeadRecordRow {
  cust_id: number;
  display_name: string;
  cust_address: string;
  area: string;
  city: string;
  district_name: string;
  pincode: string;
  contact_number: string;
  received_on: string | null;
  enquiry_created_on: string | null;
  first_received_by: string;
  assigned_to: string;
  sales_person: string;
  enquiry_source: string;
  vertical_name: string;
  segment_name: string;
  hardware_partner: string;
  referred_by_customer: string;
  old_software: string;
  converted_to_so: string;
  so_number: number | null;
  so_date: string | null;
  so_amount: number;
  special_rating: string;
  campaign: string;
  narration: string;
}

function toLeadRecordRow(r: ApiLeadRecordRow): LeadRecordRow {
  return {
    custId: r.cust_id,
    displayName: r.display_name,
    custAddress: r.cust_address,
    area: r.area,
    city: r.city,
    districtName: r.district_name,
    pincode: r.pincode,
    contactNumber: r.contact_number,
    receivedOn: r.received_on ?? '',
    enquiryCreatedOn: r.enquiry_created_on ?? '',
    firstReceivedBy: r.first_received_by,
    assignedTo: r.assigned_to,
    salesPerson: r.sales_person,
    enquirySource: r.enquiry_source,
    verticalName: r.vertical_name,
    segmentName: r.segment_name,
    hardwarePartner: r.hardware_partner,
    referredByCustomer: r.referred_by_customer,
    oldSoftware: r.old_software,
    convertedToSo: r.converted_to_so,
    soNumber: r.so_number,
    soDate: r.so_date,
    soAmount: r.so_amount,
    specialRating: r.special_rating,
    campaign: r.campaign,
    narration: r.narration
  };
}

interface ApiOutstandingFollowupRow {
  cust_id: number;
  sales_man: string;
  display_name: string;
  city: string;
  mobile_no: string;
  ledger_balance: number;
  ledger_group_balance: number;
  amc_amount: number;
  amc_due_date: string | null;
}

function toOutstandingFollowupRow(r: ApiOutstandingFollowupRow): OutstandingFollowupRow {
  return {
    custId: r.cust_id,
    salesMan: r.sales_man,
    displayName: r.display_name,
    city: r.city,
    mobileNo: r.mobile_no,
    ledgerBalance: r.ledger_balance,
    ledgerGroupBalance: r.ledger_group_balance,
    amcAmount: r.amc_amount,
    amcDueDate: r.amc_due_date ?? ''
  };
}

interface ApiDownloadedEnquiryRow {
  cust_id: number;
  customer_name: string;
  city: string;
  narration: string;
  enquiry_date: string | null;
  assigned_user_id: number;
  assigned_to: string;
  segment_name: string;
  business_nature_name: string;
}

function toDownloadedEnquiryRow(r: ApiDownloadedEnquiryRow): DownloadedEnquiryRow {
  return {
    custId: r.cust_id,
    customerName: r.customer_name,
    city: r.city,
    narration: r.narration,
    enquiryDate: r.enquiry_date ?? '',
    assignedUserId: r.assigned_user_id,
    assignedTo: r.assigned_to,
    segmentName: r.segment_name,
    businessNatureName: r.business_nature_name
  };
}

interface ApiLeadSummaryRow {
  type_id: number;
  type_name: string;
  leads_generated: number;
  leads_converted: number;
  lead_conversion_rate: number;
  no_of_transactions: number;
  sale_revenue: number;
  amc_visit_revenue: number;
  total_revenue: number;
}

function toLeadSummaryRow(r: ApiLeadSummaryRow): LeadSummaryRow {
  return {
    typeId: r.type_id,
    typeName: r.type_name,
    leadsGenerated: r.leads_generated,
    leadsConverted: r.leads_converted,
    leadConversionRate: r.lead_conversion_rate,
    noOfTransactions: r.no_of_transactions,
    saleRevenue: r.sale_revenue,
    amcVisitRevenue: r.amc_visit_revenue,
    totalRevenue: r.total_revenue
  };
}

interface ApiLeadSummaryDetailRow {
  cust_id: number;
  generated: boolean;
  converted: boolean;
  assigned_to: string;
  enquiry_date: string | null;
  customer_name: string;
  mobile_no: string;
  vertical_name: string;
  segment_name: string;
  source_type_name: string;
  source_narration: string;
  city: string;
  contact_person: string;
  existing_software: string;
}

function toLeadSummaryDetailRow(r: ApiLeadSummaryDetailRow): LeadSummaryDetailRow {
  return {
    custId: r.cust_id,
    generated: r.generated,
    converted: r.converted,
    assignedTo: r.assigned_to,
    enquiryDate: r.enquiry_date ?? '',
    customerName: r.customer_name,
    mobileNo: r.mobile_no,
    verticalName: r.vertical_name,
    segmentName: r.segment_name,
    sourceTypeName: r.source_type_name,
    sourceNarration: r.source_narration,
    city: r.city,
    contactPerson: r.contact_person,
    existingSoftware: r.existing_software
  };
}

interface ApiTourCityRow {
  city: string;
  tour_count: number;
}

function toTourCityRow(r: ApiTourCityRow): TourCityRow {
  return { city: r.city, tourCount: r.tour_count };
}

interface ApiTourReportRow {
  user_name: string;
  visit_type: string;
  mode_of_travel: string;
  city: string;
  customer: string;
  date: string | null;
  payment_voucher_no: string;
  month: string;
  amount: number;
}

function toTourReportRow(r: ApiTourReportRow): TourReportRow {
  return {
    userName: r.user_name,
    visitType: r.visit_type,
    modeOfTravel: r.mode_of_travel,
    city: r.city,
    customer: r.customer,
    date: r.date ?? '',
    paymentVoucherNo: r.payment_voucher_no,
    month: r.month,
    amount: r.amount
  };
}

interface ApiEReferralRow {
  request_sr_no: number;
  referral_voucher_no: string;
  shop_name: string;
  shop_address: string;
  shop_city: string;
  shop_contact_person: string;
  shop_mobile_no: string;
  email_address: string;
  introduced_by_shop_name: string;
  introduce_by_name: string;
  introduced_by_shop_city: string;
  introduced_by_mobile_no: string;
  creation_date: string;
  creation_time: string;
  remark: string;
}

function toEReferralRow(r: ApiEReferralRow): EReferralRow {
  return {
    requestSrNo: r.request_sr_no,
    referralVoucherNo: r.referral_voucher_no,
    shopName: r.shop_name,
    shopAddress: r.shop_address,
    shopCity: r.shop_city,
    shopContactPerson: r.shop_contact_person,
    shopMobileNo: r.shop_mobile_no,
    emailAddress: r.email_address,
    introducedByShopName: r.introduced_by_shop_name,
    introduceByName: r.introduce_by_name,
    introducedByShopCity: r.introduced_by_shop_city,
    introducedByMobileNo: r.introduced_by_mobile_no,
    creationDate: r.creation_date,
    creationTime: r.creation_time,
    remark: r.remark
  };
}

interface ApiTeleCallingRow {
  cust_id: number;
  next_action: string;
  ref_action_id: number;
  mobile_no: string;
  ph_no: string;
  enquiry_date: string | null;
  shop_name: string;
  contact_person: string;
  city: string;
  received_by: string;
  narration: string;
  segment_name: string;
  business_nature_name: string;
  source_type_name: string;
  introduced_by_name: string;
  communication_method_name: string;
  referred_by_name: string;
}

function toTeleCallingRow(r: ApiTeleCallingRow): TeleCallingRow {
  return {
    custId: r.cust_id,
    nextAction: r.next_action as TeleCallingRow['nextAction'],
    refActionId: r.ref_action_id,
    mobileNo: r.mobile_no,
    phNo: r.ph_no,
    enquiryDate: r.enquiry_date ?? '',
    shopName: r.shop_name,
    contactPerson: r.contact_person,
    city: r.city,
    receivedBy: r.received_by,
    narration: r.narration,
    segmentName: r.segment_name,
    businessNatureName: r.business_nature_name,
    sourceTypeName: r.source_type_name,
    introducedByName: r.introduced_by_name,
    communicationMethodName: r.communication_method_name,
    referredByName: r.referred_by_name
  };
}

interface ApiTeleCallingActionRow {
  action_id: number;
  action_stage: string;
  action_stage_status: string;
  creation_date: string | null;
  creation_time: string;
  created_by: string;
  action_date: string | null;
  action_time: string;
  assigned_to: string;
  action_description: string;
  action_remark: string;
  completion_date: string | null;
  completion_time: string;
  completed_by: string;
  completed_remark: string;
  sales_person: string;
  voucher_no: string;
  to_do_voucher_no: string;
}

function toTeleCallingActionRow(r: ApiTeleCallingActionRow): TeleCallingActionRow {
  return {
    actionId: r.action_id,
    actionStage: r.action_stage,
    actionStageStatus: r.action_stage_status,
    creationDate: r.creation_date ?? '',
    creationTime: r.creation_time,
    createdBy: r.created_by,
    actionDate: r.action_date ?? '',
    actionTime: r.action_time,
    assignedTo: r.assigned_to,
    actionDescription: r.action_description,
    actionRemark: r.action_remark,
    completionDate: r.completion_date ?? '',
    completionTime: r.completion_time,
    completedBy: r.completed_by,
    completedRemark: r.completed_remark,
    salesPerson: r.sales_person,
    voucherNo: r.voucher_no,
    toDoVoucherNo: r.to_do_voucher_no
  };
}

interface ApiCustGeoRow {
  cust_id: number;
  customer_name: string;
  vertical_id: number;
  vertical_name: string;
  segment_name: string;
  enquiry_source_type_name: string;
  location_address: string;
  latitude: number;
  longitude: number;
}

function toCustGeoRow(r: ApiCustGeoRow): CustGeoRow {
  return {
    custId: r.cust_id,
    customerName: r.customer_name,
    verticalId: r.vertical_id,
    verticalName: r.vertical_name,
    segmentName: r.segment_name,
    enquirySourceTypeName: r.enquiry_source_type_name,
    locationAddress: r.location_address,
    latitude: r.latitude,
    longitude: r.longitude
  };
}

interface ApiEntityLatLongOption {
  cust_id: number;
  display_name: string;
  location_name: string;
  latitude: string;
  longitude: string;
}

function toEntityLatLongOption(r: ApiEntityLatLongOption): EntityLatLongOption {
  return {
    custId: r.cust_id,
    displayName: r.display_name,
    locationName: r.location_name,
    latitude: r.latitude,
    longitude: r.longitude
  };
}

interface ApiCustEnquiryHistoryRow {
  shop_name: string;
  enquiry_date: string | null;
  source_type_name: string;
  source_narration: string;
  received_by_name: string;
  assigned_to_name: string;
  no_of_outlets: string;
  ownership_name: string;
  business_nature_name: string;
  size_of_shop: string;
  goods_sold: string;
  present_billing_system: string;
  modules: string;
  creation_date: string | null;
  order_value: string;
  narration: string;
}

function toCustEnquiryHistoryRow(r: ApiCustEnquiryHistoryRow): CustEnquiryHistoryRow {
  return {
    shopName: r.shop_name,
    enquiryDate: r.enquiry_date ?? '',
    sourceTypeName: r.source_type_name,
    sourceNarration: r.source_narration,
    receivedByName: r.received_by_name,
    assignedToName: r.assigned_to_name,
    noOfOutlets: r.no_of_outlets,
    ownershipName: r.ownership_name,
    businessNatureName: r.business_nature_name,
    sizeOfShop: r.size_of_shop,
    goodsSold: r.goods_sold,
    presentBillingSystem: r.present_billing_system,
    modules: r.modules,
    creationDate: r.creation_date ?? '',
    orderValue: r.order_value,
    narration: r.narration
  };
}

interface ApiEnquiryStatusRow {
  assigned_to_user_id: number;
  assigned_to: string;
  assigned_to_mobile: string;
  assigned_to_email: string;
  enquiry_count: number;
  progress_percent: number;
  last_action_date: string | null;
}

interface ApiEnquiryStatusDetailRow {
  cust_id: number;
  customer_name: string;
  segment_name: string;
  stage_percent: number;
  last_action_date: string | null;
  is_auto: boolean;
  enquiry_date: string | null;
  mobile_no: string;
  area: string;
  city: string;
}

export interface LookupOption {
  label: string;
  value: number;
}

/** Data service backing Section_Marketing's Angular migration — mirrors the support-data.service.ts / admin-data.service.ts pattern. */
@Injectable({ providedIn: 'root' })
export class MarketingDataService {
  private readonly http = inject(HttpClient);

  /** CustEnquiryAction is the canonical add/close-action popup — shared with Support's AMC pages, backed by support_amc.py. */
  getActionStages(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${AMC}/action-stages`);
  }

  getUsers(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/marketing/users`);
  }

  getSalesmen(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/marketing/salesmen`);
  }

  /** Mirrors CustEnquiryAction.aspx.vb's ddlCompitator source (Web_Compitator). */
  getCompetitors(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${AMC}/competitors`);
  }

  /** Mirrors CustEnquiryAction.aspx.vb's DropDownCheckBoxes1/rcbCAChklist/rcbANAChklist source (web_ThanksNoteActionReasons). */
  getThanksNoteReasons(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${AMC}/thanks-note-reasons`);
  }

  /** New "Thanks Note" admin form (Marketing menu) — the write side of the same web_ThanksNoteActionReasons table getThanksNoteReasons() above reads. */
  addThanksNoteReason(reason: string): Observable<{ success: boolean; message: string }> {
    return this.http.post<{ success: boolean; message: string }>(`${AMC}/thanks-note-reasons`, { reason });
  }

  /** Mirrors CustEnquiryAction.aspx.vb's ddlSpecialRating/ddlAddSpecialRating source (Web_LittleMaster SpecialRatingMaster). */
  getSpecialRatings(): Observable<string[]> {
    return this.http.get<string[]>(`${AMC}/special-ratings`);
  }

  /** Mirrors CustEnquiryAction.aspx.vb's Page_Load lookup for the current ActionStageId/SalesmanId/Referance on a given ref action. */
  getEnquiryActionContext(custId: number, refActionId: number): Observable<{ actionStageId: number; salesmanId: number; specialRating: string }> {
    return this.http
      .get<{ action_stage_id: number; salesman_id: number; special_rating: string }>(`${AMC}/enquiry-action-context`, {
        params: { cust_id: custId, ref_action_id: refActionId }
      })
      .pipe(map((r) => ({ actionStageId: r.action_stage_id, salesmanId: r.salesman_id, specialRating: r.special_rating })));
  }

  /** Mirrors CustEnquiryAction.aspx.vb's Ismodify=1 branch (EXEC webproc_showenquiryaction). */
  getEnquiryActionForModify(custId: number, refActionId: number): Observable<{
    quotationAmt: number;
    actionDescription: string;
    actionRemark: string;
    actionDate: string;
    actionTime: string;
    completedRemark: string;
    completionDate: string;
    completionTime: string;
  } | null> {
    return this.http
      .get<{
        quotation_amt: number;
        action_description: string;
        action_remark: string;
        action_date: string;
        action_time: string;
        completed_remark: string;
        completion_date: string;
        completion_time: string;
      } | null>(`${AMC}/enquiry-action-for-modify`, { params: { cust_id: custId, ref_action_id: refActionId } })
      .pipe(
        map((r) =>
          r
            ? {
                quotationAmt: r.quotation_amt,
                actionDescription: r.action_description,
                actionRemark: r.action_remark,
                actionDate: r.action_date,
                actionTime: r.action_time,
                completedRemark: r.completed_remark,
                completionDate: r.completion_date,
                completionTime: r.completion_time
              }
            : null
        )
      );
  }

  /** Mirrors CustEnquiryAction.aspx.vb's btnAddAction_Click (webProc_AddEnquiryAction / WebProc_ModifyEnquiryAction). */
  addEnquiryAction(payload: Record<string, unknown>): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${AMC}/enquiry-action`, {
      cust_id: payload['custId'],
      ref_action_id: payload['refActionId'],
      action_stage_id: payload['actionStageId'],
      // toDateParam() (not .toISOString()) — see closeEnquiryAction()'s
      // completed_date below for why .toISOString().slice(0, 10) silently
      // shifts the selected day back by one in an ahead-of-UTC timezone.
      action_date: this.toDateParam(payload['actionDate'] as Date),
      action_time: payload['actionTime'],
      description: payload['description'],
      assigned_to: payload['assignedTo'],
      remark: payload['remark'],
      close_action: payload['closeAction'],
      sales_person_id: payload['salesPersonId'],
      competitor_id: payload['competitorId'],
      special_rating: payload['specialRating'],
      reasons: payload['reasons'],
      quotation_amt: payload['quotationAmt'],
      is_modify: payload['isModify']
    });
  }

  /** Mirrors CustEnquiryAction.aspx.vb's btnCloseAction_Click (webProc_CloseEnquiryAction, optional chained webProc_AddEnquiryAction). */
  closeEnquiryAction(payload: Record<string, unknown>): Observable<{ success: boolean }> {
    const addNewAction = payload['addNewAction'] as Record<string, unknown> | undefined;
    return this.http.post<{ success: boolean }>(`${AMC}/enquiry-action/close`, {
      cust_id: payload['custId'],
      ref_action_id: payload['refActionId'],
      completed_by: payload['completedBy'],
      // toDateParam() (not .toISOString()) — the picker sets local midnight
      // for the selected day, and .toISOString() converts through UTC:
      // in an ahead-of-UTC timezone (e.g. IST), local midnight on the 12th
      // becomes ...T18:30:00Z on the 11th, so .slice(0, 10) silently sent
      // the PREVIOUS day to the backend. toDateParam() reads the Date's
      // local year/month/day components directly, with no UTC conversion,
      // so the exact day picked is always what gets sent.
      completed_date: this.toDateParam(payload['completedDate'] as Date),
      completed_time: payload['completedTime'],
      salesman_id: payload['salesmanId'],
      narration: payload['narration'],
      action_stage_id: payload['actionStageId'],
      special_rating: payload['specialRating'],
      reasons: payload['reasons'],
      quotation_amt: payload['quotationAmt'],
      add_new_action: addNewAction
        ? {
            action_stage_id: addNewAction['actionStageId'],
            // Same toDateParam() fix as the two Action/Completed Date sites above.
            action_date: this.toDateParam(addNewAction['actionDate'] as Date),
            action_time: addNewAction['actionTime'],
            description: addNewAction['description'],
            assigned_to: addNewAction['assignedTo'],
            remark: addNewAction['remark'],
            sales_person_id: addNewAction['salesPersonId'],
            reasons: addNewAction['reasons'],
            quotation_amt: addNewAction['quotationAmt']
          }
        : null
    });
  }

/** Mirrors CustEnquiry.aspx.vb's FillMasterSelection (Webproc_LittleMaster per master name). */
  getEnquiryMasterLists(): Observable<{
    goodsSold: LookupOption[];
    natureOfBusiness: LookupOption[];
    methodOfSale: LookupOption[];
    ownership: LookupOption[];
    commMethod: LookupOption[];
    sourceType: LookupOption[];
    receivedBy: LookupOption[];
    segment: LookupOption[];
  }> {
    return this.http
      .get<{
        goods_sold: LookupOption[];
        nature_of_business: LookupOption[];
        method_of_sale: LookupOption[];
        ownership: LookupOption[];
        comm_method: LookupOption[];
        source_type: LookupOption[];
        received_by: LookupOption[];
        segment: LookupOption[];
      }>(`${ENQ}/master-lists`)
      .pipe(
        map((r) => ({
          goodsSold: r.goods_sold,
          natureOfBusiness: r.nature_of_business,
          methodOfSale: r.method_of_sale,
          ownership: r.ownership,
          commMethod: r.comm_method,
          sourceType: r.source_type,
          receivedBy: r.received_by,
          segment: r.segment
        }))
      );
  }

  /** Top 100, re-queried by name as the user types — same load-on-demand shape as Referred By Customer/Customer Name. */
  getCustomersForSearch(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${ENQ}/customers-for-search`, { params: { search } });
  }

  /** Mirrors CustEnquiry.aspx.vb's ShowCustomerGeneralInfo. */
  getCustomerGeneralInfo(custId: number): Observable<{ custId: number; shopName: string; address: string; contactPerson: string; mobileNo: string; telNo: string; email: string } | null> {
    return this.http
      .get<{ cust_id: number; shop_name: string; address: string; contact_person: string; mobile_no: string; tel_no: string; email: string } | null>(
        `${ENQ}/customer-general-info/${custId}`
      )
      .pipe(
        map((r) =>
          r
            ? { custId: r.cust_id, shopName: r.shop_name, address: r.address, contactPerson: r.contact_person, mobileNo: r.mobile_no, telNo: r.tel_no, email: r.email }
            : null
        )
      );
  }

  /** Mirrors CustEnquiry.aspx.vb's ShowCustomerEnquiryInfo (EXEC Webproc_ViewEnquiry). */
  getCustomerEnquiry(custId: number): Observable<CustEnquiryForm | null> {
    return this.http.get<Record<string, unknown> | null>(`${ENQ}/customer-enquiry/${custId}`).pipe(
      map((r) =>
        r
          ? {
              enquiryDate: r['enquiry_date'] as string,
              receivedBy: r['received_by'] as number | null,
              sourceType: r['source_type'] as number | null,
              sourceDetail: r['source_detail'] as string,
              natureOfBusiness: r['nature_of_business'] as number | null,
              segment: r['segment'] as number | null,
              commMethod: r['comm_method'] as number | null,
              commDetails: r['comm_details'] as string,
              ownership: r['ownership'] as number | null,
              noOfOutlets: r['no_of_outlets'] as string,
              methodOfSale: r['method_of_sale'] as number | null,
              sizeOfShop: r['size_of_shop'] as string,
              goodsSold: r['goods_sold'] as number | null,
              totalItems: r['total_items'] as string,
              rushHours: r['rush_hours'] as string,
              salesStaff: r['sales_staff'] as string,
              billingSystem: r['billing_system'] as string,
              transactionsPerDay: r['transactions_per_day'] as string,
              competitor: r['competitor'] as string,
              customisation: r['customisation'] as string,
              orderValue: r['order_value'] as string,
              modules: r['modules'] as string,
              discountOffered: r['discount_offered'] as string,
              assignedTo: r['assigned_to'] as string,
              narration: r['narration'] as string
            }
          : null
      )
    );
  }

  /** Mirrors CustEnquiry.aspx.vb's btninsert_Click (webproc_AddCustEnquiry / webproc_ModifyCustEnquiry). */
  saveCustEnquiry(custId: number | null, payload: CustEnquiryForm, isModify: boolean): Observable<{ success: boolean; custId: number }> {
    const targetId = custId ?? 0;
    return this.http
      .post<{ success: boolean; cust_id: number }>(
        `${ENQ}/customer-enquiry/${targetId}`,
        {
          enquiry_date: payload.enquiryDate.slice(0, 10),
          received_by: payload.receivedBy,
          source_type: payload.sourceType,
          source_detail: payload.sourceDetail,
          nature_of_business: payload.natureOfBusiness,
          segment: payload.segment,
          comm_method: payload.commMethod,
          comm_details: payload.commDetails,
          ownership: payload.ownership,
          no_of_outlets: payload.noOfOutlets,
          method_of_sale: payload.methodOfSale,
          size_of_shop: payload.sizeOfShop,
          goods_sold: payload.goodsSold,
          total_items: payload.totalItems,
          rush_hours: payload.rushHours,
          sales_staff: payload.salesStaff,
          billing_system: payload.billingSystem,
          transactions_per_day: payload.transactionsPerDay,
          competitor: payload.competitor,
          customisation: payload.customisation,
          order_value: payload.orderValue,
          modules: payload.modules,
          discount_offered: payload.discountOffered,
          assigned_to: payload.assignedTo,
          narration: payload.narration
        },
        { params: { is_modify: isModify } }
      )
      .pipe(map((r) => ({ success: r.success, custId: r.cust_id })));
  }

  /** Mirrors CustEnquiryRegister.aspx.vb's rgAction master grid (list-shaped rebuild — see marketing_register.py docstring). */
  getEnquiryRegisterRows(custId?: number): Observable<CustEnquiryRegisterRow[]> {
    return this.http
      .get<ApiCustEnquiryRegisterRow[]>(`${REG}/rows`, { params: custId ? { cust_id: custId } : {} })
      .pipe(map((rows) => rows.map(toCustEnquiryRegisterRow)));
  }

  /** Mirrors CustEnquiryRegister.aspx.vb's GetFilters()+btnshow_Click (radio-mode search resolving to one CustID, then EXEC webproc_showenquiry). */
  searchEnquiryRegister(mode: 'shop_id' | 'cust_id' | 'contact_person' | 'mobile' | 'gst', value: string): Observable<EnquiryRegisterSearchResult> {
    return this.http
      .get<ApiEnquiryRegisterSearchResult>(`${REG}/search`, { params: { mode, value } })
      .pipe(
        map((r) => ({
          customerInfo: r.customer_info ? toCustomerRegisterInfo(r.customer_info) : null,
          rows: r.rows.map(toCustEnquiryRegisterRow)
        }))
      );
  }

  /** Direct by-ID lookup of the same Customer Information panel /search builds — for pages that already have a resolved CustID (e.g. CustEnquiryAction) and just need to display who they're acting on. */
  getCustomerRegisterInfo(custId: number): Observable<CustomerRegisterInfo | null> {
    return this.http
      .get<ApiCustomerRegisterInfo | null>(`${REG}/customer-info/${custId}`)
      .pipe(map((r) => (r ? toCustomerRegisterInfo(r) : null)));
  }

  /** Mirrors CustEnquiryRegister.aspx.vb's ddlContact source (distinct CustomerMaster.Landmark values — text, not an ID, unlike LookupOption). Capped to top 100 + server-side search, same load-on-demand shape as the Shop Name picker on the same page. */
  getContactPersonLookup(search = ''): Observable<{ label: string; value: string }[]> {
    return this.http.get<{ label: string; value: string }[]>(`${REG}/lookup/contact-persons`, { params: { search } });
  }

  /** Mirrors CustEnquiryRegister.aspx.vb's DetailTableDataBind ("CustEnquiryAction", EXEC webproc_showenquiryaction). */
  getEnquiryRegisterActions(custId: number): Observable<EnquiryRegisterActionRow[]> {
    return this.http
      .get<ApiEnquiryRegisterActionRow[]>(`${REG}/actions/${custId}`)
      .pipe(map((rows) => rows.map(toEnquiryRegisterActionRow)));
  }

  /** One action's editable fields, for the Edit button on Customer Enquiry - Action's action sub-grid. */
  getEnquiryActionForEdit(custId: number, actionId: number): Observable<EnquiryActionEdit> {
    return this.http.get<Record<string, unknown>>(`${REG}/actions/${custId}/${actionId}`).pipe(
      map((r) => ({
        actionStageId: (r['action_stage_id'] as number) || null,
        actionDate: r['action_date'] ? new Date(`${r['action_date']}T00:00:00`) : null,
        actionTime: (r['action_time'] as string) ?? '',
        description: (r['description'] as string) ?? '',
        remark: (r['remark'] as string) ?? '',
        assignedTo: (r['assigned_to'] as number) || null,
        salesPersonId: (r['sales_person_id'] as number) || null,
        quotationAmt: (r['quotation_amt'] as number) || null,
        completed: !!r['completed'],
        completedBy: (r['completed_by'] as number) || null,
        completionDate: r['completion_date'] ? new Date(`${r['completion_date']}T00:00:00`) : null,
        completionTime: (r['completion_time'] as string) ?? '',
        completedRemark: (r['completed_remark'] as string) ?? ''
      }))
    );
  }

  updateEnquiryAction(custId: number, actionId: number, a: EnquiryActionEdit): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${REG}/actions/${custId}/${actionId}`, {
      action_stage_id: a.actionStageId ?? 0,
      action_date: a.actionDate ? this.toDateParam(a.actionDate) : null,
      action_time: a.actionTime,
      description: a.description,
      remark: a.remark,
      assigned_to: a.assignedTo ?? 0,
      sales_person_id: a.salesPersonId ?? 0,
      quotation_amt: a.quotationAmt ?? 0,
      completed: a.completed,
      completed_by: a.completedBy ?? 0,
      completion_date: a.completionDate ? this.toDateParam(a.completionDate) : null,
      completion_time: a.completionTime,
      completed_remark: a.completedRemark
    });
  }

  /** Mirrors LeadRecord.aspx.vb's filter-source lookups (usermaster/SalesMan/Geo_DistrictMaster/geo_CityMaster), plus the distinct Enquiry Source / Enquiry Source 2 values actually present in the lead data (plain text, no real ID — same shape as Tour Report's visitTypes/modesOfTravel). */
  getLeadRecordFilters(): Observable<{
    users: LookupOption[];
    salesmen: LookupOption[];
    cities: LookupOption[];
    districts: LookupOption[];
    enquirySources: string[];
    enquirySources2: string[];
  }> {
    return this.http
      .get<{
        users: LookupOption[];
        salesmen: LookupOption[];
        cities: LookupOption[];
        districts: LookupOption[];
        enquiry_sources: string[];
        enquiry_sources_2: string[];
      }>(`${RPT}/lead-record/filters`)
      .pipe(
        map((f) => ({
          users: [{ label: '', value: 0 }, ...f.users],
          salesmen: [{ label: '', value: 0 }, ...f.salesmen],
          cities: [{ label: '', value: 0 }, ...f.cities],
          districts: [{ label: '', value: 0 }, ...f.districts],
          enquirySources: ['', ...f.enquiry_sources],
          enquirySources2: ['', ...f.enquiry_sources_2]
        }))
      );
  }

  // Bound to Lead Record's Assigned To/Salesman/City <p-select>'s (onFilter) —
  // re-queries the server with whatever's typed instead of only filtering the
  // already-loaded top 100 client-side (same load-on-demand shape as
  // /customers-for-search). Each prepends the same blank "(any)" option the
  // initial combined load does, so it's still selectable after a search.
  getLeadRecordAssignedToOptions(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${RPT}/lead-record/users`, { params: { search } }).pipe(map((u) => [{ label: '', value: 0 }, ...u]));
  }

  getLeadRecordSalesmenOptions(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${RPT}/lead-record/salesmen`, { params: { search } }).pipe(map((s) => [{ label: '', value: 0 }, ...s]));
  }

  getLeadRecordCitiesOptions(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${RPT}/lead-record/cities`, { params: { search } }).pipe(map((c) => [{ label: '', value: 0 }, ...c]));
  }

  /** Mirrors LeadRecord.aspx.vb's FillGV (EXEC WebProc_LeadRecords1) — city/district filter by name text, matching rcbCity.Text/rcbdistrict.Text in the source. */
  getLeadRecords(filters: Record<string, unknown>): Observable<LeadRecordRow[]> {
    const params: Record<string, string | number> = {
      received_by: (filters['firstReceivedBy'] as number) ?? 0,
      assigned_to: (filters['assignedTo'] as number) ?? 0,
      salesman: (filters['salesman'] as number) ?? 0,
      city: (filters['city'] as string) ?? '',
      district: (filters['district'] as string) ?? '',
      enquiry_source: (filters['enquirySource'] as string) ?? '',
      enquiry_source_2: (filters['enquirySource2'] as string) ?? ''
    };
    if (filters['fromDate']) {
      params['from_date'] = this.toDateParam(filters['fromDate'] as Date);
    }
    if (filters['toDate']) {
      params['to_date'] = this.toDateParam(filters['toDate'] as Date);
    }
    return this.http.get<ApiLeadRecordRow[]>(`${RPT}/lead-records`, { params }).pipe(map((rows) => rows.map(toLeadRecordRow)));
  }

  /** Mirrors ActionDelay.aspx.vb's rcbSalesman source. */
  getActionDelaySalesmen(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${RPT}/action-delay-salesmen`);
  }

  /** Mirrors ActionDelay.aspx.vb's FillGV (Exec Proc_WebEnquiryActionDelayReport) / chkNextAction_CheckedChanged (Webproc_NextActionNotDecided). */
  getActionDelayRows(salesmanId: number, nextActionNotTaken: boolean): Observable<{ columns: string[]; rows: Record<string, unknown>[] }> {
    return this.http.get<{ columns: string[]; rows: Record<string, unknown>[] }>(`${RPT}/action-delay`, {
      params: { salesman_id: salesmanId, next_action_not_taken: nextActionNotTaken }
    });
  }

  /** Mirrors ActionNotTaken.aspx.vb's FillGV (Exec Webproc_ActionNotCreated). */
  getActionNotTakenRows(custId: number): Observable<{ columns: string[]; rows: Record<string, unknown>[] }> {
    return this.http.get<{ columns: string[]; rows: Record<string, unknown>[] }>(`${RPT}/action-not-taken`, { params: { cust_id: custId } });
  }

  /** Mirrors NextActionNotTaken.aspx.vb's rcbAssignedTo source, shared with ActionDelayreport.aspx. */
  getAssignedToUsers(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${RPT}/assigned-to-users`).pipe(map((u) => [{ label: '', value: 0 }, ...u]));
  }

  /** Mirrors NextActionNotTaken.aspx.vb's FillGV (Exec Webproc_NextActionNotDecided). */
  getNextActionNotTakenRows(assignedTo: number): Observable<{ columns: string[]; rows: Record<string, unknown>[] }> {
    return this.http.get<{ columns: string[]; rows: Record<string, unknown>[] }>(`${RPT}/next-action-not-taken`, { params: { assigned_to: assignedTo } });
  }

  /** Mirrors ActionDelayreport.aspx.vb's FillGV (Exec Proc_GetActionDelaydetails). */
  getActionDelayReportRows(assignedTo: number): Observable<{ columns: string[]; rows: Record<string, unknown>[] }> {
    return this.http.get<{ columns: string[]; rows: Record<string, unknown>[] }>(`${RPT}/action-delay-report`, { params: { assigned_to: assignedTo } });
  }

  /** Mirrors ActionSearchReport.aspx.vb's filter-source lookups. */
  getActionSearchFilters(): Observable<{ salesmen: LookupOption[]; segments: LookupOption[]; cities: LookupOption[] }> {
    return this.http.get<{ salesmen: LookupOption[]; segments: LookupOption[]; cities: LookupOption[] }>(`${RPT}/action-search/filters`);
  }

  // Bound to each of Action Search Report's Salesman/Segment/City <p-select>'s
  // (onFilter) — re-queries the server with whatever's typed instead of only
  // filtering the already-loaded top 100 client-side (same load-on-demand
  // shape as /customers-for-search).
  getActionSearchSalesmen(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${RPT}/action-search/salesmen`, { params: { search } });
  }

  getActionSearchSegments(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${RPT}/action-search/segments`, { params: { search } });
  }

  getActionSearchCities(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${RPT}/action-search/cities`, { params: { search } });
  }

  /** Mirrors ActionSearchReport.aspx.vb's FillGV (webproc_SearchEnquiryAction). */
  getActionSearchRows(filters: Record<string, unknown>): Observable<ActionSearchRow[]> {
    return this.http
      .get<ApiActionSearchRow[]>(`${RPT}/action-search`, {
        params: {
          salesman_id: (filters['salesmanId'] as number) ?? 0,
          segment: (filters['segmentId'] as number) ?? 0,
          action_desc: (filters['actionDesc'] as string) ?? '',
          city_id: (filters['cityId'] as number) ?? 0,
          customer_only: (filters['customerOnly'] as boolean) ?? false,
          ...(filters['fromDate'] ? { from_date: this.toDateParam(filters['fromDate'] as Date) } : {}),
          ...(filters['toDate'] ? { to_date: this.toDateParam(filters['toDate'] as Date) } : {})
        }
      })
      .pipe(map((rows) => rows.map(toActionSearchRow)));
  }

  /** Mirrors ActionStageDetailReport.aspx.vb's FillGV (Exec WebProc_GetActionStagesDetails / Exec WebProc_GetTourDetails for "Tour Count"). */
  getActionStageDetailRows(actionStageName: string, executiveName = '', fromDate: Date | null = null, toDate: Date | null = null): Observable<ActionStageDetailRow[]> {
    const params: Record<string, string> = { action_stage_name: actionStageName, executive_name: executiveName };
    if (fromDate) {
      params['from_date'] = this.toDateParam(fromDate);
    }
    if (toDate) {
      params['to_date'] = this.toDateParam(toDate);
    }
    return this.http
      .get<ApiActionStageDetailRow[]>(`${RPT}/action-stage-detail`, { params })
      .pipe(map((rows) => rows.map(toActionStageDetailRow)));
  }

  /** Mirrors ActionStageDetailReport.aspx.vb's DetailTableDataBind (webproc_showenquiryaction, combining LastEnquiryAction + CustEnquiryAction levels into one history table). */
  getActionStageDetailHistory(custId: number): Observable<EnquiryRegisterActionRow[]> {
    return this.getEnquiryRegisterActions(custId);
  }

  /** Mirrors ActionStageSummaryReport.aspx.vb's rcbActionStage source (Web_EnquiryActionStage). */
  getActionStages2(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${RPT}/action-stages`);
  }

  /**
   * Mirrors ActionStageSummaryReport.aspx.vb's FillGV (EXEC
   * WebProc_GetActionStagesSummary) — dynamic report-engine columns beyond
   * index 2 become drill-down links, same simplified treatment as
   * CRMReview. Executive/link columns route to ActionStageDetailReport
   * (or LeadRecord for the "Received By Count" column).
   */
  getActionStageSummaryRows(fromDate: Date | null, toDate: Date | null, stageNames: string[]): Observable<{ columns: string[]; linkColumns: string[]; rows: Record<string, unknown>[] }> {
    const excluded = new Set(['Demo Onsite', 'Demo Online', 'Demo At Office']);
    const actionStages = stageNames
      .filter((n) => !excluded.has(n))
      .map((n) => `,'[${n}]'`)
      .join('');
    const params: Record<string, string> = { action_stages: actionStages };
    if (fromDate) {
      params['from_date'] = this.toDateParam(fromDate);
    }
    if (toDate) {
      params['to_date'] = this.toDateParam(toDate);
    }
    return this.http
      .get<{ columns: string[]; rows: Record<string, unknown>[] }>(`${RPT}/action-stage-summary`, { params })
      .pipe(map((res) => ({ ...res, linkColumns: res.columns.slice(3) })));
  }

  /** Mirrors ActivityStatuslog.aspx.vb's filter-source lookups (Usermaster/Web_EnquiryActionStage). */
  getActivityStatusLogFilters(): Observable<{ users: LookupOption[]; actionStages: LookupOption[] }> {
    return this.http
      .get<{ users: LookupOption[]; actionStages: LookupOption[] }>(`${RPT}/activity-status-log/filters`)
      .pipe(map((f) => ({ users: [{ label: '', value: 0 }, ...f.users], actionStages: [{ label: '', value: 0 }, ...f.actionStages] })));
  }

  /** Mirrors ActivityStatuslog.aspx.vb's FillGV (vwCRMActivity_ForReport). */
  getActivityStatusLogRows(fromDate: Date, toDate: Date, actionStage = '', userName = ''): Observable<{ columns: string[]; rows: Record<string, unknown>[] }> {
    return this.http.get<{ columns: string[]; rows: Record<string, unknown>[] }>(`${RPT}/activity-status-log`, {
      params: { from_date: this.toDateParam(fromDate), to_date: this.toDateParam(toDate), action_stage: actionStage, user_name: userName }
    });
  }

  /** Mirrors CRMActivity.aspx.vb's rcbUsers source. */
  getCrmActivityUsers(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${RPT}/crm-activity/users`);
  }

  /** Mirrors CRMActivity.aspx.vb's FillGV (vwCRMActivity, top 10). */
  getCrmActivityRows(userId = 0, fromDate: Date | null = null, toDate: Date | null = null): Observable<CrmActivityRow[]> {
    const params: Record<string, string | number> = { user_id: userId };
    if (fromDate) {
      params['from_date'] = this.toDateParam(fromDate);
    }
    if (toDate) {
      params['to_date'] = this.toDateParam(toDate);
    }
    return this.http.get<ApiCrmActivityRow[]>(`${RPT}/crm-activity`, { params }).pipe(map((rows) => rows.map(toCrmActivityRow)));
  }

  /** Mirrors CRMReport.aspx.vb's rcbCity source. */
  getCrmReportCities(search = ''): Observable<string[]> {
    return this.http.get<string[]>(`${RPT}/crm-report/cities`, { params: { search } });
  }

  /** Mirrors CRMReport.aspx.vb's FillGV (Web_Enquiry joined CustomerMaster/UserMaster/Web_EnquiryAction). */
  getCrmReportRows(city = 'All', fromDate: Date | null = null, toDate: Date | null = null, sortBy = 'EnquiryDate'): Observable<CrmReportRow[]> {
    const params: Record<string, string> = { city, sort_by: sortBy };
    if (fromDate) {
      params['from_date'] = this.toDateParam(fromDate);
    }
    if (toDate) {
      params['to_date'] = this.toDateParam(toDate);
    }
    return this.http.get<ApiCrmReportRow[]>(`${RPT}/crm-report`, { params }).pipe(map((rows) => rows.map(toCrmReportRow)));
  }

  /** Mirrors DailyCRMActivity.aspx.vb's FillGV (exec Web_Proc_CRMActionDelay). */
  getDailyCrmActivityRows(userId: number, fromDate: Date, toDate: Date): Observable<{ columns: string[]; rows: Record<string, unknown>[] }> {
    return this.http.get<{ columns: string[]; rows: Record<string, unknown>[] }>(`${RPT}/daily-crm-activity`, {
      params: { user_id: userId, from_date: this.toDateParam(fromDate), to_date: this.toDateParam(toDate) }
    });
  }

  /** Mirrors DailyCRMActivity.aspx.vb's rcbUsers source. */
  getDailyCrmActivityUsers(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${RPT}/daily-crm-activity/users`);
  }

  private toDateParam(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  /** Mirrors CustEnquiryStatus.aspx.vb's FillGV (vwWebEnquiry_Status, StagePercent<100, grouped by AssignedToUserID). */
  getEnquiryStatusRows(): Observable<EnquiryStatusRow[]> {
    return this.http
      .get<ApiEnquiryStatusRow[]>(`${REG}/status`)
      .pipe(
        map((rows) =>
          rows.map((r) => ({
            assignedToUserId: r.assigned_to_user_id,
            assignedTo: r.assigned_to,
            assignedToMobile: r.assigned_to_mobile,
            assignedToEmail: r.assigned_to_email,
            enquiryCount: r.enquiry_count,
            progressPercent: r.progress_percent,
            lastActionDate: r.last_action_date ?? ''
          }))
        )
      );
  }

  /** Mirrors CustEnquiryStatus.aspx.vb's DetailTableDataBind ("GVCustEnquiryDetail"). */
  getEnquiryStatusDetail(assignedToUserId: number): Observable<EnquiryStatusDetailRow[]> {
    return this.http
      .get<ApiEnquiryStatusDetailRow[]>(`${REG}/status/${assignedToUserId}`)
      .pipe(
        map((rows) =>
          rows.map((r) => ({
            custId: r.cust_id,
            isAuto: r.is_auto ? 1 : 0,
            segmentName: r.segment_name,
            enquiryDate: r.enquiry_date ?? '',
            customerName: r.customer_name,
            mobileNo: r.mobile_no,
            area: r.area,
            city: r.city,
            stagePercent: r.stage_percent,
            lastActionDate: r.last_action_date ?? ''
          }))
        )
      );
  }

  /** Mirrors EnquiryDownloaded.aspx.vb's FillGV (Exec WebProc_GetDownLoadEnquiry). */
  getDownloadedEnquiryRows(fromDate: Date, toDate: Date): Observable<DownloadedEnquiryRow[]> {
    return this.http
      .get<ApiDownloadedEnquiryRow[]>(`${OPS}/downloaded-enquiry`, {
        params: { from_date: this.toDateParam(fromDate), to_date: this.toDateParam(toDate) }
      })
      .pipe(map((rows) => rows.map(toDownloadedEnquiryRow)));
  }

  /** Mirrors EnquiryDownloaded.aspx.vb's rcbAssignedTo_SelectedIndexChanged (Exec Proc_UpdateAssignedToDownloadEnq). */
  reassignDownloadedEnquiry(custId: number, existingAssigned: number, newAssignedTo: number): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${OPS}/downloaded-enquiry/${custId}/reassign`, null, {
      params: { existing_assigned: existingAssigned, new_assigned_to: newAssignedTo }
    });
  }

  /** Mirrors OutstandingFollowup.aspx.vb's filter-source lookups. */
  getOutstandingFollowupFilters(): Observable<{ salesmen: string[]; customers: string[]; ledgerGroups: LookupOption[] }> {
    return this.http.get<{ salesmen: string[]; customers: string[]; ledgerGroups: LookupOption[] }>(`${OPS}/outstanding-followup/filters`);
  }

  // Bound to Outstanding Follow-up's Customer <p-select>'s (onFilter) —
  // re-queries the server with whatever's typed instead of only filtering the
  // already-loaded top 100 client-side (same load-on-demand shape as
  // /customers-for-search).
  getOutstandingFollowupCustomers(search = ''): Observable<string[]> {
    return this.http.get<string[]>(`${OPS}/outstanding-followup/customers`, { params: { search } });
  }

  /** Mirrors OutstandingFollowup.aspx.vb's FillGV (VWAMCForAllCustomers joined CustomerAttributes). */
  getOutstandingFollowupRows(salesman = '', amount = 1, customer = '', ledgerGroupId = 0): Observable<OutstandingFollowupRow[]> {
    return this.http
      .get<ApiOutstandingFollowupRow[]>(`${OPS}/outstanding-followup`, {
        params: { salesman, amount, customer, ledger_group_id: ledgerGroupId }
      })
      .pipe(map((rows) => rows.map(toOutstandingFollowupRow)));
  }

  /** Mirrors OutstandingFollowup.aspx.vb's DetailTableDataBind ("AMCDetail", ActionStageID=27). */
  getOutstandingFollowupActions(custId: number): Observable<EnquiryRegisterActionRow[]> {
    return this.getEnquiryRegisterActions(custId);
  }

  /** Mirrors OutstandingFollowup.aspx.vb's ItemDataBound edit-form (RSPL_CustSoftwareProductDetail). */
  getOutstandingCustomerModules(custId: number): Observable<Record<string, unknown>[]> {
    return this.http.get<Record<string, unknown>[]>(`${OPS}/outstanding-followup/${custId}/modules`);
  }

  /** Mirrors CustLeadReport.aspx.vb's FillLeadSummary (EXEC webproc_LeadChartSummaryV2). */
  getLeadSummaryRows(groupBy: string, fromDate: Date | null = null, toDate: Date | null = null): Observable<LeadSummaryRow[]> {
    const params: Record<string, string> = { group_by: groupBy };
    if (fromDate) {
      params['from_date'] = this.toDateParam(fromDate);
    }
    if (toDate) {
      params['to_date'] = this.toDateParam(toDate);
    }
    // webproc_LeadChartSummaryV2 re-evaluates a heavy view ~10 times per
    // call and has been confirmed live to sometimes exceed a minute — the
    // backend's own pooled-connection timeout (db.py, 60s) is the primary
    // safety net; this is defense-in-depth for the (rarer) case where the
    // backend process itself hangs rather than the DB call specifically.
    return this.http.get<ApiLeadSummaryRow[]>(`${LEAD}/summary`, { params }).pipe(timeout(65000), map((rows) => rows.map(toLeadSummaryRow)));
  }

  /** Mirrors CustLeadReport.aspx.vb's GVLead_DetailTableDataBind ("GVLeadL3", EXEC webproc_LeadChartDetailV2). */
  getLeadSummaryDetail(typeId: number, groupBy: string, fromDate: Date | null = null, toDate: Date | null = null): Observable<LeadSummaryDetailRow[]> {
    const params: Record<string, string | number> = { group_by: groupBy };
    if (fromDate) {
      params['from_date'] = this.toDateParam(fromDate);
    }
    if (toDate) {
      params['to_date'] = this.toDateParam(toDate);
    }
    return this.http
      .get<ApiLeadSummaryDetailRow[]>(`${LEAD}/summary/${typeId}/detail`, { params })
      .pipe(timeout(65000), map((rows) => rows.map(toLeadSummaryDetailRow)));
  }

  /** Mirrors TourDetails.aspx.vb's Page_Load (salesman combo fill). */
  getTourSalesmen(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${TOUR}/salesmen`);
  }

  /** Mirrors TourDetails.aspx.vb's FillGV (EXEC WebProc_GetCityWiseTourdetails), with an appended Total row (server-side, using rcbSalesman.Text — a name, not an ID). */
  getTourCityDetails(fromDate: Date, toDate: Date, salesmanName = ''): Observable<TourCityRow[]> {
    return this.http
      .get<ApiTourCityRow[]>(`${TOUR}/city-details`, {
        params: { from_date: this.toDateParam(fromDate), to_date: this.toDateParam(toDate), salesman_name: salesmanName }
      })
      .pipe(map((rows) => rows.map(toTourCityRow)));
  }

  /** Mirrors TourReport.aspx.vb's Page_Load filter combo fills (VisitType/ModeOfTravel are static text lists in the source, not ID-backed lookups). */
  getTourReportFilters(): Observable<{ users: LookupOption[]; cities: LookupOption[]; customers: LookupOption[]; visitTypes: string[]; modesOfTravel: string[] }> {
    return this.http.get<{ users: LookupOption[]; cities: LookupOption[]; customers: LookupOption[]; visitTypes: string[]; modesOfTravel: string[] }>(
      `${TOUR}/report/filters`
    );
  }

  // Bound to Tour Report's Customer <p-select>'s (onFilter) — re-queries the
  // server with whatever's typed instead of only filtering the already-loaded
  // top 100 client-side (same load-on-demand shape as /customers-for-search).
  getTourReportCustomers(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${TOUR}/report/customers`, { params: { search } }).pipe(map((c) => [{ label: 'All', value: 0 }, ...c]));
  }

  /** Mirrors TourReport.aspx.vb's FillGV Case 1 (unfiltered-column select from rspl_tourdata). The source's dynamic
   *  column-chooser (choose/reorder columns, persisted to ReportOptions) is not replicated — always shows all columns. */
  getTourReportRows(filters: Record<string, unknown>): Observable<TourReportRow[]> {
    const params: Record<string, string> = {
      user_name: (filters['userName'] as string) ?? '',
      customer: (filters['customer'] as string) ?? '',
      city: (filters['city'] as string) ?? '',
      visit_type: (filters['visitType'] as string) ?? '',
      mode_of_travel: (filters['modeOfTravel'] as string) ?? '',
      payment_voucher_no: (filters['voucherNo'] as string) ?? ''
    };
    if (filters['fromDate']) {
      params['from_date'] = this.toDateParam(filters['fromDate'] as Date);
    }
    if (filters['toDate']) {
      params['to_date'] = this.toDateParam(filters['toDate'] as Date);
    }
    return this.http.get<ApiTourReportRow[]>(`${TOUR}/report`, { params }).pipe(map((rows) => rows.map(toTourReportRow)));
  }

  /** Mirrors e-ReferralRegister.aspx.vb's Page_Load shop-name web-service combo. */
  getEReferralShops(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${REFERRAL}/shops`, { params: { search } });
  }

  // Bound to <p-table>'s (onLazyLoad) — true server-side paging (OFFSET/FETCH
  // in SQL Server itself, per marketing_referral.py), unlike this app's other
  // "paginated" reports which fetch everything and page client-side.
  /** Mirrors e-ReferralRegister.aspx.vb's FillGV (Select ... From vw_web_eReferralVoucher). */
  getEReferralRows(shopClientId = 0, page = 0, pageSize = 20): Observable<{ rows: EReferralRow[]; total: number }> {
    return this.http
      .get<{ rows: ApiEReferralRow[]; total: number }>(`${REFERRAL}/rows`, {
        params: { shop_client_id: shopClientId, page, page_size: pageSize }
      })
      .pipe(map((r) => ({ rows: r.rows.map(toEReferralRow), total: r.total })));
  }

  /** Mirrors CustRegistration.aspx.vb's Page_Load dropdown fills (group/case-type/business-nature/etc.). */
  getCustRegistrationLookups(): Observable<CustRegistrationLookups> {
    return this.http
      .get<{
        groups: LookupOption[];
        case_types: LookupOption[];
        business_natures: LookupOption[];
        enquiry_sources: LookupOption[];
        received_by_users: LookupOption[];
        segments: LookupOption[];
        providers: LookupOption[];
        campaigns: LookupOption[];
        continents: LookupOption[];
        zones: LookupOption[];
        countries: LookupOption[];
        states: LookupOption[];
        districts: LookupOption[];
        cities: LookupOption[];
      }>(`${REGN}/lookups`)
      .pipe(
        map((r) => ({
          groups: r.groups,
          caseTypes: r.case_types,
          businessNatures: r.business_natures,
          enquirySources: r.enquiry_sources,
          receivedByUsers: r.received_by_users,
          segments: r.segments,
          providers: r.providers,
          campaigns: r.campaigns,
          continents: r.continents,
          zones: r.zones,
          countries: r.countries,
          states: r.states,
          districts: r.districts,
          cities: r.cities
        }))
      );
  }

  /**
   * Mirrors ComboFill.asmx's FillCustomerWithGroupID1 — the source's
   * rcbRefferedBy was a genuinely load-on-demand RadComboBox (capped TOP-N,
   * re-queried by DisplayName as the user types), never a fully-preloaded
   * list. `search` empty returns the first 100 alphabetically.
   */
  getReferredByCustomers(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${REGN}/referred-by-customers`, { params: { search } });
  }

  /** Mirrors ComboFill.asmx's FillPotentialCustomer — same load-on-demand shape as above, opposite GroupID filter. */
  getPotentialCustomers(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${REGN}/potential-customers`, { params: { search } });
  }

  /** Mirrors ComboFill.asmx's FillCustomerWithGroupType1 (cmbCustomerName) — same load-on-demand shape as above. */
  searchCustomerName(search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${REGN}/customer-name-search`, { params: { search } });
  }

  /** Mirrors CustRegistration.aspx.vb's ddlState_SelectedIndexChanged (state-filtered city/district). */
  getCitiesAndDistricts(stateId: number): Observable<{ cities: LookupOption[]; districts: LookupOption[] }> {
    return this.http.get<{ cities: LookupOption[]; districts: LookupOption[] }>(`${REGN}/cities-districts`, { params: { state_id: stateId } });
  }

  /** Mirrors CustRegistration.aspx.vb's ViewCustomerDetails (Modify mode: existing customer + Webproc_ViewEnquiry). */
  getCustRegistrationDetail(custId: number): Observable<CustRegistrationDetail> {
    return this.http.get<Record<string, unknown>>(`${REGN}/detail/${custId}`).pipe(
      map((r) => ({
        custId: r['cust_id'] as number,
        groupId: r['group_id'] as number,
        name: r['name'] as string,
        lastName: r['last_name'] as string,
        mobileNo: r['mobile_no'] as string,
        telephoneNo: r['telephone_no'] as string,
        email: r['email'] as string,
        address1: r['address1'] as string,
        address2: r['address2'] as string,
        area: r['area'] as string,
        pinCode: r['pin_code'] as string,
        contactPerson: r['contact_person'] as string,
        gstin: r['gstin'] as string,
        arn: r['arn'] as string,
        caseType: r['case_type'] as string,
        hardwarePartner: r['hardware_partner'] as string,
        narration: r['narration'] as string,
        continentId: r['continent_id'] as number,
        countryId: r['country_id'] as number,
        stateId: r['state_id'] as number,
        districtId: r['district_id'] as number,
        cityId: r['city_id'] as number,
        zoneId: r['zone_id'] as number,
        enquiryDate: r['enquiry_date'] as string,
        receivedBy: r['received_by'] as number,
        enquirySource: r['enquiry_source'] as number,
        enquirySource2: r['enquiry_source_2'] as number,
        enquirySource2Date: r['enquiry_source_2_date'] as string | null,
        sourceDetail: r['source_detail'] as string,
        businessNature: r['business_nature'] as number,
        segment: r['segment'] as number,
        provider: r['provider'] as number,
        referralCardNo: r['referral_card_no'] as string,
        hardware: r['hardware'] as string,
        campaignId: r['campaign_id'] as number,
        referredByName: r['referred_by_name'] as string,
        referredByCustomerId: r['referred_by_customer_id'] as number,
        assignedToName: r['assigned_to_name'] as string
      }))
    );
  }

  /** Mirrors CustRegistration.aspx.vb's btnSave_Click ActionType=1 (EXEC webProc_AddCustomer). */
  addCustomerRegistration(form: CustRegistrationDetail): Observable<{ success: boolean; custId: number; message: string }> {
    return this.http.post<{ success: boolean; custId: number; message: string }>(`${REGN}/add`, this.toApiRegistrationDetail(form));
  }

  /** Mirrors CustRegistration.aspx.vb's btnSave_Click ActionType=2 (EXEC webProc_ModifyCustomer). */
  modifyCustomerRegistration(form: CustRegistrationDetail): Observable<{ success: boolean; message: string }> {
    return this.http.post<{ success: boolean; message: string }>(`${REGN}/modify`, this.toApiRegistrationDetail(form));
  }

  private toApiRegistrationDetail(form: CustRegistrationDetail): Record<string, unknown> {
    return {
      cust_id: form.custId,
      group_id: form.groupId,
      name: form.name,
      last_name: form.lastName,
      mobile_no: form.mobileNo,
      telephone_no: form.telephoneNo,
      email: form.email,
      address1: form.address1,
      address2: form.address2,
      area: form.area,
      pin_code: form.pinCode,
      contact_person: form.contactPerson,
      gstin: form.gstin,
      arn: form.arn,
      case_type: form.caseType,
      hardware_partner: form.hardwarePartner,
      narration: form.narration,
      continent_id: form.continentId,
      country_id: form.countryId,
      state_id: form.stateId,
      district_id: form.districtId,
      city_id: form.cityId,
      zone_id: form.zoneId,
      enquiry_date: form.enquiryDate.slice(0, 10),
      received_by: form.receivedBy,
      enquiry_source: form.enquirySource,
      enquiry_source_2: form.enquirySource2,
      enquiry_source_2_date: form.enquirySource2Date ? form.enquirySource2Date.slice(0, 10) : null,
      source_detail: form.sourceDetail,
      business_nature: form.businessNature,
      segment: form.segment,
      provider: form.provider,
      referral_card_no: form.referralCardNo,
      hardware: form.hardware,
      campaign_id: form.campaignId,
      referred_by_name: form.referredByName,
      referred_by_customer_id: form.referredByCustomerId,
      assigned_to_name: form.assignedToName
    };
  }

  /** Mirrors CustRegistration.aspx.vb's lnkCheckMobileNo_Click (duplicate mobile lookup). */
  checkMobileAvailability(mobileNo: string): Observable<{ available: boolean; custId?: number }> {
    return this.http.get<{ available: boolean; custId?: number }>(`${REGN}/check-mobile`, { params: { mobile_no: mobileNo } });
  }

  /** Mirrors CustRegistration.aspx.vb's lnkbtnCheckGSTVarification_Click — calls Retailware's internal
   * license-server GSTIN_TaxPayerSearch service (same one the legacy app used) via the backend. */
  verifyGstin(
    gstin: string
  ): Observable<{
    verified: boolean;
    name?: string;
    address1?: string;
    pinCode?: string;
    area?: string;
    stateId?: number;
    districtId?: number;
    gstApiError?: string;
  }> {
    return this.http.get<{
      verified: boolean;
      name?: string;
      address1?: string;
      pinCode?: string;
      area?: string;
      stateId?: number;
      districtId?: number;
      gstApiError?: string;
    }>(`${REGN}/verify-gstin`, { params: { gstin } });
  }

  /** Mirrors CustRegistration.aspx.vb's lbkPincode_Click (GetCityStateFromPincode). */
  lookupPincode(pinCode: string): Observable<{ stateId: number; districtId: number } | null> {
    return this.http.get<{ stateId: number; districtId: number } | null>(`${REGN}/lookup-pincode`, { params: { pin_code: pinCode } });
  }

  /** Mirrors CustRegistration.aspx.vb's lnkCity_Click (Exec WebProc_CreateCity). */
  createCity(stateId: number, cityName: string): Observable<{ cityId: number; message: string }> {
    return this.http.post<{ cityId: number; message: string }>(`${REGN}/create-city`, null, { params: { state_id: stateId, city_name: cityName } });
  }

  /** Mirrors CustTeleCallingRegister.aspx.vb's Page_Load (customer groups + TelecallStatusMaster dropdown fill). */
  getTeleCallingFilters(): Observable<{ groups: LookupOption[]; stages: LookupOption[] }> {
    return this.http.get<{ groups: LookupOption[]; stages: LookupOption[] }>(`${OPS}/telecalling/filters`);
  }

  /** Mirrors CustTeleCallingRegister.aspx.vb's FillGV (EXEC webproc_ShowTeleCallEnquiry). */
  getTeleCallingRows(groupId = 0, actionStageStatusId = 0): Observable<TeleCallingRow[]> {
    return this.http
      .get<ApiTeleCallingRow[]>(`${OPS}/telecalling`, { params: { group_id: groupId, action_stage_status_id: actionStageStatusId } })
      .pipe(map((rows) => rows.map(toTeleCallingRow)));
  }

  /** Mirrors CustTeleCallingRegister.aspx.vb's GVAction_DetailTableDataBind (EXEC webproc_ShowTeleCallEnquiryAction). */
  getTeleCallingActions(custId: number): Observable<TeleCallingActionRow[]> {
    return this.http
      .get<ApiTeleCallingActionRow[]>(`${OPS}/telecalling/${custId}/actions`)
      .pipe(map((rows) => rows.map(toTeleCallingActionRow)));
  }

  /** Mirrors CustHeatMap/CustMapLocation's client-side call to App_Service/CRMMAP.asmx/GetLatLong. */
  getCustGeoLocations(): Observable<CustGeoRow[]> {
    return this.http.get<ApiCustGeoRow[]>(`${GEO}/locations`).pipe(map((rows) => rows.map(toCustGeoRow)));
  }

  /** Mirrors EntityLatLong.aspx.vb's FillCustomer (customers with/without Latitude set, per chkEdit). */
  getEntityLatLongCustomers(editMode: boolean, search = ''): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${GEO}/entity-customers`, { params: { edit_mode: editMode, search } });
  }

  /** Mirrors EntityLatLong.aspx.vb's FillLatLong. */
  getEntityLatLong(custId: number): Observable<EntityLatLongOption> {
    return this.http
      .get<ApiEntityLatLongOption | null>(`${GEO}/entity/${custId}`)
      .pipe(map((r) => (r ? toEntityLatLongOption(r) : { custId, displayName: '', locationName: '', latitude: '', longitude: '' })));
  }

  /** Mirrors EntityLatLong.aspx.vb's btnSave_Click (Update CustomerMaster Set Latitude/Longitude). */
  saveEntityLatLong(custId: number, latitude: string, longitude: string): Observable<boolean> {
    return this.http
      .post<{ success: boolean }>(`${GEO}/entity/${custId}`, null, { params: { latitude, longitude } })
      .pipe(map((r) => r.success));
  }

  /** Mirrors CustEnquiryRegister.aspx.vb's btnsend_Click (WhatsApp template message send). */
  sendWhatsAppMessage(custId: number, messageIndex: number, mobileNo: string): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${REG}/whatsapp/${custId}`, null, {
      params: { message_index: messageIndex, mobile_no: mobileNo }
    });
  }

  /** Mirrors CustEnquiry.aspx.vb's ViewPanel grid (gvviewenquiry, ActionType=3). */
  getEnquiryHistory(custId: number): Observable<CustEnquiryHistoryRow[]> {
    return this.http
      .get<ApiCustEnquiryHistoryRow[]>(`${ENQ}/enquiry-history/${custId}`)
      .pipe(map((rows) => rows.map(toCustEnquiryHistoryRow)));
  }
}

export interface CustEnquiryForm {
  enquiryDate: string;
  receivedBy: number | null;
  sourceType: number | null;
  sourceDetail: string;
  natureOfBusiness: number | null;
  segment: number | null;
  commMethod: number | null;
  commDetails: string;
  ownership: number | null;
  noOfOutlets: string;
  methodOfSale: number | null;
  sizeOfShop: string;
  goodsSold: number | null;
  totalItems: string;
  rushHours: string;
  salesStaff: string;
  billingSystem: string;
  transactionsPerDay: string;
  competitor: string;
  customisation: string;
  orderValue: string;
  modules: string;
  discountOffered: string;
  assignedTo: string;
  narration: string;
}

export interface OutstandingFollowupRow {
  custId: number;
  salesMan: string;
  displayName: string;
  city: string;
  mobileNo: string;
  ledgerBalance: number;
  ledgerGroupBalance: number;
  amcAmount: number;
  amcDueDate: string;
}

export interface DownloadedEnquiryRow {
  custId: number;
  customerName: string;
  city: string;
  narration: string;
  enquiryDate: string;
  assignedUserId: number;
  assignedTo: string;
  segmentName: string;
  businessNatureName: string;
}

export interface LeadSummaryRow {
  typeId: number;
  typeName: string;
  leadsGenerated: number;
  leadsConverted: number;
  leadConversionRate: number;
  noOfTransactions: number;
  saleRevenue: number;
  amcVisitRevenue: number;
  totalRevenue: number;
}

export interface LeadSummaryDetailRow {
  custId: number;
  generated: boolean;
  converted: boolean;
  assignedTo: string;
  enquiryDate: string;
  customerName: string;
  mobileNo: string;
  verticalName: string;
  segmentName: string;
  sourceTypeName: string;
  sourceNarration: string;
  city: string;
  contactPerson: string;
  existingSoftware: string;
}

export interface TourCityRow {
  city: string;
  tourCount: number;
}

export interface TourReportRow {
  userName: string;
  visitType: string;
  modeOfTravel: string;
  city: string;
  customer: string;
  date: string;
  paymentVoucherNo: string;
  month: string;
  amount: number;
}

export interface EReferralRow {
  requestSrNo: number;
  referralVoucherNo: string;
  shopName: string;
  shopAddress: string;
  shopCity: string;
  shopContactPerson: string;
  shopMobileNo: string;
  emailAddress: string;
  introducedByShopName: string;
  introduceByName: string;
  introducedByShopCity: string;
  introducedByMobileNo: string;
  creationDate: string;
  creationTime: string;
  remark: string;
}

export interface CustRegistrationLookups {
  groups: LookupOption[];
  caseTypes: LookupOption[];
  businessNatures: LookupOption[];
  enquirySources: LookupOption[];
  receivedByUsers: LookupOption[];
  segments: LookupOption[];
  providers: LookupOption[];
  campaigns: LookupOption[];
  continents: LookupOption[];
  zones: LookupOption[];
  countries: LookupOption[];
  states: LookupOption[];
  districts: LookupOption[];
  cities: LookupOption[];
}

export interface CustRegistrationDetail {
  custId: number;
  groupId: number;
  name: string;
  lastName: string;
  mobileNo: string;
  telephoneNo: string;
  email: string;
  address1: string;
  address2: string;
  area: string;
  pinCode: string;
  contactPerson: string;
  gstin: string;
  arn: string;
  caseType: string;
  hardwarePartner: string;
  narration: string;
  continentId: number;
  countryId: number;
  stateId: number;
  districtId: number;
  cityId: number;
  zoneId: number;
  enquiryDate: string;
  receivedBy: number;
  enquirySource: number;
  // Web_Enquiry.sourcetype2/sourceDate — a second Enquiry Source picker with
  // its own date, same EnquirySourceType lookup as enquirySource above. See
  // marketing_registration.py's CustRegistrationDetail.enquiry_source_2
  // comment for why these need a dedicated follow-up write on the backend.
  enquirySource2: number;
  enquirySource2Date: string | null;
  sourceDetail: string;
  businessNature: number;
  segment: number;
  provider: number;
  referralCardNo: string;
  hardware: string;
  campaignId: number;
  referredByName: string;
  // The actual FK the backend's stored procs gate their referral-card
  // validation on (@ReferredCustID) — referredByName alone isn't enough,
  // see marketing_registration.py's 2026-08-04 update note. 0 means "no
  // referral selected", matching the backend's own default/sentinel.
  referredByCustomerId: number;
  assignedToName: string;
}

export interface TeleCallingRow {
  custId: number;
  nextAction: 'Add' | 'Close' | 'Closed';
  refActionId: number;
  mobileNo: string;
  phNo: string;
  enquiryDate: string;
  shopName: string;
  contactPerson: string;
  city: string;
  receivedBy: string;
  narration: string;
  segmentName: string;
  businessNatureName: string;
  sourceTypeName: string;
  introducedByName: string;
  communicationMethodName: string;
  referredByName: string;
}

export interface TeleCallingActionRow {
  actionId: number;
  actionStage: string;
  actionStageStatus: string;
  creationDate: string;
  creationTime: string;
  createdBy: string;
  actionDate: string;
  actionTime: string;
  assignedTo: string;
  actionDescription: string;
  actionRemark: string;
  completionDate: string;
  completionTime: string;
  completedBy: string;
  completedRemark: string;
  salesPerson: string;
  voucherNo: string;
  toDoVoucherNo: string;
}

export interface CustGeoRow {
  custId: number;
  customerName: string;
  verticalId: number;
  verticalName: string;
  segmentName: string;
  enquirySourceTypeName: string;
  locationAddress: string;
  latitude: number;
  longitude: number;
}

export interface EntityLatLongOption {
  custId: number;
  displayName: string;
  locationName: string;
  latitude: string;
  longitude: string;
}

export interface EnquiryStatusRow {
  assignedToUserId: number;
  assignedTo: string;
  assignedToMobile: string;
  assignedToEmail: string;
  enquiryCount: number;
  progressPercent: number;
  lastActionDate: string;
}

export interface EnquiryStatusDetailRow {
  custId: number;
  isAuto: number;
  segmentName: string;
  enquiryDate: string;
  customerName: string;
  mobileNo: string;
  area: string;
  city: string;
  stagePercent: number;
  lastActionDate: string;
}

export interface CrmReportRow {
  custId: number;
  enquiryDate: string;
  displayName: string;
  city: string;
  mobileNo: string;
  email: string;
  contactPerson: string;
  address: string;
  sourceNarration: string;
  receivedBy: string;
  communicationDetails: string;
  salesman: string;
}

export interface CrmActivityRow {
  userId: number;
  custId: number;
  activityId: number;
  crmActivity: string;
  activityDateTime: string;
}

export interface ActionStageDetailRow {
  custId: number;
  date: string;
  name: string;
  segment: string;
  sourceDetail: string;
  city: string;
  salesman: string;
  orderValue: number;
  area: string;
}

export interface ActionSearchRow {
  custId: number;
  custName: string;
  city: string;
  actionStage: string;
  actionDescription: string;
  actionDate: string;
  actionTime: string;
  completedRemark: string;
  assignedTo: string;
  createdBy: string;
  actionRemark: string;
  actionCompleted: boolean;
  completedBy: string;
  salesPerson: string;
  actionStageStatus: string;
}

export interface LeadRecordRow {
  custId: number;
  displayName: string;
  custAddress: string;
  area: string;
  city: string;
  districtName: string;
  pincode: string;
  contactNumber: string;
  receivedOn: string;
  enquiryCreatedOn: string;
  firstReceivedBy: string;
  assignedTo: string;
  salesPerson: string;
  enquirySource: string;
  verticalName: string;
  segmentName: string;
  hardwarePartner: string;
  referredByCustomer: string;
  oldSoftware: string;
  convertedToSo: string;
  soNumber: number | null;
  soDate: string | null;
  soAmount: number;
  specialRating: string;
  campaign: string;
  narration: string;
}

export interface CustEnquiryRegisterRow {
  custId: number;
  enquiryDate: string;
  stagePercent: number;
  receivedBy: string;
  narration: string;
  segmentName: string;
  businessNatureName: string;
  sourceTypeName: string;
  sourceNarration: string;
  introducedByName: string;
  referredByName: string;
  currentSoftware: string;
  campaignName: string;
  caseType: string;
  hardwarePartner: string;
  sourceType2Name: string;
  sourceDate2: string | null;
}

export interface CustomerRegisterInfo {
  custId: number;
  shopName: string;
  address: string;
  contactPerson: string;
  mobileNo: string;
  telNo: string;
  email: string;
  gstin: string;
  websiteName: string;
}

export interface EnquiryRegisterSearchResult {
  customerInfo: CustomerRegisterInfo | null;
  rows: CustEnquiryRegisterRow[];
}

interface ApiCustomerRegisterInfo {
  cust_id: number;
  shop_name: string;
  address: string;
  contact_person: string;
  mobile_no: string;
  tel_no: string;
  email: string;
  gstin: string;
  website_name: string;
}

function toCustomerRegisterInfo(r: ApiCustomerRegisterInfo): CustomerRegisterInfo {
  return {
    custId: r.cust_id,
    shopName: r.shop_name,
    address: r.address,
    contactPerson: r.contact_person,
    mobileNo: r.mobile_no,
    telNo: r.tel_no,
    email: r.email,
    gstin: r.gstin,
    websiteName: r.website_name
  };
}

interface ApiEnquiryRegisterSearchResult {
  customer_info: ApiCustomerRegisterInfo | null;
  rows: ApiCustEnquiryRegisterRow[];
}

export interface EnquiryActionEdit {
  actionStageId: number | null;
  actionDate: Date | null;
  actionTime: string;
  description: string;
  remark: string;
  assignedTo: number | null;
  salesPersonId: number | null;
  quotationAmt: number | null;
  /** Completion fields below only apply (and are only saved) when the action is already closed. */
  completed: boolean;
  completedBy: number | null;
  completionDate: Date | null;
  completionTime: string;
  completedRemark: string;
}

export interface EnquiryRegisterActionRow {
  actionId: number;
  actionStage: string;
  creationDate: string;
  creationTime: string;
  createdBy: string;
  actionDate: string;
  actionTime: string;
  assignedTo: string;
  actionDescription: string;
  actionRemark: string;
  completionDate: string;
  completionTime: string;
  completedBy: string;
  completedRemark: string;
  salesPerson: string;
  voucherNo: string;
  toDoVoucherNo: string;
  actionStageStatus: string;
  quotationAmt: number;
  nextAction: 'Add' | 'Close' | 'Closed';
}

export interface CustEnquiryHistoryRow {
  shopName: string;
  enquiryDate: string;
  sourceTypeName: string;
  sourceNarration: string;
  receivedByName: string;
  assignedToName: string;
  noOfOutlets: string;
  ownershipName: string;
  businessNatureName: string;
  sizeOfShop: string;
  goodsSold: string;
  presentBillingSystem: string;
  modules: string;
  creationDate: string;
  orderValue: string;
  narration: string;
}
