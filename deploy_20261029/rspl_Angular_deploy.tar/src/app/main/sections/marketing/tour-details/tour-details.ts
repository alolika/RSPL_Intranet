import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { LookupOption, MarketingDataService, TourCityRow } from '../marketing-data.service';

/**
 * Mirrors Section_Marketing/TourDetails.aspx ("City Wise Tour Details
 * Report" / menu "Tour Count Report"): a date-range + salesman filtered
 * per-city tour count grid with an appended Total row.
 */
@Component({
  selector: 'app-tour-details',
  imports: [FormsModule, ButtonModule, DatePickerModule, SelectModule, TableModule],
  templateUrl: './tour-details.html',
  styleUrl: './tour-details.scss'
})
export class TourDetails implements OnInit {
  private readonly data = inject(MarketingDataService);

  readonly salesmen = signal<LookupOption[]>([]);
  readonly rows = signal<TourCityRow[]>([]);
  readonly loading = signal(false);

  fromDate: Date | null = new Date();
  toDate: Date | null = new Date();
  salesmanName = '';

  ngOnInit(): void {
    this.data.getTourSalesmen().subscribe((s) => this.salesmen.set(s));
    this.show();
  }

  show(): void {
    if (!this.fromDate || !this.toDate) {
      return;
    }
    this.loading.set(true);
    this.data.getTourCityDetails(this.fromDate, this.toDate, this.salesmanName).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }

  export(): void {
    exportToExcel('CityWiseTourCount', this.rows());
  }
}
