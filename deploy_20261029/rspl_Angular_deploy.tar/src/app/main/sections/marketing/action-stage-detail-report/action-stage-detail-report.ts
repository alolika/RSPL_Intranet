import { DatePipe, Location } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, computed, inject, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import {
  ActionStageDetailRow,
  EnquiryRegisterActionRow,
  MarketingDataService
} from '../marketing-data.service';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';

export interface ActionStageDetailParams {
  actionStageName: string;
  executiveName: string;
  fromDate: Date | null;
  toDate: Date | null;
}

/**
 * Mirrors Section_Marketing/ActionStageDetailReport.aspx: a drill-down grid,
 * with a Total row summing Order Value. The source's two-level nested detail
 * expand (LastEnquiryAction wrapping CustEnquiryAction) is collapsed into one
 * action-history table per row — same simplification already applied to
 * CustomerLicenseViolation.
 *
 * Embedded inside a p-dialog by ActionStageSummaryReport (its only caller) via
 * the `params` input, rather than navigated to as its own route — a full page
 * navigation away and back (Location.back()) destroyed and recreated the
 * summary report's component instance, resetting its filters/loaded rows/
 * scroll position every time the drill-down was closed. `params` bypassing
 * `ngOnInit` re-fires because the summary report mounts a fresh instance of
 * this component each time the dialog opens (see its template), the same way
 * a fresh route navigation used to. The ActivatedRoute path below is kept as
 * a fallback in case this is ever linked to directly instead of embedded.
 */
@Component({
  selector: 'app-action-stage-detail-report',
  imports: [ButtonModule, TableModule, DatePipe, IndianNumberPipe],
  templateUrl: './action-stage-detail-report.html',
  styleUrl: './action-stage-detail-report.scss'
})
export class ActionStageDetailReport implements OnInit, OnChanges {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(MarketingDataService);
  private readonly location = inject(Location);

  @Input() params: ActionStageDetailParams | null = null;
  @Output() readonly closeRequested = new EventEmitter<void>();

  readonly heading = signal('');
  readonly isTourCount = signal(false);
  readonly rows = signal<ActionStageDetailRow[]>([]);
  readonly expandedCustId = signal<number | null>(null);
  readonly actionHistory = signal<EnquiryRegisterActionRow[]>([]);

  readonly totalOrderValue = computed(() => this.rows().reduce((sum, r) => sum + r.orderValue, 0));

  ngOnInit(): void {
    if (this.params) {
      this.load(this.params);
      return;
    }

    // Fallback for direct route usage (no embedding parent) — launched
    // repeatedly from other reports' per-column links with different params
    // each time, so subscribe rather than reading a one-time snapshot.
    this.route.queryParamMap.subscribe((q) => {
      this.load({
        actionStageName: q.get('ActionStageName') ?? '',
        executiveName: q.get('ExecutiveName') ?? '',
        fromDate: q.get('FromDate') ? new Date(q.get('FromDate')!) : null,
        toDate: q.get('ToDate') ? new Date(q.get('ToDate')!) : null
      });
    });
  }

  // The parent keeps this component mounted between dialog opens/closes
  // (rather than tearing it down on close) to avoid the dialog's close
  // animation revealing an empty/torn-down body mid-fade — so a second
  // drill-down click updates `params` on an already-mounted instance rather
  // than creating a fresh one, and needs this to actually reload.
  // ngOnInit already handles the first binding (fires before ngOnChanges'
  // firstChange too, so skip that one here to avoid loading twice).
  ngOnChanges(changes: SimpleChanges): void {
    if (this.params && changes['params'] && !changes['params'].firstChange) {
      this.load(this.params);
    }
  }

  private load(p: ActionStageDetailParams): void {
    this.isTourCount.set(p.actionStageName === 'Tour Count');
    this.heading.set(`Enquiry Stage Detail Report - ${p.actionStageName} By ${p.executiveName}`);
    this.expandedCustId.set(null);
    this.data
      .getActionStageDetailRows(p.actionStageName, p.executiveName, p.fromDate, p.toDate)
      .subscribe((rows) => this.rows.set(rows));
  }

  toggleExpand(row: ActionStageDetailRow): void {
    if (this.expandedCustId() === row.custId) {
      this.expandedCustId.set(null);
      return;
    }
    this.expandedCustId.set(row.custId);
    this.data.getActionStageDetailHistory(row.custId).subscribe((rows) => this.actionHistory.set(rows));
  }

  export(): void {
    exportToExcel('ActionDetailreport', this.rows());
  }

  close(): void {
    if (this.params) {
      this.closeRequested.emit();
      return;
    }
    this.location.back();
  }
}
