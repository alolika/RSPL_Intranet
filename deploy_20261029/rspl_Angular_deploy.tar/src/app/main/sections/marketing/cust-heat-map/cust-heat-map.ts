import { DecimalPipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { TableModule } from 'primeng/table';

import { GOOGLE_MAPS_API_KEY } from '../../../../shared/google-maps-key';
import { CustGeoRow, MarketingDataService } from '../marketing-data.service';

/**
 * Mirrors Section_Marketing/CustHeatMap.aspx ("Customer Geo Location" /
 * menu "CustomerMap-Heat"): all-customer geo markers with clustering, backed
 * by App_Service/CRMMAP.asmx/GetLatLong. No Google Maps API key is
 * configured in this frontend-only phase (see shared/google-maps-key.ts),
 * so the clustered map itself is replaced with the same underlying geo data
 * as a table — the marker-clustering visual has no functional effect beyond
 * the map render anyway.
 */
@Component({
  selector: 'app-cust-heat-map',
  imports: [TableModule, DecimalPipe],
  templateUrl: './cust-heat-map.html',
  styleUrl: './cust-heat-map.scss'
})
export class CustHeatMap implements OnInit {
  private readonly data = inject(MarketingDataService);

  readonly rows = signal<CustGeoRow[]>([]);
  readonly hasMapsKey = !!GOOGLE_MAPS_API_KEY;

  ngOnInit(): void {
    this.data.getCustGeoLocations().subscribe((rows) => this.rows.set(rows));
  }
}
