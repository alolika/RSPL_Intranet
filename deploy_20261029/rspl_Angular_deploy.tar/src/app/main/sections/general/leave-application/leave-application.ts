import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelectModule } from 'primeng/multiselect';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { PortalAuthService } from '../../../../core/auth/portal-auth.service';
import { LeaveDataService, LookupOption, StagedLeaveRow } from '../leave-data.service';

const LEAVE_DAY_OPTIONS = ['0.5', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15'];
const HALF_OPTIONS: LookupOption[] = [
  { label: '1st Half', value: 1 },
  { label: '2nd Half', value: 2 }
];

/**
 * Mirrors Section_General/LeaveApplication.aspx: the letter-style leave
 * request form. Rows are staged client-side (source used Session("dt")) and
 * only actually submitted when "Submit" is clicked, matching the source's
 * Add-then-Submit two-step flow.
 */
@Component({
  selector: 'app-leave-application',
  imports: [FormsModule, ButtonModule, SelectModule, DatePickerModule, InputTextModule, MultiSelectModule, TableModule],
  templateUrl: './leave-application.html',
  styleUrl: './leave-application.scss'
})
export class LeaveApplication implements OnInit {
  private readonly data = inject(LeaveDataService);
  private readonly auth = inject(PortalAuthService);
  private readonly router = inject(Router);

  readonly applicantName = this.auth.currentUser()?.userName ?? '';
  readonly leaveDayOptions = LEAVE_DAY_OPTIONS;
  readonly halfOptions = HALF_OPTIONS;
  readonly hoOptions = signal<LookupOption[]>([]);
  readonly informToOptions = signal<LookupOption[]>([]);
  readonly hoEnabled = signal(false);
  readonly stagedRows = signal<StagedLeaveRow[]>([]);
  readonly submitting = signal(false);

  // From Date can't be older than 15 days ago — no upper bound, any future
  // date is allowed. Truncated to midnight so comparisons against `fromDate`
  // (also truncated before comparing) aren't thrown off by time-of-day.
  readonly minFromDate = (() => {
    const d = new Date();
    d.setDate(d.getDate() - 15);
    return this.dateOnly(d);
  })();

  fromDate = new Date();
  selectedDays: string | null = null;
  toDateText = '';
  showHalf = false;
  selectedHalf: number | null = null;
  reason = '';
  selectedHo: string | null = null;
  informTo: number[] = [];

  ngOnInit(): void {
    this.data.isHoEnabledForUser().subscribe((enabled) => this.hoEnabled.set(enabled));
    this.data.getHoOptions().subscribe((opts) => this.hoOptions.set(opts));
    this.data.getInformToOptions().subscribe((opts) => this.informToOptions.set(opts));
  }

  onDaysChange(): void {
    this.recalculateToDate();
  }

  onFromDateChange(): void {
    this.recalculateToDate();
  }

  private dateOnly(d: Date): Date {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
  }

  private recalculateToDate(): void {
    if (!this.selectedDays) {
      return;
    }
    const fromDateOnly = this.dateOnly(this.fromDate);
    if (fromDateOnly < this.minFromDate) {
      alert('From Date cannot be more than 15 days in the past!');
      return;
    }
    if (this.selectedDays === '0.5') {
      this.showHalf = true;
      this.toDateText = this.formatDate(this.fromDate);
    } else {
      this.showHalf = false;
      const toDate = new Date(this.fromDate);
      toDate.setDate(toDate.getDate() + Number(this.selectedDays) - 1);
      this.toDateText = this.formatDate(toDate);
    }
  }

  // Builds the exact "dd-MMM-yyyy" format the backend parses with Python's
  // strptime("%d-%b-%Y") (e.g. "01-Sep-2026"). Deliberately NOT using
  // toLocaleDateString('en-GB', { month: 'short' }) — this browser's ICU
  // data renders September as "Sept" (4 letters), which strptime's "%b"
  // rejects with "Invalid From Date", while every other month happens to
  // match. A fixed abbreviation table avoids depending on locale/ICU data.
  private static readonly MONTH_ABBR = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];

  private formatDate(date: Date): string {
    const day = String(date.getDate()).padStart(2, '0');
    const month = LeaveApplication.MONTH_ABBR[date.getMonth()];
    return `${day}-${month}-${date.getFullYear()}`;
  }

  addRow(): void {
    if (!this.selectedDays) {
      alert('Please select proper days !');
      return;
    }
    if (!this.reason.trim()) {
      alert('Please enter Reason!');
      return;
    }
    this.stagedRows.update((rows) => [
      ...rows,
      {
        userId: this.auth.currentUser()?.userId ?? 0,
        reason: this.reason,
        fromDate: this.formatDate(this.fromDate),
        toDate: this.toDateText,
        days: this.selectedDays!,
        halfDays: this.showHalf && this.selectedHalf ? (this.selectedHalf === 1 ? '1st Half' : '2nd Half') : ''
      }
    ]);
    this.selectedDays = null;
    this.reason = '';
  }

  removeRow(index: number): void {
    this.stagedRows.update((rows) => rows.filter((_, i) => i !== index));
  }

  submit(): void {
    if (!this.toDateText) {
      alert('To date is not valid !');
      return;
    }
    if (this.hoEnabled() && !this.selectedHo) {
      alert('Please select HO !');
      return;
    }
    if (this.stagedRows().length === 0) {
      return;
    }

    // The HOD <p-select> binds optionValue="label" (display name, used as-is for the
    // legacy `HO` text column) — resolve the matching option's UserID separately so the
    // backend can look up the HOD's email for notifications.
    const hoUserId = this.hoOptions().find((o) => o.label === this.selectedHo)?.value ?? null;

    this.submitting.set(true);
    this.data.submitLeaveApplication(this.stagedRows(), this.selectedHo ?? '', hoUserId, this.informTo).subscribe({
      next: () => {
        this.submitting.set(false);
        alert('Leave Application send successfully !');
        this.router.navigate(['/dashboard']);
      },
      // Previously silent on failure (no error callback) — the Submit
      // button would stay stuck in its loading state with no feedback.
      // Surfaces the backend's actual detail message (e.g. a 400 validation
      // reason) instead of a generic string, so a real cause is visible
      // instead of being swallowed.
      error: (err: HttpErrorResponse) => {
        this.submitting.set(false);
        const detail = typeof err.error?.detail === 'string' ? err.error.detail : null;
        alert(detail ?? 'Could not submit the leave application. Please try again.');
      }
    });
  }
}
