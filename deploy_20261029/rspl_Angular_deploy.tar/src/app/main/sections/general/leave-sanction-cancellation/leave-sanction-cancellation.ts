import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { TextareaModule } from 'primeng/textarea';

import { LeaveCancelSanctionRequest, LeaveDataService } from '../leave-data.service';

type Decision = 'approve' | 'reject';

/**
 * Mirrors Section_General/LeaveSanctionCancellation.aspx: an unauthenticated
 * email-action-link page (?LID=&UID=&SrNo=) where an employee's HO approves
 * or rejects a cancellation of an already-sanctioned leave. Uses
 * Index.master in the source (bare shell) — see BareLayout.
 *
 * Update (2026-08-18): per explicit request, matched leave-sanction.ts's
 * format — replaced the SelectButton (pick Approve/Reject) + separate
 * Submit button with two direct-action buttons (Approve/green, Reject/red)
 * that immediately submit that decision, same as the leave-application
 * sanction page. submitHoCancelSanction() below is called exactly the same
 * way the old submit() did — only how the decision is chosen changed.
 */
@Component({
  selector: 'app-leave-sanction-cancellation',
  imports: [FormsModule, ButtonModule, TextareaModule, DatePipe],
  templateUrl: './leave-sanction-cancellation.html',
  styleUrl: './leave-sanction-cancellation.scss'
})
export class LeaveSanctionCancellation implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(LeaveDataService);
  // No zone.js in this app — plain (non-signal) properties like `remark`
  // below don't trigger a re-render when mutated inside an RxJS subscribe
  // callback.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly request = signal<LeaveCancelSanctionRequest | null>(null);
  readonly submitting = signal(false);
  remark = '';

  private leaveId = 0;
  private userId = 0;

  ngOnInit(): void {
    this.route.queryParamMap.subscribe((params) => {
      this.leaveId = Number(params.get('LID') ?? 0);
      this.userId = Number(params.get('UID') ?? 0);
      const srNo = Number(params.get('SrNo') ?? 0);
      this.remark = '';
      this.cdr.markForCheck();

      this.data.getLeaveCancelSanctionRequest(this.leaveId, this.userId, srNo).subscribe((req) => {
        this.request.set(req);
        this.cdr.markForCheck();
        if (req.alreadyCancelledByHo || req.alreadyRejected) {
          alert('You have already responded to this cancellation request !');
        }
      });
    });
  }

  approve(): void {
    this.submitDecision('approve');
  }

  reject(): void {
    this.submitDecision('reject');
  }

  private submitDecision(decision: Decision): void {
    this.submitting.set(true);
    this.data.submitHoCancelSanction(this.leaveId, this.userId, decision, this.remark).subscribe(() => {
      this.submitting.set(false);
      alert(
        decision === 'approve'
          ? 'Thank you — the leave cancellation has been approved and the applicant notified.'
          : 'The cancellation request has been rejected and the applicant notified.'
      );
    });
  }
}
