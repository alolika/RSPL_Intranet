import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { TableModule } from 'primeng/table';
import { TagModule } from 'primeng/tag';
import { TextareaModule } from 'primeng/textarea';

import { LeaveDataService, LeaveSanctionArticle } from '../leave-data.service';

const STATUS_SEVERITY: Record<string, 'success' | 'danger' | 'warn'> = {
  Sanctioned: 'success',
  Rejected: 'danger',
  Pending: 'warn'
};

type Decision = 'approve' | 'reject' | null;

type NoticeTone = 'success' | 'info' | 'warn';

interface Notice {
  tone: NoticeTone;
  icon: string;
  text: string;
}

const NOTICE_ICON: Record<NoticeTone, string> = {
  success: 'pi-check-circle',
  info: 'pi-info-circle',
  warn: 'pi-exclamation-triangle'
};

/**
 * Mirrors Section_General/LeaveSanction.aspx: an unauthenticated
 * email-action-link page (reached via ?si=ArticleID) where an employee's
 * HO approves or rejects a pending leave request. Uses Index.master (bare
 * shell, no nav) in the source — see BareLayout.
 *
 * Update (2026-08-04): per explicit request, replaced the old
 * per-item Approve/Reject toggle + single bottom Submit button with two
 * direct-action buttons (Approve/green, Reject/red) in Submit's old spot —
 * clicking either immediately applies that decision to every item on this
 * article and submits, with no separate Submit step. This is a UI-only
 * change: submitDecisions() below calls the exact same
 * LeaveDataService.submitHoSanction() the old submit() did, so every
 * server-side validation/workflow/email-notification rule (including the
 * akshayaj@retailware.info copy added 2026-08-04 earlier the same day) is
 * completely untouched — only how the decisions array gets built changed
 * (every item set uniformly by the clicked button, instead of picked one
 * item at a time via a per-item selectButton that no longer exists).
 *
 * Update (2026-10-22): with more than one item, each has a checkbox and the
 * two buttons act on just the ticked items — see decide().
 */
@Component({
  selector: 'app-leave-sanction',
  imports: [FormsModule, ButtonModule, CheckboxModule, TableModule, TextareaModule, TagModule, DatePipe],
  templateUrl: './leave-sanction.html',
  styleUrl: './leave-sanction.scss'
})
export class LeaveSanction implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(LeaveDataService);
  // No zone.js in this app — plain (non-signal) properties like `decisions`/
  // `remark` below don't trigger a re-render when mutated inside an RxJS
  // subscribe callback.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly article = signal<LeaveSanctionArticle | null>(null);
  readonly submitting = signal(false);
  // Attractive inline banner shown for "already approved / already rejected"
  // and post-action confirmations — replaces the old raw window.alert()s
  // (same notifications, nicer presentation; no functionality removed).
  readonly notice = signal<Notice | null>(null);
  decisions: Record<number, Decision> = {};
  remark = '';

  private articleId = 0;

  // True once every item on this article has been HO-sanctioned — used to
  // catch a repeat click on Approve without re-submitting.
  readonly allApproved = computed(() => {
    const a = this.article();
    return !!a && a.items.length > 0 && a.items.every((i) => i.alreadySanctioned);
  });

  private readonly allRejected = computed(() => {
    const a = this.article();
    return !!a && a.items.length > 0 && a.items.every((i) => i.alreadyRejected);
  });

  statusSeverity(status: string): 'success' | 'danger' | 'warn' {
    return STATUS_SEVERITY[status] ?? 'warn';
  }

  private setNotice(tone: NoticeTone, text: string): void {
    this.notice.set({ tone, icon: NOTICE_ICON[tone], text });
    this.cdr.markForCheck();
  }

  ngOnInit(): void {
    this.route.queryParamMap.subscribe((q) => {
      this.articleId = Number(q.get('si') ?? 0);
      this.decisions = {};
      this.selected = {};
      this.remark = '';
      this.notice.set(null);
      this.cdr.markForCheck();
      this.data.getLeaveSanctionArticle(this.articleId).subscribe((article) => {
        this.article.set(article);
        for (const item of article.items) {
          this.decisions[item.srNo] = item.alreadySanctioned ? 'approve' : item.alreadyRejected ? 'reject' : null;
        }
        this.cdr.markForCheck();
        if (this.allApproved()) {
          this.setNotice('info', 'This leave has already been approved.');
        } else if (this.allRejected()) {
          this.setNotice('info', 'This leave has already been rejected.');
        } else if (article.items.some((i) => i.alreadySanctioned || i.alreadyRejected)) {
          this.setNotice('warn', 'You have already responded to some of these leave items.');
        }
      });
    });
  }

  // Update (2026-10-22): per explicit request, when an article has more than
  // one leave item (e.g. two separate dates) each gets a checkbox. Approve /
  // Reject then act on just the ticked items, so one date can be approved and
  // the other rejected; with nothing ticked they still act on every item
  // (the original one-click behavior, applyDecisionToAll below).
  selected: Record<number, boolean> = {};

  selectedCount(): number {
    return (this.article()?.items ?? []).filter((i) => this.selected[i.srNo]).length;
  }

  // Bound to the green Approve button.
  approve(): void {
    this.decide('approve');
  }

  // Bound to the red Reject button.
  reject(): void {
    this.decide('reject');
  }

  // Acts on the ticked items, or on every item when nothing is ticked.
  // Per explicit request (2026-10-23): an approved leave is final — rejecting
  // it is blocked, and approving it again just shows "already approved"
  // (no repeat submit / applicant notifications). The backend enforces the
  // same rule in submit_ho_sanction.
  private decide(decision: 'approve' | 'reject'): void {
    const items = this.article()?.items ?? [];
    const picked = items.filter((i) => this.selected[i.srNo]);
    const targets = picked.length ? picked : items;
    if (targets.length === 0) {
      return;
    }
    const one = targets.length === 1;

    if (decision === 'reject' && targets.some((i) => i.alreadySanctioned)) {
      const msg = one
        ? 'This leave has already been approved and cannot be rejected.'
        : 'Approved leave cannot be rejected. Tick only the leave(s) that are not approved yet.';
      this.setNotice('warn', msg);
      return;
    }

    const pending = targets.filter((i) =>
      decision === 'approve' ? !i.alreadySanctioned : !i.alreadyRejected
    );
    if (pending.length === 0) {
      const msg = decision === 'approve'
        ? one ? 'This leave has already been approved.' : 'The selected leave has already been approved.'
        : one ? 'This leave has already been rejected.' : 'The selected leave has already been rejected.';
      this.setNotice('info', msg);
      return;
    }

    for (const item of pending) {
      this.decisions[item.srNo] = decision;
    }
    this.submitItems(pending.map((i) => ({ srNo: i.srNo, decision })));
  }

  private submitItems(changed: { srNo: number; decision: 'approve' | 'reject' }[]): void {
    this.submitting.set(true);
    this.data.submitHoSanction(this.articleId, changed, this.remark).subscribe({
      next: () => {
        this.submitting.set(false);
        this.selected = {};
        const bySrNo = new Map(changed.map((d) => [d.srNo, d.decision]));
        this.article.update((a) =>
          a
            ? {
                ...a,
                items: a.items.map((i) =>
                  bySrNo.has(i.srNo)
                    ? { ...i, alreadySanctioned: bySrNo.get(i.srNo) === 'approve', alreadyRejected: bySrNo.get(i.srNo) === 'reject' }
                    : i
                )
              }
            : a
        );
        const approved = changed.filter((d) => d.decision === 'approve').length;
        const rejected = changed.length - approved;
        const parts = [approved ? `${approved} approved` : '', rejected ? `${rejected} rejected` : ''].filter(Boolean);
        this.setNotice('success', `Leave updated: ${parts.join(', ')}. The applicant has been notified.`);
      },
      error: () => {
        this.submitting.set(false);
        this.setNotice('warn', 'Could not save the decision. Please try again.');
      }
    });
  }
}
