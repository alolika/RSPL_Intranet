import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { TextareaModule } from 'primeng/textarea';

import { GeneralDataService } from '../general-data.service';

const EMAIL_PATTERN = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;

/**
 * Mirrors Section_General/Feedback.aspx ("New Feedback" / Suggestion Box).
 * The source's RadCaptcha has no client-only equivalent (validation is
 * inherently server-side) — omitted until the real API exists rather than
 * faked with a non-functional widget.
 */
@Component({
  selector: 'app-feedback',
  imports: [ReactiveFormsModule, ButtonModule, InputTextModule, TextareaModule],
  templateUrl: './feedback.html',
  styleUrl: './feedback.scss'
})
export class Feedback {
  private readonly fb = inject(FormBuilder);
  private readonly data = inject(GeneralDataService);

  readonly submitting = signal(false);

  readonly form = this.fb.nonNullable.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.pattern(EMAIL_PATTERN)]],
    city: ['', Validators.required],
    subject: ['', Validators.required],
    message: ['', Validators.required]
  });

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting.set(true);
    this.data.submitFeedback(this.form.getRawValue()).subscribe({
      next: () => {
        this.submitting.set(false);
        alert('Thanks for your feedback.');
        this.form.reset();
      },
      // Previously silent on failure (no error callback) — the Submit
      // button would stay stuck in its loading state with no feedback.
      error: () => {
        this.submitting.set(false);
        alert('Could not submit your feedback. Please try again.');
      }
    });
  }
}
