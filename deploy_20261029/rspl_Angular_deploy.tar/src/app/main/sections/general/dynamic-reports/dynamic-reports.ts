import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';

import { ReportSummary, ReportsDataService } from '../report-viewer/reports-data.service';

interface ReportGroup {
  name: string;
  icon: string;
  reports: ReportSummary[];
}

// Known category -> icon mapping for a bit of visual identity per group;
// anything not listed here (a new Analytic_ReportMenuMaster category added
// later) safely falls back to a generic icon rather than breaking.
const GROUP_ICONS: Record<string, string> = {
  AMC: 'pi-shield',
  'EXE Version': 'pi-desktop',
  Sales: 'pi-chart-line',
  Other: 'pi-ellipsis-h'
};
const DEFAULT_GROUP_ICON = 'pi-folder';

/**
 * Mirrors Section_General/DynamicReports.aspx: a RadMenu of available
 * reports linking into the report viewer. The source's menu structure and
 * the backend's own `report_menu_name` (Analytic_ReportMenuMaster,
 * confirmed live — 38 reports across AMC/EXE Version/Sales/Other) were
 * both already grouped by category, but the previous version of this page
 * ignored that and rendered every report as one flat, unstyled list —
 * fine at a handful of reports, not at 38. Grouped by that same category
 * here, plus a live search across all of them.
 */
@Component({
  selector: 'app-dynamic-reports',
  imports: [RouterLink, FormsModule, InputTextModule, MessageModule],
  templateUrl: './dynamic-reports.html',
  styleUrl: './dynamic-reports.scss'
})
export class DynamicReports implements OnInit {
  private readonly data = inject(ReportsDataService);

  readonly reports = signal<ReportSummary[]>([]);
  readonly loading = signal(false);
  readonly loadError = signal<string | null>(null);
  searchText = '';

  private readonly searchTextSignal = signal('');

  readonly groups = computed<ReportGroup[]>(() => {
    const query = this.searchTextSignal().trim().toLowerCase();
    const filtered = query ? this.reports().filter((r) => r.reportName.toLowerCase().includes(query)) : this.reports();

    const byName = new Map<string, ReportSummary[]>();
    for (const r of filtered) {
      const key = r.reportMenuName || 'Other';
      const list = byName.get(key);
      if (list) {
        list.push(r);
      } else {
        byName.set(key, [r]);
      }
    }

    return [...byName.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([name, reports]) => ({
        name,
        icon: GROUP_ICONS[name] ?? DEFAULT_GROUP_ICON,
        reports: reports.sort((a, b) => a.reportName.localeCompare(b.reportName))
      }));
  });

  readonly totalCount = computed(() => this.reports().length);
  readonly visibleCount = computed(() => this.groups().reduce((sum, g) => sum + g.reports.length, 0));

  ngOnInit(): void {
    this.loading.set(true);
    this.data.getReports().subscribe({
      next: (r) => {
        this.reports.set(r);
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
        this.loadError.set('Could not load the report list. Please try again.');
      }
    });
  }

  onSearchInput(): void {
    this.searchTextSignal.set(this.searchText);
  }
}
