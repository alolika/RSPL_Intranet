import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../../../shared/api-config';

const BASE = `${API_BASE_URL}/general`;

export interface LookupOption {
  label: string;
  value: number;
}

export interface DashboardTile {
  reportId: number;
  title: string;
  rows: Record<string, unknown>[];
}

export interface AmcDetailResult {
  columns: string[];
  rows: Record<string, unknown>[];
}

interface ApiDashboardTile {
  report_id: number;
  title: string;
  rows: Record<string, unknown>[];
}

export interface AttendanceRow {
  userId: number;
  userName: string;
  /** Keys "1".."31" -> status code (P/X/H/L/LH/AB), mirrors the source's day-numbered columns. */
  days: Record<string, string>;
}

export interface AssetTrackRow {
  date: string;
  fromUser: string;
  toUser: string;
  assetType: string;
  remark: string;
}

interface ApiAttendanceRow {
  user_id: number;
  user_name: string;
  days: Record<string, string>;
}

interface ApiAssetTrackRow {
  date: string;
  from_user: string;
  to_user: string;
  asset_type: string;
  remark: string;
}

/**
 * Calls the FastAPI backend (D:\Maruti_workspace\rspl_Api\app\routers\general.py),
 * which mirrors clsDBLayer calls from Section_General/*.aspx.vb
 * (webproc_FeedbackAdd, webproc_getuserschedule, webproc_AssettrackAdd, usermaster, MonthMaster).
 */
@Injectable({ providedIn: 'root' })
export class GeneralDataService {
  private readonly http = inject(HttpClient);

  submitFeedback(feedback: { name: string; email: string; city: string; subject: string; message: string }): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/feedback`, feedback);
  }

  getUsers(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/users`);
  }

  getMonths(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/months`);
  }

  getYears(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/years`);
  }

  getAssetTypes(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/asset-types`);
  }

  /** "From User" excludes the current session user, mirroring the source's `userid<>Session("userid")` filter. */
  getOtherUsers(excludeUserId: number): Observable<LookupOption[]> {
    const params = new HttpParams().set('exclude_user_id', excludeUserId);
    return this.http.get<LookupOption[]>(`${BASE}/other-users`, { params });
  }

  getAssetTrackRows(): Observable<AssetTrackRow[]> {
    return this.http.get<ApiAssetTrackRow[]>(`${BASE}/asset-track`).pipe(
      map((rows) =>
        rows.map((r) => ({
          date: r.date,
          fromUser: r.from_user,
          toUser: r.to_user,
          assetType: r.asset_type,
          remark: r.remark
        }))
      )
    );
  }

  addAssetTrack(assetType: string, fromUserId: number, remark: string): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/asset-track`, {
      asset_type: assetType,
      from_user_id: fromUserId,
      remark
    });
  }

  getUserSchedule(userId: number, year: number, month: number): Observable<AttendanceRow[]> {
    const params = new HttpParams().set('user_id', userId).set('year', year).set('month', month);
    return this.http.get<ApiAttendanceRow[]>(`${BASE}/attendance`, { params }).pipe(
      map((rows) => rows.map((r) => ({ userId: r.user_id, userName: r.user_name, days: r.days })))
    );
  }

  // Mirrors App_Master/Home.master.vb's dynamic "Dashboard" menu, built at
  // runtime from rspl_ReportDashboardTypeMAster — see general_dashboards.py
  // docstring for the full source-mapping explanation.
  getSalesTeamDashboard(): Observable<DashboardTile[]> {
    return this.http
      .get<ApiDashboardTile[]>(`${BASE}/dashboards/sales-team`)
      .pipe(map((tiles) => tiles.map((t) => ({ reportId: t.report_id, title: t.title, rows: t.rows }))));
  }

  getAmcDashboard(): Observable<DashboardTile[]> {
    return this.http
      .get<ApiDashboardTile[]>(`${BASE}/dashboards/amc`)
      .pipe(map((tiles) => tiles.map((t) => ({ reportId: t.report_id, title: t.title, rows: t.rows }))));
  }

  /** Customer-wise list behind one AMC Dashboard forecast cell (RSPL_AMCDashBoard_Analysis_Details). */
  getAmcDashboardDetails(column: string, month: string): Observable<AmcDetailResult> {
    return this.http.get<AmcDetailResult>(`${BASE}/dashboards/amc/details`, { params: { column, month } });
  }
}
