import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { TextareaModule } from 'primeng/textarea';

import { LeaveDataService, LeaveSanctionArticle } from '../leave-data.service';

/** Mirrors Section_General/CEO_LeaveSanction.aspx (?si=ArticleID), the CEO's final sanction step. */
@Component({
  selector: 'app-ceo-leave-sanction',
  imports: [FormsModule, ButtonModule, CheckboxModule, TextareaModule],
  templateUrl: './ceo-leave-sanction.html',
  styleUrl: './ceo-leave-sanction.scss'
})
export class CeoLeaveSanction implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(LeaveDataService);
  // No zone.js in this app — plain (non-signal) properties like `selected`/
  // `remark` below don't trigger a re-render when mutated inside an RxJS
  // subscribe callback.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly article = signal<LeaveSanctionArticle | null>(null);
  readonly submitting = signal(false);
  readonly ceoName = 'Ajit Thadhani';
  selected: Record<number, boolean> = {};
  remark = '';

  private articleId = 0;

  ngOnInit(): void {
    this.route.queryParamMap.subscribe((q) => {
      this.articleId = Number(q.get('si') ?? 0);
      this.selected = {};
      this.remark = '';
      this.cdr.markForCheck();
      this.data.getCeoSanctionArticle(this.articleId).subscribe((article) => {
        this.article.set(article);
        for (const item of article.items) {
          this.selected[item.srNo] = item.alreadySanctioned;
        }
        this.cdr.markForCheck();
        if (article.items.some((i) => i.alreadySanctioned)) {
          alert('You have already Sanction my Leaves !');
        }
      });
    });
  }

  submit(): void {
    const article = this.article();
    if (!article) {
      return;
    }
    const selectedSrNos = article.items.filter((i) => this.selected[i.srNo]).map((i) => i.srNo);
    this.submitting.set(true);
    this.data.submitCeoSanction(this.articleId, selectedSrNos, this.remark).subscribe(() => {
      this.submitting.set(false);
      alert('Thank you for Sanction my Leaves !');
    });
  }
}
