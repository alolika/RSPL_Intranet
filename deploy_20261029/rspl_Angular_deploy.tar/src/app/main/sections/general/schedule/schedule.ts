import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { ColorPickerModule } from 'primeng/colorpicker';
import { DatePickerModule } from 'primeng/datepicker';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TabsModule } from 'primeng/tabs';
import { TextareaModule } from 'primeng/textarea';

import { LookupOption, ScheduleComment, ScheduleDataService, ScheduleTask } from './schedule-data.service';

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];
// Was a hardcoded 2021-2030 — arbitrary, and (per the Dim_Time gap flagged
// in general_schedule.py) not actually any more "usable" than any other
// range for saving new tasks today. Centered on the current year instead,
// matching the same current-relative convention already used by
// AssetTrack/EmpAttendance's own getYears() (general.py) elsewhere in this
// app, so the default view at least starts somewhere relevant.
const CURRENT_YEAR = new Date().getFullYear();
const YEARS = Array.from({ length: 6 }, (_, i) => CURRENT_YEAR - 2 + i);

/**
 * Simplified rebuild of Section_General/schedule.aspx: a plain
 * employee x day-of-month grid instead of the source's dynamically
 * generated GridView columns with manual rowspan-merge logic (ASP.NET
 * WebForms plumbing, not a business rule) — same underlying data
 * (task/appointment per employee per day, reminders, guests, comments).
 */
@Component({
  selector: 'app-schedule',
  imports: [
    FormsModule,
    ButtonModule,
    SelectModule,
    TableModule,
    DialogModule,
    TabsModule,
    InputTextModule,
    TextareaModule,
    DatePickerModule,
    ColorPickerModule,
    CheckboxModule
  ],
  templateUrl: './schedule.html',
  styleUrl: './schedule.scss'
})
export class Schedule implements OnInit {
  private readonly data = inject(ScheduleDataService);
  // No zone.js in this app — plain (non-signal) properties like `newComment`
  // below don't trigger a re-render when mutated inside an RxJS subscribe callback.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly months = MONTHS;
  readonly monthOptions = MONTHS.map((label, value) => ({ label, value }));
  readonly yearOptions = YEARS.map((y) => ({ label: String(y), value: y }));
  readonly employees = signal<LookupOption[]>([]);
  readonly entityTypes = signal<LookupOption[]>([]);
  readonly reminderChannels = signal<LookupOption[]>([]);
  readonly tasks = signal<ScheduleTask[]>([]);
  readonly comments = signal<ScheduleComment[]>([]);
  readonly dialogVisible = signal(false);
  readonly saving = signal(false);

  selectedMonth = new Date().getMonth();
  selectedYear = new Date().getFullYear();
  days: number[] = [];

  activeTab: 'task' | 'appointment' | 'comment' = 'task';
  editing: ScheduleTask | null = null;
  form = this.blankForm();
  newComment = '';

  ngOnInit(): void {
    this.data.getEmployees().subscribe((e) => this.employees.set(e));
    this.data.getEntityTypes().subscribe((e) => this.entityTypes.set(e));
    this.data.getReminderChannels().subscribe((e) => this.reminderChannels.set(e));
    this.recalculateDays();
    this.refresh();
  }

  onMonthYearChange(): void {
    this.recalculateDays();
    this.refresh();
  }

  private recalculateDays(): void {
    const daysInMonth = new Date(this.selectedYear, this.selectedMonth + 1, 0).getDate();
    this.days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  }

  private refresh(): void {
    this.data.getMonthTasks(this.selectedYear, this.selectedMonth + 1).subscribe((tasks) => this.tasks.set(tasks));
  }

  // Was taskFor() — .find() only ever returned the FIRST match, so a day
  // with more than one task/appointment for the same employee (confirmed
  // live: 39 such user/day combinations exist in the real data) silently
  // hid every task after the first, both in the cell display and from ever
  // being opened/edited. Returns all matches now; the template renders each
  // one and the cell click adds a new task alongside them instead of
  // replacing what's shown.
  tasksFor(userId: number, day: number): ScheduleTask[] {
    return this.tasks().filter((t) => t.userId === userId && t.day === day);
  }

  openTask(task: ScheduleTask): void {
    this.editing = task;
    this.activeTab = task.isAppointment ? 'appointment' : 'task';
    this.form = { ...task };
    this.comments.set([]);
    this.data.getComments(task.taskSrNo, task.userId, this.taskDate(task.day)).subscribe((c) => this.comments.set(c));
    this.dialogVisible.set(true);
  }

  openCell(userId: number, userName: string, day: number): void {
    this.editing = null;
    this.activeTab = 'task';
    this.form = { ...this.blankForm(), userId, userName, day };
    this.comments.set([]);
    this.dialogVisible.set(true);
  }

  private taskDate(day: number): Date {
    return new Date(this.selectedYear, this.selectedMonth, day);
  }

  private blankForm(): ScheduleTask {
    return {
      taskSrNo: 0,
      userId: 0,
      userName: '',
      day: 0,
      isAppointment: false,
      title: '',
      fromTime: null,
      toTime: null,
      description: '',
      color: '#ffff00',
      isPrivate: false,
      entityTypeId: null,
      entityName: '',
      guestEmails: [],
      reminderChannels: []
    };
  }

  save(): void {
    if (!this.form.fromTime || !this.form.toTime) {
      alert(`Please select ${this.activeTab} from/to time`);
      return;
    }
    // Was missing entirely — nothing stopped saving a task "From 5 PM To 9
    // AM". Also checked server-side (general_schedule.py) since this
    // endpoint shouldn't trust the frontend to be its only caller.
    if (this.form.fromTime >= this.form.toTime) {
      alert(`${this.activeTab === 'appointment' ? 'Appointment' : 'Task'} From Time must be before To Time.`);
      return;
    }
    this.form.isAppointment = this.activeTab === 'appointment';
    this.saving.set(true);
    this.data.saveTask(this.form, this.selectedYear, this.selectedMonth + 1).subscribe({
      next: (res) => {
        this.saving.set(false);
        // Was previously ignored entirely — the backend can return
        // {success: false} (invalid time order, or a date this system
        // doesn't support — see dateNotSupported below) and the dialog
        // would close and refresh as if it had saved.
        if (!res.success) {
          alert(
            res.dateNotSupported
              ? 'This date is not supported by the scheduling system yet — please contact your administrator.'
              : 'Could not save. Please check the details and try again.'
          );
          return;
        }
        alert(this.editing ? 'Your task is updated successfully' : 'Your task is submitted successfully');
        this.dialogVisible.set(false);
        this.refresh();
      },
      // Previously silent on failure (no error callback) — the Submit
      // button would stay stuck in its loading state with no feedback.
      error: () => {
        this.saving.set(false);
        alert('Could not save. Please try again.');
      }
    });
  }

  submitComment(): void {
    if (!this.newComment.trim() || !this.editing) {
      return;
    }
    const editing = this.editing;
    this.data.addComment(editing.taskSrNo, editing.userId, this.taskDate(editing.day), this.newComment).subscribe({
      next: () => {
        this.data.getComments(editing.taskSrNo, editing.userId, this.taskDate(editing.day)).subscribe((c) => this.comments.set(c));
        this.newComment = '';
        this.cdr.markForCheck();
      },
      error: () => alert('Could not add your comment. Please try again.')
    });
  }
}
