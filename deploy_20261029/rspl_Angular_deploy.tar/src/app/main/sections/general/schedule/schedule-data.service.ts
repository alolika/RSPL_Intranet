import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../../../../shared/api-config';

const BASE = `${API_BASE_URL}/general/schedule`;

export interface LookupOption {
  label: string;
  value: number;
}

export interface ScheduleTask {
  taskSrNo: number;
  userId: number;
  userName: string;
  day: number;
  isAppointment: boolean;
  title: string;
  fromTime: Date | null;
  toTime: Date | null;
  description: string;
  color: string;
  isPrivate: boolean;
  entityTypeId: number | null;
  entityName: string;
  guestEmails: string[];
  reminderChannels: number[];
}

export interface ScheduleComment {
  userName: string;
  commentTime: string;
  commentText: string;
}

interface ApiScheduleTask {
  task_sr_no: number;
  user_id: number;
  user_name: string;
  day: number;
  is_appointment: boolean;
  title: string;
  from_time: string | null;
  to_time: string | null;
  description: string;
  color: string;
  is_private: boolean;
  entity_type_id: number | null;
  entity_name: string;
  guest_emails: string[];
  reminder_channels: number[];
}

interface ApiScheduleComment {
  user_name: string;
  comment_time: string;
  comment_text: string;
}

/**
 * Calls the FastAPI backend (D:\Maruti_workspace\rspl_Api\app\routers\general_schedule.py),
 * which mirrors Section_General/schedule.aspx.vb's Schedular_Proc_GetTaskData /
 * RSPL_EmployeeSchedule table and the Insert_Update_Task /
 * Insert_Update_Appointment helpers. The source's dynamic GridView-column
 * mechanics (per-cell rowspan merging, cell-index math) are ASP.NET
 * WebForms plumbing, not business rules — reproduced here as a plain
 * employee x day grid instead, same underlying data model.
 */
@Injectable({ providedIn: 'root' })
export class ScheduleDataService {
  private readonly http = inject(HttpClient);

  getEmployees(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/employees`);
  }

  getEntityTypes(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/entity-types`);
  }

  getReminderChannels(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/reminder-channels`);
  }

  getMonthTasks(year: number, month: number): Observable<ScheduleTask[]> {
    const params = new HttpParams().set('year', year).set('month', month);
    return this.http.get<ApiScheduleTask[]>(`${BASE}/tasks`, { params }).pipe(map((rows) => rows.map((r) => this.toTask(r))));
  }

  saveTask(
    task: Omit<ScheduleTask, 'taskSrNo'> & { taskSrNo?: number },
    year: number,
    month: number
  ): Observable<{ success: boolean; dateNotSupported?: boolean }> {
    return this.http.post<{ success: boolean; dateNotSupported?: boolean }>(`${BASE}/tasks`, {
      task: {
        task_sr_no: task.taskSrNo ?? 0,
        user_id: task.userId,
        user_name: task.userName,
        day: task.day,
        is_appointment: task.isAppointment,
        title: task.title,
        from_time: task.fromTime ? task.fromTime.toISOString() : null,
        to_time: task.toTime ? task.toTime.toISOString() : null,
        description: task.description,
        color: task.color,
        is_private: task.isPrivate,
        entity_type_id: task.entityTypeId,
        entity_name: task.entityName,
        guest_emails: task.guestEmails,
        reminder_channels: task.reminderChannels
      },
      year,
      month
    });
  }

  getComments(taskSrNo: number, taskUserId: number, taskDate: Date): Observable<ScheduleComment[]> {
    const params = new HttpParams()
      .set('task_sr_no', taskSrNo)
      .set('user_id', taskUserId)
      .set('task_date', this.toDateParam(taskDate));
    return this.http
      .get<ApiScheduleComment[]>(`${BASE}/comments`, { params })
      .pipe(map((rows) => rows.map((r) => ({ userName: r.user_name, commentTime: r.comment_time, commentText: r.comment_text }))));
  }

  addComment(taskSrNo: number, taskUserId: number, taskDate: Date, text: string): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/comments`, {
      task_sr_no: taskSrNo,
      task_user_id: taskUserId,
      task_date: this.toDateParam(taskDate),
      text
    });
  }

  searchGuestEmails(term: string): Observable<string[]> {
    const params = new HttpParams().set('term', term);
    return this.http.get<string[]>(`${BASE}/guest-emails`, { params });
  }

  private toTask(r: ApiScheduleTask): ScheduleTask {
    return {
      taskSrNo: r.task_sr_no,
      userId: r.user_id,
      userName: r.user_name,
      day: r.day,
      isAppointment: r.is_appointment,
      title: r.title,
      fromTime: r.from_time ? new Date(r.from_time) : null,
      toTime: r.to_time ? new Date(r.to_time) : null,
      description: r.description,
      color: r.color,
      isPrivate: r.is_private,
      entityTypeId: r.entity_type_id,
      entityName: r.entity_name,
      guestEmails: r.guest_emails,
      reminderChannels: r.reminder_channels
    };
  }

  private toDateParam(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }
}
