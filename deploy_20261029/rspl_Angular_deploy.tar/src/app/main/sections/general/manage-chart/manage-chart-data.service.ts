import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../../../../shared/api-config';

const BASE = `${API_BASE_URL}/general/manage-chart`;

export interface LookupOption {
  label: string;
  value: number;
}

export interface DepartmentRow {
  deptId: number;
  name: string;
  hodName: string;
  hodUserId: number;
  enabled: boolean;
}

export interface DesignationRow {
  designationId: number;
  desigName: string;
  enabled: boolean;
}

export interface AssignmentRow {
  userId: number;
  empName: string;
  desigName: string;
  desigId: number;
  deptName: string;
  deptId: number;
  parentEmpName: string;
  parentEmpId: number;
}

interface ApiDepartmentRow {
  dept_id: number;
  name: string;
  hod_name: string;
  hod_user_id: number;
  enabled: boolean;
}

interface ApiDesignationRow {
  designation_id: number;
  desig_name: string;
  enabled: boolean;
}

interface ApiAssignmentRow {
  user_id: number;
  emp_name: string;
  desig_name: string;
  desig_id: number;
  dept_name: string;
  dept_id: number;
  parent_emp_name: string;
  parent_emp_id: number;
}

/** Calls the FastAPI backend (D:\Maruti_workspace\rspl_Api\app\routers\general_org.py). Mirrors Section_General/ManageChart.aspx.vb — feeds the OragnizationalChart.aspx data. */
@Injectable({ providedIn: 'root' })
export class ManageChartDataService {
  private readonly http = inject(HttpClient);

  getEmployees(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/employees`);
  }

  getDepartments(): Observable<DepartmentRow[]> {
    return this.http.get<ApiDepartmentRow[]>(`${BASE}/departments`).pipe(
      map((rows) =>
        rows.map((r) => ({ deptId: r.dept_id, name: r.name, hodName: r.hod_name, hodUserId: r.hod_user_id, enabled: r.enabled }))
      )
    );
  }

  addDepartment(name: string, hodUserId: number, enabled: boolean): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/departments`, { name, hod_user_id: hodUserId, enabled });
  }

  updateDepartment(row: DepartmentRow): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${BASE}/departments/${row.deptId}`, {
      dept_id: row.deptId,
      name: row.name,
      hod_name: row.hodName,
      hod_user_id: row.hodUserId,
      enabled: row.enabled
    });
  }

  getDesignations(): Observable<DesignationRow[]> {
    return this.http
      .get<ApiDesignationRow[]>(`${BASE}/designations`)
      .pipe(map((rows) => rows.map((r) => ({ designationId: r.designation_id, desigName: r.desig_name, enabled: r.enabled }))));
  }

  addDesignation(name: string, enabled: boolean): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/designations`, { name, enabled });
  }

  updateDesignation(row: DesignationRow): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${BASE}/designations/${row.designationId}`, {
      designation_id: row.designationId,
      desig_name: row.desigName,
      enabled: row.enabled
    });
  }

  getAssignments(): Observable<AssignmentRow[]> {
    return this.http.get<ApiAssignmentRow[]>(`${BASE}/assignments`).pipe(
      map((rows) =>
        rows.map((r) => ({
          userId: r.user_id,
          empName: r.emp_name,
          desigName: r.desig_name,
          desigId: r.desig_id,
          deptName: r.dept_name,
          deptId: r.dept_id,
          parentEmpName: r.parent_emp_name,
          parentEmpId: r.parent_emp_id
        }))
      )
    );
  }

  updateAssignment(row: AssignmentRow): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${BASE}/assignments/${row.userId}`, {
      user_id: row.userId,
      emp_name: row.empName,
      desig_name: row.desigName,
      desig_id: row.desigId,
      dept_name: row.deptName,
      dept_id: row.deptId,
      parent_emp_name: row.parentEmpName,
      parent_emp_id: row.parentEmpId
    });
  }

  uploadEmployeeImage(userId: number, file: File): Observable<{ success: boolean }> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post<{ success: boolean }>(`${BASE}/upload-image?employee_id=${userId}`, formData);
  }
}
