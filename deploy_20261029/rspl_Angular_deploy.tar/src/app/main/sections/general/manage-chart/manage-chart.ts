import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { FileUploadModule } from 'primeng/fileupload';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TabsModule } from 'primeng/tabs';

import {
  AssignmentRow,
  DepartmentRow,
  DesignationRow,
  LookupOption,
  ManageChartDataService
} from './manage-chart-data.service';

/** Mirrors Section_General/ManageChart.aspx — feeds OragnizationalChart.aspx's data. */
@Component({
  selector: 'app-manage-chart',
  imports: [FormsModule, ButtonModule, SelectModule, CheckboxModule, InputTextModule, TableModule, TabsModule, FileUploadModule],
  templateUrl: './manage-chart.html',
  styleUrl: './manage-chart.scss'
})
export class ManageChart implements OnInit {
  private readonly data = inject(ManageChartDataService);
  // No zone.js in this app — plain (non-signal) properties like `newDeptName`/
  // `newDeptHod`/`newDesigName` below don't trigger a re-render when mutated
  // inside an RxJS subscribe callback.
  private readonly cdr = inject(ChangeDetectorRef);

  activeTab: 'department' | 'designation' | 'assign' | 'upload' = 'department';

  readonly employees = signal<LookupOption[]>([]);
  readonly departments = signal<DepartmentRow[]>([]);
  readonly designations = signal<DesignationRow[]>([]);
  readonly assignments = signal<AssignmentRow[]>([]);

  newDeptName = '';
  newDeptHod: number | null = null;
  newDeptEnabled = true;

  newDesigName = '';
  newDesigEnabled = true;

  uploadEmployeeId: number | null = null;

  ngOnInit(): void {
    this.data.getEmployees().subscribe((e) => this.employees.set(e));
    this.refreshDepartments();
    this.refreshDesignations();
    this.refreshAssignments();
  }

  private refreshDepartments(): void {
    this.data.getDepartments().subscribe((d) => this.departments.set(d));
  }

  private refreshDesignations(): void {
    this.data.getDesignations().subscribe((d) => this.designations.set(d));
  }

  private refreshAssignments(): void {
    this.data.getAssignments().subscribe((a) => this.assignments.set(a));
  }

  addDepartment(): void {
    if (!this.newDeptName.trim()) {
      alert('Please enter a Department Name.');
      return;
    }
    if (!this.newDeptHod) {
      alert('Please select an HOD Name.');
      return;
    }
    this.data.addDepartment(this.newDeptName, this.newDeptHod, this.newDeptEnabled).subscribe(() => {
      this.newDeptName = '';
      this.newDeptHod = null;
      this.cdr.markForCheck();
      this.refreshDepartments();
    });
  }

  saveDepartment(row: DepartmentRow): void {
    this.data.updateDepartment(row).subscribe(() => this.refreshDepartments());
  }

  // HOD editor binds to the ID (what the backend actually persists) — kept
  // in sync here so the read-only view shows the right name once saved,
  // same reasoning as the Assign tab's onAssignDesigChange/etc.
  onDeptHodChange(row: DepartmentRow): void {
    row.hodName = this.employees().find((e) => e.value === row.hodUserId)?.label ?? '';
  }

  addDesignation(): void {
    if (!this.newDesigName.trim()) {
      return;
    }
    this.data.addDesignation(this.newDesigName, this.newDesigEnabled).subscribe(() => {
      this.newDesigName = '';
      this.cdr.markForCheck();
      this.refreshDesignations();
    });
  }

  saveDesignation(row: DesignationRow): void {
    this.data.updateDesignation(row).subscribe(() => this.refreshDesignations());
  }

  saveAssignment(row: AssignmentRow): void {
    this.data.updateAssignment(row).subscribe(() => this.refreshAssignments());
  }

  // The Assign tab's Designation/Department/Parent Employee editors bind to
  // the ID (what updateAssignment actually persists — the backend ignores
  // the *_name fields entirely), so the display name shown once back in
  // read-only mode needs to be kept in sync here rather than derived from
  // a name-bound ngModel that the backend never reads.
  onAssignDesigChange(row: AssignmentRow): void {
    row.desigName = this.designations().find((d) => d.designationId === row.desigId)?.desigName ?? '';
  }

  onAssignDeptChange(row: AssignmentRow): void {
    row.deptName = this.departments().find((d) => d.deptId === row.deptId)?.name ?? '';
  }

  onAssignParentChange(row: AssignmentRow): void {
    row.parentEmpName = this.employees().find((e) => e.value === row.parentEmpId)?.label ?? '';
  }

  onUpload(event: { files: File[] }): void {
    if (!this.uploadEmployeeId || !event.files[0]) {
      alert('Please select employee name');
      return;
    }
    this.data.uploadEmployeeImage(this.uploadEmployeeId, event.files[0]).subscribe(() => {
      alert('Image uploaded successfully');
    });
  }
}
