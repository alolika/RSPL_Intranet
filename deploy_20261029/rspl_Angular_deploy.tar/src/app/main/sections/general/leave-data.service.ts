import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../../../shared/api-config';

const BASE = `${API_BASE_URL}/general/leave`;

export interface LookupOption {
  label: string;
  value: number;
}

export interface StagedLeaveRow {
  userId: number;
  reason: string;
  fromDate: string;
  toDate: string;
  days: string;
  halfDays: string;
}

export interface MyLeaveRow {
  srNo: number;
  leaveId: number;
  appDate: string;
  forDays: string;
  fromDate: string;
  toDate: string;
  status: string;
  cancellation: string;
}

export interface PendingSanctionItem {
  srNo: number;
  description: string;
  alreadySanctioned: boolean;
  alreadyRejected: boolean;
}

export interface SanctionDecision {
  srNo: number;
  decision: 'approve' | 'reject';
}

export interface LeaveDateEmployee {
  name: string;
  dayType: string;
  reason: string;
  status: string;
  fromDate: string;
  toDate: string;
}

export interface LeaveDateGroup {
  date: string;
  employees: LeaveDateEmployee[];
  total: number;
}

export interface LeaveSanctionArticle {
  applicantName: string;
  hoName: string;
  hoEnabled: boolean;
  items: PendingSanctionItem[];
  dateGroups: LeaveDateGroup[];
}

export interface LeaveCancelSanctionRequest {
  applicantName: string;
  hoName: string;
  cancelFromDate: string;
  cancelToDate: string;
  cancelReason: string;
  alreadyCancelledByHo: boolean;
  alreadyRejected: boolean;
}

interface ApiMyLeaveRow {
  sr_no: number;
  leave_id: number;
  app_date: string;
  for_days: string;
  from_date: string;
  to_date: string;
  status: string;
  cancellation: string;
}

interface ApiPendingSanctionItem {
  sr_no: number;
  description: string;
  already_sanctioned: boolean;
  already_rejected: boolean;
}

interface ApiLeaveDateEmployee {
  name: string;
  day_type: string;
  reason: string;
  status: string;
  from_date: string;
  to_date: string;
}

interface ApiLeaveDateGroup {
  date: string;
  employees: ApiLeaveDateEmployee[];
  total: number;
}

interface ApiLeaveSanctionArticle {
  applicant_name: string;
  ho_name: string;
  ho_enabled: boolean;
  items: ApiPendingSanctionItem[];
  date_groups: ApiLeaveDateGroup[];
}

interface ApiLeaveCancelSanctionRequest {
  applicant_name: string;
  ho_name: string;
  cancel_from_date: string | null;
  cancel_to_date: string | null;
  cancel_reason: string;
  already_cancelled_by_ho: boolean;
  already_rejected: boolean;
}

/**
 * Calls the FastAPI backend (D:\Maruti_workspace\rspl_Api\app\routers\general_leave.py).
 * Shared across the leave-workflow page family (Application, Sanction,
 * Cancellation, CEO override) which appears near-identically under both
 * Section_General and Section_Admin in the source. NOTE: per user decision,
 * the source's PROC_SENDEMAIL/PROC_SendWhatsApp notification side effects
 * are intentionally stubbed out on the backend for now — see that router's
 * module docstring.
 */
@Injectable({ providedIn: 'root' })
export class LeaveDataService {
  private readonly http = inject(HttpClient);

  isHoEnabledForUser(): Observable<boolean> {
    return this.http.get<boolean>(`${BASE}/ho-enabled`);
  }

  getHoOptions(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/ho-options`);
  }

  getInformToOptions(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/inform-to-options`);
  }

  submitLeaveApplication(
    rows: StagedLeaveRow[],
    ho: string,
    hoUserId: number | null,
    informToUserIds: number[]
  ): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/application`, {
      rows: rows.map((r) => ({
        user_id: r.userId,
        reason: r.reason,
        from_date: r.fromDate,
        to_date: r.toDate,
        days: r.days,
        half_days: r.halfDays
      })),
      ho,
      ho_user_id: hoUserId,
      inform_to_user_ids: informToUserIds
    });
  }

  /** Mirrors LeaveCancellation.aspx.vb's FillGV — pending, un-cancelled, future leaves for the current user. */
  getMyPendingLeaves(): Observable<MyLeaveRow[]> {
    return this.http.get<ApiMyLeaveRow[]>(`${BASE}/my-pending`).pipe(
      map((rows) =>
        rows.map((r) => ({
          srNo: r.sr_no,
          leaveId: r.leave_id,
          appDate: r.app_date,
          forDays: r.for_days,
          fromDate: r.from_date,
          toDate: r.to_date,
          status: r.status,
          cancellation: r.cancellation
        }))
      )
    );
  }

  /** Mirrors lnkCancellation_click's "Cancel" branch (CancelledByApplicant=1). */
  cancelMyLeave(leaveId: number): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/cancel-my/${leaveId}`, {});
  }

  /** Mirrors LeaveCancel.aspx.vb's btnSubmit_Click — request HO to cancel an already-sanctioned leave. */
  requestHoCancelLeave(leaveId: number, fromDate: Date, toDate: Date, remark: string): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/request-ho-cancel`, {
      leave_id: leaveId,
      from_date: this.toDateParam(fromDate),
      to_date: this.toDateParam(toDate),
      remark
    });
  }

  /** Mirrors LeaveSanction.aspx.vb Page_Load (reached via emailed link with ?si=ArticleID). */
  getLeaveSanctionArticle(articleId: number): Observable<LeaveSanctionArticle> {
    return this.http.get<ApiLeaveSanctionArticle>(`${BASE}/sanction-article/${articleId}`).pipe(map((r) => this.toArticle(r)));
  }

  /** Mirrors LeaveSanction.aspx.vb btnSubmit_Click — HO approves or rejects each leave item. */
  submitHoSanction(articleId: number, decisions: SanctionDecision[], remark: string): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/ho-sanction`, {
      article_id: articleId,
      decisions: decisions.map((d) => ({ sr_no: d.srNo, decision: d.decision })),
      remark
    });
  }

  /** Mirrors LeaveSanctionCancellation.aspx.vb Page_Load (?LID=&UID=&SrNo=). */
  getLeaveCancelSanctionRequest(leaveId: number, userId: number, srNo: number): Observable<LeaveCancelSanctionRequest> {
    const params = new HttpParams().set('leave_id', leaveId).set('user_id', userId).set('sr_no', srNo);
    return this.http
      .get<ApiLeaveCancelSanctionRequest>(`${BASE}/cancel-sanction-request`, { params })
      .pipe(
        map((r) => ({
          applicantName: r.applicant_name,
          hoName: r.ho_name,
          cancelFromDate: r.cancel_from_date ?? '',
          cancelToDate: r.cancel_to_date ?? '',
          cancelReason: r.cancel_reason,
          alreadyCancelledByHo: r.already_cancelled_by_ho,
          alreadyRejected: r.already_rejected
        }))
      );
  }

  /** Mirrors LeaveSanctionCancellation.aspx.vb btnSubmit_Click — HO approves or rejects the cancellation. */
  submitHoCancelSanction(
    leaveId: number,
    userId: number,
    decision: 'approve' | 'reject',
    remark: string
  ): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/ho-cancel-sanction`, {
      leave_id: leaveId,
      user_id: userId,
      decision,
      remark
    });
  }

  /** Mirrors CEO_LeaveSanction.aspx.vb Page_Load (?si=ArticleID). */
  getCeoSanctionArticle(articleId: number): Observable<LeaveSanctionArticle> {
    return this.http.get<ApiLeaveSanctionArticle>(`${BASE}/ceo-sanction-article/${articleId}`).pipe(map((r) => this.toArticle(r)));
  }

  /** Mirrors CEO_LeaveSanction.aspx.vb btnSubmit_Click. */
  submitCeoSanction(articleId: number, selectedSrNos: number[], remark: string): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/ceo-sanction`, {
      article_id: articleId,
      selected_sr_nos: selectedSrNos,
      remark
    });
  }

  private toArticle(r: ApiLeaveSanctionArticle): LeaveSanctionArticle {
    return {
      applicantName: r.applicant_name,
      hoName: r.ho_name,
      hoEnabled: r.ho_enabled,
      items: r.items.map((i) => ({
        srNo: i.sr_no,
        description: i.description,
        alreadySanctioned: i.already_sanctioned,
        alreadyRejected: i.already_rejected
      })),
      dateGroups: (r.date_groups ?? []).map((g) => ({
        date: g.date,
        employees: g.employees.map((e) => ({
          name: e.name,
          dayType: e.day_type,
          reason: e.reason,
          status: e.status,
          fromDate: e.from_date,
          toDate: e.to_date
        })),
        total: g.total
      }))
    };
  }

  private toDateParam(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }
}
