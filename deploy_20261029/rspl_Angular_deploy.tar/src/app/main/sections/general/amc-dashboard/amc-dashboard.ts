import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild, inject, signal } from '@angular/core';
import { DialogModule } from 'primeng/dialog';
import { TableModule } from 'primeng/table';
import { Chart, ChartConfiguration } from 'chart.js/auto';

import { AmcDetailResult, DashboardTile, GeneralDataService } from '../general-data.service';
import { ExcelColumn, exportToExcel } from '../../../../shared/export-excel';

interface TileWithColumns extends DashboardTile {
  columns: string[];
}

interface StatTile {
  icon: string;
  label: string;
  value: string;
}

/**
 * Mirrors the "AMC Dashboard" entry of App_Master/Home.master.vb's dynamic
 * Dashboard menu (rspl_ReportDashboardTypeMAster, ReportTypeID=5) — see
 * general_dashboards.py for the full source-mapping explanation. Distinct
 * from Section_Support/AMCCo-OrdinatorDashBoard.aspx (already migrated at
 * /support/amc-coordinator-dashboard), which is a separate feature despite
 * the similar name.
 *
 * Redesigned from a plain 2-tile grid (each tile a small scrolling raw-value
 * table) into a proper dashboard: a KPI strip, a grouped-bar chart for the
 * "AMC Forecasting" tile's Expected/Received/Pending-per-month figures, and
 * an emphasis line chart for "Yearly AMC Comparison" (16 fiscal-year columns
 * — far too many for a categorical legend, so the current year is the one
 * accent line and the other 15 render as de-emphasized gray context, per
 * the dataviz skill's "one series is the point, rest are context" form).
 * Both tiles' exact figures are still shown in full below each chart — the
 * chart is a summary, not a replacement for the precise numbers this app's
 * users need. Matched against these two tiles' real column shapes
 * ('Expected AMC'/'CYAMCReceived'/'Pending AMC' vs the 'R|YY-YY' fiscal-year
 * columns) rather than by title text, since the source's own title has a
 * literal typo ("finacial") that shouldn't be load-bearing.
 *
 * The source's month-click drill-down (RSPL_AMCDashBoard_Analysis ->
 * RSPL_AMCDashBoard_Analysis_Details) is still not replicated — its legacy
 * click-handler builds the drill query via a Session-stored string whose
 * exact construction wasn't found in the source, so replicating it risked
 * guessing wrong.
 */
@Component({
  selector: 'app-amc-dashboard',
  imports: [TableModule, DialogModule],
  templateUrl: './amc-dashboard.html',
  styleUrl: './amc-dashboard.scss'
})
export class AmcDashboard implements AfterViewInit, OnDestroy {
  private readonly data = inject(GeneralDataService);

  @ViewChild('forecastCanvas') forecastCanvasRef?: ElementRef<HTMLCanvasElement>;
  @ViewChild('yearlyCanvas') yearlyCanvasRef?: ElementRef<HTMLCanvasElement>;

  private forecastChart: Chart | null = null;
  private yearlyChart: Chart | null = null;

  readonly loading = signal(true);
  readonly loadError = signal(false);
  readonly stats = signal<StatTile[]>([]);
  readonly forecastTile = signal<TileWithColumns | null>(null);
  readonly yearlyTile = signal<TileWithColumns | null>(null);

  // Drill-down: click an amount cell in the month-wise grid -> customer list.
  readonly detailVisible = signal(false);
  readonly detailLoading = signal(false);
  readonly detailError = signal(false);
  readonly detailTitle = signal('');
  readonly detail = signal<AmcDetailResult>({ columns: [], rows: [] });
  private detailFileName = '';

  ngAfterViewInit(): void {
    this.load();
  }

  retry(): void {
    this.loading.set(true);
    this.loadError.set(false);
    this.load();
  }

  private load(): void {
    this.data.getAmcDashboard().subscribe({
      next: (tiles) => {
        const withColumns: TileWithColumns[] = tiles.map((t) => ({
          ...t,
          columns: t.rows.length > 0 ? Object.keys(t.rows[0]) : []
        }));

        const forecast = withColumns.find((t) => t.columns.includes('Expected AMC')) ?? null;
        const yearly = withColumns.find((t) => t.columns.includes('Mon')) ?? null;
        this.forecastTile.set(forecast);
        this.yearlyTile.set(yearly);
        this.loading.set(false);
        if (forecast) {
          this.stats.set(this.buildStats(forecast));
        }

        // The chart canvases sit behind `@if (forecastTile(); as tile)` /
        // `@if (yearlyTile(); as tile)` in the template (so a genuinely
        // missing tile doesn't render an empty chart card at all) — setting
        // the signal above only *schedules* that block's first render, it
        // doesn't create the <canvas> synchronously. Calling
        // drawForecastChart/drawYearlyChart in the same tick as the .set()
        // read a ViewChild that didn't exist in the DOM yet and silently
        // no-op'd (canvas undefined), which is why the charts never
        // appeared. Deferring one tick lets Angular commit that render
        // first, by which point the ViewChild queries have re-resolved.
        setTimeout(() => {
          if (forecast) {
            this.drawForecastChart(forecast);
          }
          if (yearly) {
            this.drawYearlyChart(yearly);
          }
        });
      },
      // Previously had no error callback at all — a failed request (expired
      // token, network blip, slow backend) left `loading` stuck at `true`
      // forever with no way out except a full page reload. Both of the two
      // stored procs behind this page take multiple seconds even in the
      // healthy case, so a timeout/hiccup here isn't a remote edge case.
      error: () => {
        this.loading.set(false);
        this.loadError.set(true);
      }
    });
  }

  ngOnDestroy(): void {
    this.forecastChart?.destroy();
    this.yearlyChart?.destroy();
  }

  private buildStats(forecast: TileWithColumns): StatTile[] {
    const total = forecast.rows.find((r) => r['Month'] === 'Total');
    const overdue = forecast.rows.find((r) => r['Month'] === 'Total Till Overdue');
    return [
      { icon: 'pi pi-check-circle', label: 'Received This Year', value: this.money(total?.['CYAMCReceived']) },
      { icon: 'pi pi-clock', label: 'Total Pending', value: this.money(total?.['Pending AMC']) },
      { icon: 'pi pi-exclamation-triangle', label: 'Overdue (Till Date)', value: this.money(overdue?.['Pending AMC']) }
    ];
  }

  private money(raw: unknown): string {
    const n = this.parseNumber(raw);
    return n === null ? '—' : `₹${this.formatIndian(n)}`;
  }

  private parseNumber(raw: unknown): number | null {
    if (raw === null || raw === undefined || raw === '') {
      return null;
    }
    const n = typeof raw === 'number' ? raw : Number(String(raw).replace(/,/g, ''));
    return Number.isFinite(n) ? n : null;
  }

  // Every amount on this page (KPI tiles, both tables, chart tooltips and
  // axis ticks) renders through this one helper so the Indian lakh/crore
  // grouping (1,00,000.00 — comma every 2 digits after the leading 3,
  // rather than the Western 1,00,000.00 -> 100,000.00 every-3 grouping) is
  // applied consistently instead of per-callsite. 'en-IN' is a standard
  // ICU locale, not a hand-rolled regex, so it correctly handles crore-plus
  // values (1,00,00,000) too.
  private formatIndian(n: number): string {
    return n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  // The two tiles' amount columns (everything except the row-label column,
  // Month/Mon) arrive as SQL-side pre-formatted strings ("1,559,120") using
  // Western thousand grouping — re-parsed and re-formatted here (rather
  // than interpolated raw) so the grid always shows the Indian grouping
  // this app's users expect, regardless of how the backend happens to
  // format its own string.
  formatTableCell(row: Record<string, unknown>, col: string): string {
    const value = row[col];
    if (col === 'Month' || col === 'Mon') {
      return String(value ?? '');
    }
    const n = this.parseNumber(value);
    return n === null ? String(value ?? '') : this.formatIndian(n);
  }

  private static readonly DRILL_COLUMNS = ['Pending AMC', 'Expected AMC', 'CYAMCReceived'];

  // The details proc understands a month ("Apr".."Mar") or "Total Till
  // Overdue" — it has no branch for the whole-year "Total" row. Zero cells
  // have nothing to list.
  canDrill(row: Record<string, unknown>, col: string): boolean {
    return (
      AmcDashboard.DRILL_COLUMNS.includes(col) &&
      row['Month'] !== 'Total' &&
      (this.parseNumber(row[col]) ?? 0) !== 0
    );
  }

  openDetail(row: Record<string, unknown>, col: string): void {
    if (!this.canDrill(row, col)) {
      return;
    }
    const month = String(row['Month']);
    const label = col === 'CYAMCReceived' ? 'AMC Received' : col;
    this.detailTitle.set(`${label} — ${month} (₹${this.formatTableCell(row, col)})`);
    this.detailFileName = `AMC_${label.replace(/\s+/g, '')}_${month.replace(/\s+/g, '')}`;
    this.detail.set({ columns: [], rows: [] });
    this.detailError.set(false);
    this.detailLoading.set(true);
    this.detailVisible.set(true);
    this.data.getAmcDashboardDetails(col, month).subscribe({
      next: (res) => {
        this.detail.set(res);
        this.detailLoading.set(false);
      },
      error: () => {
        this.detailLoading.set(false);
        this.detailError.set(true);
      }
    });
  }

  isNumericDetailCol(col: string): boolean {
    const first = this.detail().rows.find((r) => r[col] !== null && r[col] !== undefined && r[col] !== '');
    return first !== undefined && typeof first[col] === 'number';
  }

  detailTotal(col: string): string {
    if (!this.isNumericDetailCol(col) || col === 'AMC %') {
      return '';
    }
    const sum = this.detail().rows.reduce((acc, r) => acc + (typeof r[col] === 'number' ? (r[col] as number) : 0), 0);
    return this.formatIndian(sum);
  }

  formatDetailCell(row: Record<string, unknown>, col: string): string {
    const v = row[col];
    return typeof v === 'number' ? this.formatIndian(v) : String(v ?? '');
  }

  exportDetail(): void {
    type Row = Record<string, unknown>;
    const { columns, rows } = this.detail();
    // Comma-formatted amount strings (e.g. "18,673") go out as real numbers.
    const cols: ExcelColumn<Row>[] = columns.map((c) => ({
      header: c,
      value: (r: Row) => {
        const v = r[c];
        if (typeof v === 'number') {
          return v;
        }
        if (typeof v === 'string' && /^-?[\d,]+(\.\d+)?$/.test(v.trim())) {
          return this.parseNumber(v);
        }
        return v == null ? null : String(v);
      }
    }));
    exportToExcel(this.detailFileName, rows, cols);
  }

  // Exports a tile's grid exactly as shown (same column order/headers, Idx
  // hidden, "R|YY-YY" shown as "FY YY-YY"), but amounts go out as real
  // numbers rather than the Indian-grouped display strings, so they can be
  // summed/sorted in Excel.
  exportTile(tile: TileWithColumns, labelCol: 'Month' | 'Mon', fileName: string): void {
    type Row = Record<string, unknown>;
    const columns: ExcelColumn<Row>[] = [
      { header: labelCol === 'Mon' ? 'Month' : labelCol, value: (r) => String(r[labelCol] ?? '') },
      ...tile.columns
        .filter((c) => c !== 'Idx' && c !== labelCol)
        .map((c) => ({
          header: c.replace('R|', 'FY '),
          value: (r: Row) => this.parseNumber(r[c]) ?? (r[c] == null ? null : String(r[c]))
        }))
    ];
    exportToExcel(fileName, tile.rows, columns);
  }

  // Chart.js series colors are the validated default categorical palette
  // (dataviz skill's references/palette.md) — the first three slots
  // (blue/orange/aqua), which the palette documents as passing every
  // adjacent AND all-pairs CVD/contrast gate in both light and dark mode.
  // Assigned in fixed order (Expected -> slot 1, Received -> slot 2,
  // Pending -> slot 3), not cherry-picked for connotation.
  private drawForecastChart(tile: TileWithColumns): void {
    const canvas = this.forecastCanvasRef?.nativeElement;
    if (!canvas) {
      return;
    }
    const months = tile.rows.filter((r) => Number(r['Idx']) >= 1 && Number(r['Idx']) <= 12);
    if (months.length === 0) {
      return;
    }
    const config: ChartConfiguration<'bar'> = {
      type: 'bar',
      data: {
        labels: months.map((r) => String(r['Month'])),
        datasets: [
          { label: 'Expected AMC', data: months.map((r) => this.parseNumber(r['Expected AMC']) ?? 0), backgroundColor: '#2a78d6' },
          { label: 'Received', data: months.map((r) => this.parseNumber(r['CYAMCReceived']) ?? 0), backgroundColor: '#eb6834' },
          { label: 'Pending', data: months.map((r) => this.parseNumber(r['Pending AMC']) ?? 0), backgroundColor: '#1baf7a' }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { position: 'bottom' },
          // Without this, Chart.js's default tooltip shows the raw
          // unformatted number (e.g. "1559120") even though the axis ticks
          // above are thousand-separated — the mismatch is what actually
          // reads as "thousand separator not working," since the tooltip
          // is what a user reads when hovering a bar.
          tooltip: {
            callbacks: {
              label: (ctx) => `${ctx.dataset.label}: ${this.formatIndian(Number(ctx.parsed.y))}`
            }
          }
        },
        scales: {
          y: { ticks: { callback: (v) => this.formatIndian(Number(v)) } }
        }
      }
    };
    this.forecastChart?.destroy();
    this.forecastChart = new Chart(canvas, config);
  }

  // Emphasis form (dataviz skill's choosing-a-form.md: "one series is the
  // point, rest are context"): 16 fiscal-year columns is far past the
  // 7-8 series ceiling for a categorical legend, and re-ordering years by
  // hue would carry no meaning anyway (they're chronological, not
  // arbitrary identities). The current fiscal year (the rightmost/last
  // "R|YY-YY" column) is the one story worth telling here -- how this
  // year is tracking against history -- so it alone gets the accent hue
  // and a bold line; the other 15 render as thin, low-opacity gray
  // context, with a single merged legend entry rather than 15 near-
  // identical gray rows.
  private drawYearlyChart(tile: TileWithColumns): void {
    const canvas = this.yearlyCanvasRef?.nativeElement;
    if (!canvas) {
      return;
    }
    const months = tile.rows.filter((r) => Number(r['Idx']) >= 1 && Number(r['Idx']) <= 12);
    if (months.length === 0) {
      return;
    }
    const yearColumns = tile.columns.filter((c) => c.startsWith('R|'));
    if (yearColumns.length === 0) {
      return;
    }
    const currentYearKey = yearColumns[yearColumns.length - 1];

    const datasets: ChartConfiguration<'line'>['data']['datasets'] = yearColumns.map((yearKey) => {
      const isCurrent = yearKey === currentYearKey;
      return {
        label: yearKey.replace('R|', 'FY '),
        data: months.map((r) => this.parseNumber(r[yearKey]) ?? 0),
        borderColor: isCurrent ? '#2a78d6' : '#c3c2b7',
        backgroundColor: isCurrent ? '#2a78d6' : '#c3c2b7',
        borderWidth: isCurrent ? 3 : 1,
        pointRadius: isCurrent ? 3 : 0,
        pointHoverRadius: isCurrent ? 5 : 3,
        order: isCurrent ? 0 : 1
      };
    });

    const config: ChartConfiguration<'line'> = {
      type: 'line',
      data: { labels: months.map((r) => String(r['Mon'])), datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: {
            labels: {
              // Collapses the 16-line legend down to 2 entries: the
              // highlighted current year, and one representative "Previous
              // Years" swatch standing in for the other 15 gray lines.
              generateLabels: (chart) => {
                const currentLabel = currentYearKey.replace('R|', 'FY ');
                return [
                  { text: currentLabel, strokeStyle: '#2a78d6', fillStyle: '#2a78d6', lineWidth: 3, datasetIndex: yearColumns.length - 1, hidden: false },
                  { text: 'Previous years', strokeStyle: '#c3c2b7', fillStyle: '#c3c2b7', lineWidth: 1, datasetIndex: 0, hidden: false }
                ];
              }
            },
            onClick: () => {
              // Both legend entries represent groups of datasets, not one
              // each — the default toggle-by-datasetIndex behavior would
              // only hide one line per click; disabled so the emphasis
              // stays intact regardless of legend interaction.
            }
          },
          tooltip: {
            // Only the highlighted current-year line surfaces a value on
            // hover — showing all 15 gray context lines in the crosshair
            // would defeat the point of de-emphasizing them.
            filter: (item) => item.dataset.borderWidth === 3,
            callbacks: {
              label: (ctx) => `${ctx.dataset.label}: ${this.formatIndian(Number(ctx.parsed.y))}`
            }
          }
        },
        scales: {
          y: { ticks: { callback: (v) => this.formatIndian(Number(v)) } }
        }
      }
    };
    this.yearlyChart?.destroy();
    this.yearlyChart = new Chart(canvas, config);
  }
}
