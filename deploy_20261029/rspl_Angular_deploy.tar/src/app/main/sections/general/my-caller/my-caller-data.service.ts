import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../../../../shared/api-config';

const BASE = `${API_BASE_URL}/general/my-caller`;

export interface LookupOption {
  label: string;
  value: string;
}

export interface CallLocation {
  username: string;
  latitude: number;
  longitude: number;
  callType: boolean;
  htmlTable: string;
}

interface ApiCallLocation {
  username: string;
  latitude: number;
  longitude: number;
  call_type: boolean;
  html_table: string;
}

/** Calls the FastAPI backend (D:\Maruti_workspace\rspl_Api\app\routers\general_mycaller.py). Mirrors App_Code/VB/MyCallerHistory.vb's GetLatLongMYCallerHistory. */
@Injectable({ providedIn: 'root' })
export class MyCallerDataService {
  private readonly http = inject(HttpClient);

  getUsers(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/users`);
  }

  getCallLocations(userName: string, callCount: number, date: Date, showAll: boolean, callType: string): Observable<CallLocation[]> {
    const params = new HttpParams()
      .set('user_name', userName)
      .set('call_count', callCount)
      .set('call_date', this.toDateParam(date))
      .set('show_all', showAll)
      .set('call_type', callType);
    return this.http.get<ApiCallLocation[]>(`${BASE}/call-locations`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          username: r.username,
          latitude: r.latitude,
          longitude: r.longitude,
          callType: r.call_type,
          htmlTable: r.html_table
        }))
      )
    );
  }

  private toDateParam(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }
}
