import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, OnDestroy, OnInit, ViewChild, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import * as L from 'leaflet';

import { CallLocation, LookupOption, MyCallerDataService } from './my-caller-data.service';

const CALL_TYPES: LookupOption[] = [
  { label: 'All', value: '0' },
  { label: 'Incoming Calls', value: '1' },
  { label: 'Outgoing Calls', value: '2' }
];

// Same default center the backend falls back to (general_mycaller.py's
// _DEFAULT_LAT/_DEFAULT_LNG) when a call has no real GPS coordinates on
// file — confirmed live that's every single row in RSPL_CallHistory today
// (all 3,387 rows have Latitude/Longitude of '0.0'), so every marker
// currently lands here until the mobile app actually starts logging real
// coordinates. Not a bug in this page — reflecting genuinely absent data.
const DEFAULT_CENTER: L.LatLngTuple = [18.4911754, 73.8566163];

const MARKER_COLORS: Record<'blue' | 'green' | 'red', string> = {
  blue: '#1976d2',
  green: '#43a047',
  red: '#e53935'
};

function dotIcon(color: string): L.DivIcon {
  return L.divIcon({
    className: 'caller-dot-icon',
    html: `<span style="background:${color}"></span>`,
    iconSize: [16, 16],
    iconAnchor: [8, 8]
  });
}

/**
 * Mirrors Section_General/MyCaller.aspx: a Google Maps view of a user's
 * recent call locations (App_Service/MyCallerHistory.asmx), colored by
 * recency/call-type. Rebuilt on Leaflet + OpenStreetMap (see
 * entity-lat-long.ts's doc comment for why: Google Maps requires a real,
 * billed API key that isn't provisioned in this environment; Leaflet +
 * OpenStreetMap tiles are free and keyless and already proven working
 * elsewhere in this app) instead of staying a permanent placeholder.
 */
@Component({
  selector: 'app-my-caller',
  imports: [FormsModule, ButtonModule, SelectModule, DatePickerModule, InputTextModule, CheckboxModule],
  templateUrl: './my-caller.html',
  styleUrl: './my-caller.scss'
})
export class MyCaller implements OnInit, AfterViewInit, OnDestroy {
  private readonly data = inject(MyCallerDataService);
  // No zone.js in this app — plain (non-signal) properties like `selectedUser`
  // below don't trigger a re-render when mutated inside an RxJS subscribe callback.
  private readonly cdr = inject(ChangeDetectorRef);

  @ViewChild('mapCanvas', { static: true }) private readonly mapCanvasRef!: ElementRef<HTMLDivElement>;
  private map: L.Map | null = null;
  private markers: L.Marker[] = [];

  readonly users = signal<LookupOption[]>([]);
  readonly callTypes = CALL_TYPES;
  readonly locations = signal<CallLocation[]>([]);
  readonly loading = signal(false);
  readonly errorMessage = signal('');

  selectedUser: string | null = null;
  selectedDate = new Date();
  lastNCalls = 10;
  showAllCalls = false;
  selectedCallType = '0';

  ngOnInit(): void {
    this.data.getUsers().subscribe({
      next: (users) => {
        this.users.set([{ label: 'All', value: 'none' }, ...users]);
        this.selectedUser = 'none';
        this.cdr.markForCheck();
      },
      error: () => this.users.set([{ label: 'All', value: 'none' }])
    });
  }

  ngAfterViewInit(): void {
    this.map = L.map(this.mapCanvasRef.nativeElement).setView(DEFAULT_CENTER, 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19
    }).addTo(this.map);
    // The container's final layout size isn't guaranteed settled the instant
    // the view mounts — Leaflet caches the size it sees at creation time, so
    // a stale/zero read here renders the map at the wrong scale until told
    // to re-measure (same fix as entity-lat-long.ts).
    setTimeout(() => this.map?.invalidateSize(), 0);
  }

  ngOnDestroy(): void {
    this.map?.remove();
  }

  show(): void {
    this.loading.set(true);
    this.errorMessage.set('');
    this.data.getCallLocations(this.selectedUser ?? 'none', this.lastNCalls, this.selectedDate, this.showAllCalls, this.selectedCallType).subscribe({
      next: (rows) => {
        this.locations.set(rows);
        this.loading.set(false);
        this.plotMarkers(rows);
        if (rows.length === 0) {
          alert('No Call history');
        }
      },
      error: () => {
        this.locations.set([]);
        this.loading.set(false);
        this.plotMarkers([]);
        this.errorMessage.set('Could not load call locations. Please try again.');
      }
    });
  }

  private plotMarkers(rows: CallLocation[]): void {
    this.markers.forEach((m) => m.remove());
    this.markers = [];
    if (!this.map || rows.length === 0) {
      return;
    }
    rows.forEach((loc, index) => {
      const color = MARKER_COLORS[this.markerColor(loc, index)];
      const marker = L.marker([loc.latitude, loc.longitude], { icon: dotIcon(color) })
        .bindPopup(`<b>${loc.username}</b><br>${loc.latitude}, ${loc.longitude}${loc.htmlTable ? '<br>' + loc.htmlTable : ''}`)
        .addTo(this.map!);
      this.markers.push(marker);
    });
    const bounds = L.latLngBounds(rows.map((r) => [r.latitude, r.longitude] as L.LatLngTuple));
    this.map.fitBounds(bounds.pad(0.2), { maxZoom: 15 });
  }

  markerColor(loc: CallLocation, index: number): 'blue' | 'green' | 'red' {
    if (index === 0) {
      return 'blue';
    }
    return loc.callType ? 'red' : 'green';
  }
}
