import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { PortalAuthService } from '../../../../core/auth/portal-auth.service';
import { AttendanceRow, GeneralDataService, LookupOption } from '../general-data.service';

const ALL: LookupOption = { label: 'ALL', value: 0 };

/** Cell background matching gvschedule_ItemDataBound's Select Case in the source. */
const STATUS_COLOR: Record<string, string> = {
  X: '#f5f5f5',
  H: '#f5f5f5',
  L: '#fff59d',
  LH: '#fff59d',
  AB: '#ef9a9a'
};

const WEEKDAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

interface DayColumn {
  // Raw unpadded day number ("1".."31") — matches the backend's `days` dict
  // keys exactly, which come straight from the stored proc's column names.
  key: string;
  // Zero-padded for display only ("01".."31").
  label: string;
  weekday: string;
  isWeekend: boolean;
}

@Component({
  selector: 'app-emp-attendance',
  imports: [FormsModule, ButtonModule, SelectModule, TableModule],
  templateUrl: './emp-attendance.html',
  styleUrl: './emp-attendance.scss'
})
export class EmpAttendance implements OnInit {
  private readonly data = inject(GeneralDataService);
  private readonly auth = inject(PortalAuthService);
  // No zone.js in this app — plain (non-signal) properties like `selectedUser`
  // below don't trigger a re-render when mutated inside an RxJS subscribe callback.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly users = signal<LookupOption[]>([ALL]);
  readonly years = signal<LookupOption[]>([]);
  readonly months = signal<LookupOption[]>([]);
  readonly rows = signal<AttendanceRow[]>([]);
  readonly dayColumns = signal<DayColumn[]>([]);
  readonly loading = signal(false);
  readonly errorMessage = signal('');
  // PrimeNG's p-table doesn't reset its current page when [value] changes —
  // without this, switching from a single user back to ALL (114 rows) while
  // sitting on a later page could leave the paginator on a stale offset.
  readonly first = signal(0);

  // Defaults to the logged-in user's own attendance, same intent as the
  // source's ddlUser pre-selection (Session("UserID")) — set synchronously
  // from the already-available auth signal, not inside the getUsers()
  // subscribe. The previous version set this.selectedUser only after
  // getUsers() resolved, but had already called show() one line earlier —
  // so the very first load always ran with the default 0 ("ALL", 114 rows)
  // instead of the intended single-user view, no matter who was logged in.
  selectedUser = 0;
  selectedYear = new Date().getFullYear();
  selectedMonth = new Date().getMonth() + 1;

  ngOnInit(): void {
    this.selectedUser = this.auth.currentUser()?.userId ?? 0;
    this.data.getUsers().subscribe({
      next: (users) => this.users.set([ALL, ...users]),
      error: () => this.users.set([ALL])
    });
    this.data.getYears().subscribe({
      next: (years) => this.years.set(years),
      error: () => this.years.set([])
    });
    this.data.getMonths().subscribe({
      next: (months) => this.months.set(months),
      error: () => this.months.set([])
    });
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.errorMessage.set('');
    this.first.set(0);
    this.data.getUserSchedule(this.selectedUser, this.selectedYear, this.selectedMonth).subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.dayColumns.set(this.buildDayColumns());
        this.loading.set(false);
      },
      error: () => {
        this.rows.set([]);
        this.dayColumns.set(this.buildDayColumns());
        this.loading.set(false);
        this.errorMessage.set('Could not load attendance data. Please try again.');
      }
    });
  }

  private buildDayColumns(): DayColumn[] {
    const dayCount = new Date(this.selectedYear, this.selectedMonth, 0).getDate();
    return Array.from({ length: dayCount }, (_, i) => {
      const day = i + 1;
      const weekdayIndex = new Date(this.selectedYear, this.selectedMonth - 1, day).getDay();
      return {
        key: String(day),
        label: String(day).padStart(2, '0'),
        weekday: WEEKDAY_LABELS[weekdayIndex],
        isWeekend: weekdayIndex === 0 || weekdayIndex === 6
      };
    });
  }

  cellColor(status: string | undefined): string {
    return status ? (STATUS_COLOR[status] ?? '') : '';
  }
}
