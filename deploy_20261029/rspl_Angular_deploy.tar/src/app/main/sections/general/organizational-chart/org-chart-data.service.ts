import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../../../../shared/api-config';

export interface OrgEmployee {
  userId: number;
  name: string;
  department: string;
  designation: string;
  parentEmpId: number;
  mobileNo: string;
  branchName: string;
}

interface ApiOrgEmployee {
  user_id: number;
  name: string;
  department: string;
  designation: string;
  parent_emp_id: number;
  mobile_no: string;
  branch_name: string;
}

/** Calls the FastAPI backend (D:\Maruti_workspace\rspl_Api\app\routers\general_org.py). Mirrors App_Code/VB/Org_ChartWebservice.vb's GetEmployees (backed by sp_testRec). */
@Injectable({ providedIn: 'root' })
export class OrgChartDataService {
  private readonly http = inject(HttpClient);

  getEmployees(): Observable<OrgEmployee[]> {
    return this.http.get<ApiOrgEmployee[]>(`${API_BASE_URL}/general/org-chart/employees`).pipe(
      map((rows) =>
        rows.map((r) => ({
          userId: r.user_id,
          name: r.name,
          department: r.department,
          designation: r.designation,
          parentEmpId: r.parent_emp_id,
          mobileNo: r.mobile_no,
          branchName: r.branch_name
        }))
      )
    );
  }
}
