import { Component, OnInit, inject, signal } from '@angular/core';
import { TreeNode } from 'primeng/api';
import { OrganizationChartModule } from 'primeng/organizationchart';

import { OrgChartDataService, OrgEmployee } from './org-chart-data.service';

/**
 * Mirrors Section_General/OragnizationalChart.aspx, which used a
 * third-party canvas-based orgchart.js library driven by
 * Org_ChartWebservice.asmx. PrimeNG ships a native OrganizationChart
 * component with built-in expand/collapse — used directly instead of
 * porting the canvas/jQuery library, same underlying employee-hierarchy
 * data (UserId/ParentEmpID/Department/Designation/Branch).
 */
@Component({
  selector: 'app-organizational-chart',
  imports: [OrganizationChartModule],
  templateUrl: './organizational-chart.html',
  styleUrl: './organizational-chart.scss'
})
export class OrganizationalChart implements OnInit {
  private readonly data = inject(OrgChartDataService);
  readonly root = signal<TreeNode<OrgEmployee> | null>(null);

  ngOnInit(): void {
    this.data.getEmployees().subscribe((employees) => {
      this.root.set(this.buildTree(employees));
    });
  }

  private buildTree(employees: OrgEmployee[]): TreeNode<OrgEmployee> | null {
    const byId = new Map(employees.map((e) => [e.userId, e]));
    const toNode = (e: OrgEmployee): TreeNode<OrgEmployee> => ({
      data: e,
      expanded: true,
      children: employees.filter((c) => c.parentEmpId === e.userId).map(toNode)
    });
    const rootEmployee = employees.find((e) => !byId.has(e.parentEmpId));
    return rootEmployee ? toNode(rootEmployee) : null;
  }
}
