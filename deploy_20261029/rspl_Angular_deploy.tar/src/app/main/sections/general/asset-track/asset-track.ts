import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { PortalAuthService } from '../../../../core/auth/portal-auth.service';
import { AssetTrackRow, GeneralDataService, LookupOption } from '../general-data.service';

@Component({
  selector: 'app-asset-track',
  imports: [FormsModule, ButtonModule, SelectModule, InputTextModule, TableModule, DatePipe],
  templateUrl: './asset-track.html',
  styleUrl: './asset-track.scss'
})
export class AssetTrack implements OnInit {
  private readonly data = inject(GeneralDataService);
  private readonly auth = inject(PortalAuthService);
  // No zone.js in this app — plain (non-signal) properties like `remark` below
  // don't trigger a re-render when mutated inside an RxJS subscribe callback.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly assetTypes = signal<LookupOption[]>([]);
  readonly fromUsers = signal<LookupOption[]>([]);
  readonly rows = signal<AssetTrackRow[]>([]);
  readonly submitting = signal(false);
  readonly loading = signal(false);
  // PrimeNG's p-table doesn't reset its current page when [value] changes —
  // without this, a fresh submit that changes the row count while sitting
  // on a later page could leave the paginator on a stale offset.
  readonly first = signal(0);

  selectedAssetType: number | null = null;
  selectedFromUser: number | null = null;
  remark = '';

  ngOnInit(): void {
    this.data.getAssetTypes().subscribe((opts) => this.assetTypes.set(opts));
    this.data.getOtherUsers(this.auth.currentUser()?.userId ?? 0).subscribe((opts) => this.fromUsers.set(opts));
    this.refresh();
  }

  private refresh(): void {
    this.loading.set(true);
    this.first.set(0);
    this.data.getAssetTrackRows().subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: () => {
        this.rows.set([]);
        this.loading.set(false);
      }
    });
  }

  submit(): void {
    const assetTypeName = this.assetTypes().find((a) => a.value === this.selectedAssetType)?.label ?? '';
    this.submitting.set(true);
    this.data.addAssetTrack(assetTypeName, this.selectedFromUser ?? 0, this.remark).subscribe({
      next: () => {
        this.submitting.set(false);
        alert('Asset Track Saved successfully!');
        this.remark = '';
        this.cdr.markForCheck();
        this.refresh();
      },
      // Previously silent on failure (no error callback) — the Submit
      // button would stay stuck in its loading state with no feedback.
      error: () => {
        this.submitting.set(false);
        alert('Could not save the asset track. Please try again.');
        this.cdr.markForCheck();
      }
    });
  }
}
