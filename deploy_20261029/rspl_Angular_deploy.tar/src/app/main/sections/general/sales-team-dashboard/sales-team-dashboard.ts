import { Component, OnInit, inject, signal } from '@angular/core';
import { TableModule } from 'primeng/table';

import { DashboardTile, GeneralDataService } from '../general-data.service';

interface TileWithColumns extends DashboardTile {
  columns: string[];
}

interface StatTile {
  icon: string;
  label: string;
  value: string;
}

// The three tiles' genuine money columns (everything else here — dates,
// day counts, city/name text — isn't a currency amount). Values arrive as
// SQL-side pre-formatted strings ("6,340") using Western grouping; these
// get re-parsed and re-rendered in Indian lakh/crore grouping instead of
// interpolated raw, same treatment as the AMC Dashboard.
const AMOUNT_COLUMNS = new Set(['Bill Amt', 'O/S Amt', 'Order Amt', 'Adv. Amt']);

function parseAmount(raw: unknown): number | null {
  if (raw === null || raw === undefined || raw === '') {
    return null;
  }
  const n = typeof raw === 'number' ? raw : Number(String(raw).replace(/,/g, ''));
  return Number.isFinite(n) ? n : null;
}

/**
 * Mirrors the "Sales Team DashBoard" entry of App_Master/Home.master.vb's
 * dynamic Dashboard menu (rspl_ReportDashboardTypeMAster, ReportTypeID=2) —
 * see general_dashboards.py for the full source-mapping explanation.
 *
 * Redesigned to match the AMC Dashboard's layout (same `page-card`/
 * `dashboard-header`/`stat-row`/`section-tile` structure and stylesheet) per
 * explicit request, for visual consistency between this app's dashboards.
 * No chart here, unlike AMC Dashboard's month-series tiles — these three
 * tiles are per-customer/per-lead transactional lists with no natural time
 * series to plot, so the parity is in layout and table styling, not in
 * forcing a chart onto data that isn't chart-shaped.
 */
@Component({
  selector: 'app-sales-team-dashboard',
  imports: [TableModule],
  templateUrl: './sales-team-dashboard.html',
  styleUrl: './sales-team-dashboard.scss'
})
export class SalesTeamDashboard implements OnInit {
  private readonly data = inject(GeneralDataService);

  readonly loading = signal(true);
  readonly stats = signal<StatTile[]>([]);
  readonly outstandingTile = signal<TileWithColumns | null>(null);
  readonly unbilledTile = signal<TileWithColumns | null>(null);
  readonly leadsTile = signal<TileWithColumns | null>(null);

  ngOnInit(): void {
    this.data.getSalesTeamDashboard().subscribe((tiles) => {
      const withColumns: TileWithColumns[] = tiles.map((t) => ({
        ...t,
        columns: t.rows.length > 0 ? Object.keys(t.rows[0]) : []
      }));

      // Matched by each tile's real column shape rather than title text —
      // same precedent as AMC Dashboard (the source's own dashboard titles
      // aren't reliable identifiers to key off of).
      const outstanding = withColumns.find((t) => t.columns.includes('O/S Amt')) ?? null;
      const unbilled = withColumns.find((t) => t.columns.includes('Order Amt')) ?? null;
      const leads = withColumns.find((t) => t.columns.includes('Lead Name')) ?? null;

      this.outstandingTile.set(outstanding);
      this.unbilledTile.set(unbilled);
      this.leadsTile.set(leads);
      this.loading.set(false);

      this.stats.set(this.buildStats(outstanding, unbilled, leads));
    });
  }

  private buildStats(outstanding: TileWithColumns | null, unbilled: TileWithColumns | null, leads: TileWithColumns | null): StatTile[] {
    const sumBy = (tile: TileWithColumns | null, col: string): number =>
      (tile?.rows ?? []).reduce((sum, r) => sum + (parseAmount(r[col]) ?? 0), 0);

    return [
      { icon: 'pi pi-wallet', label: 'Outstanding Amount', value: this.money(sumBy(outstanding, 'O/S Amt')) },
      { icon: 'pi pi-shopping-cart', label: 'Unbilled Orders', value: this.money(sumBy(unbilled, 'Order Amt')) },
      { icon: 'pi pi-users', label: 'Open Leads', value: String(leads?.rows.length ?? 0) }
    ];
  }

  private money(n: number): string {
    return `₹${n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }

  formatCell(row: Record<string, unknown>, col: string): string {
    const value = row[col];
    if (!AMOUNT_COLUMNS.has(col)) {
      return String(value ?? '');
    }
    const n = parseAmount(value);
    return n === null ? String(value ?? '') : n.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  }
}
