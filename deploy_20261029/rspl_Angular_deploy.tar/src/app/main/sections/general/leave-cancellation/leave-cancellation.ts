import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { DialogModule } from 'primeng/dialog';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { LeaveDataService, MyLeaveRow } from '../leave-data.service';

/**
 * Mirrors Section_General/LeaveCancellation.aspx (the register) and
 * Section_General/LeaveCancel.aspx (the RadWindow popup it opens). The
 * source loads LeaveCancel.aspx as a separate iframe-popup page; here the
 * same "Send Request HOD To Cancel Leave" flow is a p-dialog on this
 * component instead, since Angular has no page-in-a-popup mechanism and
 * a modal dialog is the direct equivalent.
 */
@Component({
  selector: 'app-leave-cancellation',
  imports: [FormsModule, ButtonModule, DatePickerModule, TextareaModule, DialogModule, TableModule, DatePipe],
  templateUrl: './leave-cancellation.html',
  styleUrl: './leave-cancellation.scss'
})
export class LeaveCancellation implements OnInit {
  private readonly data = inject(LeaveDataService);

  readonly rows = signal<MyLeaveRow[]>([]);
  readonly loading = signal(false);
  readonly dialogVisible = signal(false);
  readonly submitting = signal(false);
  // Tracks which row's direct "Cancel" action is in flight, so that one row
  // shows a loading state instead of the whole page/button set.
  readonly cancellingId = signal<number | null>(null);

  activeRow: MyLeaveRow | null = null;
  cancelFromDate: Date | null = null;
  cancelToDate: Date | null = null;
  remark = '';

  ngOnInit(): void {
    this.refresh();
  }

  private refresh(): void {
    this.loading.set(true);
    this.data.getMyPendingLeaves().subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: () => {
        this.rows.set([]);
        this.loading.set(false);
        alert('Could not load your pending leaves. Please try again.');
      }
    });
  }

  onCancellationClick(row: MyLeaveRow): void {
    if (row.cancellation === 'Cancel') {
      this.cancellingId.set(row.leaveId);
      this.data.cancelMyLeave(row.leaveId).subscribe({
        next: (res) => {
          this.cancellingId.set(null);
          if (!res.success) {
            alert('Could not cancel this leave. Please try again.');
            return;
          }
          alert('Leave cancelled successfully.');
          this.refresh();
        },
        // Previously silent on failure (no error callback) — the row would
        // just sit there with no feedback that anything went wrong.
        error: () => {
          this.cancellingId.set(null);
          alert('Could not cancel this leave. Please try again.');
        }
      });
      return;
    }
    // "Send Request HOD To Cancel Leave" -> open the cancellation-request dialog
    this.activeRow = row;
    this.cancelFromDate = new Date(row.fromDate);
    this.cancelToDate = new Date(row.toDate);
    this.remark = '';
    this.dialogVisible.set(true);
  }

  submitCancelRequest(): void {
    if (!this.activeRow || !this.cancelFromDate || !this.cancelToDate) {
      return;
    }
    const originalFrom = new Date(this.activeRow.fromDate);
    const originalTo = new Date(this.activeRow.toDate);
    if (this.cancelFromDate < originalFrom || this.cancelToDate > originalTo) {
      alert(
        `Please Select Date between ${originalFrom.toDateString()} and ${originalTo.toDateString()}`
      );
      return;
    }
    this.submitting.set(true);
    this.data.requestHoCancelLeave(this.activeRow.leaveId, this.cancelFromDate, this.cancelToDate, this.remark).subscribe({
      next: (res) => {
        this.submitting.set(false);
        // Was previously ignored entirely — the backend can return
        // {success: false} (e.g. the leave record wasn't found for this
        // user) and the dialog would close and refresh as if it worked.
        if (!res.success) {
          alert('Could not send the cancellation request. Please check the dates and try again.');
          return;
        }
        this.dialogVisible.set(false);
        alert('Cancellation request sent to HOD successfully.');
        this.refresh();
      },
      // Previously silent on failure (no error callback) — the dialog would
      // stay open with the Submit button stuck in its loading state.
      error: () => {
        this.submitting.set(false);
        alert('Could not send the cancellation request. Please try again.');
      }
    });
  }
}
