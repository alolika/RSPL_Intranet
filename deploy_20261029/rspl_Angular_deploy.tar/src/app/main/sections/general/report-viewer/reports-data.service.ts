import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../../../../shared/api-config';

const BASE = `${API_BASE_URL}/general/reports`;

export interface ReportSummary {
  reportTypeId: number;
  reportName: string;
  reportMenuName: string;
}

export interface ReportFilterField {
  columnId: number;
  columnName: string;
  displayName: string;
  dataType: 'string' | 'date' | 'number';
  autoPopulate: boolean;
}

export interface ReportRow {
  [key: string]: string | number;
}

export interface FilterTemplate {
  name: string;
  filters: Record<string, string>;
}

interface ApiReportSummary {
  report_type_id: number;
  report_name: string;
  report_menu_name: string;
}

interface ApiReportFilterField {
  column_id: number;
  column_name: string;
  display_name: string;
  data_type: string;
  auto_populate: boolean;
}

/**
 * Simplified rebuild of the source's ad-hoc report engine
 * (webDashboard.aspx.vb / ReportNew.aspx.vb / ReportViewer.aspx.vb —
 * Analytic_ReportColumnMaster / RSPL_ReportDashboard driven, ~1970 lines of
 * runtime server-control generation in the largest case). Same end-user
 * capability — pick a report, set filters, view a grid, drill down, save a
 * filter template — via a normal reactive form instead of dynamically
 * building WebForms controls in code-behind. See
 * feedback_report_engine_simplification memory for the rationale.
 */
@Injectable({ providedIn: 'root' })
export class ReportsDataService {
  private readonly http = inject(HttpClient);

  getReports(): Observable<ReportSummary[]> {
    return this.http.get<ApiReportSummary[]>(BASE).pipe(
      map((rows) =>
        rows.map((r) => ({ reportTypeId: r.report_type_id, reportName: r.report_name, reportMenuName: r.report_menu_name }))
      )
    );
  }

  getFilterFields(reportTypeId: number): Observable<ReportFilterField[]> {
    return this.http.get<ApiReportFilterField[]>(`${BASE}/${reportTypeId}/filter-fields`).pipe(
      map((rows) =>
        rows.map((r) => ({
          columnId: r.column_id,
          columnName: r.column_name,
          displayName: r.display_name,
          dataType: r.data_type as ReportFilterField['dataType'],
          autoPopulate: r.auto_populate
        }))
      )
    );
  }

  getFilterFieldOptions(reportTypeId: number, columnId: number): Observable<string[]> {
    return this.http.get<string[]>(`${BASE}/${reportTypeId}/filter-fields/${columnId}/options`);
  }

  runReport(reportTypeId: number, filters: Record<string, string>): Observable<ReportRow[]> {
    return this.http.post<ReportRow[]>(`${BASE}/${reportTypeId}/run`, { filters });
  }

  getDrillDown(reportTypeId: number, row: ReportRow): Observable<ReportRow[]> {
    return this.http.post<ReportRow[]>(`${BASE}/${reportTypeId}/drill-down`, { row });
  }

  getTemplates(reportTypeId: number): Observable<FilterTemplate[]> {
    return this.http.get<FilterTemplate[]>(`${BASE}/${reportTypeId}/templates`);
  }

  saveTemplate(reportTypeId: number, name: string, filters: Record<string, string>): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/${reportTypeId}/templates`, { name, filters });
  }

  removeTemplate(reportTypeId: number, name: string): Observable<{ success: boolean }> {
    return this.http.delete<{ success: boolean }>(`${BASE}/${reportTypeId}/templates/${encodeURIComponent(name)}`);
  }
}
