import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToCsv } from '../../../../shared/export-csv';
import { exportToExcel } from '../../../../shared/export-excel';
import { exportToPdf } from '../../../../shared/export-pdf';
import {
  FilterTemplate,
  ReportFilterField,
  ReportRow,
  ReportSummary,
  ReportsDataService
} from './reports-data.service';

// Column-name overrides for abbreviations that read poorly when
// auto-split from PascalCase (e.g. "ASSValue" -> "ASS Value"). These are
// shared, well-known terms across this app's AMC/customer reports, not
// specific to any one report.
const COLUMN_LABEL_OVERRIDES: Record<string, string> = {
  custid: 'Customer ID',
  custid1: 'Customer ID',
  mobileno: 'Mobile No',
  phno: 'Phone No',
  voucherno: 'Voucher No',
  nooftt: 'No. of Tickets',
  reqtt: 'Pending Requirement Tickets',
  pendingtts: 'Pending Tickets',
  displayname: 'Customer Name',
  softwarename: 'Software',
  amcper: 'AMC %',
  assvalue: 'Assessed Value',
  amcamount: 'AMC Amount',
  ledgerbalance: 'Ledger Balance',
  lastlettersentdate: 'Last Letter Sent',
  expirydate: 'AMC Expiry Date',
  invoicedate: 'Invoice Date',
  groupname: 'Customer Group',
  customername: 'Customer Name',
  contactperson: 'Contact Person'
};

function humanizeColumn(name: string): string {
  const override = COLUMN_LABEL_OVERRIDES[name.toLowerCase()];
  if (override) {
    return override;
  }
  const spaced = name
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2')
    .trim();
  return spaced
    .split(/\s+/)
    .map((w) => (w.length > 1 && w === w.toUpperCase() ? w : w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()))
    .join(' ');
}

const ISO_DATE_RE = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/;
const AMOUNT_COLUMNS = new Set([
  'ledgerbalance',
  'assvalue',
  'amcamount',
  'assessable value',
  'amc amt',
  'saleoutstanding',
  'balancesr',
  'balancecreditnote',
  'balanceadvance',
  'balanceorder',
  'balancedebitnote',
  'effitivebalance',
  // Found by inspecting live output columns of all 38 Analytic_ReportMaster
  // reports (Reports menu) — several arrive as pre-formatted strings rather
  // than numbers (e.g. SO Outstanding's InvoiceAmt/Outstanding/LedgerBalance),
  // so generic typeof-number detection alone would miss them.
  'lifetimevalue',
  'billamount',
  'amount',
  'advance',
  'orderamount',
  'assessablevalue',
  'lastpaymentamt',
  'ordervalue',
  'invoiceamt',
  'outstanding',
  'pregstamt',
  'itemvaluemrptotal',
  'soamount',
  'salenetamount',
  'gross incentive',
  'net incentive',
  'senior incentive',
  'orderedbillamount',
  'non amc revenue',
  'total revenue amt',
  'basic amc amt',
  'orderamt',
  'avg yearly',
  'gross advance adjusted',
  'cess amount',
  'integrated amount',
  'central amount',
  'state amount',
  'order value target',
  'actual performance',
  'last year same entire month',
  'current year ytd performance',
  'last year till this monthend'
]);
const PERCENT_COLUMNS = new Set(['amcper', '% disc so']);
const NUMERIC_COLUMNS = new Set(['nooftt', 'reqtt', 'pendingtts']);

function formatCellValue(col: string, value: unknown): string {
  if (value === null || value === undefined || value === '') {
    return '—';
  }
  const key = col.toLowerCase();
  if (typeof value === 'string' && ISO_DATE_RE.test(value)) {
    const d = new Date(value);
    return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  }
  if (PERCENT_COLUMNS.has(key) && (typeof value === 'number' || (typeof value === 'string' && value.trim() !== '' && !isNaN(Number(value))))) {
    return `${value}%`;
  }
  if (AMOUNT_COLUMNS.has(key)) {
    // Some reports return amounts as backend-preformatted strings rather
    // than numbers (e.g. SO Outstanding's InvoiceAmt/Outstanding) -- re-parse
    // those too so every amount column shows the same 2-decimal "0.00" shape
    // instead of only the ones that happen to arrive as JSON numbers.
    const n = typeof value === 'number' ? value : Number(String(value).replace(/,/g, ''));
    if (Number.isFinite(n)) {
      return n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
  }
  return String(value);
}

function isNumericColumn(col: string, rows: ReportRow[]): boolean {
  const key = col.toLowerCase();
  if (AMOUNT_COLUMNS.has(key) || PERCENT_COLUMNS.has(key) || NUMERIC_COLUMNS.has(key)) {
    return true;
  }
  return rows.length > 0 && typeof rows[0][col] === 'number';
}

function isAmountColumn(col: string): boolean {
  return AMOUNT_COLUMNS.has(col.toLowerCase());
}

/**
 * Generic ad-hoc report viewer used by DynamicReports / ReportNew /
 * ReportViewer / webDashboard routes (all the same underlying engine in
 * the source — see ReportsDataService doc comment).
 *
 * No zone.js in this app (confirmed — not a dependency, no polyfill entry).
 * Signal writes re-render on their own; plain (non-signal) properties like
 * `reportTypeId`/`filterValues`/`templateName` only re-render when mutated
 * inside a template-dispatched event handler. Any mutation of those from
 * inside an RxJS `subscribe` callback needs an explicit `cdr.markForCheck()`
 * afterward, or the view silently goes stale even though the field is
 * correct in memory.
 */
@Component({
  selector: 'app-report-viewer',
  imports: [
    FormsModule,
    ButtonModule,
    SelectModule,
    DatePickerModule,
    InputTextModule,
    TableModule,
    DialogModule,
    MessageModule
  ],
  templateUrl: './report-viewer.html',
  styleUrl: './report-viewer.scss'
})
export class ReportViewer implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(ReportsDataService);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly reports = signal<ReportSummary[]>([]);
  readonly reportsLoading = signal(false);
  readonly reportsError = signal<string | null>(null);

  readonly filterFields = signal<ReportFilterField[]>([]);
  readonly filterFieldsError = signal<string | null>(null);
  readonly filterFieldOptions = signal<Record<string, string[]>>({});

  readonly rows = signal<ReportRow[]>([]);
  readonly columns = signal<string[]>([]);
  readonly firstRow = signal(0);
  readonly loading = signal(false);
  readonly runError = signal<string | null>(null);
  readonly emptyHint = signal<string | null>(null);
  readonly hasRun = signal(false);

  readonly templates = signal<FilterTemplate[]>([]);
  readonly templateError = signal<string | null>(null);
  readonly savingTemplate = signal(false);

  readonly drillDownVisible = signal(false);
  readonly drillDownRows = signal<ReportRow[]>([]);
  readonly drillDownLoading = signal(false);
  readonly drillDownError = signal<string | null>(null);
  readonly drillDownColumns = computed(() => (this.drillDownRows().length > 0 ? Object.keys(this.drillDownRows()[0]) : []));

  readonly showPrintPreview = signal(false);

  reportTypeId: number | null = null;
  filterValues: Record<string, string> = {};
  templateName = '';

  ngOnInit(): void {
    this.reportsLoading.set(true);
    this.data.getReports().subscribe({
      next: (r) => {
        this.reports.set(r);
        this.reportsLoading.set(false);
      },
      error: () => {
        this.reportsLoading.set(false);
        this.reportsError.set('Could not load the report list. Please try again.');
      }
    });

    // Different report links can point at this same route with a different
    // ?reportId — subscribe rather than reading a one-time snapshot so
    // switching reports while this component is already mounted reloads it.
    this.route.queryParamMap.subscribe((q) => {
      const queryReportId = Number(q.get('reportId') ?? 0);
      if (queryReportId) {
        this.reportTypeId = queryReportId;
        this.onReportChange();
        this.cdr.markForCheck();
      }
    });
  }

  onReportChange(): void {
    this.filterValues = {};
    this.rows.set([]);
    this.columns.set([]);
    this.hasRun.set(false);
    this.runError.set(null);
    this.emptyHint.set(null);
    this.filterFields.set([]);
    this.filterFieldsError.set(null);
    this.filterFieldOptions.set({});
    this.templates.set([]);
    this.templateError.set(null);
    if (!this.reportTypeId) {
      return;
    }
    const reportTypeId = this.reportTypeId;
    this.data.getFilterFields(reportTypeId).subscribe({
      next: (fields) => {
        this.filterFields.set(fields);
        for (const f of fields) {
          if (!f.autoPopulate) {
            continue;
          }
          this.data.getFilterFieldOptions(reportTypeId, f.columnId).subscribe({
            next: (options) => {
              this.filterFieldOptions.update((m) => ({ ...m, [f.columnName]: options }));
              this.cdr.markForCheck();
            },
            // A dropdown that fails to load falls back to the plain text
            // input (see report-viewer.html) rather than showing an empty,
            // unusable select.
            error: () => this.cdr.markForCheck()
          });
        }
      },
      error: () => this.filterFieldsError.set('Could not load filters for this report.')
    });
    this.data.getTemplates(reportTypeId).subscribe({
      next: (t) => this.templates.set(t),
      error: () => this.templateError.set('Could not load saved templates for this report.')
    });
  }

  show(): void {
    if (!this.reportTypeId) {
      return;
    }
    this.loading.set(true);
    this.runError.set(null);
    this.emptyHint.set(null);
    this.data.runReport(this.reportTypeId, this.filterValues).subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.columns.set(rows.length > 0 ? Object.keys(rows[0]) : []);
        this.firstRow.set(0);
        this.hasRun.set(true);
        this.loading.set(false);
        // A 0-row result on a report that has a date-range filter is easy to
        // mistake for "broken" — several of this engine's reports default to
        // a narrow internal date window when no filter is supplied (see
        // Proc_TTReview), so real data can exist while today's default
        // window happens to be empty. Nudging the user toward the date
        // filter is a generic fix that doesn't require replicating each
        // report's own internal default logic.
        if (rows.length === 0 && this.filterFields().some((f) => f.dataType === 'date')) {
          this.emptyHint.set('No rows for the current filters — try adjusting the date range and running again.');
        }
      },
      error: (err: HttpErrorResponse) => {
        this.loading.set(false);
        this.runError.set(
          err.status === 503 && err.error?.detail
            ? err.error.detail
            : 'Could not run this report. Please check the filters and try again.'
        );
      }
    });
  }

  drillDown(row: ReportRow): void {
    if (!this.reportTypeId) {
      return;
    }
    this.drillDownError.set(null);
    this.drillDownRows.set([]);
    this.drillDownLoading.set(true);
    this.drillDownVisible.set(true);
    this.data.getDrillDown(this.reportTypeId, row).subscribe({
      next: (rows) => {
        this.drillDownRows.set(rows);
        this.drillDownLoading.set(false);
      },
      error: (err: HttpErrorResponse) => {
        this.drillDownLoading.set(false);
        this.drillDownError.set(
          err.status === 503 && err.error?.detail ? err.error.detail : 'Could not load drill-down details for this row.'
        );
      }
    });
  }

  currentReportName(): string {
    return this.reports().find((r) => r.reportTypeId === this.reportTypeId)?.reportName || 'Report';
  }

  columnLabel(col: string): string {
    return humanizeColumn(col);
  }

  optionsFor(field: ReportFilterField): string[] | null {
    const options = this.filterFieldOptions()[field.columnName];
    return field.autoPopulate && options && options.length > 0 ? options : null;
  }

  cellValue(col: string, row: ReportRow): string {
    return formatCellValue(col, row[col]);
  }

  isNumeric(col: string): boolean {
    return isNumericColumn(col, this.rows());
  }

  isAmount(col: string): boolean {
    return isAmountColumn(col);
  }

  isOtherNumeric(col: string): boolean {
    return isNumericColumn(col, this.rows()) && !isAmountColumn(col);
  }

  export(): void {
    exportToExcel(this.currentReportName(), this.rows());
  }

  exportCsv(): void {
    exportToCsv(this.currentReportName(), this.rows());
  }

  exportPdf(): void {
    exportToPdf(this.currentReportName(), this.currentReportName(), this.rows());
  }

  print(): void {
    this.showPrintPreview.set(true);
    setTimeout(() => {
      window.print();
      this.showPrintPreview.set(false);
    });
  }

  saveTemplate(): void {
    if (!this.reportTypeId || !this.templateName.trim()) {
      return;
    }
    const reportTypeId = this.reportTypeId;
    this.templateError.set(null);
    this.savingTemplate.set(true);
    this.data.saveTemplate(reportTypeId, this.templateName, this.filterValues).subscribe({
      next: () => {
        this.templateName = '';
        this.data.getTemplates(reportTypeId).subscribe({
          next: (t) => {
            this.templates.set(t);
            this.savingTemplate.set(false);
            this.cdr.markForCheck();
          },
          error: () => {
            this.savingTemplate.set(false);
            this.cdr.markForCheck();
          }
        });
      },
      error: () => {
        this.savingTemplate.set(false);
        this.templateError.set('Could not save this template. Please try again.');
      }
    });
  }

  applyTemplate(template: FilterTemplate): void {
    this.filterValues = { ...template.filters };
  }

  removeTemplate(name: string): void {
    if (!this.reportTypeId) {
      return;
    }
    const reportTypeId = this.reportTypeId;
    this.templateError.set(null);
    this.data.removeTemplate(reportTypeId, name).subscribe({
      next: () => {
        this.data.getTemplates(reportTypeId).subscribe({ next: (t) => this.templates.set(t) });
      },
      error: () => this.templateError.set('Could not remove this template. Please try again.')
    });
  }
}
