import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { API_BASE_URL } from '../../../shared/api-config';
import {
  FaceAttendanceResponse,
  FaceCheckoutResponse,
  FaceEmbeddingsResponse,
  FaceEnrolResponse,
} from '../../../shared/face/face.models';

export interface EmployeeRow {
  userId: number;
  userName: string;
  faceRegisteredAt: string | null;
}

@Injectable({ providedIn: 'root' })
export class FaceDataService {
  private readonly http = inject(HttpClient);

  listEmployees(): Promise<EmployeeRow[]> {
    return firstValueFrom(
      this.http.get<EmployeeRow[]>(`${API_BASE_URL}/admin/face/employees`),
    );
  }

  enrol(userId: number, embeddings: number[][], photo: Blob): Promise<FaceEnrolResponse> {
    const form = new FormData();
    form.append('embedding', JSON.stringify(embeddings));
    form.append('photo', photo, `${userId}-face.jpg`);
    return firstValueFrom(
      this.http.post<FaceEnrolResponse>(
        `${API_BASE_URL}/admin/face/employees/${encodeURIComponent(userId)}`,
        form,
      ),
    );
  }

  clearEnrolment(userId: number): Promise<void> {
    return firstValueFrom(
      this.http.delete<void>(
        `${API_BASE_URL}/admin/face/employees/${encodeURIComponent(userId)}`,
      ),
    );
  }

  async embeddings(ifNoneMatch?: string): Promise<FaceEmbeddingsResponse | null> {
    const headers = ifNoneMatch
      ? new HttpHeaders({ 'If-None-Match': ifNoneMatch })
      : undefined;
    const resp = await firstValueFrom(
      this.http.get<FaceEmbeddingsResponse>(`${API_BASE_URL}/admin/face/embeddings`, {
        headers,
        observe: 'response',
      }),
    );
    if (resp.status === 304) return null;
    return resp.body;
  }

  markByFace(
    employeeId: string,
    confidence: number,
    geo: {
      lat?: number;
      lng?: number;
      accuracyM?: number;
      city?: string;
      state?: string;
      country?: string;
    },
  ): Promise<FaceAttendanceResponse> {
    return firstValueFrom(
      this.http.post<FaceAttendanceResponse>(`${API_BASE_URL}/general/face/attendance`, {
        employeeId,
        confidence,
        ...geo,
      }),
    );
  }

  checkoutByFace(employeeId: string, confidence: number): Promise<FaceCheckoutResponse> {
    return firstValueFrom(
      this.http.post<FaceCheckoutResponse>(`${API_BASE_URL}/general/face/checkout`, {
        employeeId,
        confidence,
      }),
    );
  }
}
