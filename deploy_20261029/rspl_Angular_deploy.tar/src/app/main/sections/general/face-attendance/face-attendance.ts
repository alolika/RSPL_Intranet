import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  computed,
  inject,
  signal,
  viewChild,
} from '@angular/core';
import { MessageModule } from 'primeng/message';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ButtonModule } from 'primeng/button';

import { FaceApiService } from '../../../../shared/face/face-api.service';
import { EnrolledFace, FaceAttendanceResponse, FaceCheckoutResponse, FaceEmbeddingsResponse } from '../../../../shared/face/face.models';
import { bestMatch, topMatch } from '../../../../shared/face/matching';
import { greeting, primeSpeech, speakGreeting } from '../../../../shared/face/voice';
import { FaceDataService } from '../face-data.service';

type Phase =
  | 'preparing'
  | 'scanning'
  | 'blink'
  | 'matching'
  | 'success'
  | 'alreadyMarked'
  | 'checkout'
  | 'alreadyCheckedOut'
  | 'unknown'
  | 'error';
type Mode = 'checkin' | 'checkout';
type Guidance = 'position' | 'noFace' | 'tooSmall' | 'tooLarge' | 'offCenter' | 'ok';

const MATCH_THRESHOLD = 0.45;
const DETECTION_INTERVAL_MS = 180;
const BLINK_PROMPT_TIMEOUT_MS = 4500;
const BLINK_EAR_CLOSED = 0.22;
const BLINK_EAR_OPEN = 0.23;
const BLINK_GRACE_FRAMES = 8;
const STABLE_FRAMES_TO_MARK = 5;
const RESULT_DISPLAY_MS = 3000;
const SUPPRESSION_WINDOW_MS = 2500;
const EMBEDDINGS_REFRESH_MS = 120_000;

interface Fix {
  lat: number;
  lng: number;
  accuracyM: number;
}

interface Place {
  city: string;
  state: string;
  country: string;
}

function getFix(timeoutMs = 8000): Promise<Fix> {
  return new Promise((resolve, reject) => {
    if (!('geolocation' in navigator)) {
      reject(new Error('Geolocation is not available on this device.'));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) =>
        resolve({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracyM: pos.coords.accuracy,
        }),
      (err) => reject(new Error(err.message || 'Could not read location.')),
      { enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 30_000 },
    );
  });
}

async function reverseGeocode(lat: number, lng: number): Promise<Place> {
  const url =
    `https://api.bigdatacloud.net/data/reverse-geocode-client` +
    `?latitude=${lat}&longitude=${lng}&localityLanguage=en`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Reverse geocode failed (${res.status})`);
  const json = await res.json();
  return {
    city:
      json.city ||
      json.locality ||
      json.localityInfo?.administrative?.[3]?.name ||
      '',
    state: json.principalSubdivision || '',
    country: json.countryName || '',
  };
}

interface SplashData {
  phase: Phase;
  memberName: string;
  firstName: string;
  photoUrl: string;
  arrivalTime: string;
  city: string;
  closestName: string;
  closestScore: number;
  departureTime?: string;
}

@Component({
  selector: 'app-face-attendance',
  standalone: true,
  imports: [MessageModule, ProgressSpinnerModule, ButtonModule],
  template: `
    <div class="face-att-page">
      <div class="page-hero">
        <div class="hero-icon"><i class="pi pi-face-smile"></i></div>
        <h3 class="hero-title">Face Attendance</h3>
        <p class="hero-sub">Look at the camera to mark your attendance</p>
      </div>

      <div class="mode-toggle">
        <button class="mode-btn" [class.active]="mode() === 'checkin'" (click)="setMode('checkin')">
          <i class="pi pi-sign-in"></i> Check In
        </button>
        <button class="mode-btn" [class.active]="mode() === 'checkout'" (click)="setMode('checkout')">
          <i class="pi pi-sign-out"></i> Check Out
        </button>
      </div>

      <div class="camera-wrap">
        <div class="viewfinder">
          <video #video playsinline autoplay muted class="att-video"></video>
          <canvas #overlay class="att-overlay"></canvas>

          @if (splash(); as s) {
            @if (s.phase === 'success' || s.phase === 'alreadyMarked') {
              <div class="splash" [class.already]="s.phase === 'alreadyMarked'">
                @if (s.photoUrl) {
                  <img class="splash-photo" [src]="s.photoUrl" alt="" />
                } @else {
                  <i class="pi pi-check-circle splash-icon"></i>
                }
                <div class="splash-name">{{ s.memberName }}</div>
                @if (s.phase === 'success') {
                  <div class="splash-greeting">{{ greetingFor(s.firstName) }}</div>
                  <div class="splash-time">In at {{ formatTime(s.arrivalTime) }}</div>
                  @if (s.city) {
                    <div class="splash-city"><i class="pi pi-map-marker"></i> {{ s.city }}</div>
                  }
                } @else {
                  <div class="splash-greeting">Already marked today</div>
                  <div class="splash-time">at {{ formatTime(s.arrivalTime) }}</div>
                }
              </div>
            } @else if (s.phase === 'checkout' || s.phase === 'alreadyCheckedOut') {
              <div class="splash checkout-splash" [class.already]="s.phase === 'alreadyCheckedOut'">
                @if (s.photoUrl) {
                  <img class="splash-photo" [src]="s.photoUrl" alt="" />
                } @else {
                  <i class="pi pi-sign-out splash-icon"></i>
                }
                <div class="splash-name">{{ s.memberName }}</div>
                @if (s.phase === 'checkout') {
                  <div class="splash-greeting">Goodbye, {{ s.firstName }}!</div>
                  <div class="splash-time">Out at {{ formatTime(s.departureTime ?? '') }}</div>
                } @else {
                  <div class="splash-greeting">Already checked out</div>
                  <div class="splash-time">at {{ formatTime(s.departureTime ?? '') }}</div>
                }
              </div>
            } @else if (s.phase === 'unknown') {
              <div class="unknown-banner">
                <i class="pi pi-question-circle"></i>
                <div>
                  <strong>Not recognised</strong>
                  @if (s.closestName) {
                    <span>Closest: {{ s.closestName }} ({{ s.closestScore.toFixed(2) }}, need ≥ {{ threshold }})</span>
                  } @else {
                    <span>Try again or mark manually</span>
                  }
                </div>
              </div>
            }
          }
        </div>

        <div class="status-row">
          <span class="badge primary">{{ enrolledCount() }} enrolled</span>
          <span class="badge neutral">{{ markedToday() }} marked today</span>
        </div>

        <div class="status-msg">
          @switch (phase()) {
            @case ('preparing') {
              <p><i class="pi pi-spin pi-spinner"></i> Starting camera…</p>
            }
            @case ('scanning') {
              <p [class]="guidance() === 'ok' ? 'ok-text' : 'guide-text'">
                {{ guideMessage() }}
              </p>
            }
            @case ('blink') {
              <p class="blink-prompt">Please blink to confirm</p>
            }
            @case ('matching') {
              <p><i class="pi pi-spin pi-spinner"></i> Verifying…</p>
            }
            @case ('error') {
              <p-message severity="error" [text]="errorMessage()" styleClass="w-full" />
            }
          }
        </div>

        <p-button
          label="Refresh enrolled list"
          icon="pi pi-refresh"
          severity="secondary"
          [text]="true"
          (onClick)="refreshEmbeddings()"
        />
      </div>
    </div>
  `,
  styles: `
    .face-att-page { padding: 20px; max-width: 500px; margin: 0 auto; }

    .page-hero { text-align: center; margin-bottom: 20px; }
    .hero-icon { font-size: 2.5rem; color: var(--p-primary-color, #6366f1); }
    .hero-title { font-size: 1.5rem; font-weight: 700; margin: 8px 0 4px; }
    .hero-sub { color: #666; margin: 0; }

    .camera-wrap { display: flex; flex-direction: column; align-items: center; gap: 12px; }

    .viewfinder {
      position: relative; width: min(340px, 100%); aspect-ratio: 3/4;
      background: #000; border-radius: 18px; overflow: hidden;
      box-shadow: 0 10px 24px rgba(0,0,0,0.22);
    }
    .att-video { width: 100%; height: 100%; object-fit: cover; transform: scaleX(-1); }
    .att-overlay { position: absolute; inset: 0; width: 100%; height: 100%; pointer-events: none; }

    .mode-toggle {
      display: flex; gap: 8px; margin-bottom: 4px; background: #f1f5f9;
      border-radius: 12px; padding: 4px;
    }
    .mode-btn {
      flex: 1; padding: 8px 16px; border: none; border-radius: 9px;
      font-size: 0.9rem; font-weight: 600; cursor: pointer;
      background: transparent; color: #64748b; transition: all 150ms;
      display: flex; align-items: center; justify-content: center; gap: 6px;
    }
    .mode-btn.active { background: #fff; color: #1e293b; box-shadow: 0 1px 4px rgba(0,0,0,0.12); }

    .splash {
      position: absolute; inset: 0;
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      gap: 10px; padding: 20px; text-align: center; color: #fff;
      background: linear-gradient(145deg, #0ea80e 0%, #0a7a0a 100%);
      animation: splash-in 180ms ease-out;
    }
    .splash.already { background: linear-gradient(145deg, #585858 0%, #3a3a3a 100%); }
    .checkout-splash { background: linear-gradient(145deg, #0369a1 0%, #075985 100%); }
    .checkout-splash.already { background: linear-gradient(145deg, #585858 0%, #3a3a3a 100%); }
    .splash-photo {
      width: 130px; height: 130px; border-radius: 50%; object-fit: cover;
      border: 4px solid rgba(255,255,255,0.85);
    }
    .splash-icon { font-size: 100px; }
    .splash-name { font-size: 1.8rem; font-weight: 800; line-height: 1.2; }
    .splash-greeting { font-size: 1rem; font-weight: 600; }
    .splash-time { font-size: 0.85rem; opacity: 0.85; }
    .splash-city { font-size: 0.82rem; opacity: 0.8; }
    @keyframes splash-in { from { opacity:0; transform:scale(0.94); } to { opacity:1; transform:scale(1); } }

    .unknown-banner {
      position: absolute; inset: auto 8px 8px 8px;
      background: rgba(178,106,0,0.92); color: #fff;
      border-radius: 12px; padding: 10px 12px;
      display: flex; align-items: center; gap: 10px;
    }
    .unknown-banner .pi { font-size: 40px; }
    .unknown-banner div { display: flex; flex-direction: column; }
    .unknown-banner strong { font-size: 0.95rem; }
    .unknown-banner span { font-size: 0.8rem; opacity: 0.9; }

    .status-row { display: flex; gap: 8px; }
    .badge { font-size: 0.8rem; padding: 3px 10px; border-radius: 12px; font-weight: 600; }
    .badge.primary { background: #e8eaf6; color: #3949ab; }
    .badge.neutral { background: #f5f5f5; color: #555; }

    .status-msg { text-align: center; min-height: 28px; }
    .status-msg p { margin: 0; }
    .ok-text { color: #2e7d32; font-weight: 600; }
    .guide-text { color: #b26a00; }
    .blink-prompt { font-size: 1.1rem; font-weight: 700; color: #1565c0; }
  `,
})
export class FaceAttendance implements OnInit, OnDestroy {
  protected readonly threshold = MATCH_THRESHOLD.toFixed(2);

  private readonly faceData = inject(FaceDataService);
  private readonly faceApi = inject(FaceApiService);
  private readonly cdr = inject(ChangeDetectorRef);

  private readonly videoRef = viewChild<ElementRef<HTMLVideoElement>>('video');
  private readonly overlayRef = viewChild<ElementRef<HTMLCanvasElement>>('overlay');

  protected readonly phase = signal<Phase>('preparing');
  protected readonly guidance = signal<Guidance>('position');
  protected readonly splash = signal<SplashData | null>(null);
  protected readonly errorMessage = signal('');
  protected readonly enrolled = signal<EnrolledFace[]>([]);
  protected readonly markedToday = signal(0);
  protected readonly enrolledCount = computed(() => this.enrolled().length);
  protected readonly mode = signal<Mode>('checkin');

  protected setMode(m: Mode): void {
    if (this.mode() === m) return;
    this.mode.set(m);
    this.splash.set(null);
    this.stableFrames = 0;
    if (this.phase() !== 'error') this.phase.set('scanning');
  }

  protected greetingFor(firstName: string): string {
    return greeting(firstName);
  }

  protected formatTime(iso: string): string {
    try {
      return new Date(iso).toLocaleTimeString('en-IN', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      });
    } catch {
      return iso;
    }
  }

  protected readonly guideMessage = computed((): string => {
    switch (this.guidance()) {
      case 'noFace': return 'Position your face in the oval.';
      case 'tooSmall': return 'Move a little closer.';
      case 'tooLarge': return 'Move a little further back.';
      case 'offCenter': return 'Center your face in the oval.';
      case 'ok': return 'Hold steady…';
      default: return 'Position your face in the oval.';
    }
  });

  private stream: MediaStream | null = null;
  private detectTimer: ReturnType<typeof setInterval> | null = null;
  private embeddingsTimer: ReturnType<typeof setInterval> | null = null;
  private splashTimer: ReturnType<typeof setTimeout> | null = null;
  private embeddingsEtag: string | null = null;
  private suppressedUntil = new Map<string, number>();
  private blinkStartedAt = 0;
  private seenClosed = false;
  private missedBlinkFrames = 0;
  private stableFrames = 0;
  private readonly requireBlink = false; // hard-coded off; wire to a setting later
  private disposed = false;

  ngOnInit(): void {
    void this.start();
  }

  ngOnDestroy(): void {
    this.disposed = true;
    this.stopAll();
  }

  async start(): Promise<void> {
    this.phase.set('preparing');
    try {
      await this.faceApi.ensureReady();
      await this.loadEmbeddings(true);
      primeSpeech();
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 720 }, height: { ideal: 960 } },
        audio: false,
      });
      const video = this.videoRef()?.nativeElement;
      if (!video) throw new Error('Camera surface not ready.');
      video.srcObject = this.stream;
      await video.play();
      const overlay = this.overlayRef()?.nativeElement;
      if (overlay) {
        overlay.width = video.videoWidth;
        overlay.height = video.videoHeight;
      }
      this.drawOverlay();
      this.phase.set('scanning');
      this.detectTimer = setInterval(() => void this.tick(), DETECTION_INTERVAL_MS);
      this.embeddingsTimer = setInterval(
        () => void this.loadEmbeddings(false),
        EMBEDDINGS_REFRESH_MS,
      );
    } catch (err) {
      this.showError((err as Error).message || 'Could not start the camera.');
    }
    this.cdr.markForCheck();
  }

  async refreshEmbeddings(): Promise<void> {
    try {
      await this.loadEmbeddings(true);
      this.cdr.markForCheck();
    } catch {
      // Non-fatal
    }
  }

  private async tick(): Promise<void> {
    if (this.disposed) return;
    const current = this.phase();
    if (current !== 'scanning' && current !== 'blink') return;
    const video = this.videoRef()?.nativeElement;
    if (!video || video.readyState < 2 || !video.videoWidth) return;

    const result = await this.faceApi.detect(video).catch(() => null);
    if (!result) {
      if (current === 'blink' && this.missedBlinkFrames < BLINK_GRACE_FRAMES) {
        this.missedBlinkFrames++;
        return;
      }
      this.stableFrames = 0;
      if (current === 'blink') this.returnToScanning();
      else this.guidance.set('noFace');
      return;
    }

    const framing = this.framingCheck(result.box, video);
    if (framing !== 'ok') {
      if (current === 'blink' && this.missedBlinkFrames < BLINK_GRACE_FRAMES) {
        this.missedBlinkFrames++;
        return;
      }
      this.stableFrames = 0;
      if (current === 'blink') this.returnToScanning();
      else this.guidance.set(framing);
      return;
    }
    this.missedBlinkFrames = 0;
    if (current === 'scanning') this.guidance.set('ok');

    if (current === 'scanning') {
      if (!this.requireBlink) {
        this.stableFrames++;
        if (this.stableFrames >= STABLE_FRAMES_TO_MARK) {
          this.stableFrames = 0;
          this.phase.set('matching');
          void this.matchAndMark(result.descriptor);
        }
        return;
      }
      this.phase.set('blink');
      this.blinkStartedAt = performance.now();
      this.seenClosed = false;
      this.missedBlinkFrames = 0;
      return;
    }

    // Blink path
    const ear = this.faceApi.eyeAspectRatio(result.landmarks);
    if (!this.seenClosed && ear < BLINK_EAR_CLOSED) this.seenClosed = true;
    if (this.seenClosed && ear > BLINK_EAR_OPEN) {
      this.phase.set('matching');
      void this.matchAndMark(result.descriptor);
      return;
    }
    if (performance.now() - this.blinkStartedAt > BLINK_PROMPT_TIMEOUT_MS) {
      this.blinkStartedAt = performance.now();
      this.seenClosed = false;
    }
  }

  private returnToScanning(): void {
    this.phase.set('scanning');
    this.seenClosed = false;
    this.missedBlinkFrames = 0;
  }

  private framingCheck(
    box: { x: number; y: number; width: number; height: number },
    video: HTMLVideoElement,
  ): Guidance {
    const ratio = box.width / video.videoWidth;
    if (ratio < 0.15) return 'tooSmall';
    if (ratio > 0.85) return 'tooLarge';
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;
    const dx = (cx - video.videoWidth / 2) / (video.videoWidth * 0.42);
    const dy = (cy - video.videoHeight / 2) / (video.videoHeight * 0.48);
    if (dx * dx + dy * dy > 1) return 'offCenter';
    return 'ok';
  }

  private async matchAndMark(descriptor: Float32Array): Promise<void> {
    const match = bestMatch(descriptor, this.enrolled(), MATCH_THRESHOLD);
    if (!match) {
      const top = topMatch(descriptor, this.enrolled());
      this.showSplash({
        phase: 'unknown',
        memberName: '',
        firstName: '',
        photoUrl: '',
        arrivalTime: '',
        city: '',
        closestName: top?.face.memberName ?? '',
        closestScore: top?.similarity ?? NaN,
      });
      return;
    }
    const now = performance.now();
    if ((this.suppressedUntil.get(match.face.memberId) ?? 0) > now) {
      this.phase.set('scanning');
      return;
    }
    this.suppressedUntil.set(match.face.memberId, now + SUPPRESSION_WINDOW_MS);

    if (this.mode() === 'checkout') {
      try {
        const result: FaceCheckoutResponse = await this.faceData.checkoutByFace(
          match.face.memberId,
          match.similarity,
        );
        this.showSplash({
          phase: result.alreadyCheckedOut ? 'alreadyCheckedOut' : 'checkout',
          memberName: result.memberName,
          firstName: result.firstName,
          photoUrl: match.face.photoUrl,
          arrivalTime: '',
          departureTime: result.departureTime,
          city: '',
          closestName: '',
          closestScore: NaN,
        });
      } catch (err: unknown) {
        const msg = (err as { error?: { detail?: string } })?.error?.detail ?? 'Check-out failed.';
        this.showSplash({
          phase: 'unknown',
          memberName: match.face.memberName,
          firstName: match.face.firstName,
          photoUrl: match.face.photoUrl,
          arrivalTime: '',
          city: '',
          closestName: msg,
          closestScore: NaN,
        });
      }
      this.cdr.markForCheck();
      return;
    }

    // Capture geolocation + city before POSTing
    let fix: Fix | null = null;
    let place: Place = { city: '', state: '', country: '' };
    try {
      fix = await getFix();
      place = await reverseGeocode(fix.lat, fix.lng).catch(() => place);
    } catch {
      // Location unavailable — proceed without it (policy: allow attendance without geo)
    }

    try {
      const arrival: FaceAttendanceResponse = await this.faceData.markByFace(
        match.face.memberId,
        match.similarity,
        {
          lat: fix?.lat,
          lng: fix?.lng,
          accuracyM: fix?.accuracyM,
          city: place.city,
          state: place.state,
          country: place.country,
        },
      );
      this.markedToday.update((n) => (arrival.alreadyMarked ? n : n + 1));
      if (!arrival.alreadyMarked) speakGreeting(arrival.firstName);
      this.showSplash({
        phase: arrival.alreadyMarked ? 'alreadyMarked' : 'success',
        memberName: arrival.memberName,
        firstName: arrival.firstName,
        photoUrl: match.face.photoUrl,
        arrivalTime: arrival.arrivalTime,
        city: arrival.city ?? '',
        closestName: '',
        closestScore: NaN,
      });
    } catch (err) {
      this.phase.set('scanning');
      console.error('markByFace failed', err);
    }
    this.cdr.markForCheck();
  }

  private showSplash(data: SplashData): void {
    this.splash.set(data);
    this.phase.set(data.phase);
    if (this.splashTimer !== null) clearTimeout(this.splashTimer);
    this.splashTimer = setTimeout(() => {
      this.splash.set(null);
      this.phase.set('scanning');
      this.cdr.markForCheck();
    }, RESULT_DISPLAY_MS);
  }

  private async loadEmbeddings(force: boolean): Promise<void> {
    try {
      const resp: FaceEmbeddingsResponse | null = await this.faceData.embeddings(
        force ? undefined : this.embeddingsEtag ?? undefined,
      );
      if (resp) {
        this.enrolled.set(resp.faces);
        this.embeddingsEtag = resp.etag;
      }
    } catch {
      // Keep existing enrolled set
    }
  }

  private drawOverlay(): void {
    const canvas = this.overlayRef()?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const { width, height } = canvas;
    ctx.clearRect(0, 0, width, height);
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.fillRect(0, 0, width, height);
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.ellipse(width / 2, height / 2, width * 0.35, height * 0.4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    ctx.save();
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(width / 2, height / 2, width * 0.35, height * 0.4, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  private stopAll(): void {
    if (this.detectTimer !== null) { clearInterval(this.detectTimer); this.detectTimer = null; }
    if (this.embeddingsTimer !== null) { clearInterval(this.embeddingsTimer); this.embeddingsTimer = null; }
    if (this.splashTimer !== null) { clearTimeout(this.splashTimer); this.splashTimer = null; }
    const video = this.videoRef()?.nativeElement;
    if (video) { video.pause(); video.srcObject = null; }
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }

  private showError(message: string): void {
    this.errorMessage.set(message);
    this.phase.set('error');
    this.stopAll();
    this.cdr.markForCheck();
  }
}
