import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { SelectModule } from 'primeng/select';

import { ExcelColumn, exportToExcel } from '../../../../shared/export-excel';
import { AttendanceSheetDataService } from '../attendance-sheet-data.service';

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];
// A real attendance sheet only ever needs recent history plus a bit of
// lookahead — deliberately narrower than Executive Schedule's 2025-2050
// range, which exists for long-range schedule planning, not attendance.
const MIN_YEAR = 2022;
const MAX_YEAR = 2030;
const YEARS = Array.from({ length: MAX_YEAR - MIN_YEAR + 1 }, (_, i) => MIN_YEAR + i);

// Deliberately colored automatically from each cell's auto-generated status
// code — this module's whole point is a small, bounded attendance
// vocabulary, so the color can just follow the value instead of being a
// separate thing to set.
interface StatusMeta {
  label: string;
  bg: string;
  fg: string;
}

const STATUS_META: Record<string, StatusMeta> = {
  P: { label: 'Present', bg: '#dcfce7', fg: '#166534' },
  A: { label: 'Absent', bg: '#e7d5c8', fg: '#78350f' },
  HD: { label: 'Half Day', bg: '#fef3c7', fg: '#92400e' },
  WO: { label: 'Week Off', bg: '#e5e7eb', fg: '#374151' },
  H: { label: 'Holiday', bg: '#ede9fe', fg: '#5b21b6' },
  PH: { label: 'Public Holiday', bg: '#a7f3d0', fg: '#065f46' },
  L: { label: 'Leave', bg: '#fecaca', fg: '#b91c1c' },
  CL: { label: 'Casual Leave', bg: '#cffafe', fg: '#155e75' },
  PL: { label: 'Privilege Leave', bg: '#fce7f3', fg: '#9d174d' },
  SL: { label: 'Sick Leave', bg: '#ffe4e6', fg: '#9f1239' },
  OD: { label: 'On Duty', bg: '#e0e7ff', fg: '#3730a3' }
};

interface GridCell {
  day: number;
  status: string;
}

interface GridRow {
  employeeId: number;
  employeeName: string;
  cells: GridCell[];
}

/**
 * New, independent "Employee Attendance Sheet" module — completely
 * separate from the existing (read-only, proc-backed) Attendance module at
 * general/emp-attendance, per explicit request. See
 * app/routers/general_attendance_sheet.py for the backend/table design
 * (RSPL_EmployeeAttendanceSheet, composite (EmployeeId, AttendanceDate)
 * key, sparse per-cell storage).
 *
 * Architecture borrows Executive Schedule's proven grid mechanics (one flat
 * GET returning employees+days+cells joined into GridRow[] client-side) —
 * but the visual layout, color scheme, and status-legend/summary
 * presentation are intentionally fresh, per the explicit "do not copy the
 * existing form" request (which was about not reusing/copying a UI, not
 * about reinventing already-solved plumbing).
 *
 * Update (2026-08-05): converted to READ-ONLY, per explicit request — all
 * cell editing, autosave, the manual Save button, and the Excel import were
 * removed (both here and in the backend, which no longer has the
 * cells/save or import endpoints at all — see general_attendance_sheet.py's
 * own 2026-08-05 update note). Every value shown now comes solely from the
 * backend's automatic Holiday/Present/Approved-Leave overlay logic; users
 * can only view, search by name, and export.
 */
@Component({
  selector: 'app-employee-attendance-sheet',
  imports: [FormsModule, ButtonModule, SelectModule, InputTextModule, MessageModule, DatePipe],
  templateUrl: './employee-attendance-sheet.html',
  styleUrl: './employee-attendance-sheet.scss'
})
export class EmployeeAttendanceSheet implements OnInit {
  private readonly data = inject(AttendanceSheetDataService);
  // No zone.js in this app — plain (non-signal) properties like
  // `selectedMonth`/`selectedYear`/`employeeSearch` below don't trigger a
  // re-render on their own when mutated inside a plain event handler or
  // subscribe callback; markForCheck() after such a mutation is what
  // actually gets the new state on screen.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly monthOptions = MONTHS.map((label, value) => ({ label, value }));
  readonly yearOptions = YEARS.map((y) => ({ label: String(y), value: y }));
  readonly statusLegend = Object.entries(STATUS_META).map(([code, meta]) => ({ code, ...meta }));

  readonly rows = signal<GridRow[]>([]);
  readonly days = signal<number[]>([]);
  readonly loading = signal(false);
  readonly errorMessage = signal<string | null>(null);

  selectedMonth = new Date().getMonth();
  selectedYear = EmployeeAttendanceSheet.clampYear(new Date().getFullYear());
  employeeSearch = '';

  private static clampYear(year: number): number {
    return Math.min(Math.max(year, MIN_YEAR), MAX_YEAR);
  }

  ngOnInit(): void {
    this.load();
  }

  // Plain method, not computed() — employeeSearch is a plain (non-signal)
  // property, and computed() only re-runs when a SIGNAL it read changes
  // (same gotcha this app has hit repeatedly elsewhere); a plain method
  // called directly from the template re-evaluates on every change
  // detection pass instead, which is fine at this scale (~100s of rows).
  displayRows(): GridRow[] {
    const term = this.employeeSearch.trim().toLowerCase();
    if (!term) {
      return this.rows();
    }
    return this.rows().filter((r) => r.employeeName.toLowerCase().includes(term));
  }

  // Plain method for the same reason as displayRows() — depends on the
  // plain selectedMonth/selectedYear properties.
  dateForDay(day: number): Date {
    return new Date(this.selectedYear, this.selectedMonth, day);
  }

  statusMeta(code: string): StatusMeta | null {
    return STATUS_META[code.toUpperCase()] ?? null;
  }

  cellStyle(status: string): { background: string; color: string } | null {
    const meta = this.statusMeta(status);
    return meta ? { background: meta.bg, color: meta.fg } : null;
  }

  // Per-row summary chips (e.g. "P 22 · A 1 · L 2") — this module's own
  // fresh take on Executive Schedule's Grand Total column, using counts of
  // each status instead of a numeric sum (there's no single meaningful
  // "total" for a row of attendance codes).
  statusCounts(row: GridRow): { code: string; count: number }[] {
    const counts = new Map<string, number>();
    for (const cell of row.cells) {
      if (!cell.status) {
        continue;
      }
      counts.set(cell.status, (counts.get(cell.status) ?? 0) + 1);
    }
    return Array.from(counts.entries()).map(([code, count]) => ({ code, count }));
  }

  onMonthYearChange(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.errorMessage.set(null);
    this.data.getCells(this.selectedYear, this.selectedMonth + 1).subscribe({
      next: (result) => {
        this.days.set(result.days);
        const byEmployee = new Map<number, Map<number, string>>();
        for (const c of result.cells) {
          if (!byEmployee.has(c.employeeId)) {
            byEmployee.set(c.employeeId, new Map());
          }
          byEmployee.get(c.employeeId)!.set(c.day, c.status);
        }
        this.rows.set(
          result.employees.map((e) => ({
            employeeId: e.employeeId,
            employeeName: e.name,
            cells: result.days.map((day) => ({ day, status: byEmployee.get(e.employeeId)?.get(day) ?? '' }))
          }))
        );
        this.loading.set(false);
        this.cdr.markForCheck();
      },
      error: () => {
        this.loading.set(false);
        this.errorMessage.set('Could not load attendance data. Please check your connection and try again.');
        this.cdr.markForCheck();
      }
    });
  }

  private isoDateForDay(day: number): string {
    const y = this.selectedYear;
    const m = String(this.selectedMonth + 1).padStart(2, '0');
    const d = String(day).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  // Mirrors the on-screen grid exactly (Employee ID/Name plus one
  // date-named column per day) — the sheet is view-only now, so this is
  // purely a report export, not a re-import source.
  exportExcel(): void {
    const days = this.days();
    const dayColumns: ExcelColumn<GridRow>[] = days.map((day, ci) => ({
      header: this.isoDateForDay(day),
      value: (r: GridRow) => r.cells[ci]?.status || ''
    }));
    const columns: ExcelColumn<GridRow>[] = [
      { header: 'Employee ID', value: (r) => r.employeeId },
      { header: 'Employee Name', value: (r) => r.employeeName },
      ...dayColumns
    ];
    exportToExcel(`EmployeeAttendanceSheet_${this.selectedYear}_${String(this.selectedMonth + 1).padStart(2, '0')}`, this.rows(), columns);
  }
}
