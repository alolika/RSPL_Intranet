import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../../../shared/api-config';

const BASE = `${API_BASE_URL}/general/attendance-sheet`;

/**
 * New, independent "Employee Attendance Sheet" module — see
 * app/routers/general_attendance_sheet.py for the backend/table design.
 * Employee lookup deliberately reuses GeneralDataService.getUsers()
 * (existing GET /general/users) rather than duplicating it here.
 *
 * Update (2026-08-05): read-only, per explicit request — the backend's
 * cells/save and import endpoints were removed entirely, so this service
 * only ever calls GET /cells now.
 */
export interface EmployeeOption {
  employeeId: number;
  name: string;
}

export interface AttendanceCell {
  employeeId: number;
  day: number;
  status: string;
  inTime?: string;
  outTime?: string;
}

export interface AttendanceCellsResult {
  employees: EmployeeOption[];
  days: number[];
  cells: AttendanceCell[];
}

interface ApiEmployeeOption {
  employee_id: number;
  name: string;
}

interface ApiAttendanceCell {
  employee_id: number;
  day: number;
  status: string;
  in_time?: string;
  out_time?: string;
}

@Injectable({ providedIn: 'root' })
export class AttendanceSheetDataService {
  private readonly http = inject(HttpClient);

  getCells(year: number, month: number): Observable<AttendanceCellsResult> {
    return this.http
      .get<{ employees: ApiEmployeeOption[]; days: number[]; cells: ApiAttendanceCell[] }>(`${BASE}/cells`, {
        params: { year, month }
      })
      .pipe(
        map((res) => ({
          employees: res.employees.map((e) => ({ employeeId: e.employee_id, name: e.name })),
          days: res.days,
          cells: res.cells.map((c) => ({ employeeId: c.employee_id, day: c.day, status: c.status, inTime: c.in_time ?? undefined, outTime: c.out_time ?? undefined }))
        }))
      );
  }
}
