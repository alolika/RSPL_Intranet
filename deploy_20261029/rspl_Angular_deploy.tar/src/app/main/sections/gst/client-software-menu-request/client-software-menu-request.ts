import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { MessageModule } from 'primeng/message';
import { RadioButtonModule } from 'primeng/radiobutton';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { GstDataService, LookupOption, MenuRequestDetailRow, MenuRequestSummaryRow } from '../gst-data.service';

type Mode = 'summary' | 'details';

const ALL_CUSTOMER: LookupOption = { label: 'All', value: 0 };

/**
 * Mirrors Section_GST/ClientSoftwareMenuRequest.aspx.vb.
 *
 * NOTE: this page's data (vw_Web_ClientSoftwareMenuRequest), its Software
 * filter's options (vw_web_softwaremaster), and its Customer filter's
 * options (also joined against vw_Web_ClientSoftwareMenuRequest) all
 * ultimately read `[License].[License_Retailware]` via a linked server
 * that does not exist on this SQL instance (confirmed live, same gap
 * documented in gst.py's module docstring) — every request here 500s,
 * confirmed in well under a second, not a slow query. None of the three
 * calls had any error handling before.
 *
 * Also fixed while reviewing: `export()` labelled both the Summary and
 * Details exports "GST State Master" (copied from a different page and
 * never updated) — now exports under names that actually match what's
 * being exported.
 */
@Component({
  selector: 'app-client-software-menu-request',
  imports: [FormsModule, ButtonModule, RadioButtonModule, SelectModule, TableModule, MessageModule, DatePipe],
  templateUrl: './client-software-menu-request.html',
  styleUrl: './client-software-menu-request.scss'
})
export class ClientSoftwareMenuRequest implements OnInit {
  private readonly data = inject(GstDataService);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly softwareOptions = signal<LookupOption[]>([]);
  readonly softwareLoading = signal(false);
  readonly customerOptions = signal<LookupOption[]>([ALL_CUSTOMER]);
  readonly customersLoading = signal(false);
  readonly summaryRows = signal<MenuRequestSummaryRow[]>([]);
  readonly detailRows = signal<MenuRequestDetailRow[]>([]);
  readonly loading = signal(false);
  readonly loadError = signal<string | null>(null);

  mode: Mode = 'summary';
  softwareId: number | null = null;
  customerId = 0;

  private readonly unavailableMessage =
    'This report depends on the License database linked server, which is not currently configured on this server.';

  ngOnInit(): void {
    this.softwareLoading.set(true);
    this.data.getSoftwareOptions().subscribe({
      next: (opts) => {
        this.softwareOptions.set(opts);
        this.softwareId = opts[0]?.value ?? null;
        this.softwareLoading.set(false);
        this.cdr.markForCheck();
        this.show();
      },
      error: () => {
        this.softwareLoading.set(false);
        this.loadError.set(this.unavailableMessage);
      }
    });
  }

  onModeChange(): void {
    this.refreshCustomerOptions();
  }

  onSoftwareChange(): void {
    this.refreshCustomerOptions();
  }

  private refreshCustomerOptions(): void {
    if (this.mode !== 'details' || !this.softwareId) {
      return;
    }
    this.customersLoading.set(true);
    this.data.getCustomerOptionsForSoftware(this.softwareId).subscribe({
      next: (opts) => {
        this.customerOptions.set([ALL_CUSTOMER, ...opts]);
        this.customersLoading.set(false);
      },
      error: () => {
        this.customersLoading.set(false);
        this.loadError.set(this.unavailableMessage);
      }
    });
  }

  show(): void {
    if (!this.softwareId || this.loading()) {
      return;
    }
    this.loading.set(true);
    this.loadError.set(null);
    if (this.mode === 'summary') {
      this.data.getMenuRequestSummary(this.softwareId).subscribe({
        next: (rows) => {
          this.summaryRows.set(rows);
          this.loading.set(false);
        },
        error: () => {
          this.loading.set(false);
          this.loadError.set(this.unavailableMessage);
        }
      });
    } else {
      this.data.getMenuRequestDetails(this.softwareId, this.customerId).subscribe({
        next: (rows) => {
          this.detailRows.set(rows);
          this.loading.set(false);
        },
        error: () => {
          this.loading.set(false);
          this.loadError.set(this.unavailableMessage);
        }
      });
    }
  }

  export(): void {
    if (this.mode === 'summary') {
      exportToExcel('GSTReportRequestLog_Summary', this.summaryRows());
    } else {
      exportToExcel('GSTReportRequestLog_Details', this.detailRows());
    }
  }
}
