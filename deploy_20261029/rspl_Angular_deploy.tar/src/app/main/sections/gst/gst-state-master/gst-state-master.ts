import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { MessageModule } from 'primeng/message';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import { GstDataService, GstState } from '../gst-data.service';

/**
 * Mirrors Section_GST/GSTStateMaster.aspx.vb.
 *
 * NOTE: the data source, vw_web_StateMaster, ultimately reads
 * `[License].[License_Retailware]` via a linked server that does not exist
 * on this SQL instance (confirmed live, same gap documented in gst.py's
 * module docstring) — `ngOnInit` 500s every time, confirmed in well under
 * a second, not a slow query. There was no error handling here at all
 * before, so a failed load just left an empty table with the loading
 * spinner cleared and no indication anything had gone wrong — easy to
 * mistake for "it's just slow" rather than "it failed."
 */
@Component({
  selector: 'app-gst-state-master',
  imports: [ButtonModule, TableModule, MessageModule, DatePipe, IndianNumberPipe],
  templateUrl: './gst-state-master.html',
  styleUrl: './gst-state-master.scss'
})
export class GstStateMaster implements OnInit {
  private readonly data = inject(GstDataService);

  readonly rows = signal<GstState[]>([]);
  readonly loading = signal(false);
  readonly loadError = signal<string | null>(null);

  ngOnInit(): void {
    this.refresh();
  }

  refresh(): void {
    this.loading.set(true);
    this.loadError.set(null);
    this.data.getStateMaster().subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
        this.loadError.set(
          'Could not load the GST State Master. This report depends on the License database linked server, which is not currently configured on this server.'
        );
      }
    });
  }

  export(): void {
    exportToExcel('GST State Master', this.rows());
  }
}
