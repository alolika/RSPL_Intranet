import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputNumberModule } from 'primeng/inputnumber';
import { MessageModule } from 'primeng/message';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import { GstDataService, GstTaxCalcRow, LookupOption } from '../gst-data.service';

/**
 * Mirrors Section_GST/GSTTaxCalculator.aspx.vb.
 *
 * NOTE on "verify the calculation logic, ensure accurate results": the
 * actual GST calculation is not implemented on this SQL instance at all.
 * `proc_web_CalculateGSTTax` here (confirmed via OBJECT_DEFINITION) is a
 * one-line wrapper —
 *   EXEC [License].[License_Retailware].[dbo].Proc_CalculateGSTTax ...
 * — that forwards straight to a stored procedure on a completely separate
 * remote database, reached only through the `[License]` linked server that
 * doesn't exist here (confirmed live). The endpoint also fails before ever
 * reaching that call, since its first query (against `vw_web_VatMaster` to
 * resolve the software's tax IDs) already 500s for the same reason —
 * confirmed in ~0.3s, not a slow calculation.
 *
 * The parameter order/types into the wrapper proc were confirmed correct
 * against its real signature (@TaxTypeID int, @TaxID bigint, @Inclusive
 * bit, @RateAfterDiscount numeric(18,2), @Quantity numeric(18,3)). What
 * can NOT be verified from here is the *result* shape — the actual
 * calculation, and therefore its output columns, live entirely on that
 * remote database. The result mapping (saleRate/TaxAmount/NetAmount/
 * TaxName) is still a best-effort guess from the one column name
 * (`saleRate`) visible in the legacy VB source, not a confirmed contract.
 * This can only be genuinely verified once the linked server exists and a
 * real calculation can be run and inspected — flagging this clearly rather
 * than claiming correctness that can't be checked from this side.
 *
 * The GST Tax Type dropdown (Web_LittleMaster, a real local table) is the
 * one part of this page that does work today — confirmed live.
 */
@Component({
  selector: 'app-gst-tax-calculator',
  imports: [FormsModule, ButtonModule, SelectModule, InputNumberModule, CheckboxModule, TableModule, MessageModule, IndianNumberPipe],
  templateUrl: './gst-tax-calculator.html',
  styleUrl: './gst-tax-calculator.scss'
})
export class GstTaxCalculator implements OnInit {
  private readonly data = inject(GstDataService);
  private readonly cdr = inject(ChangeDetectorRef);

  readonly gstTaxTypes = signal<LookupOption[]>([]);
  readonly softwareOptions = signal<LookupOption[]>([]);
  readonly softwareLoading = signal(false);
  readonly rows = signal<GstTaxCalcRow[]>([]);
  readonly calculating = signal(false);
  readonly formError = signal<string | null>(null);
  readonly touched = signal(false);

  gstTaxTypeId: number | null = null;
  softwareId: number | null = null;
  rate: number | null = null;
  qty = 1;
  inclusive = true;

  ngOnInit(): void {
    this.data.getGstTaxTypes().subscribe({
      next: (opts) => this.gstTaxTypes.set(opts),
      error: () => this.formError.set('Could not load GST Tax Types.')
    });
    this.softwareLoading.set(true);
    this.data.getSoftwareOptions().subscribe({
      next: (opts) => {
        this.softwareOptions.set(opts);
        this.softwareId = opts[0]?.value ?? null;
        this.softwareLoading.set(false);
        this.cdr.markForCheck();
      },
      error: () => {
        this.softwareLoading.set(false);
        this.formError.set(
          'Could not load the Software list. This depends on the License database linked server, which is not currently configured on this server.'
        );
      }
    });
  }

  calculate(): void {
    this.touched.set(true);
    if (!this.softwareId) {
      this.formError.set('Please select Software.');
      return;
    }
    if (!this.gstTaxTypeId) {
      this.formError.set('Please select GST Tax Type.');
      return;
    }
    if (!this.rate) {
      this.formError.set('Please enter Rate.');
      return;
    }
    if (!this.qty) {
      this.formError.set('Please enter Quantity.');
      return;
    }

    this.formError.set(null);
    this.calculating.set(true);
    this.data.calculateTax(this.gstTaxTypeId, this.softwareId, this.rate, this.qty, this.inclusive).subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.calculating.set(false);
      },
      error: () => {
        this.calculating.set(false);
        this.formError.set(
          'Could not calculate tax. This depends on the License database linked server, which is not currently configured on this server.'
        );
      }
    });
  }

  export(): void {
    exportToExcel('GSTTaxCalculator', this.rows());
  }
}
