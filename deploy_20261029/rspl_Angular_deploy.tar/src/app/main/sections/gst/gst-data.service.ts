import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../../../shared/api-config';

const BASE = `${API_BASE_URL}/gst`;

export interface LookupOption {
  label: string;
  value: number;
}

export interface GstState {
  stateCode: string;
  stateName: string;
  gstStartDate: string;
  hsnCodeStartDate: string;
  eWayBillStartDate: string;
  eWayBillMinimumValue: number;
  saleTurnover: number;
}

export interface GstTaxRow {
  softwareName: string;
  taxId: number;
  taxName: string;
  taxPer: number;
  sgstPer: number;
  cgstPer: number;
  igstPer: number;
  utgstPer: number;
  cessBasedOn: string;
  cessPer: number;
  cessAmtPerUnit: number;
  slabApplicable: boolean;
  disabled: boolean;
}

export interface GstTaxCalcRow {
  taxId: number;
  taxName: string;
  saleRate: number;
  taxAmount: number;
  netAmount: number;
}

export interface MenuRequestSummaryRow {
  menuName: string;
  viewCount: number;
  lastViewedOn: string;
  clientCount: number;
}

export interface MenuRequestDetailRow {
  customerId: number;
  customerName: string;
  menuName: string;
  lastUserName: string;
  lastMachineName: string;
  lastViewedOn: string;
  viewCount: number;
}

interface ApiGstState {
  state_code: string;
  state_name: string;
  gst_start_date: string | null;
  hsn_code_start_date: string | null;
  e_way_bill_start_date: string | null;
  e_way_bill_minimum_value: number;
  sale_turnover: number;
}

interface ApiGstTaxRow {
  software_name: string;
  tax_id: number;
  tax_name: string;
  tax_per: number;
  sgst_per: number;
  cgst_per: number;
  igst_per: number;
  utgst_per: number;
  cess_based_on: string;
  cess_per: number;
  cess_amt_per_unit: number;
  slab_applicable: boolean;
  disabled: boolean;
}

interface ApiGstTaxCalcRow {
  tax_id: number | null;
  tax_name: string | null;
  sale_rate: number | null;
  tax_amount: number | null;
  net_amount: number | null;
}

interface ApiMenuRequestSummaryRow {
  menu_name: string;
  view_count: number;
  last_viewed_on: string | null;
  client_count: number;
}

interface ApiMenuRequestDetailRow {
  customer_id: number;
  customer_name: string;
  menu_name: string;
  last_user_name: string;
  last_machine_name: string;
  last_viewed_on: string | null;
  view_count: number;
}

/**
 * Calls the FastAPI backend (D:\Maruti_workspace\rspl_Api\app\routers\gst.py),
 * which mirrors Section_GST/*.aspx.vb (vw_web_StateMaster, vw_web_VatMaster,
 * proc_web_CalculateGSTTax, vw_Web_ClientSoftwareMenuRequest). NOTE: every one
 * of these ultimately depends on a `License` linked server that is not
 * configured on the current DB instance, so these calls will fail with a 500
 * until that's set up on the backend side — this is a known, not silent, gap.
 */
@Injectable({ providedIn: 'root' })
export class GstDataService {
  private readonly http = inject(HttpClient);

  getSoftwareOptions(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/software-options`);
  }

  getGstTaxTypes(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/tax-types`);
  }

  getStateMaster(): Observable<GstState[]> {
    return this.http.get<ApiGstState[]>(`${BASE}/state-master`).pipe(
      map((rows) =>
        rows.map((r) => ({
          stateCode: r.state_code,
          stateName: r.state_name,
          gstStartDate: r.gst_start_date ?? '',
          hsnCodeStartDate: r.hsn_code_start_date ?? '',
          eWayBillStartDate: r.e_way_bill_start_date ?? '',
          eWayBillMinimumValue: r.e_way_bill_minimum_value,
          saleTurnover: r.sale_turnover
        }))
      )
    );
  }

  getTaxMaster(softwareId: number): Observable<GstTaxRow[]> {
    const params = new HttpParams().set('software_id', softwareId);
    return this.http.get<ApiGstTaxRow[]>(`${BASE}/tax-master`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          softwareName: r.software_name,
          taxId: r.tax_id,
          taxName: r.tax_name,
          taxPer: r.tax_per,
          sgstPer: r.sgst_per,
          cgstPer: r.cgst_per,
          igstPer: r.igst_per,
          utgstPer: r.utgst_per,
          cessBasedOn: r.cess_based_on,
          cessPer: r.cess_per,
          cessAmtPerUnit: r.cess_amt_per_unit,
          slabApplicable: r.slab_applicable,
          disabled: r.disabled
        }))
      )
    );
  }

  calculateTax(
    gstTaxTypeId: number,
    softwareId: number,
    rate: number,
    qty: number,
    inclusive: boolean
  ): Observable<GstTaxCalcRow[]> {
    return this.http
      .post<ApiGstTaxCalcRow[]>(`${BASE}/calculate-tax`, {
        gst_tax_type_id: gstTaxTypeId,
        software_id: softwareId,
        rate,
        qty,
        inclusive
      })
      .pipe(
        map((rows) =>
          rows.map((r) => ({
            taxId: r.tax_id ?? 0,
            taxName: r.tax_name ?? '',
            saleRate: r.sale_rate ?? 0,
            taxAmount: r.tax_amount ?? 0,
            netAmount: r.net_amount ?? 0
          }))
        )
      );
  }

  getCustomerOptionsForSoftware(softwareId: number): Observable<LookupOption[]> {
    const params = new HttpParams().set('software_id', softwareId);
    return this.http.get<LookupOption[]>(`${BASE}/customers`, { params });
  }

  getMenuRequestSummary(softwareId: number): Observable<MenuRequestSummaryRow[]> {
    const params = new HttpParams().set('software_id', softwareId);
    return this.http.get<ApiMenuRequestSummaryRow[]>(`${BASE}/menu-request-summary`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          menuName: r.menu_name,
          viewCount: r.view_count,
          lastViewedOn: r.last_viewed_on ?? '',
          clientCount: r.client_count
        }))
      )
    );
  }

  getMenuRequestDetails(softwareId: number, customerId: number): Observable<MenuRequestDetailRow[]> {
    const params = new HttpParams().set('software_id', softwareId).set('customer_id', customerId);
    return this.http.get<ApiMenuRequestDetailRow[]>(`${BASE}/menu-request-details`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          customerId: r.customer_id,
          customerName: r.customer_name,
          menuName: r.menu_name,
          lastUserName: r.last_user_name,
          lastMachineName: r.last_machine_name,
          lastViewedOn: r.last_viewed_on ?? '',
          viewCount: r.view_count
        }))
      )
    );
  }
}
