import { DecimalPipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { MessageModule } from 'primeng/message';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { exportToExcel } from '../../../../shared/export-excel';
import { IndianNumberPipe } from '../../../../shared/indian-number.pipe';
import { GstDataService, GstTaxRow, LookupOption } from '../gst-data.service';

const ALL: LookupOption = { label: 'All', value: 0 };

/**
 * Mirrors Section_GST/GSTTaxMaster.aspx.vb.
 *
 * NOTE: both this page's data (vw_web_VatMaster joined to
 * vw_web_softwaremaster) and its own Software filter's options
 * (vw_web_softwaremaster) ultimately read `[License].[License_Retailware]`
 * via a linked server that does not exist on this SQL instance (confirmed
 * live, same gap documented in gst.py's module docstring) — every request
 * here 500s, confirmed in well under a second, not a slow query. Neither
 * call had any error handling before: a failed filter-options load left
 * the Software dropdown silently stuck at just "All" with no explanation,
 * and a failed Show left an empty table with no indication anything had
 * gone wrong.
 */
@Component({
  selector: 'app-gst-tax-master',
  imports: [FormsModule, ButtonModule, SelectModule, TableModule, MessageModule, DecimalPipe, IndianNumberPipe],
  templateUrl: './gst-tax-master.html',
  styleUrl: './gst-tax-master.scss'
})
export class GstTaxMaster implements OnInit {
  private readonly data = inject(GstDataService);

  readonly softwareOptions = signal<LookupOption[]>([ALL]);
  readonly softwareLoading = signal(false);
  readonly rows = signal<GstTaxRow[]>([]);
  readonly loading = signal(false);
  readonly loadError = signal<string | null>(null);

  selectedSoftware = 0;

  private readonly unavailableMessage =
    'This report depends on the License database linked server, which is not currently configured on this server.';

  ngOnInit(): void {
    this.softwareLoading.set(true);
    this.data.getSoftwareOptions().subscribe({
      next: (opts) => {
        this.softwareOptions.set([ALL, ...opts]);
        this.softwareLoading.set(false);
      },
      error: () => {
        this.softwareLoading.set(false);
        this.loadError.set(this.unavailableMessage);
      }
    });
    this.show();
  }

  show(): void {
    if (this.loading()) {
      return;
    }
    this.loading.set(true);
    this.loadError.set(null);
    this.data.getTaxMaster(this.selectedSoftware).subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
        this.loadError.set(this.unavailableMessage);
      }
    });
  }

  export(): void {
    exportToExcel('GSTTaxMaster', this.rows());
  }
}
