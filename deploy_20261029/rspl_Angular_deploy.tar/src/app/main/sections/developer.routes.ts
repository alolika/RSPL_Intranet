import { Routes } from '@angular/router';

export const developerRoutes: Routes = [
  {
    path: 'daily-log',
    loadComponent: () => import('./developer/daily-log/daily-log').then((m) => m.DailyLog)
  },
  {
    path: 'daily-log-register',
    loadComponent: () => import('./developer/daily-log-register/daily-log-register').then((m) => m.DailyLogRegister)
  },
  {
    path: 'table-list',
    loadComponent: () => import('./developer/table-list/table-list').then((m) => m.TableList)
  },
  {
    path: 'vote-for-best-share',
    loadComponent: () =>
      import('./developer/vote-for-best-share/vote-for-best-share').then((m) => m.VoteForBestShare)
  }
];
