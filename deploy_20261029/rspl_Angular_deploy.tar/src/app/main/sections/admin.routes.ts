import { Routes } from '@angular/router';

import { formAccessGuard } from '../../core/auth/form-access.guard';
import { FORM_HOLIDAY_MASTER } from '../../core/auth/user-rights.service';

export const adminRoutes: Routes = [
  {
    path: 'holiday-master',
    canActivate: [formAccessGuard(FORM_HOLIDAY_MASTER)],
    loadComponent: () => import('./admin/holiday-master/holiday-master').then((m) => m.HolidayMaster)
  },
  {
    path: 'face-in-out',
    loadComponent: () => import('./admin/face-in-out/face-in-out').then((m) => m.FaceInOut)
  },
  {
    path: 'face-register',
    loadComponent: () =>
      import('./admin/face-register/face-register').then((m) => m.FaceRegister),
  },
  {
    path: 'leave-app-register',
    loadComponent: () => import('./admin/leave-app-register/leave-app-register').then((m) => m.LeaveAppRegister)
  },
  {
    path: 'leave-app-register1',
    loadComponent: () => import('./admin/leave-app-register1/leave-app-register1').then((m) => m.LeaveAppRegister1)
  },
  {
    // Section_Admin/LeaveCancel.aspx, .vb-diffed against Section_General's copy: identical
    // markup, near-identical code-behind (only server-side email/WhatsApp notification
    // differences with no user-facing effect) — same physical page duplicated across two
    // source folders. Reuses the already-built General components rather than re-migrating
    // a duplicate.
    path: 'leave-cancel',
    redirectTo: '/general/leave-cancellation'
  },
  {
    path: 'leave-cancellation',
    redirectTo: '/general/leave-cancellation'
  },
  {
    path: 'leave-sanction',
    redirectTo: '/leave-sanction'
  },
  {
    path: 'leave-sanction-cancellation',
    redirectTo: '/leave-sanction-cancellation'
  },
  {
    path: 'add-tag',
    loadComponent: () => import('./admin/add-tag/add-tag').then((m) => m.AddTag)
  },
  {
    path: 'add-videos',
    loadComponent: () => import('./admin/add-videos/add-videos').then((m) => m.AddVideos)
  },
  {
    path: 'view-video',
    loadComponent: () => import('./admin/view-video/view-video').then((m) => m.ViewVideo)
  },
  {
    path: 'article',
    loadComponent: () => import('./admin/article/article').then((m) => m.Article)
  },
  {
    path: 'article-register',
    loadComponent: () => import('./admin/article-register/article-register').then((m) => m.ArticleRegister)
  },
  {
    path: 'cust-ledger',
    loadComponent: () => import('./admin/cust-ledger/cust-ledger').then((m) => m.CustLedger)
  },
  {
    path: 'customer-info',
    loadComponent: () => import('./admin/customer-info/customer-info').then((m) => m.CustomerInfo)
  },
  {
    path: 'cust-tin-followup',
    loadComponent: () => import('./admin/cust-tin-followup/cust-tin-followup').then((m) => m.CustTinFollowup)
  },
  {
    path: 'customer-ans',
    loadComponent: () => import('./admin/customer-ans/customer-ans').then((m) => m.CustomerAns)
  },
  {
    path: 'customer-grace-period',
    loadComponent: () => import('./admin/customer-grace-period/customer-grace-period').then((m) => m.CustomerGracePeriod)
  },
  {
    path: 'customer-license-violation',
    loadComponent: () =>
      import('./admin/customer-license-violation/customer-license-violation').then((m) => m.CustomerLicenseViolation)
  },
  {
    path: 'advance',
    loadComponent: () => import('./admin/advance/advance').then((m) => m.Advance)
  },
  {
    path: 'crm-review',
    loadComponent: () => import('./admin/crm-review/crm-review').then((m) => m.CrmReview)
  },
  {
    path: 'crm-review-detail',
    loadComponent: () => import('./admin/crm-review-detail/crm-review-detail').then((m) => m.CrmReviewDetail)
  },
  {
    path: 'feedback-register',
    loadComponent: () => import('./admin/feedback-register/feedback-register').then((m) => m.FeedbackRegister)
  },
  {
    path: 'my-caller-history',
    loadComponent: () => import('./admin/my-caller-history/my-caller-history').then((m) => m.MyCallerHistory)
  },
  {
    path: 'referral-analysis',
    loadComponent: () => import('./admin/referral-analysis/referral-analysis').then((m) => m.ReferralAnalysis)
  },
  {
    path: 'send-email',
    loadComponent: () => import('./admin/send-email/send-email').then((m) => m.SendEmail)
  },
  {
    path: 'web-masters',
    loadComponent: () => import('./admin/web-masters/web-masters').then((m) => m.WebMasters)
  },
  {
    path: 'payment-voucher',
    loadComponent: () => import('./admin/payment-voucher/payment-voucher').then((m) => m.PaymentVoucher)
  },
  {
    path: 'voucher-detail',
    loadComponent: () => import('./admin/voucher-detail/voucher-detail').then((m) => m.VoucherDetail)
  },
  {
    path: 'ledger-balance',
    loadComponent: () => import('./admin/ledger-balance/ledger-balance').then((m) => m.LedgerBalance)
  },
  {
    // No route-level guard here — the component itself shows an "access
    // denied" message and never fires its data calls for non-admins (see
    // user-rights.ts), and every backend endpoint it uses independently
    // 403s anyone off the RIGHTS_ADMIN_USER_IDS allow-list regardless.
    path: 'user-rights',
    loadComponent: () => import('./admin/user-rights/user-rights').then((m) => m.UserRights)
  }
];
