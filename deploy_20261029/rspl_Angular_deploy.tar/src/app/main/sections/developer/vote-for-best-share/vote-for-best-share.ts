import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { PortalAuthService } from '../../../../core/auth/portal-auth.service';
import { Branch, ShareStatus, VoteDataService, VoteResultRow } from './vote-data.service';

/**
 * Mirrors Section_Developer/VoteForBestShare.aspx.vb. The source duplicates
 * nearly identical Pune/Nagar coordinator-check blocks in VisibleLinks();
 * collapsed here into one generic "is current user the coordinator for the
 * selected branch" check driven by VoteDataService.getShareStatus(), same
 * observable behavior without the copy-paste.
 */
@Component({
  selector: 'app-vote-for-best-share',
  imports: [FormsModule, ButtonModule, SelectModule, DatePickerModule, TextareaModule, TableModule],
  templateUrl: './vote-for-best-share.html',
  styleUrl: './vote-for-best-share.scss'
})
export class VoteForBestShare implements OnInit {
  private readonly data = inject(VoteDataService);
  private readonly auth = inject(PortalAuthService);

  readonly branches = signal<Branch[]>([]);
  readonly status = signal<ShareStatus | null>(null);
  readonly hasSubmitted = signal(false);
  readonly votingEmployees = signal<{ label: string; value: number }[]>([]);
  readonly closedShareDates = signal<{ label: string; value: number }[]>([]);
  readonly resultRows = signal<VoteResultRow[]>([]);
  readonly busy = signal(false);

  selectedBranch: number | null = null;
  shareDateToOpen: Date = new Date();
  myShareText = '';
  selectedEmployee: number | null = null;
  selectedEmployeeShareText = '';
  selectedResultShareId: number | null = null;

  statusMessage = '';
  showDatePicker = false;
  showPanelBar = false;
  showCoordinatorButton = false;
  showFinalResult = false;
  coordinatorButtonText: 'Submit' | 'Close this Share now' = 'Submit';

  ngOnInit(): void {
    this.data.getBranches().subscribe((branches) => this.branches.set(branches));
  }

  onBranchChange(): void {
    this.resultRows.set([]);
    this.selectedResultShareId = null;
    if (this.selectedBranch === null) {
      return;
    }
    this.refreshStatus();
  }

  private refreshStatus(): void {
    if (this.selectedBranch === null) {
      return;
    }
    this.busy.set(true);
    this.data.getShareStatus(this.selectedBranch).subscribe((status) => {
      this.status.set(status);
      this.applyVisibility(status);
      this.busy.set(false);

      if (status.shareId) {
        this.data.getVotingEmployees(status.shareId).subscribe((opts) => this.votingEmployees.set(opts));
        this.data.hasSubmittedShare(status.shareId).subscribe((v) => this.hasSubmitted.set(v));
      }
      this.data.getClosedShareDates(this.selectedBranch!).subscribe((dates) => this.closedShareDates.set(dates));
    });
  }

  private applyVisibility(status: ShareStatus): void {
    const openAndActive = status.hasAnyShare && !status.isClosed;

    if (status.isCurrentUserCoordinator) {
      this.showCoordinatorButton = true;
      if (openAndActive) {
        this.statusMessage = `Sharing and voting is open for ${new Date(status.shareDate!).toDateString()}`;
        this.showDatePicker = false;
        this.coordinatorButtonText = 'Close this Share now';
        this.showPanelBar = true;
      } else {
        this.statusMessage = 'Open share for';
        this.showDatePicker = true;
        this.coordinatorButtonText = 'Submit';
        this.showPanelBar = false;
      }
      this.showFinalResult = status.hasAnyShare;
    } else {
      this.showCoordinatorButton = false;
      this.showDatePicker = false;
      if (openAndActive) {
        this.statusMessage = `Sharing and voting is open for ${new Date(status.shareDate!).toDateString()}`;
        this.showPanelBar = true;
      } else {
        this.statusMessage = 'No any share is open for this branch, please visit this page later.';
        this.showPanelBar = false;
      }
      this.showFinalResult = status.hasAnyShare;
    }
  }

  coordinatorAction(): void {
    if (this.selectedBranch === null) {
      return;
    }
    if (this.coordinatorButtonText === 'Submit') {
      if (!this.shareDateToOpen) {
        alert('Please select Date !');
        return;
      }
      this.data.openShare(this.selectedBranch, this.shareDateToOpen).subscribe((res) => {
        if (!res.success && res.alreadyOpen) {
          alert('Voting already closed!');
        } else {
          alert('Sharing and Voting opened');
        }
        this.refreshStatus();
      });
    } else {
      this.data.closeShare(this.selectedBranch).subscribe(() => {
        alert('Voting completed successfully!');
        this.refreshStatus();
      });
    }
  }

  submitShare(): void {
    const status = this.status();
    if (!status?.shareId) {
      return;
    }
    if (this.hasSubmitted()) {
      alert('You have already entered your share!');
      return;
    }
    if (this.myShareText.trim().length <= 50) {
      alert('Please your share having minimum 50 characters!');
      return;
    }
    this.data.submitMyShare(this.selectedBranch!, status.shareId, this.myShareText).subscribe((res) => {
      alert(res.resultMsg);
      this.hasSubmitted.set(true);
      this.data.getVotingEmployees(status.shareId).subscribe((opts) => this.votingEmployees.set(opts));
    });
  }

  onEmployeeChange(): void {
    const status = this.status();
    if (!status?.shareId || this.selectedEmployee === null) {
      this.selectedEmployeeShareText = '';
      return;
    }
    this.data.getEmployeeShareText(status.shareId, this.selectedEmployee).subscribe((text) => {
      this.selectedEmployeeShareText = text;
    });
  }

  vote(): void {
    const status = this.status();
    if (!status?.shareId) {
      return;
    }
    if (!this.hasSubmitted()) {
      alert('Please add your share.');
      return;
    }
    if (this.selectedEmployee === null) {
      alert('Please select employee.');
      return;
    }
    if (this.selectedEmployee === this.auth.currentUser()?.userId) {
      alert('Sorry!! cannot vote yourselves');
      return;
    }
    this.data.voteForEmployee(status.shareId, this.selectedEmployee).subscribe((res) => alert(res.resultMsg));
  }

  showResults(): void {
    if (this.selectedResultShareId === null || this.selectedBranch === null) {
      alert('Please select proper Date!');
      return;
    }
    this.data.getVoteResults(this.selectedResultShareId).subscribe((rows) => {
      this.resultRows.set(rows);
      if (rows.length === 0) {
        alert('No voting done for this date!');
      }
    });
  }

  // Pure display helper (added for the results table's winner highlight) —
  // doesn't change any existing data flow or method signature.
  isTopVoted(row: VoteResultRow): boolean {
    const max = Math.max(...this.resultRows().map((r) => r.voteCount));
    return max > 0 && row.voteCount === max;
  }
}
