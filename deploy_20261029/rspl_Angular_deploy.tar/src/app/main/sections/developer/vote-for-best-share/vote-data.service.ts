import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, delay, map, of } from 'rxjs';

import { API_BASE_URL } from '../../../../shared/api-config';

const BASE = `${API_BASE_URL}/developer/vote`;

export interface Branch {
  branchId: number;
  branchName: string;
}

export interface ShareStatus {
  shareId: number;
  coordinatorId: number;
  isClosed: boolean;
  shareDate: string | null;
  hasAnyShare: boolean;
  isCurrentUserCoordinator: boolean;
}

export interface VoteResultRow {
  userName: string;
  myCorrectShare: string;
  voteCount: number;
}

interface ApiShareStatus {
  share_id: number;
  coordinator_id: number;
  is_closed: boolean;
  share_date: string | null;
  has_any_share: boolean;
  is_current_user_coordinator: boolean;
}

interface ApiVoteResultRow {
  user_name: string;
  my_correct_share: string;
  vote_count: number;
}

/**
 * Mirrors Section_Developer/VoteForBestShare.aspx.vb's Proc_InsertShareMaster /
 * Proc_InsertShareDetail workflow and the options2 coordinator lookup
 * (NagarShareCoordinatorUserID / PuneShareCoordinatorUserID). Branches are
 * hardcoded 1=Nagar/2=Pune in the source itself (not DB-driven), kept the
 * same way here — same as the source, not backed by a real endpoint.
 */
@Injectable({ providedIn: 'root' })
export class VoteDataService {
  private readonly http = inject(HttpClient);

  private readonly branches: Branch[] = [
    { branchId: 1, branchName: 'Nagar' },
    { branchId: 2, branchName: 'Pune' }
  ];

  getBranches(): Observable<Branch[]> {
    return of(this.branches).pipe(delay(50));
  }

  getShareStatus(branchId: number): Observable<ShareStatus> {
    const params = new HttpParams().set('branch_id', branchId);
    return this.http.get<ApiShareStatus>(`${BASE}/status`, { params }).pipe(map((r) => this.toShareStatus(r)));
  }

  openShare(branchId: number, date: Date): Observable<{ success: boolean; alreadyOpen: boolean }> {
    return this.http.post<{ success: boolean; alreadyOpen: boolean }>(`${BASE}/open-share`, {
      branch_id: branchId,
      date: this.toDateParam(date)
    });
  }

  closeShare(branchId: number): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/close-share`, { branch_id: branchId });
  }

  hasSubmittedShare(shareId: number): Observable<boolean> {
    const params = new HttpParams().set('share_id', shareId);
    return this.http.get<boolean>(`${BASE}/has-submitted`, { params });
  }

  submitMyShare(branchId: number, shareId: number, shareText: string): Observable<{ resultMsg: string }> {
    return this.http.post<{ resultMsg: string }>(`${BASE}/submit-share`, {
      branch_id: branchId,
      share_id: shareId,
      share_text: shareText
    });
  }

  voteForEmployee(shareId: number, voteToUserId: number): Observable<{ resultMsg: string }> {
    return this.http.post<{ resultMsg: string }>(`${BASE}/vote`, {
      share_id: shareId,
      vote_to_user_id: voteToUserId
    });
  }

  getVotingEmployees(shareId: number): Observable<{ label: string; value: number }[]> {
    const params = new HttpParams().set('share_id', shareId);
    return this.http
      .get<{ label: string; value: string }[]>(`${BASE}/voting-employees`, { params })
      .pipe(map((opts) => opts.map((o) => ({ label: o.label, value: Number(o.value) }))));
  }

  getEmployeeShareText(shareId: number, userId: number): Observable<string> {
    const params = new HttpParams().set('share_id', shareId).set('user_id', userId);
    return this.http.get<{ text: string }>(`${BASE}/employee-share-text`, { params }).pipe(map((r) => r.text));
  }

  getClosedShareDates(branchId: number): Observable<{ label: string; value: number }[]> {
    const params = new HttpParams().set('branch_id', branchId);
    return this.http
      .get<{ label: string; value: string }[]>(`${BASE}/closed-share-dates`, { params })
      .pipe(map((opts) => opts.map((o) => ({ label: o.label, value: Number(o.value) }))));
  }

  getVoteResults(shareId: number): Observable<VoteResultRow[]> {
    const params = new HttpParams().set('share_id', shareId);
    return this.http.get<ApiVoteResultRow[]>(`${BASE}/results`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          userName: r.user_name,
          myCorrectShare: r.my_correct_share,
          voteCount: r.vote_count
        }))
      )
    );
  }

  private toShareStatus(r: ApiShareStatus): ShareStatus {
    return {
      shareId: r.share_id,
      coordinatorId: r.coordinator_id,
      isClosed: r.is_closed,
      shareDate: r.share_date,
      hasAnyShare: r.has_any_share,
      isCurrentUserCoordinator: r.is_current_user_coordinator
    };
  }

  private toDateParam(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }
}
