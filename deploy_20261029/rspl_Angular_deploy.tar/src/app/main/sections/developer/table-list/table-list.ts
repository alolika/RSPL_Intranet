import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { DeveloperDataService, LookupOption, TableListRow } from '../developer-data.service';

const ALL: LookupOption = { label: 'ALL', value: 'ALL' };

@Component({
  selector: 'app-table-list',
  imports: [FormsModule, ButtonModule, SelectModule, CheckboxModule, InputTextModule, TableModule, DatePipe],
  templateUrl: './table-list.html',
  styleUrl: './table-list.scss'
})
export class TableList implements OnInit {
  private readonly data = inject(DeveloperDataService);

  readonly ytDescriptions = signal<LookupOption[]>([ALL]);
  readonly transactions = signal<LookupOption[]>([ALL]);
  readonly modifiedByUsers = signal<LookupOption[]>([ALL]);
  readonly rows = signal<TableListRow[]>([]);
  readonly loading = signal(false);
  // PrimeNG's p-table doesn't reset its current page when [value] shrinks —
  // without this, filtering down from 1771 rows while sitting on, say, page
  // 50 leaves the paginator on a page offset past the end of the new
  // (smaller) result set, rendering a blank grid that looks like broken
  // pagination. Reset to page 1 on every fresh load instead.
  readonly first = signal(0);

  selectedYtDescription = 'ALL';
  selectedTransaction = 'ALL';
  selectedModifiedBy = 'ALL';

  ngOnInit(): void {
    this.data.getYtDescriptions().subscribe((opts) => this.ytDescriptions.set([ALL, ...opts]));
    this.data.getTransactionTypes().subscribe((opts) => this.transactions.set([ALL, ...opts]));
    this.data.getModifiedByUsers().subscribe((opts) => this.modifiedByUsers.set([ALL, ...opts]));
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.first.set(0);
    this.data
      .getTableList({
        ytDescription: this.selectedYtDescription,
        transaction: this.selectedTransaction,
        modifiedBy: this.selectedModifiedBy
      })
      .subscribe((rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      });
  }

  saveRow(row: TableListRow): void {
    this.data.updateTableListRow(row).subscribe();
  }
}
