import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../../../shared/api-config';

const BASE = `${API_BASE_URL}/developer`;

export interface DailyLogEntry {
  logId: number;
  date: string;
  forDate: string;
  location: string;
  product: string;
  workDescription: string;
  planForNextDay: string;
  reasonForLateEntry: string;
  remark: string;
  userName: string;
  userId: number;
}

export interface TableListRow {
  tableId: number;
  tableName: string;
  sequence: number;
  script: string;
  description: string;
  transName: string;
  isTrackTable: boolean;
  purposeOfTable: string;
  comments: string;
  primaryKeyInfo: string;
  modifyDate: string;
  questionable: boolean;
}

export interface LookupOption {
  label: string;
  value: string;
}

interface ApiDailyLogEntry {
  log_id: number;
  date: string;
  for_date: string;
  location: string;
  product: string;
  work_description: string;
  plan_for_next_day: string;
  reason_for_late_entry: string;
  remark: string;
  user_name: string;
  user_id: number;
}

interface ApiTableListRow {
  table_id: number;
  table_name: string;
  sequence: number;
  script: string;
  description: string;
  trans_name: string | null;
  is_track_table: boolean;
  purpose_of_table: string;
  comments: string;
  primary_key_info: string;
  modify_date: string | null;
  questionable: boolean;
}

/** Calls the FastAPI backend (D:\Maruti_workspace\rspl_Api), which runs the same queries/stored procs as Section_Developer/*.aspx.vb against the real WNT database. */
@Injectable({ providedIn: 'root' })
export class DeveloperDataService {
  private readonly http = inject(HttpClient);

  getProductOptions(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/products`);
  }

  saveDailyLog(entry: Partial<DailyLogEntry>): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/daily-log`, {
      for_date: entry.forDate,
      location: entry.location,
      product: entry.product,
      work_description: entry.workDescription,
      plan_for_next_day: entry.planForNextDay ?? '',
      reason_for_late_entry: entry.reasonForLateEntry ?? '',
      remark: entry.remark ?? ''
    });
  }

  getUsers(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/users`);
  }

  getDailyLogs(fromDate: Date, toDate: Date, userId: string | null): Observable<DailyLogEntry[]> {
    let params = new HttpParams()
      .set('from_date', this.toDateParam(fromDate))
      .set('to_date', this.toDateParam(toDate));
    if (userId) {
      params = params.set('user_id', userId);
    }
    return this.http.get<ApiDailyLogEntry[]>(`${BASE}/daily-logs`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          logId: r.log_id,
          date: r.date,
          forDate: r.for_date,
          location: r.location,
          product: r.product,
          workDescription: r.work_description,
          planForNextDay: r.plan_for_next_day,
          reasonForLateEntry: r.reason_for_late_entry,
          remark: r.remark,
          userName: r.user_name,
          userId: r.user_id
        }))
      )
    );
  }

  getYtDescriptions(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/yt-descriptions`);
  }

  getTransactionTypes(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/transaction-types`);
  }

  getModifiedByUsers(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/modified-by-users`);
  }

  getTableList(filters: { ytDescription?: string; transaction?: string; modifiedBy?: string }): Observable<TableListRow[]> {
    let params = new HttpParams();
    if (filters.ytDescription) {
      params = params.set('yt_description', filters.ytDescription);
    }
    if (filters.transaction) {
      params = params.set('transaction', filters.transaction);
    }
    if (filters.modifiedBy) {
      params = params.set('modified_by', filters.modifiedBy);
    }
    return this.http.get<ApiTableListRow[]>(`${BASE}/table-list`, { params }).pipe(
      map((rows) =>
        rows.map((r) => ({
          tableId: r.table_id,
          tableName: r.table_name,
          sequence: r.sequence,
          script: r.script,
          description: r.description,
          transName: r.trans_name ?? '',
          isTrackTable: r.is_track_table,
          purposeOfTable: r.purpose_of_table,
          comments: r.comments,
          primaryKeyInfo: r.primary_key_info,
          modifyDate: r.modify_date ?? '',
          questionable: r.questionable
        }))
      )
    );
  }

  updateTableListRow(row: TableListRow): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${BASE}/table-list/${row.tableId}`, {
      table_id: row.tableId,
      table_name: row.tableName,
      sequence: row.sequence,
      script: row.script,
      description: row.description,
      trans_name: row.transName || null,
      is_track_table: row.isTrackTable,
      purpose_of_table: row.purposeOfTable,
      comments: row.comments,
      primary_key_info: row.primaryKeyInfo,
      modify_date: row.modifyDate || null,
      questionable: row.questionable
    });
  }

  private toDateParam(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }
}
