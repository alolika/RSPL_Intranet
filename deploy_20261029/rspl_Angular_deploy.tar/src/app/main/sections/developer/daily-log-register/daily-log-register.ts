import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { DailyLogEntry, DeveloperDataService, LookupOption } from '../developer-data.service';

@Component({
  selector: 'app-daily-log-register',
  imports: [FormsModule, ButtonModule, SelectModule, DatePickerModule, TableModule, DatePipe],
  templateUrl: './daily-log-register.html',
  styleUrl: './daily-log-register.scss'
})
export class DailyLogRegister implements OnInit {
  private readonly data = inject(DeveloperDataService);

  readonly users = signal<LookupOption[]>([]);
  readonly logs = signal<DailyLogEntry[]>([]);
  readonly loading = signal(false);
  // PrimeNG's p-table doesn't reset its current page when [value] changes —
  // without this, filtering to a smaller result set while sitting on a later
  // page leaves the paginator on an offset past the end of the new data,
  // rendering a blank grid that looks like broken pagination. Reset to page
  // 1 on every fresh load instead (same fix as Table List/Ledger Balance).
  readonly first = signal(0);

  fromDate = new Date();
  toDate = new Date();
  selectedUser: string | null = null;

  ngOnInit(): void {
    this.data.getUsers().subscribe((users) => {
      this.users.set([{ label: 'ALL', value: 'ALL' }, ...users]);
      this.selectedUser = 'ALL';
    });
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.first.set(0);
    this.data
      .getDailyLogs(this.fromDate, this.toDate, this.selectedUser === 'ALL' ? null : this.selectedUser)
      .subscribe((rows) => {
        this.logs.set(rows);
        this.loading.set(false);
      });
  }
}
