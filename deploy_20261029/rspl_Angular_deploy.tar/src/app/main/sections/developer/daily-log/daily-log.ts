import { DatePipe } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';

import { PortalAuthService } from '../../../../core/auth/portal-auth.service';
import { DeveloperDataService, LookupOption } from '../developer-data.service';

const LOCATIONS = [
  { label: 'Office', value: 'Office' },
  { label: 'Home', value: 'Home' },
  { label: 'Client', value: 'Client' }
];

/**
 * Mirrors Section_Developer/DailyLog.aspx. For Date is always the current
 * system date (on request) — was previously server-computed as "the day
 * after the user's last log" to let someone catch up on missed days one
 * form at a time, with a "Reason for late entry" field required whenever
 * that computed date fell before today. Since For Date can now never be
 * anything but today, that whole catch-up/late-entry path is permanently
 * unreachable, so it's been removed rather than left as dead code.
 */
@Component({
  selector: 'app-daily-log',
  imports: [ReactiveFormsModule, ButtonModule, SelectModule, TextareaModule, InputTextModule, DatePickerModule, DatePipe],
  templateUrl: './daily-log.html',
  styleUrl: './daily-log.scss'
})
export class DailyLog {
  private readonly fb = inject(FormBuilder);
  private readonly data = inject(DeveloperDataService);
  private readonly auth = inject(PortalAuthService);

  readonly userName = this.auth.currentUser()?.userName ?? 'Guest';
  readonly locations = LOCATIONS;
  readonly products = signal<LookupOption[]>([]);
  readonly saving = signal(false);

  readonly form = this.fb.nonNullable.group({
    forDate: [new Date(), Validators.required],
    location: ['Office', Validators.required],
    product: ['', Validators.required],
    description: ['', Validators.required],
    nextDayPlan: [''],
    remark: ['']
  });

  constructor() {
    this.data.getProductOptions().subscribe((p) => this.products.set(p));
  }

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.saving.set(true);
    const raw = this.form.getRawValue();
    this.data
      .saveDailyLog({
        forDate: this.toDateParam(raw.forDate),
        location: raw.location,
        product: raw.product,
        workDescription: raw.description,
        planForNextDay: raw.nextDayPlan,
        reasonForLateEntry: '',
        remark: raw.remark
      })
      .subscribe({
        next: () => {
          this.saving.set(false);
          alert('Daily log Saved successfully!');
          this.form.reset({ forDate: new Date(), location: 'Office', product: '', description: '', nextDayPlan: '', remark: '' });
        },
        // Previously silent on failure (no error callback) — the Submit
        // button would stay stuck in its loading state with no feedback.
        error: () => {
          this.saving.set(false);
          alert('Could not save your daily log. Please try again.');
        }
      });
  }

  private toDateParam(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }
}
