import { Routes } from '@angular/router';

export const marketingRoutes: Routes = [
  {
    path: 'thanks-note',
    loadComponent: () => import('./marketing/thanks-note/thanks-note').then((m) => m.ThanksNote)
  },
  {
    path: 'cust-enquiry-action',
    loadComponent: () => import('./marketing/cust-enquiry-action/cust-enquiry-action').then((m) => m.CustEnquiryAction)
  },
  {
    path: 'cust-enquiry',
    loadComponent: () => import('./marketing/cust-enquiry/cust-enquiry').then((m) => m.CustEnquiry)
  },
  {
    path: 'cust-enquiry-register',
    loadComponent: () => import('./marketing/cust-enquiry-register/cust-enquiry-register').then((m) => m.CustEnquiryRegister)
  },
  {
    path: 'lead-record',
    loadComponent: () => import('./marketing/lead-record/lead-record').then((m) => m.LeadRecord)
  },
  {
    path: 'action-delay',
    loadComponent: () => import('./marketing/action-delay/action-delay').then((m) => m.ActionDelay)
  },
  {
    path: 'action-not-taken',
    loadComponent: () => import('./marketing/action-not-taken/action-not-taken').then((m) => m.ActionNotTaken)
  },
  {
    path: 'next-action-not-taken',
    loadComponent: () => import('./marketing/next-action-not-taken/next-action-not-taken').then((m) => m.NextActionNotTaken)
  },
  {
    path: 'action-delay-report',
    loadComponent: () => import('./marketing/action-delay-report/action-delay-report').then((m) => m.ActionDelayReport)
  },
  {
    path: 'action-search-report',
    loadComponent: () => import('./marketing/action-search-report/action-search-report').then((m) => m.ActionSearchReport)
  },
  {
    path: 'action-stage-detail-report',
    loadComponent: () =>
      import('./marketing/action-stage-detail-report/action-stage-detail-report').then((m) => m.ActionStageDetailReport)
  },
  {
    path: 'action-stage-summary-report',
    loadComponent: () =>
      import('./marketing/action-stage-summary-report/action-stage-summary-report').then((m) => m.ActionStageSummaryReport)
  },
  {
    path: 'activity-status-log',
    loadComponent: () => import('./marketing/activity-status-log/activity-status-log').then((m) => m.ActivityStatusLog)
  },
  {
    path: 'crm-activity',
    loadComponent: () => import('./marketing/crm-activity/crm-activity').then((m) => m.CrmActivity)
  },
  {
    path: 'crm-report',
    loadComponent: () => import('./marketing/crm-report/crm-report').then((m) => m.CrmReport)
  },
  {
    path: 'daily-crm-activity',
    loadComponent: () => import('./marketing/daily-crm-activity/daily-crm-activity').then((m) => m.DailyCrmActivity)
  },
  {
    path: 'cust-enquiry-status',
    loadComponent: () => import('./marketing/cust-enquiry-status/cust-enquiry-status').then((m) => m.CustEnquiryStatus)
  },
  {
    path: 'enquiry-downloaded',
    loadComponent: () => import('./marketing/enquiry-downloaded/enquiry-downloaded').then((m) => m.EnquiryDownloaded)
  },
  {
    path: 'outstanding-followup',
    loadComponent: () => import('./marketing/outstanding-followup/outstanding-followup').then((m) => m.OutstandingFollowup)
  },
  {
    path: 'cust-lead-report',
    loadComponent: () => import('./marketing/cust-lead-report/cust-lead-report').then((m) => m.CustLeadReport)
  },
  {
    path: 'cust-lead-chart',
    loadComponent: () => import('./marketing/cust-lead-chart/cust-lead-chart').then((m) => m.CustLeadChart)
  },
  {
    path: 'cust-heat-map',
    loadComponent: () => import('./marketing/cust-heat-map/cust-heat-map').then((m) => m.CustHeatMap)
  },
  {
    path: 'cust-map-location',
    loadComponent: () => import('./marketing/cust-map-location/cust-map-location').then((m) => m.CustMapLocation)
  },
  {
    path: 'entity-lat-long',
    loadComponent: () => import('./marketing/entity-lat-long/entity-lat-long').then((m) => m.EntityLatLong)
  },
  {
    path: 'cust-tele-calling-register',
    loadComponent: () =>
      import('./marketing/cust-tele-calling-register/cust-tele-calling-register').then((m) => m.CustTeleCallingRegister)
  },
  // Registered as two distinct routes (not one path with ?ActionType=) so
  // Angular's default RouteReuseStrategy — which reuses a component whenever
  // future.routeConfig === curr.routeConfig — can never reuse the instance
  // between Create and Modify: different route entries always get a fresh
  // component, guaranteed, regardless of query params.
  {
    path: 'cust-registration-new',
    loadComponent: () => import('./marketing/cust-registration/cust-registration').then((m) => m.CustRegistration),
    data: { mode: 'new' }
  },
  {
    path: 'cust-registration-modify',
    loadComponent: () => import('./marketing/cust-registration/cust-registration').then((m) => m.CustRegistration),
    data: { mode: 'modify' }
  },
  {
    path: 'tour-details',
    loadComponent: () => import('./marketing/tour-details/tour-details').then((m) => m.TourDetails)
  },
  {
    path: 'tour-report',
    loadComponent: () => import('./marketing/tour-report/tour-report').then((m) => m.TourReport)
  },
  {
    path: 'e-referral-register',
    loadComponent: () => import('./marketing/e-referral-register/e-referral-register').then((m) => m.EReferralRegister)
  }
];
