import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { MessageModule } from 'primeng/message';
import { PasswordModule } from 'primeng/password';

import { PortalAuthService } from '../../core/auth/portal-auth.service';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule, ButtonModule, InputTextModule, PasswordModule, MessageModule],
  templateUrl: './login.html',
  styleUrl: './login.scss'
})
export class Login {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(PortalAuthService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);

  readonly errorMessage = signal<string | null>(null);
  // Set when session-expiry.interceptor.ts redirects here after a 401 on an
  // already-logged-in request (e.g. a save that silently failed because the
  // token had expired) — distinct from errorMessage (a wrong-password
  // submission on THIS form), and shown with a milder "warn" severity since
  // it isn't the user's fault.
  readonly sessionExpiredNotice = signal<boolean>(this.route.snapshot.queryParamMap.get('reason') === 'session-expired');
  readonly submitting = signal(false);
  readonly year = new Date().getFullYear();

  readonly form = this.fb.nonNullable.group({
    loginName: ['', Validators.required],
    password: ['', Validators.required],
    securityKey: ['']
  });

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.errorMessage.set(null);
    this.sessionExpiredNotice.set(false);
    this.submitting.set(true);
    const { loginName, password, securityKey } = this.form.getRawValue();
    this.auth.login(loginName, password, securityKey).subscribe({
      next: () => {
        this.submitting.set(false);
        this.router.navigate(['/dashboard']);
      },
      error: (err: Error) => {
        this.submitting.set(false);
        this.errorMessage.set(err.message);
      }
    });
  }
}
