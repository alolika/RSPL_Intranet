import { definePreset } from '@primeuix/themes';
import Aura from '@primeuix/themes/aura';

/**
 * Lemon yellow + orange brand palette applied as a PrimeNG theme preset.
 * Primary = a genuine bright lemon yellow (500), paired with a deep orange
 * (900) for dark surfaces/emphasis states — pure bright yellow fails WCAG
 * contrast for white text, so surfaces that need white text use
 * white-on-deep-orange (900) instead of white-on-bright-yellow, and buttons/
 * interactive elements use dark text on the bright yellow (500) rather than
 * white. The 600/700 mid-tones are vivid orange, used for accent/badge/link
 * roles — together the ramp reads as a clean two-tone lemon-yellow + orange
 * scheme rather than yellow fading into brown or gold.
 */
export const IciciPreset = definePreset(Aura, {
  semantic: {
    primary: {
      50: '#fefce8',
      100: '#fef9c3',
      200: '#fef08a',
      300: '#fde047',
      400: '#facc15',
      500: '#eab308',
      600: '#ea580c',
      700: '#c2410c',
      800: '#9a3412',
      900: '#7c2d12',
      950: '#431407'
    },
    colorScheme: {
      light: {
        primary: {
          color: '{primary.500}',
          inverseColor: '#1b2a4a',
          hoverColor: '{primary.600}',
          activeColor: '{primary.700}'
        },
        highlight: {
          background: '{primary.500}',
          focusBackground: '{primary.600}',
          color: '#1b2a4a',
          focusColor: '#1b2a4a'
        }
      }
    }
  },
  components: {
    menubar: {
      colorScheme: {
        light: {
          root: {
            background: '#7c2d12',
            color: '#ffffff',
            borderColor: '#7c2d12'
          },
          item: {
            color: '#ffffff',
            focusColor: '#ffffff',
            activeColor: '#ffffff',
            focusBackground: 'rgba(255,255,255,0.12)',
            activeBackground: 'rgba(255,255,255,0.18)'
          },
          // The dropdown-indicator chevron (submenu.icon) is rendered via
          // the SAME token/class at every nesting depth — root-bar items
          // ("Marketing" etc, on the dark orange background) and items
          // nested inside an already-open white dropdown both use it. Aura's
          // default is a neutral gray tuned for light backgrounds, which
          // reads poorly against the dark background. Set it white to match
          // the root bar's label color; the scoped .p-menubar-submenu override in
          // styles.scss (higher specificity) repaints it dark navy once
          // it's inside a white dropdown, so both contexts stay readable.
          submenu: {
            background: '#ffffff',
            icon: {
              color: '#ffffff',
              focusColor: '#ffffff',
              activeColor: '#ffffff'
            }
          },
          mobileButton: {
            color: '#ffffff',
            hoverColor: '#ffffff',
            hoverBackground: 'rgba(255,255,255,0.12)'
          }
        }
      }
    }
  }
});

/** Flat brand tokens for plain CSS use (headers/footers outside PrimeNG components). */
export const IciciBrand = {
  orange: '#ea580c',
  orangeDark: '#c2410c',
  maroon: '#7c2d12',
  navy: '#1b2a4a',
  surface: '#ffffff',
  textOnBrand: '#ffffff'
};
