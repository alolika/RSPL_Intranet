import { ActivatedRouteSnapshot, DetachedRouteHandle, RouteReuseStrategy } from '@angular/router';

// Scoped to exactly one route: Customer Enquiry Register (the search panel +
// paginated action grid at /marketing/cust-enquiry-register). Its "Add"/
// "Close" Next Step links (cust-enquiry-action) and its CustID column link
// (cust-enquiry, view mode) both navigate away to a different route and
// back — under Angular's default RouteReuseStrategy (which only ever
// reuses a component when future.routeConfig === curr.routeConfig), that
// always destroyed and recreated this component on the way back, resetting
// the search fields, results, and the p-table's own internal pagination/
// sort/row-expand state every single time. A plain state-caching service
// wouldn't have been enough on its own — p-table keeps that pagination
// state inside its own component instance, which only survives if the
// parent component itself is never destroyed. Detaching (not destroying)
// the instance on the way out and reattaching the SAME instance unchanged
// on the way back is what actually preserves everything at once.
//
// Every other route in the app falls through to Angular's own default
// shouldReuseRoute check (identity comparison of routeConfig) — this
// strategy changes behavior for this one route only.
export class PreserveCustEnquiryRegisterRouteReuseStrategy implements RouteReuseStrategy {
  private static readonly PRESERVED_PATH = 'cust-enquiry-register';

  private handle: DetachedRouteHandle | null = null;

  shouldDetach(route: ActivatedRouteSnapshot): boolean {
    return route.routeConfig?.path === PreserveCustEnquiryRegisterRouteReuseStrategy.PRESERVED_PATH;
  }

  store(route: ActivatedRouteSnapshot, handle: DetachedRouteHandle | null): void {
    if (route.routeConfig?.path === PreserveCustEnquiryRegisterRouteReuseStrategy.PRESERVED_PATH) {
      this.handle = handle;
    }
  }

  shouldAttach(route: ActivatedRouteSnapshot): boolean {
    return route.routeConfig?.path === PreserveCustEnquiryRegisterRouteReuseStrategy.PRESERVED_PATH && this.handle !== null;
  }

  retrieve(route: ActivatedRouteSnapshot): DetachedRouteHandle | null {
    if (route.routeConfig?.path !== PreserveCustEnquiryRegisterRouteReuseStrategy.PRESERVED_PATH) {
      return null;
    }
    return this.handle;
  }

  shouldReuseRoute(future: ActivatedRouteSnapshot, curr: ActivatedRouteSnapshot): boolean {
    return future.routeConfig === curr.routeConfig;
  }
}
