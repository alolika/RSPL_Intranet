import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { RecruitmentAuthService } from './recruitment-auth.service';

export const recruitmentAuthGuard: CanActivateFn = () => {
  const auth = inject(RecruitmentAuthService);
  const router = inject(Router);
  return auth.isLoggedIn() ? true : router.createUrlTree(['/recruitment/login']);
};
