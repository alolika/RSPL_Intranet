import { HttpClient } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { Observable, catchError, map, tap, throwError } from 'rxjs';

import { API_BASE_URL } from '../../shared/api-config';
import { RecruitmentUser } from './recruitment-user.model';

const SESSION_KEY = 'rspl.recruitment.session';
const TOKEN_KEY = 'rspl.recruitment.token';
const BASE = `${API_BASE_URL}/recruitment/auth`;

interface ApiRecruitmentUser {
  candidate_id: number;
  candidate_name: string;
  admin_code: number;
  is_admin: boolean;
  email: string;
  mobile_no: string;
  qualification: string;
  department: string;
  show_answer: boolean;
  question_paper_id: number;
}

function toRecruitmentUser(r: ApiRecruitmentUser): RecruitmentUser {
  return {
    candidateId: r.candidate_id,
    candidateName: r.candidate_name,
    adminCode: r.admin_code,
    isAdmin: r.is_admin,
    email: r.email,
    mobileNo: r.mobile_no,
    qualification: r.qualification,
    department: r.department,
    showAnswer: r.show_answer,
    questionPaperId: r.question_paper_id
  };
}

@Injectable({ providedIn: 'root' })
export class RecruitmentAuthService {
  private readonly http = inject(HttpClient);
  private readonly currentUserSignal = signal<RecruitmentUser | null>(this.readSession());
  readonly currentUser = computed(() => this.currentUserSignal());
  readonly isLoggedIn = computed(() => this.currentUserSignal() !== null);

  login(loginName: string, password: string): Observable<RecruitmentUser> {
    return this.http
      .post<{ access_token: string; user: ApiRecruitmentUser }>(`${BASE}/login`, { login_name: loginName, password })
      .pipe(
        map((res) => ({ token: res.access_token, user: toRecruitmentUser(res.user) })),
        tap(({ token, user }) => {
          this.currentUserSignal.set(user);
          localStorage.setItem(SESSION_KEY, JSON.stringify(user));
          localStorage.setItem(TOKEN_KEY, token);
        }),
        map(({ user }) => user),
        catchError(() => throwError(() => new Error('Login Failed !')))
      );
  }

  logout(): void {
    this.currentUserSignal.set(null);
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(TOKEN_KEY);
  }

  private readSession(): RecruitmentUser | null {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as RecruitmentUser) : null;
  }
}
