import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { map } from 'rxjs';

import { UserRightsService } from './user-rights.service';

/**
 * Redirects to the dashboard when the current user's rights for `formCode`
 * are 'none'. Always fetches fresh from /user-rights/me at the moment of
 * navigation (via fetchAccess()) rather than trusting the cached signal —
 * an admin can restrict a user while that user's session is already open,
 * and this guard is the actual enforcement boundary (the nav menu hiding
 * the item is only a convenience), so it must never rely on data that could
 * be stale. A failed lookup falls back to whatever's already cached
 * (defaulting to 'edit' if nothing's cached either) rather than blocking
 * navigation outright on a transient network error.
 */
export function formAccessGuard(formCode: string): CanActivateFn {
  return () => {
    const rights = inject(UserRightsService);
    const router = inject(Router);
    return rights.fetchAccess(formCode).pipe(map((level) => (level !== 'none' ? true : router.createUrlTree(['/dashboard']))));
  };
}
