import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { PortalAuthService } from './portal-auth.service';

/**
 * Centralizes what the source app did per-page (81 copy-pasted
 * `If IsNothing(Session("userid"))` checks across Section_* pages).
 */
export const portalAuthGuard: CanActivateFn = () => {
  const auth = inject(PortalAuthService);
  const router = inject(Router);
  return auth.isLoggedIn() ? true : router.createUrlTree(['/login']);
};
