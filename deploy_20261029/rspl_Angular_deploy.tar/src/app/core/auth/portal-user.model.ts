/**
 * Mirrors the Session(...) keys populated by WebProc_ValidateUserCRM on login
 * in the source app's Login.aspx.vb, minus the raw password.
 */
export interface PortalUser {
  userId: number;
  userName: string;
  shortName: string;
  homeBranchId: number;
  billDate: string | null;
  mobileNo: string;
  email: string;
  sipExtNo: string;
  userType: string;
}
