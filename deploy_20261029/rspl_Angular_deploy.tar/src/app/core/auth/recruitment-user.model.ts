/**
 * Recruitment sub-portal has its own session model (Recruitment.master.vb),
 * keyed on CandidateID/AdminCode rather than the main portal's UserID.
 */
export interface RecruitmentUser {
  candidateId: number;
  candidateName: string;
  adminCode: number;
  isAdmin: boolean;
  email: string;
  mobileNo: string;
  qualification: string;
  department: string;
  showAnswer: boolean;
  questionPaperId: number;
}
