import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { Observable, catchError, map, tap, throwError } from 'rxjs';

import { API_BASE_URL } from '../../shared/api-config';
import { clearAccessToken, storeAccessToken } from './auth.interceptor';
import { PortalUser } from './portal-user.model';

const SESSION_KEY = 'rspl.portal.session';

interface LoginApiResponse {
  access_token: string;
  user: {
    user_id: number;
    user_name: string;
    short_name: string;
    home_branch_id: number | null;
    bill_date: string | null;
    mobile_no: string | null;
    email: string | null;
    sip_ext_no: string | null;
    user_type: string | null;
  };
}

/** Calls the FastAPI backend's /auth/login, which runs WebProc_ValidateUserCRM against the real WNT database. */
@Injectable({ providedIn: 'root' })
export class PortalAuthService {
  private readonly http = inject(HttpClient);

  private readonly currentUserSignal = signal<PortalUser | null>(this.readSession());
  readonly currentUser = computed(() => this.currentUserSignal());
  readonly isLoggedIn = computed(() => this.currentUserSignal() !== null);

  login(loginName: string, password: string, securityKey: string): Observable<PortalUser> {
    return this.http
      .post<LoginApiResponse>(`${API_BASE_URL}/auth/login`, {
        login_name: loginName,
        password,
        security_key: securityKey
      })
      .pipe(
        map((res) => this.toPortalUser(res)),
        tap((user) => {
          this.currentUserSignal.set(user);
          localStorage.setItem(SESSION_KEY, JSON.stringify(user));
        }),
        catchError((err: HttpErrorResponse) => {
          // A down/unreachable API (status 0, or a proxy 502/503/504 with an
          // HTML body) must not read as a wrong password.
          const detail =
            err.error?.detail ??
            (err.status === 0 || err.status >= 500
              ? `Server not reachable (${err.status || 'network error'}). Please try again later.`
              : 'Login Failed !');
          return throwError(() => new Error(detail));
        })
      );
  }

  private toPortalUser(res: LoginApiResponse): PortalUser {
    storeAccessToken(res.access_token);
    const u = res.user;
    return {
      userId: u.user_id,
      userName: u.user_name,
      shortName: u.short_name,
      homeBranchId: u.home_branch_id ?? 0,
      billDate: u.bill_date,
      mobileNo: u.mobile_no ?? '',
      email: u.email ?? '',
      sipExtNo: u.sip_ext_no ?? '',
      userType: u.user_type ?? ''
    };
  }

  logout(): void {
    this.currentUserSignal.set(null);
    localStorage.removeItem(SESSION_KEY);
    clearAccessToken();
  }

  private readSession(): PortalUser | null {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as PortalUser) : null;
  }
}
