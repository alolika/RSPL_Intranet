import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';

import { API_BASE_URL } from '../../shared/api-config';
import { PortalAuthService } from './portal-auth.service';

// Excluded from the global handling below:
// - /auth/login itself also returns 401 on a plain wrong password (see
//   auth.py) — treating THAT as "session expired" would blow away a user's
//   half-typed login attempt and show a confusing message instead of the
//   real "Login Failed !" one.
// - The recruitment sub-portal has its own separate token/guard namespace
//   (see recruitment-auth.guard.ts) and isn't touched here.
const EXCLUDED_PREFIXES = [`${API_BASE_URL}/auth/login`, `${API_BASE_URL}/recruitment/`];

/**
 * Every write in this app (Executive Schedule's Save, cell autosave, etc.)
 * previously failed silently with a generic "Could not save" message
 * whenever the JWT had simply expired (480 min by default) — nothing ever
 * told the user their SESSION was the problem, only that the specific
 * action failed. This catches any 401 from the main portal API, clears the
 * now-useless token, and sends the user back to /login with a clear reason
 * — instead of a login-adjacent page endlessly resurfacing "could not
 * save"/"could not load" for every subsequent action.
 */
export const sessionExpiryInterceptor: HttpInterceptorFn = (req, next) => {
  if (!req.url.startsWith(API_BASE_URL) || EXCLUDED_PREFIXES.some((prefix) => req.url.startsWith(prefix))) {
    return next(req);
  }

  const router = inject(Router);
  const auth = inject(PortalAuthService);

  return next(req).pipe(
    catchError((err: unknown) => {
      if (err instanceof HttpErrorResponse && err.status === 401 && !router.url.startsWith('/login')) {
        auth.logout();
        router.navigate(['/login'], { queryParams: { reason: 'session-expired' } });
      }
      return throwError(() => err);
    })
  );
};
