import { HttpInterceptorFn } from '@angular/common/http';

import { API_BASE_URL } from '../../shared/api-config';

const TOKEN_KEY = 'rspl.portal.token';
const RECRUITMENT_TOKEN_KEY = 'rspl.recruitment.token';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  if (!req.url.startsWith(API_BASE_URL)) {
    return next(req);
  }
  // Recruitment sub-portal has its own CandidateID/AdminCode session and
  // JWT namespace, separate from the main portal's UserID token — must not
  // attach the wrong one to the wrong API prefix.
  const isRecruitment = req.url.startsWith(`${API_BASE_URL}/recruitment/`);
  const token = localStorage.getItem(isRecruitment ? RECRUITMENT_TOKEN_KEY : TOKEN_KEY);
  if (!token) {
    return next(req);
  }
  return next(req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }));
};

export function storeAccessToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearAccessToken(): void {
  localStorage.removeItem(TOKEN_KEY);
}
