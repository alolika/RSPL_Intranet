import { HttpClient } from '@angular/common/http';
import { Injectable, effect, inject, signal } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Observable, catchError, filter, map, of, tap } from 'rxjs';

import { API_BASE_URL } from '../../shared/api-config';
import { PortalAuthService } from './portal-auth.service';

export type AccessLevel = 'view' | 'edit' | 'none';

// Form codes must match app.rights' FORM_* constants on the backend exactly.
export const FORM_EXEC_SCHEDULE = 'EXEC_SCHEDULE';
export const FORM_HOLIDAY_MASTER = 'HOLIDAY_MASTER';
export const FORM_CALL_HISTORY = 'CALL_HISTORY';
export const FORM_EMPLOYEE_ATTENDANCE_SHEET = 'EMPLOYEE_ATTENDANCE_SHEET';
export const FORM_SENTIMETER = 'SENTIMETER';

// Mirrors app.rights.RIGHTS_ADMIN_USER_IDS exactly (22 = Amol Jadhav, 25 =
// Alolika Lanke, 142 = Maruti Sangle). UI-only convenience for deciding
// whether to show the "User Rights" nav item/page at all — the backend's
// own require_rights_admin check on every /user-rights/admin/* endpoint is
// the actual enforcement boundary, not this list.
const RIGHTS_ADMIN_USER_IDS = new Set([22, 25, 142]);

interface MyRightsResponse {
  forms: Record<string, AccessLevel>;
}

export interface RightsFormOption {
  code: string;
  label: string;
}

export interface RightsUserOption {
  userId: number;
  name: string;
  // "238 - Parthamesh Gaikwad" instead of bare Name — the admin picker
  // otherwise has no way to tell apart near-identical names (confirmed root
  // cause of a real incident: rights meant for UserID 238 "Parthamesh
  // Gaikwad" were saved against UserID 251 "Prathamesh Gaikwad" instead,
  // since only Name was shown and they sort right next to each other).
  displayLabel: string;
}

export interface RightsRow {
  userId: number;
  userName: string;
  formCode: string;
  formLabel: string;
  accessLevel: AccessLevel;
}

interface ApiUserOption {
  user_id: number;
  name: string;
}

interface ApiRightRow {
  user_id: number;
  user_name: string;
  form_code: string;
  form_label: string;
  access_level: AccessLevel;
}

/**
 * Per-user, per-form View/Edit rights for Executive Schedule, Holiday
 * Master, and Call History Report (see app/rights.py for the backend design
 * notes). A form missing from the map (not loaded yet, or genuinely no rights
 * row exists for this user) is treated as 'edit' — the same default the
 * backend applies, so there's no "everything looks locked" flash while
 * /user-rights/me is still in flight, and no behavior change for any user
 * nobody has ever explicitly restricted.
 *
 * Refetches whenever the login state transitions to logged-in (covers both
 * a fresh login() call and an existing session found on page load/refresh,
 * since PortalAuthService seeds currentUser from localStorage on construction)
 * AND on every subsequent in-app navigation (an admin can change someone's
 * rights while that person's session is already open — without this, the
 * nav menu/in-component canEdit() signals would keep showing whatever was
 * cached at login until the next full re-login). This refresh is a
 * best-effort UI convenience only; formAccessGuard below never trusts this
 * cache for the actual access decision — it always fetches fresh via
 * fetchAccess() at the moment of navigation.
 */
@Injectable({ providedIn: 'root' })
export class UserRightsService {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(PortalAuthService);
  private readonly router = inject(Router);

  private readonly formsSignal = signal<Record<string, AccessLevel>>({});

  constructor() {
    effect(() => {
      if (this.auth.isLoggedIn()) {
        this.refresh();
      } else {
        this.formsSignal.set({});
      }
    });
    this.router.events.pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd)).subscribe(() => {
      if (this.auth.isLoggedIn()) {
        this.refresh();
      }
    });
  }

  refresh(): void {
    this.http.get<MyRightsResponse>(`${API_BASE_URL}/user-rights/me`).subscribe({
      next: (res) => this.formsSignal.set(res.forms),
      // Leave the default ('edit', via access() below) in place rather than
      // locking the user out of everything just because this one lookup failed.
      error: () => {}
    });
  }

  // Always hits the server fresh (never the cached formsSignal) and updates
  // the cache as a side effect — used by formAccessGuard so the actual
  // navigation decision is never based on stale data, regardless of how long
  // it's been since this user's session last refreshed.
  fetchAccess(formCode: string): Observable<AccessLevel> {
    return this.http.get<MyRightsResponse>(`${API_BASE_URL}/user-rights/me`).pipe(
      tap((res) => this.formsSignal.set(res.forms)),
      map((res) => res.forms[formCode] ?? 'edit'),
      catchError(() => of(this.access(formCode)))
    );
  }

  access(formCode: string): AccessLevel {
    return this.formsSignal()[formCode] ?? 'edit';
  }

  canView(formCode: string): boolean {
    return this.access(formCode) !== 'none';
  }

  canEdit(formCode: string): boolean {
    return this.access(formCode) === 'edit';
  }

  isRightsAdmin(): boolean {
    const userId = this.auth.currentUser()?.userId;
    return userId != null && RIGHTS_ADMIN_USER_IDS.has(userId);
  }

  // ---------- rights-admin only (backend 403s anyone not allow-listed) ----------

  getAdminForms(): Observable<RightsFormOption[]> {
    return this.http.get<RightsFormOption[]>(`${API_BASE_URL}/user-rights/admin/forms`);
  }

  getAdminUsers(): Observable<RightsUserOption[]> {
    return this.http
      .get<ApiUserOption[]>(`${API_BASE_URL}/user-rights/admin/users`)
      .pipe(map((rows) => rows.map((r) => ({ userId: r.user_id, name: r.name, displayLabel: `${r.user_id} - ${r.name}` }))));
  }

  getAdminRights(): Observable<RightsRow[]> {
    return this.http.get<ApiRightRow[]>(`${API_BASE_URL}/user-rights/admin`).pipe(
      map((rows) =>
        rows.map((r) => ({
          userId: r.user_id,
          userName: r.user_name,
          formCode: r.form_code,
          formLabel: r.form_label,
          accessLevel: r.access_level
        }))
      )
    );
  }

  setAdminRight(userId: number, formCode: string, accessLevel: AccessLevel): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${API_BASE_URL}/user-rights/admin`, {
      user_id: userId,
      form_code: formCode,
      access_level: accessLevel
    });
  }

  resetAdminRight(userId: number, formCode: string): Observable<{ success: boolean }> {
    return this.http.delete<{ success: boolean }>(`${API_BASE_URL}/user-rights/admin/${userId}/${formCode}`);
  }
}
