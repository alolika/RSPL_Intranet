import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { retry, timer } from 'rxjs';

import { API_BASE_URL } from '../../shared/api-config';

const MAX_RETRIES = 2;
const RETRY_DELAYS_MS = [300, 1000];

/**
 * Pages load their dropdown lookups (statuses, task types, products, ...)
 * with a plain subscribe() and no error branch — one transient failure left
 * that dropdown empty for good, and the only way out was a browser refresh,
 * which also threw away everything the user had typed into the form.
 *
 * Retries only GETs (safe to repeat — never a save/delete) and only on
 * failures that can succeed on a second try: network drop (status 0) or a
 * 5xx from the API. 4xx (401 session expiry, 403 no rights, 404) pass through
 * untouched on the first attempt.
 *
 * 503 (API says it is busy) and 504 (proxy gave up on a slow request) are
 * not retried: the server is overloaded, not flaky, and repeating the request
 * only adds load. Confirmed live (2026-10-22) — each timed-out Missed Calls
 * load was sent 3 times, deepening the very pile-up that caused the timeout.
 */
export const transientRetryInterceptor: HttpInterceptorFn = (req, next) => {
  if (req.method !== 'GET' || !req.url.startsWith(API_BASE_URL)) {
    return next(req);
  }
  return next(req).pipe(
    retry({
      count: MAX_RETRIES,
      delay: (err: unknown, attempt: number) => {
        const transient =
          err instanceof HttpErrorResponse &&
          (err.status === 0 || (err.status >= 500 && err.status !== 503 && err.status !== 504));
        if (!transient) {
          throw err;
        }
        return timer(RETRY_DELAYS_MS[attempt - 1] ?? 1000);
      }
    })
  );
};
