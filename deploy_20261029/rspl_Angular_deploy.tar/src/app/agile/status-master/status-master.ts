import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';

import { AgileDataService, StatusRow } from '../agile-data.service';

/** Mirrors Agile_project_Manegment/StatusMaster.aspx: add-form (with color picker) + inline-editable grid over StatusMaster. RadColorPicker replaced with a native HTML color input. */
@Component({
  selector: 'app-status-master',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, TableModule],
  templateUrl: './status-master.html',
  styleUrl: './status-master.scss'
})
export class StatusMaster implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `name` (plain) mutated inside subscribe needs an explicit
  // markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly rows = signal<StatusRow[]>([]);
  readonly saving = signal(false);
  readonly enabled = signal(true);

  name = '';
  color = '#7c2d12';

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.data.getStatuses().subscribe((rows) => this.rows.set(rows));
  }

  submit(): void {
    if (!this.name.trim()) {
      alert('Please insert Status.');
      return;
    }
    this.saving.set(true);
    this.data.saveStatus({ statusId: 0, statusName: this.name, color: this.color, enabled: this.enabled() }).subscribe(() => {
      this.saving.set(false);
      alert('Record inserted successfully.');
      this.name = '';
      this.load();
      this.cdr.markForCheck();
    });
  }

  cancel(): void {
    this.name = '';
    this.enabled.set(true);
  }

  saveRow(row: StatusRow): void {
    this.data.saveStatus(row).subscribe(() => {
      alert('Record updated successfully.');
      this.load();
    });
  }
}
