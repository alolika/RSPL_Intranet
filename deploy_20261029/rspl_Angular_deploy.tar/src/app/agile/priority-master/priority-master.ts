import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';

import { AgileDataService, PriorityRow } from '../agile-data.service';

/** Mirrors Agile_project_Manegment/PriorityMaster.aspx: add-form + inline-editable grid over PriorityMaster. */
@Component({
  selector: 'app-priority-master',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, TableModule],
  templateUrl: './priority-master.html',
  styleUrl: './priority-master.scss'
})
export class PriorityMaster implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `name` (plain) mutated inside subscribe needs an explicit
  // markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly rows = signal<PriorityRow[]>([]);
  readonly saving = signal(false);

  name = '';

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.data.getPriorities().subscribe((rows) => this.rows.set(rows));
  }

  submit(): void {
    if (!this.name.trim()) {
      alert('Please insert Priority.');
      return;
    }
    this.saving.set(true);
    this.data.savePriority({ priorityId: 0, priority: this.name, enabled: true }).subscribe(() => {
      this.saving.set(false);
      this.name = '';
      this.load();
      this.cdr.markForCheck();
    });
  }

  cancel(): void {
    this.name = '';
  }

  saveRow(row: PriorityRow): void {
    this.data.savePriority(row).subscribe(() => {
      alert('Record updated successfully.');
      this.load();
    });
  }
}
