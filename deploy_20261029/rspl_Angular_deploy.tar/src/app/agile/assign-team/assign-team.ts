import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { ListboxModule } from 'primeng/listbox';
import { SelectModule } from 'primeng/select';

import { AgileDataService, LookupOption, TeamMember } from '../agile-data.service';

/**
 * Mirrors Agile_project_Manegment/Assign Team.aspx ("Assign Team For
 * Project"): dual-list transfer of Developers and Testers per project. The
 * source's RadListBox drag/checkbox-transfer UI is replicated with
 * PrimeNG's checkbox multi-select Listbox + Assign/Unassign buttons (same
 * two-list-plus-buttons interaction, without the drag gesture).
 */
@Component({
  selector: 'app-assign-team',
  imports: [FormsModule, ButtonModule, ListboxModule, SelectModule],
  templateUrl: './assign-team.html',
  styleUrl: './assign-team.scss'
})
export class AssignTeam implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `projectId` and the `selected*Devs/Testers` plain arrays
  // mutated inside subscribe callbacks need an explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly projects = signal<LookupOption[]>([]);
  readonly unassignedDevelopers = signal<TeamMember[]>([]);
  readonly assignedDevelopers = signal<TeamMember[]>([]);
  readonly unassignedTesters = signal<TeamMember[]>([]);
  readonly assignedTesters = signal<TeamMember[]>([]);

  projectId: number | null = null;
  selectedUnassignedDevs: TeamMember[] = [];
  selectedAssignedDevs: TeamMember[] = [];
  selectedUnassignedTesters: TeamMember[] = [];
  selectedAssignedTesters: TeamMember[] = [];

  ngOnInit(): void {
    this.data.getAgileProjects().subscribe((projects) => {
      this.projects.set(projects);
      this.projectId = projects[0]?.value ?? null;
      this.reload();
      this.cdr.markForCheck();
    });
  }

  onProjectChange(): void {
    this.reload();
  }

  private reload(): void {
    if (!this.projectId) {
      return;
    }
    this.data.getTeamLists(this.projectId, 1).subscribe((res) => {
      this.unassignedDevelopers.set(res.unassigned);
      this.assignedDevelopers.set(res.assigned);
    });
    this.data.getTeamLists(this.projectId, 2).subscribe((res) => {
      this.unassignedTesters.set(res.unassigned);
      this.assignedTesters.set(res.assigned);
    });
  }

  assignDevelopers(): void {
    if (!this.projectId || this.selectedUnassignedDevs.length === 0) {
      return;
    }
    this.data.assignUnassignTeam(this.projectId, this.selectedUnassignedDevs.map((d) => d.userId), 1, true).subscribe(() => {
      alert('Assign developer successfully ! ');
      this.selectedUnassignedDevs = [];
      this.reload();
      this.cdr.markForCheck();
    });
  }

  unassignDevelopers(): void {
    if (!this.projectId || this.selectedAssignedDevs.length === 0) {
      return;
    }
    this.data.assignUnassignTeam(this.projectId, this.selectedAssignedDevs.map((d) => d.userId), 1, false).subscribe(() => {
      alert('UnAssign developer successfully ! ');
      this.selectedAssignedDevs = [];
      this.reload();
      this.cdr.markForCheck();
    });
  }

  assignTesters(): void {
    if (!this.projectId || this.selectedUnassignedTesters.length === 0) {
      return;
    }
    this.data.assignUnassignTeam(this.projectId, this.selectedUnassignedTesters.map((t) => t.userId), 2, true).subscribe(() => {
      alert('Assign tester successfully ! ');
      this.selectedUnassignedTesters = [];
      this.reload();
      this.cdr.markForCheck();
    });
  }

  unassignTesters(): void {
    if (!this.projectId || this.selectedAssignedTesters.length === 0) {
      return;
    }
    this.data.assignUnassignTeam(this.projectId, this.selectedAssignedTesters.map((t) => t.userId), 2, false).subscribe(() => {
      alert('UnAssign tester successfully ! ');
      this.selectedAssignedTesters = [];
      this.reload();
      this.cdr.markForCheck();
    });
  }
}
