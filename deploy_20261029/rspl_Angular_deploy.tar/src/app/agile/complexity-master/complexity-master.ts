import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';

import { AgileDataService, ComplexityRow } from '../agile-data.service';

/** Mirrors Agile_project_Manegment/ComplexityMaster.aspx: add-form + inline-editable grid over ComplexityMaster. */
@Component({
  selector: 'app-complexity-master',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, TableModule],
  templateUrl: './complexity-master.html',
  styleUrl: './complexity-master.scss'
})
export class ComplexityMaster implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `name` (plain) mutated inside subscribe needs an explicit
  // markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly rows = signal<ComplexityRow[]>([]);
  readonly saving = signal(false);
  readonly enabled = signal(true);

  name = '';

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.data.getComplexities().subscribe((rows) => this.rows.set(rows));
  }

  submit(): void {
    if (!this.name.trim()) {
      alert('Please insert Complexity.');
      return;
    }
    this.saving.set(true);
    this.data.saveComplexity({ complexityId: 0, complexity: this.name, enabled: this.enabled() }).subscribe(() => {
      this.saving.set(false);
      alert('Record inserted successfully.');
      this.name = '';
      this.enabled.set(true);
      this.load();
      this.cdr.markForCheck();
    });
  }

  cancel(): void {
    this.name = '';
    this.enabled.set(true);
  }

  saveRow(row: ComplexityRow): void {
    this.data.saveComplexity(row).subscribe(() => {
      alert('Record updated successfully.');
      this.load();
    });
  }
}
