import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { MenubarModule } from 'primeng/menubar';

import { PortalAuthService } from '../../core/auth/portal-auth.service';
import { MobileNav } from '../../shared/mobile-nav/mobile-nav';
import { buildAgileNav } from './agile-nav';

@Component({
  selector: 'app-agile-layout',
  imports: [RouterOutlet, RouterLink, MenubarModule, MobileNav],
  templateUrl: './agile-layout.html',
  styleUrl: './agile-layout.scss'
})
export class AgileLayout {
  private readonly router = inject(Router);
  readonly auth = inject(PortalAuthService);
  readonly navItems = buildAgileNav();

  logout(): void {
    this.auth.logout();
    this.router.navigate(['/login']);
  }
}
