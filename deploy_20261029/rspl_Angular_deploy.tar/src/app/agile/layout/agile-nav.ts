import { MenuItem } from 'primeng/api';

/**
 * Mirrors App_Master/AgileHome.master's RadMenu exactly, including the fact
 * that both "Home" and "Dashboard" navigate to TaskTracking.aspx in the
 * source (the real Dashboard.aspx link is commented out there) and that the
 * "Testing Planing" menu block is entirely commented out in the source
 * (its items are folded into "Test Management" below, which is not
 * commented out and duplicates several of the same target pages).
 */
export function buildAgileNav(): MenuItem[] {
  return [
    { label: 'Home', routerLink: '/agile/task-tracking' },
    { label: 'Dashboard', routerLink: '/agile/task-tracking' },
    { label: 'Project', routerLink: '/agile/rspl-projects' },
    { label: 'Product Backlog', routerLink: '/agile/product-backlog-details' },
    { label: 'Sprint Planning', routerLink: '/agile/sprint-planning' },
    { label: 'Story Master', routerLink: '/agile/story-master' },
    {
      label: 'Reports',
      items: [
        { label: 'Measurement Matrix', routerLink: '/agile/measurement-matrix' },
        { label: 'Branch Wise TaskReport', routerLink: '/agile/branch-wise-user-task' },
        { label: 'Testing Reports', routerLink: '/agile/reports' },
        { label: 'Work Tracking Reports', routerLink: '/agile/work-tracking' }
      ]
    },
    {
      label: 'Test Management',
      items: [
        { label: 'Dashboard', routerLink: '/agile/testing-dashboard' },
        { label: 'Reports', routerLink: '/agile/testing-reports' },
        { label: 'Test Management', routerLink: '/agile/test-management' },
        { label: 'Defect Report', routerLink: '/agile/testing-report' },
        { label: 'Test Plan Master', routerLink: '/agile/test-plan-master' },
        { label: 'Test Scenario Master', routerLink: '/agile/test-scenario-master' },
        { label: 'Test Case Master', routerLink: '/agile/test-case-master' },
        { label: 'Test Case Execution Master', routerLink: '/agile/test-case-execution-master' }
      ]
    },
    {
      label: 'Masters',
      items: [
        { label: 'Effort Size Master', routerLink: '/agile/effort-size-master' },
        { label: 'Complexity Master', routerLink: '/agile/complexity-master' },
        { label: 'Priority Master', routerLink: '/agile/priority-master' },
        { label: 'Status Master', routerLink: '/agile/status-master' },
        { label: 'Module Master', routerLink: '/agile/module-master' }
      ]
    },
    {
      label: 'Appreciation',
      items: [
        { label: 'Commendations', routerLink: '/agile/commendations', queryParams: { ID: 1 } },
        { label: 'Recommendations', routerLink: '/agile/commendations', queryParams: { ID: 2 } }
      ]
    }
  ];
}
