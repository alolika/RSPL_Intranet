import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild, inject, signal } from '@angular/core';
import { TableModule } from 'primeng/table';
import { Chart } from 'chart.js/auto';

import { AgileDataService, MeasurementMatrixRow, ProjectDetailRow } from '../agile-data.service';

/**
 * Mirrors Agile_project_Manegment/MeasurementMatrix.aspx ("Measurement
 * Matrix Report"): a bar chart of per-project metrics + a grid; clicking a
 * project name opens the source's popup detail (developer/task/hours
 * breakdown) — replaced with an inline expandable row.
 */
@Component({
  selector: 'app-measurement-matrix',
  imports: [TableModule],
  templateUrl: './measurement-matrix.html',
  styleUrl: './measurement-matrix.scss'
})
export class MeasurementMatrix implements AfterViewInit, OnDestroy {
  private readonly data = inject(AgileDataService);
  private chart: Chart | null = null;

  @ViewChild('matrixCanvas') canvasRef?: ElementRef<HTMLCanvasElement>;

  readonly rows = signal<MeasurementMatrixRow[]>([]);
  readonly expandedProjectId = signal<number | null>(null);
  readonly projectDetail = signal<ProjectDetailRow[]>([]);

  ngAfterViewInit(): void {
    this.data.getMeasurementMatrix().subscribe((rows) => {
      this.rows.set(rows);
      this.drawChart(rows);
    });
  }

  ngOnDestroy(): void {
    this.chart?.destroy();
  }

  private drawChart(rows: MeasurementMatrixRow[]): void {
    if (!this.canvasRef) {
      return;
    }
    this.chart?.destroy();
    this.chart = new Chart(this.canvasRef.nativeElement, {
      type: 'bar',
      data: {
        labels: rows.map((r) => r.projectName),
        datasets: [
          { label: 'Effort Variance %', data: rows.map((r) => r.effortVariance), backgroundColor: '#7c2d12' },
          { label: 'Schedule Variance %', data: rows.map((r) => r.scheduleVariance), backgroundColor: '#f2a900' },
          { label: 'Delivery Point %', data: rows.map((r) => r.deliveryPoint), backgroundColor: '#003057' },
          { label: 'Productivity', data: rows.map((r) => r.productivity), backgroundColor: '#7a9e9f' }
        ]
      },
      options: { plugins: { title: { display: true, text: 'Measurement Matrix in %' } } }
    });
  }

  toggleProject(row: MeasurementMatrixRow): void {
    if (this.expandedProjectId() === row.projectId) {
      this.expandedProjectId.set(null);
      return;
    }
    this.expandedProjectId.set(row.projectId);
    this.data.getMeasurementMatrixProjectDetail(row.projectId).subscribe((rows) => this.projectDetail.set(rows));
  }
}
