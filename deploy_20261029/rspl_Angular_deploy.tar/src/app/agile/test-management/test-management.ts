import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';

import { AgileDataService, LookupOption, RaiseDefectForm, TestManagementForm } from '../agile-data.service';

const CASE_TYPES = [
  { label: 'Unit Testing', value: 1 },
  { label: 'Regretion Testing', value: 2 },
  { label: 'Integration Testing', value: 3 },
  { label: 'System Testing', value: 4 }
];

/**
 * Mirrors Agile_project_Manegment/TestManagement.aspx ("Test Management"):
 * a combined Add-Testing-Details form (test plan + test case + execution
 * in one save, unlike the separate TestPlanMaster/TestScenarioMaster/
 * TestCaseMaster/TestCaseExecutionMaster pages) plus a Raise Defect panel.
 * The source's 785-line page also includes a full inline-editable
 * view/approval-workflow grid for existing testing details and defects
 * (with a "Reason for not approve" comment thread) — not replicated here;
 * that level of edit/approval tooling is disproportionate to this app's
 * frontend-only phase and the same records remain visible via
 * TestingReports/TestingDashboard.
 */
@Component({
  selector: 'app-test-management',
  imports: [FormsModule, ButtonModule, CheckboxModule, SelectModule, TextareaModule],
  templateUrl: './test-management.html',
  styleUrl: './test-management.scss'
})
export class TestManagement implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `form`/`defectForm` (plain) mutated inside subscribe
  // callbacks need an explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly projects = signal<LookupOption[]>([]);
  readonly modules = signal<LookupOption[]>([]);
  readonly productBacklogs = signal<LookupOption[]>([]);
  readonly stories = signal<LookupOption[]>([]);
  readonly users = signal<LookupOption[]>([]);
  readonly caseTypes = CASE_TYPES;
  readonly savingDetails = signal(false);
  readonly savingDefect = signal(false);
  readonly lastDefectId = signal<number | null>(null);

  form: TestManagementForm = this.blankForm();
  defectForm: RaiseDefectForm = this.blankDefectForm();

  ngOnInit(): void {
    this.data.getAgileProjects().subscribe((projects) => {
      this.projects.set(projects);
      this.form.projectId = projects[0]?.value ?? 0;
      this.onProjectChange();
      this.cdr.markForCheck();
    });
    this.data.getAddTaskLookups(0).subscribe((l) => this.users.set(l.users));
  }

  private blankForm(): TestManagementForm {
    return {
      projectId: 0,
      moduleId: 0,
      productBacklogId: 0,
      storyId: 0,
      testPlanDescription: '',
      caseType: 1,
      isPositive: false,
      caseDescription: '',
      testData: '',
      expectedResult: '',
      actualResult: ''
    };
  }

  private blankDefectForm(): RaiseDefectForm {
    return { defectDetails: '', stepsToReproduce: '', assignToId: 0, reproductability: false, suggestionByTester: '' };
  }

  onProjectChange(): void {
    if (!this.form.projectId) {
      return;
    }
    this.data.getTestScenarioFormLookups(this.form.projectId).subscribe((l) => {
      this.modules.set(l.modules);
      this.productBacklogs.set(l.productBacklogs);
      this.stories.set(l.stories);
    });
  }

  saveDetails(): void {
    if (!this.form.moduleId || !this.form.storyId || !this.form.caseDescription.trim() || !this.form.expectedResult.trim() || !this.form.actualResult.trim()) {
      alert('* Fields are compulsory');
      return;
    }
    this.savingDetails.set(true);
    this.data.saveTestManagementDetails(this.form).subscribe((res) => {
      this.savingDetails.set(false);
      alert(res.resultMsg);
      if (res.resultCode === 100) {
        this.form = { ...this.blankForm(), projectId: this.form.projectId };
      }
      this.cdr.markForCheck();
    });
  }

  raiseDefect(): void {
    if (!this.defectForm.defectDetails.trim() || !this.defectForm.assignToId) {
      alert('* Fields are compulsory');
      return;
    }
    if (!confirm('Do you want to add defect?')) {
      return;
    }
    this.savingDefect.set(true);
    this.data.raiseDefectDetailed(this.defectForm).subscribe((res) => {
      this.savingDefect.set(false);
      this.lastDefectId.set(res.defectId);
      alert(res.resultMsg);
      this.defectForm = this.blankDefectForm();
      this.cdr.markForCheck();
    });
  }
}
