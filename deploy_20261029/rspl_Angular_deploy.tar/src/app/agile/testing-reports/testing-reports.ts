import { DatePipe } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { AgileDataService, DefectReportRow } from '../agile-data.service';

const FILTER_TYPES = [
  { label: 'By Project', value: 1 },
  { label: 'By Developer', value: 2 },
  { label: 'By Status', value: 3 },
  { label: 'By Priority', value: 4 },
  { label: 'By Severity', value: 5 },
  { label: 'By Date', value: 6 },
  { label: 'Cause Of Defect', value: 7 },
  { label: 'Environment', value: 8 },
  { label: 'By Tester', value: 9 }
];

/**
 * Mirrors Agile_project_Manegment/TestingReports.aspx ("Defect Reports"):
 * the source rebinds the same defect grid for 9 different filter
 * dimensions (Project/Developer/Status/Priority/Severity/Date/Cause/
 * Environment/Tester) — consolidated into one grid driven by a Defect
 * Filter type select, consistent with the report-engine simplification
 * used throughout this app.
 */
@Component({
  selector: 'app-testing-reports',
  imports: [FormsModule, ButtonModule, SelectModule, TableModule, DatePipe],
  templateUrl: './testing-reports.html',
  styleUrl: './testing-reports.scss'
})
export class TestingReports implements OnInit {
  private readonly data = inject(AgileDataService);

  readonly filterTypes = FILTER_TYPES;
  readonly rows = signal<DefectReportRow[]>([]);

  filterType = 1;

  ngOnInit(): void {
    this.show();
  }

  show(): void {
    this.data.getTestingReportsDefects(this.filterType).subscribe((rows) => this.rows.set(rows));
  }
}
