import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { AgileDataService, LookupOption, TestCaseRow } from '../agile-data.service';

const CASE_TYPES = [
  { label: 'Unit Testing', value: 1 },
  { label: 'Regretion Testing', value: 2 },
  { label: 'Integration Testing', value: 3 },
  { label: 'System Testing', value: 4 }
];

/** Mirrors Agile_project_Manegment/TestCaseMaster.aspx ("Test Case Master"): cascading Project→Sprint→TestPlan→TestScenario add-form + grid. */
@Component({
  selector: 'app-test-case-master',
  imports: [FormsModule, ButtonModule, CheckboxModule, SelectModule, TableModule, TextareaModule],
  templateUrl: './test-case-master.html',
  styleUrl: './test-case-master.scss'
})
export class TestCaseMaster implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `projectId`/`filterProjectId`/`description` (plain)
  // mutated inside subscribe callbacks need an explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly projects = signal<LookupOption[]>([]);
  readonly sprints = signal<LookupOption[]>([]);
  readonly testPlans = signal<LookupOption[]>([]);
  readonly testScenarios = signal<LookupOption[]>([]);
  readonly caseTypes = CASE_TYPES;
  readonly rows = signal<TestCaseRow[]>([]);
  readonly saving = signal(false);

  projectId: number | null = null;
  sprintNo: number | null = null;
  testPlanId: number | null = null;
  testScenarioId: number | null = null;
  caseType = 1;
  isPositive = false;
  description = '';

  filterProjectId: number | null = null;

  ngOnInit(): void {
    this.data.getAgileProjects().subscribe((projects) => {
      this.projects.set(projects);
      this.projectId = projects[0]?.value ?? null;
      this.filterProjectId = this.projectId;
      this.onProjectChange();
      this.show();
      this.cdr.markForCheck();
    });
  }

  onProjectChange(): void {
    if (!this.projectId) {
      return;
    }
    this.data.getTestCaseFormLookups(this.projectId).subscribe((l) => {
      this.sprints.set(l.sprints);
      this.testPlans.set(l.testPlans);
      this.testScenarios.set(l.testScenarios);
    });
  }

  submit(): void {
    if (!this.projectId || !this.sprintNo || !this.testScenarioId || !this.description.trim()) {
      alert('* Fields are compulsory');
      return;
    }
    this.saving.set(true);
    this.data
      .addTestCase(this.projectId, this.sprintNo, this.testPlanId ?? 0, this.testScenarioId, this.description, this.isPositive, this.caseTypes.find((c) => c.value === this.caseType)?.label ?? '')
      .subscribe((res) => {
      this.saving.set(false);
      alert(res.resultMsg);
      this.description = '';
      this.show();
      this.cdr.markForCheck();
    });
  }

  cancel(): void {
    this.description = '';
  }

  show(): void {
    if (!this.filterProjectId) {
      return;
    }
    this.data.getTestCases(this.filterProjectId).subscribe((rows) => this.rows.set(rows));
  }
}
