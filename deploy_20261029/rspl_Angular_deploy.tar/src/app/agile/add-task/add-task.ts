import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';

import { AddTaskForm, AgileDataService, LookupOption } from '../agile-data.service';

/**
 * Mirrors Agile_project_Manegment/AddTask.aspx ("Add Task"), migrated as a
 * routed page (was a RadWindow popup) navigating back to
 * /agile/task-tracking on Save/Close, matching the app's established
 * popup-to-route pattern.
 */
@Component({
  selector: 'app-add-task',
  imports: [FormsModule, ButtonModule, CheckboxModule, DatePickerModule, InputTextModule, SelectModule, TextareaModule],
  templateUrl: './add-task.html',
  styleUrl: './add-task.scss'
})
export class AddTask implements OnInit {
  private readonly data = inject(AgileDataService);
  private readonly router = inject(Router);
  // No zone.js here — `form` (plain, non-signal) mutated inside subscribe
  // callbacks needs an explicit markForCheck() to render.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly projects = signal<LookupOption[]>([]);
  readonly modules = signal<LookupOption[]>([]);
  readonly taskTypes = signal<LookupOption[]>([]);
  readonly users = signal<LookupOption[]>([]);
  readonly statuses = signal<LookupOption[]>([]);
  readonly saving = signal(false);

  forDate: Date | null = new Date();
  form: AddTaskForm = this.blankForm();

  ngOnInit(): void {
    this.data.getAgileProjects().subscribe((projects) => {
      this.projects.set(projects);
      this.form.projectId = projects[0]?.value ?? 0;
      this.onProjectChange();
      this.cdr.markForCheck();
    });
  }

  private blankForm(): AddTaskForm {
    return {
      projectId: 0,
      moduleId: 0,
      taskDetails: '',
      taskHours: '',
      taskTypeId: 0,
      assignedTo: 0,
      assignedBy: 0,
      statusId: 0,
      forDate: '',
      isCurrentTask: false
    };
  }

  onProjectChange(): void {
    if (!this.form.projectId) {
      return;
    }
    this.data.getAddTaskLookups(this.form.projectId).subscribe((l) => {
      this.modules.set(l.modules);
      this.taskTypes.set(l.taskTypes);
      this.users.set(l.users);
      this.statuses.set(l.statuses);
    });
  }

  private validate(): boolean {
    if (!this.form.projectId) {
      alert('Please select project !');
      return false;
    }
    if (!this.form.moduleId) {
      alert('Please select module !');
      return false;
    }
    if (!this.form.taskDetails.trim()) {
      alert('Enter Task Description.');
      return false;
    }
    if (!this.form.taskHours.trim()) {
      alert('Enter Task Hours.');
      return false;
    }
    if (!this.form.taskTypeId) {
      alert('Please select task type !');
      return false;
    }
    if (!this.form.assignedTo) {
      alert('Please select assigned to !');
      return false;
    }
    if (!this.form.assignedBy) {
      alert('Please select assigned by !');
      return false;
    }
    if (!this.form.statusId) {
      alert('Please select status !');
      return false;
    }
    if (this.forDate && this.forDate.getTime() > Date.now()) {
      alert('Please select valid for date !');
      return false;
    }
    return true;
  }

  private save(closeAfter: boolean): void {
    if (!this.validate()) {
      return;
    }
    this.saving.set(true);
    this.form.forDate = (this.forDate ?? new Date()).toISOString();
    this.data.addTask(this.form).subscribe((res) => {
      this.saving.set(false);
      if (res.resultCode !== 100) {
        alert('Failed to add task.');
        return;
      }
      alert(res.resultMsg);
      if (closeAfter) {
        this.router.navigate(['/agile/task-tracking']);
      } else {
        this.form.taskDetails = '';
        this.form.taskHours = '';
      }
      this.cdr.markForCheck();
    });
  }

  saveAndStay(): void {
    this.save(false);
  }

  save2(): void {
    this.save(true);
  }

  close(): void {
    this.router.navigate(['/agile/task-tracking']);
  }
}
