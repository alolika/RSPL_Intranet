import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TabsModule } from 'primeng/tabs';
import { TextareaModule } from 'primeng/textarea';

import {
  AcceptanceCriteriaForm,
  AcceptanceCriteriaRow,
  AgileDataService,
  LookupOption,
  StoryForm,
  StoryRow,
  StoryTaskForm,
  StoryTaskRow
} from '../agile-data.service';

/**
 * Mirrors Agile_project_Manegment/StoryMaster.aspx ("Story Master"): the
 * source is a 4-tab page (Story Master / Task Master / Acceptance Criteria
 * / View) where the "View" tab shows a read-only nested re-display of the
 * same Story→Task hierarchy already visible via the Story tab's grid — it
 * adds no distinct data. Simplified here to 3 tabs (Story / Task /
 * Acceptance Criteria); the Story tab's grid already serves the "view"
 * need. Most in-place-edit fields in the source's Story Details grid are
 * themselves Enabled="false" (read-only even in edit mode) — only
 * IwishTodesc/Sothatdesc/Comments are genuinely editable, which this page
 * preserves.
 */
@Component({
  selector: 'app-story-master',
  imports: [FormsModule, ButtonModule, DatePickerModule, InputTextModule, SelectModule, TableModule, TabsModule, TextareaModule, DatePipe],
  templateUrl: './story-master.html',
  styleUrl: './story-master.scss'
})
export class StoryMaster implements OnInit {
  private readonly data = inject(AgileDataService);
  private readonly route = inject(ActivatedRoute);
  // No zone.js — `storyForm`/`taskForm`/`criteriaForm`/`activeTab` (plain)
  // mutated inside subscribe callbacks need an explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  activeTab = 'story';

  readonly projects = signal<LookupOption[]>([]);
  readonly productBacklogs = signal<LookupOption[]>([]);
  readonly asAOptions = signal<LookupOption[]>([]);
  readonly complexities = signal<LookupOption[]>([]);
  readonly priorities = signal<LookupOption[]>([]);
  readonly effortSizes = signal<{ label: string; value: number; days: number; hours: number }[]>([]);
  readonly developers = signal<LookupOption[]>([]);
  readonly testers = signal<LookupOption[]>([]);
  readonly storyRows = signal<StoryRow[]>([]);
  readonly savingStory = signal(false);

  readonly storyFeatures = signal<LookupOption[]>([]);
  readonly storyAssignedHours = signal(0);
  readonly storyRemainingHours = signal(0);
  readonly taskRows = signal<StoryTaskRow[]>([]);
  readonly savingTask = signal(false);

  readonly acStoryFeatures = signal<LookupOption[]>([]);
  readonly acTasks = signal<LookupOption[]>([]);
  readonly criteriaRows = signal<AcceptanceCriteriaRow[]>([]);
  readonly savingCriteria = signal(false);

  storyForm: StoryForm = this.blankStoryForm();
  startDate: Date | null = new Date();
  endDate: Date | null = new Date();

  taskForm: StoryTaskForm = this.blankTaskForm();

  criteriaForm: AcceptanceCriteriaForm = this.blankCriteriaForm();

  ngOnInit(): void {
    this.data.getAgileProjects().subscribe((projects) => this.projects.set(projects));

    // Reachable with a different ?ProjectID/?ModuleID each time (e.g. from
    // Product Backlog's "Add Story" links) — subscribe rather than reading a
    // one-time snapshot so revisiting with different params actually reloads.
    this.route.queryParamMap.subscribe((q) => {
      const projectId = Number(q.get('ProjectID') ?? 1);
      const moduleId = Number(q.get('ModuleID') ?? 1);
      this.storyForm.projectId = projectId;
      this.storyForm.moduleId = moduleId;
      this.taskForm.projectId = projectId;
      this.taskForm.moduleId = moduleId;

      this.loadStoryLookups();
      this.loadTaskLookups();
      this.loadCriteriaLookups();
      this.showStories();
      this.cdr.markForCheck();
    });
  }

  private blankStoryForm(): StoryForm {
    return {
      projectId: 0,
      moduleId: 0,
      productBacklogId: 0,
      storyTitle: '',
      asA: '',
      iWishTo: '',
      soThatICan: '',
      complexityId: 0,
      priorityId: 0,
      effortSizeId: 0,
      manDays: 0,
      manHours: 0,
      startDate: '',
      endDate: '',
      developerId: 0,
      testerId: 0,
      comments: ''
    };
  }

  private blankTaskForm(): StoryTaskForm {
    return { projectId: this.storyForm.projectId, moduleId: this.storyForm.moduleId, storyId: 0, taskDetails: '', taskHours: 0 };
  }

  private blankCriteriaForm(): AcceptanceCriteriaForm {
    return { projectId: this.storyForm.projectId, storyId: 0, taskId: 0, criteria: '' };
  }

  private loadStoryLookups(): void {
    this.data.getStoryFormLookups(this.storyForm.projectId, this.storyForm.moduleId).subscribe((l) => {
      this.productBacklogs.set(l.productBacklogs);
      this.asAOptions.set(l.asAOptions);
      this.complexities.set(l.complexities);
      this.priorities.set(l.priorities);
      this.effortSizes.set(l.effortSizes);
      this.developers.set(l.developers);
      this.testers.set(l.testers);
    });
  }

  onEffortSizeChange(): void {
    const size = this.effortSizes().find((s) => s.value === this.storyForm.effortSizeId);
    this.storyForm.manHours = size?.hours ?? 0;
    this.storyForm.manDays = size?.days ?? 0;
  }

  showStories(): void {
    this.data.getStoryList(this.storyForm.projectId, this.storyForm.moduleId, this.storyForm.productBacklogId).subscribe((rows) => this.storyRows.set(rows));
  }

  private saveStory(closeAfter: boolean): void {
    if (!this.storyForm.productBacklogId || !this.storyForm.storyTitle.trim() || !this.storyForm.asA || !this.storyForm.iWishTo.trim() || !this.storyForm.soThatICan.trim()) {
      alert('* Fields are compulsory');
      return;
    }
    if (!this.storyForm.complexityId || !this.storyForm.priorityId || !this.storyForm.effortSizeId || !this.storyForm.developerId || !this.storyForm.testerId) {
      alert('* Fields are compulsory');
      return;
    }
    this.savingStory.set(true);
    this.storyForm.startDate = (this.startDate ?? new Date()).toISOString();
    this.storyForm.endDate = (this.endDate ?? new Date()).toISOString();
    this.data.addStory(this.storyForm).subscribe((res) => {
      this.savingStory.set(false);
      if (res.resultCode !== 100) {
        alert('Failed to save story !');
        return;
      }
      alert(res.resultMsg);
      this.showStories();
      if (closeAfter) {
        this.storyForm = { ...this.blankStoryForm(), projectId: this.storyForm.projectId, moduleId: this.storyForm.moduleId };
        this.activeTab = 'task';
      } else {
        this.storyForm.storyTitle = '';
        this.storyForm.iWishTo = '';
        this.storyForm.soThatICan = '';
        this.storyForm.comments = '';
      }
      this.cdr.markForCheck();
    });
  }

  saveStoryAndStay(): void {
    this.saveStory(false);
  }

  saveStory2(): void {
    this.saveStory(true);
  }

  cancelStory(): void {
    this.storyForm = { ...this.blankStoryForm(), projectId: this.storyForm.projectId, moduleId: this.storyForm.moduleId };
  }

  saveStoryRow(row: StoryRow): void {
    this.data.updateStoryRow(row).subscribe(() => {
      alert('Story updated successfully.');
      this.showStories();
    });
  }

  private loadTaskLookups(): void {
    this.data.getTaskFormLookups(this.taskForm.projectId, this.taskForm.moduleId).subscribe((l) => this.storyFeatures.set(l.storyFeatures));
  }

  onStoryFeatureChange(): void {
    if (!this.taskForm.storyId) {
      return;
    }
    this.data.getStoryHours(this.taskForm.storyId).subscribe((h) => {
      this.storyAssignedHours.set(h.assignedHours);
      this.storyRemainingHours.set(h.remainingHours);
    });
    this.loadTasksForStory();
  }

  private loadTasksForStory(): void {
    this.data.getTasksForStory(this.taskForm.storyId).subscribe((rows) => this.taskRows.set(rows));
  }

  private saveTask(closeAfter: boolean): void {
    if (!this.taskForm.storyId || !this.taskForm.taskDetails.trim() || !this.taskForm.taskHours) {
      alert('* Fields are compulsory');
      return;
    }
    this.savingTask.set(true);
    this.data.addStoryTask(this.taskForm).subscribe((res) => {
      this.savingTask.set(false);
      if (res.resultCode !== 100) {
        alert('Failed to save task !');
        return;
      }
      alert(res.resultMsg);
      this.loadTasksForStory();
      if (closeAfter) {
        this.taskForm = { ...this.blankTaskForm() };
        this.activeTab = 'criteria';
      } else {
        this.taskForm.taskDetails = '';
        this.taskForm.taskHours = 0;
      }
      this.cdr.markForCheck();
    });
  }

  saveTaskAndStay(): void {
    this.saveTask(false);
  }

  saveTask2(): void {
    this.saveTask(true);
  }

  private loadCriteriaLookups(): void {
    this.data.getAcceptanceCriteriaFormLookups(this.criteriaForm.projectId).subscribe((l) => {
      this.acStoryFeatures.set(l.storyFeatures);
      this.acTasks.set(l.tasks);
    });
  }

  onCriteriaStoryChange(): void {
    this.data.getAcceptanceCriteriaList(this.criteriaForm.projectId, this.criteriaForm.storyId).subscribe((rows) => this.criteriaRows.set(rows));
  }

  private saveCriteria(closeAfter: boolean): void {
    if (!this.criteriaForm.storyId || !this.criteriaForm.taskId || !this.criteriaForm.criteria.trim()) {
      alert('* Fields are compulsory');
      return;
    }
    this.savingCriteria.set(true);
    this.data.addAcceptanceCriteria(this.criteriaForm).subscribe((res) => {
      this.savingCriteria.set(false);
      alert(res.resultMsg);
      this.onCriteriaStoryChange();
      if (!closeAfter) {
        this.criteriaForm.criteria = '';
      }
      this.cdr.markForCheck();
    });
  }

  saveCriteriaAndStay(): void {
    this.saveCriteria(false);
  }

  saveCriteria2(): void {
    this.saveCriteria(true);
  }
}
