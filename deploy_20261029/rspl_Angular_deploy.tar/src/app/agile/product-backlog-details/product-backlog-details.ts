import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { AgileDataService, LookupOption, ProductBacklogForm, ProductBacklogRow } from '../agile-data.service';

/**
 * Mirrors Agile_project_Manegment/ProductBacklogDetails.aspx ("Product
 * Backlog"): a create-form + filterable/inline-editable backlog grid. The
 * source's right-click context menu (Add Story / Add Task / Add Acceptance
 * Criteria) is replaced with visible per-row action links; the file
 * attachment upload is a stubbed input (no backend to upload to in this
 * frontend-only phase).
 */
@Component({
  selector: 'app-product-backlog-details',
  imports: [FormsModule, ButtonModule, InputTextModule, SelectModule, TableModule, TextareaModule],
  templateUrl: './product-backlog-details.html',
  styleUrl: './product-backlog-details.scss'
})
export class ProductBacklogDetails implements OnInit {
  private readonly data = inject(AgileDataService);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  // No zone.js — `form.projectId` (plain) mutated inside subscribe needs an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly projects = signal<LookupOption[]>([]);
  readonly modules = signal<LookupOption[]>([]);
  readonly sizes = signal<{ label: string; value: number; hours: number }[]>([]);
  readonly priorities = signal<LookupOption[]>([]);
  readonly complexities = signal<LookupOption[]>([]);
  readonly developers = signal<LookupOption[]>([]);
  readonly testers = signal<LookupOption[]>([]);
  readonly rows = signal<ProductBacklogRow[]>([]);
  readonly saving = signal(false);
  readonly showCreate = signal(false);

  filterModuleId = 0;
  form: ProductBacklogForm = this.blankForm();

  ngOnInit(): void {
    this.data.getAgileProjects().subscribe((projects) => {
      this.projects.set(projects);
      this.form.projectId = projects[0]?.value ?? 0;
      this.onProjectChange();
      this.cdr.markForCheck();
    });

    this.route.queryParamMap.subscribe((q) => {
      this.showCreate.set(q.get('ContextMenu') === '1');
    });
  }

  private blankForm(): ProductBacklogForm {
    return {
      projectId: 0,
      moduleId: 0,
      description: '',
      priorityId: 0,
      complexityId: 0,
      effortSizeId: 0,
      manHours: 0,
      developerId: 0,
      testerId: 0,
      comments: ''
    };
  }

  onProjectChange(): void {
    if (!this.form.projectId) {
      return;
    }
    this.data.getProductBacklogFormLookups(this.form.projectId).subscribe((l) => {
      this.modules.set(l.modules);
      this.sizes.set(l.sizes);
      this.priorities.set(l.priorities);
      this.complexities.set(l.complexities);
      this.developers.set(l.developers);
      this.testers.set(l.testers);
    });
    this.show();
  }

  onSizeChange(): void {
    this.form.manHours = this.sizes().find((s) => s.value === this.form.effortSizeId)?.hours ?? 0;
  }

  show(): void {
    this.data.getProductBacklogList(this.form.projectId, this.filterModuleId).subscribe((rows) => this.rows.set(rows));
  }

  toggleCreate(): void {
    this.showCreate.set(!this.showCreate());
  }

  private save(closeAfter: boolean): void {
    if (!this.form.moduleId || !this.form.description.trim() || !this.form.priorityId || !this.form.complexityId || !this.form.effortSizeId || !this.form.developerId || !this.form.testerId) {
      alert('* Fields are compulsory');
      return;
    }
    this.saving.set(true);
    this.data.addProductBacklog(this.form).subscribe((res) => {
      this.saving.set(false);
      alert(res.message);
      if (closeAfter) {
        this.showCreate.set(false);
      } else {
        this.form.description = '';
        this.form.comments = '';
      }
      this.show();
      this.cdr.markForCheck();
    });
  }

  saveAndStay(): void {
    this.save(false);
  }

  save2(): void {
    this.save(true);
  }

  cancel(): void {
    this.form = { ...this.blankForm(), projectId: this.form.projectId };
    this.showCreate.set(false);
  }

  saveRow(row: ProductBacklogRow): void {
    this.data.updateProductBacklogRow(row).subscribe(() => {
      alert('Product backlog updated successfully.');
      this.show();
    });
  }

  addStory(row: ProductBacklogRow): void {
    this.router.navigate(['/agile/story-master'], { queryParams: { ProjectID: row.projectId, ModuleID: row.moduleId, ProductBacklogID: row.productBacklogId } });
  }

  addTask(row: ProductBacklogRow): void {
    this.router.navigate(['/agile/add-task'], { queryParams: { ProjectID: row.projectId, ModuleID: row.moduleId } });
  }

  viewAttachments(row: ProductBacklogRow): void {
    this.router.navigate(['/agile/view-attachments'], { queryParams: { ProjectID: row.projectId, ProjectBackLoID: row.productBacklogId } });
  }
}
