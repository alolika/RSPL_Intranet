import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { AgileDataService, LookupOption, ModuleRow } from '../agile-data.service';

/** Mirrors Agile_project_Manegment/ModuleMaster.aspx: project-scoped add-form + inline-editable module grid. */
@Component({
  selector: 'app-module-master',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, SelectModule, TableModule],
  templateUrl: './module-master.html',
  styleUrl: './module-master.scss'
})
export class ModuleMaster implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `projectId`/`moduleName`/`description` (plain) mutated
  // inside subscribe callbacks need an explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly projects = signal<LookupOption[]>([]);
  readonly rows = signal<ModuleRow[]>([]);
  readonly saving = signal(false);

  projectId: number | null = null;
  moduleName = '';
  description = '';

  ngOnInit(): void {
    this.data.getAgileProjects().subscribe((projects) => {
      this.projects.set(projects);
      this.projectId = projects[0]?.value ?? null;
      this.load();
      this.cdr.markForCheck();
    });
  }

  onProjectChange(): void {
    this.load();
  }

  private load(): void {
    if (!this.projectId) {
      return;
    }
    this.data.getModules(this.projectId).subscribe((rows) => this.rows.set(rows));
  }

  submit(): void {
    if (!this.projectId) {
      return;
    }
    this.saving.set(true);
    this.data.saveModule({ moduleId: 0, projectId: this.projectId, moduleName: this.moduleName.trim(), description: this.description, enabled: true }).subscribe((res) => {
      this.saving.set(false);
      alert(res.resultMsg);
      if (res.resultCode === 100) {
        this.moduleName = '';
        this.description = '';
      }
      this.load();
      this.cdr.markForCheck();
    });
  }

  saveRow(row: ModuleRow): void {
    this.data.saveModule(row).subscribe((res) => {
      alert(res.resultMsg);
      this.load();
    });
  }
}
