import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { AgileDataService, LookupOption, TestPlanRow } from '../agile-data.service';

/** Mirrors Agile_project_Manegment/TestPlanMaster.aspx ("Test Plan Master"): add-form + inline-editable grid. Effort Size auto-computes from the selected sprint's stories; attachment upload is stubbed (no backend). */
@Component({
  selector: 'app-test-plan-master',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, SelectModule, TableModule, TextareaModule, DatePipe],
  templateUrl: './test-plan-master.html',
  styleUrl: './test-plan-master.scss'
})
export class TestPlanMaster implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `projectId`/`filterProjectId`/`description` (plain)
  // mutated inside subscribe callbacks need an explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly projects = signal<LookupOption[]>([]);
  readonly sprints = signal<LookupOption[]>([]);
  readonly rows = signal<TestPlanRow[]>([]);
  readonly saving = signal(false);

  projectId: number | null = null;
  sprintNo: number | null = null;
  description = '';

  filterProjectId: number | null = null;
  filterSprintNo: number | null = null;

  ngOnInit(): void {
    this.data.getAgileProjects().subscribe((projects) => {
      this.projects.set(projects);
      this.projectId = projects[0]?.value ?? null;
      this.filterProjectId = this.projectId;
      this.onProjectChange();
      this.show();
      this.cdr.markForCheck();
    });
  }

  onProjectChange(): void {
    if (!this.projectId) {
      return;
    }
    this.data.getTestSprints(this.projectId).subscribe((sprints) => this.sprints.set(sprints));
  }

  submit(): void {
    if (!this.projectId || !this.sprintNo || !this.description.trim()) {
      alert('* Fields are compulsory');
      return;
    }
    this.saving.set(true);
    this.data.addTestPlan(this.projectId, this.sprintNo, this.description).subscribe((res) => {
      this.saving.set(false);
      alert(res.resultMsg);
      this.description = '';
      this.show();
      this.cdr.markForCheck();
    });
  }

  cancel(): void {
    this.description = '';
    this.sprintNo = null;
  }

  show(): void {
    if (!this.filterProjectId) {
      return;
    }
    this.data.getTestPlans(this.filterProjectId, this.filterSprintNo ?? 0).subscribe((rows) => this.rows.set(rows));
  }

  saveRow(row: TestPlanRow): void {
    this.data.updateTestPlan(row).subscribe(() => {
      alert('Test plan updated successfully.');
      this.show();
    });
  }
}
