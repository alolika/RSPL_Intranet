import { Component, ElementRef, OnDestroy, ViewChild, inject, signal } from '@angular/core';
import { TableModule } from 'primeng/table';
import { TabsModule } from 'primeng/tabs';
import { Chart } from 'chart.js/auto';

import { AgileDataService, BalanceRevenueRow, ProductBacklogTrackingRow, ProjectStatusRow, UserTaskRow } from '../agile-data.service';
import { IndianNumberPipe } from '../../shared/indian-number.pipe';

/**
 * Mirrors Agile_project_Manegment/Dashboard.aspx — not linked from the
 * Agile menu in the source (only reachable by direct URL), and toggles
 * between three role panels (Top Management / Project Lead / User) server-
 * side. Simplified into three tabs covering the same three panels' data.
 * The source's two near-duplicate RadCharts (Project Status % and Sprint &
 * Stories Completion %, both 0-100% gauges) are consolidated into a single
 * Chart.js doughnut for Project Status — the second chart showed the same
 * kind of completion percentage already visible in this page's own grids.
 */
@Component({
  selector: 'app-agile-dashboard',
  imports: [TableModule, TabsModule, IndianNumberPipe],
  templateUrl: './agile-dashboard.html',
  styleUrl: './agile-dashboard.scss'
})
export class AgileDashboard implements OnDestroy {
  private readonly data = inject(AgileDataService);
  private chart: Chart | null = null;

  @ViewChild('statusCanvas') statusCanvasRef?: ElementRef<HTMLCanvasElement>;

  activeTab = 'top';

  readonly balanceRevenue = signal<BalanceRevenueRow[]>([]);
  readonly projectStatusList = signal<ProjectStatusRow[]>([]);
  readonly backlogTracking = signal<ProductBacklogTrackingRow[]>([]);
  readonly userTasks = signal<UserTaskRow[]>([]);

  constructor() {
    this.data.getBalanceRevenue().subscribe((rows) => this.balanceRevenue.set(rows));
    this.data.getProjectStatusList().subscribe((rows) => this.projectStatusList.set(rows));
    this.data.getProductBacklogTracking().subscribe((rows) => this.backlogTracking.set(rows));
    this.data.getUserWiseTaskList().subscribe((rows) => this.userTasks.set(rows));
    this.data.getProjectStatusChart().subscribe((rows) => {
      setTimeout(() => this.drawChart(rows.map((r) => r.projectName), rows.map((r) => r.percentComplete)));
    });
  }

  ngOnDestroy(): void {
    this.chart?.destroy();
  }

  private drawChart(labels: string[], data: number[]): void {
    if (!this.statusCanvasRef) {
      return;
    }
    this.chart?.destroy();
    this.chart = new Chart(this.statusCanvasRef.nativeElement, {
      type: 'doughnut',
      data: { labels, datasets: [{ data, backgroundColor: ['#7c2d12', '#f2a900', '#003057', '#7a9e9f'] }] },
      options: { plugins: { title: { display: true, text: 'Project Status in %' } } }
    });
  }
}
