import { Component, OnInit, inject, signal } from '@angular/core';
import { TableModule } from 'primeng/table';

import { AgileDataService, DefectReportRow } from '../agile-data.service';

/** Mirrors Agile_project_Manegment/TestingDashboard.aspx ("Tester Dashboard"): the logged-in tester's own raised defects, filterable by column (Severity/Priority/Status). */
@Component({
  selector: 'app-testing-dashboard',
  imports: [TableModule],
  templateUrl: './testing-dashboard.html',
  styleUrl: './testing-dashboard.scss'
})
export class TestingDashboard implements OnInit {
  private readonly data = inject(AgileDataService);

  readonly rows = signal<DefectReportRow[]>([]);

  ngOnInit(): void {
    this.data.getTesterDashboardDefects().subscribe((rows) => this.rows.set(rows));
  }
}
