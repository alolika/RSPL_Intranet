import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { AgileDataService, LookupOption, TestScenarioRow } from '../agile-data.service';

/** Mirrors Agile_project_Manegment/TestScenarioMaster.aspx ("Test Scenario"): cascading Project→Sprint→TestPlan→Module→ProductBacklog→Story add-form + inline-editable grid. */
@Component({
  selector: 'app-test-scenario-master',
  imports: [FormsModule, ButtonModule, InputTextModule, SelectModule, TableModule, TextareaModule],
  templateUrl: './test-scenario-master.html',
  styleUrl: './test-scenario-master.scss'
})
export class TestScenarioMaster implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `projectId`/`filterProjectId`/`description` (plain)
  // mutated inside subscribe callbacks need an explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly projects = signal<LookupOption[]>([]);
  readonly sprints = signal<LookupOption[]>([]);
  readonly testPlans = signal<LookupOption[]>([]);
  readonly modules = signal<LookupOption[]>([]);
  readonly productBacklogs = signal<LookupOption[]>([]);
  readonly stories = signal<LookupOption[]>([]);
  readonly testers = signal<LookupOption[]>([]);
  readonly statuses = signal<LookupOption[]>([]);
  readonly rows = signal<TestScenarioRow[]>([]);
  readonly saving = signal(false);

  projectId: number | null = null;
  sprintNo: number | null = null;
  testPlanId: number | null = null;
  moduleId: number | null = null;
  productBacklogId: number | null = null;
  storyId: number | null = null;
  description = '';
  testerId: number | null = null;
  statusId: number | null = null;

  filterProjectId: number | null = null;

  ngOnInit(): void {
    this.data.getAgileProjects().subscribe((projects) => {
      this.projects.set(projects);
      this.projectId = projects[0]?.value ?? null;
      this.filterProjectId = this.projectId;
      this.onProjectChange();
      this.show();
      this.cdr.markForCheck();
    });
  }

  onProjectChange(): void {
    if (!this.projectId) {
      return;
    }
    this.data.getTestScenarioFormLookups(this.projectId).subscribe((l) => {
      this.sprints.set(l.sprints);
      this.testPlans.set(l.testPlans);
      this.modules.set(l.modules);
      this.productBacklogs.set(l.productBacklogs);
      this.stories.set(l.stories);
      this.testers.set(l.testers);
      this.statuses.set(l.statuses);
    });
  }

  submit(): void {
    if (!this.projectId || !this.sprintNo || !this.storyId || !this.description.trim()) {
      alert('* Fields are compulsory');
      return;
    }
    this.saving.set(true);
    this.data
      .addTestScenario(this.projectId, this.sprintNo, this.testPlanId ?? 0, this.storyId, this.productBacklogId ?? 0, this.description, false)
      .subscribe((res) => {
      this.saving.set(false);
      alert(res.resultMsg);
      this.description = '';
      this.show();
      this.cdr.markForCheck();
    });
  }

  cancel(): void {
    this.description = '';
  }

  show(): void {
    if (!this.filterProjectId) {
      return;
    }
    this.data.getTestScenarios(this.filterProjectId).subscribe((rows) => this.rows.set(rows));
  }

  saveRow(row: TestScenarioRow): void {
    this.data.updateTestScenario(row, this.filterProjectId ?? 0).subscribe(() => {
      alert('Test scenario updated successfully.');
      this.show();
    });
  }
}
