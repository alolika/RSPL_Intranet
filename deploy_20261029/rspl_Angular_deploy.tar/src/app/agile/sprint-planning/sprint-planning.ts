import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import {
  AgileDataService,
  LookupOption,
  SprintBacklogRow,
  SprintRow,
  SprintStoryRow
} from '../agile-data.service';

/**
 * Mirrors Agile_project_Manegment/Sprint Planning.aspx: Project/Module
 * filters, an Add-Sprint / Delete-Sprint bar, an unassigned Product
 * Backlog grid, and a Sprint Backlog grid expandable to Story→Task/
 * Acceptance-Criteria detail. The source's right-click "move to sprint"
 * context menu is replaced with a visible per-row Sprint select + "Move"
 * action; the 3-level nested Repeater/RadListView story detail is
 * replicated as a 2-level expand (Sprint → Story, with Tasks and
 * Acceptance Criteria shown as two small inline tables per story).
 */
@Component({
  selector: 'app-sprint-planning',
  imports: [FormsModule, ButtonModule, DatePickerModule, SelectModule, TableModule, DatePipe],
  templateUrl: './sprint-planning.html',
  styleUrl: './sprint-planning.scss'
})
export class SprintPlanning implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `projectId` (plain) mutated inside subscribe needs an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly projects = signal<LookupOption[]>([]);
  readonly modules = signal<LookupOption[]>([]);
  readonly sprintOptions = signal<LookupOption[]>([]);
  readonly backlogRows = signal<SprintBacklogRow[]>([]);
  readonly sprints = signal<SprintRow[]>([]);
  readonly expandedSprint = signal<number | null>(null);
  readonly sprintStories = signal<SprintStoryRow[]>([]);
  readonly expandedStory = signal<number | null>(null);
  readonly saving = signal(false);
  readonly totalSprintCount = signal(0);

  projectId: number | null = null;
  moduleId: number | null = null;
  startDate: Date | null = new Date();
  endDate: Date | null = new Date();
  deleteSprintId: number | null = null;
  moveTargetSprint: Record<number, number> = {};

  ngOnInit(): void {
    this.data.getAgileProjects().subscribe((projects) => {
      this.projects.set(projects);
      this.projectId = projects[0]?.value ?? null;
      this.onProjectChange();
      this.cdr.markForCheck();
    });
  }

  onProjectChange(): void {
    if (!this.projectId) {
      return;
    }
    this.data.getSprintPlanningLookups(this.projectId).subscribe((l) => {
      this.modules.set(l.modules);
      this.sprintOptions.set(l.sprints);
    });
    this.loadBacklog();
    this.loadSprints();
  }

  loadBacklog(): void {
    if (!this.projectId) {
      return;
    }
    this.data.getProductBacklogForSprint(this.projectId, this.moduleId ?? 0).subscribe((rows) => this.backlogRows.set(rows));
  }

  private loadSprints(): void {
    if (!this.projectId) {
      return;
    }
    this.data.getSprints(this.projectId).subscribe((rows) => {
      this.sprints.set(rows);
      const total = rows.length;
      this.totalSprintCount.set(total);
    });
  }

  addSprint(): void {
    if (!this.projectId || !this.startDate || !this.endDate) {
      alert('Select start Date');
      return;
    }
    this.saving.set(true);
    this.data.addSprint(this.projectId, this.startDate.toISOString(), this.endDate.toISOString()).subscribe((res) => {
      this.saving.set(false);
      alert(res.resultMsg);
      this.onProjectChange();
    });
  }

  deleteSprint(): void {
    if (!this.projectId || !this.deleteSprintId) {
      return;
    }
    this.data.deleteSprint(this.projectId, this.deleteSprintId).subscribe((res) => {
      alert(res.resultMsg);
      this.onProjectChange();
    });
  }

  moveToSprint(row: SprintBacklogRow): void {
    const sprintId = this.moveTargetSprint[row.productBacklogId];
    if (!this.projectId || !sprintId) {
      return;
    }
    this.data.moveBacklogToSprint(this.projectId, row.productBacklogId, sprintId).subscribe((res) => {
      alert(res.resultMsg);
      this.loadBacklog();
      this.loadSprints();
    });
  }

  toggleSprint(sprint: SprintRow): void {
    if (this.expandedSprint() === sprint.sprintNo) {
      this.expandedSprint.set(null);
      return;
    }
    this.expandedSprint.set(sprint.sprintNo);
    this.expandedStory.set(null);
    if (!this.projectId) {
      return;
    }
    this.data.getSprintStories(this.projectId, sprint.sprintNo).subscribe((rows) => this.sprintStories.set(rows));
  }

  toggleStory(story: SprintStoryRow): void {
    this.expandedStory.set(this.expandedStory() === story.storyId ? null : story.storyId);
  }
}
