import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { MultiSelectModule } from 'primeng/multiselect';
import { RadioButtonModule } from 'primeng/radiobutton';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { AgileDataService, BranchWiseTaskRow, LookupOption } from '../agile-data.service';

const CORE_SKILLS = ['Asp.net', 'Vb.net', 'Php', 'IPhone', 'Android', 'Java', 'Vb6'];

/**
 * Mirrors Agile_project_Manegment/BrachWiseUserTask.aspx ("Branch wise user
 * task list"): a Branch-filtered task grid with per-row Internal/External
 * radio and Core Skill selection. The source's Core Skill selection was a
 * separate RadWindow popup with a checkbox list — replaced with an inline
 * PrimeNG MultiSelect per row (same multi-pick capability).
 */
@Component({
  selector: 'app-branch-wise-user-task',
  imports: [FormsModule, ButtonModule, MultiSelectModule, RadioButtonModule, SelectModule, TableModule, DatePipe],
  templateUrl: './branch-wise-user-task.html',
  styleUrl: './branch-wise-user-task.scss'
})
export class BranchWiseUserTask implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `branchId` (plain) mutated inside subscribe needs an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly branches = signal<LookupOption[]>([]);
  readonly rows = signal<BranchWiseTaskRow[]>([]);
  readonly coreSkillOptions = CORE_SKILLS.map((s) => ({ label: s, value: s }));

  branchId: number | null = null;

  ngOnInit(): void {
    this.data.getBranches().subscribe((branches) => {
      this.branches.set(branches);
      this.branchId = branches[0]?.value ?? null;
      this.show();
      this.cdr.markForCheck();
    });
  }

  show(): void {
    if (!this.branchId) {
      return;
    }
    this.data.getBranchWiseTasks(this.branchId).subscribe((rows) => this.rows.set(rows));
  }

  onTypeChange(row: BranchWiseTaskRow): void {
    this.data.updateBranchTaskType(row.userId, row.productBacklogId, row.internalExternal as 'Internal' | 'External').subscribe();
  }

  onCoreSkillsChange(row: BranchWiseTaskRow): void {
    this.data.updateBranchTaskCoreSkills(row.userId, row.productBacklogId, row.coreSkills).subscribe();
  }
}
