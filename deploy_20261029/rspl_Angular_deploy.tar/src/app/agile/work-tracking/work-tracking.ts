import { DatePipe, DecimalPipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { AgileDataService, LookupOption, WorkTrackingRow } from '../agile-data.service';

const VIEW_TYPES = [{ label: 'Task Wise', value: 'TaskWise' }, { label: 'Action Wise', value: 'ActionWise' }];

/**
 * Mirrors Agile_project_Manegment/WorkTracking.aspx ("Task Tracking" work
 * report): View-Type/Project/Module/Developer/Status/Date-range filters
 * over the same task grid shape as TaskTracking, plus an Action Description
 * column and "View Action" link (opens AddAction.aspx?...&IsView=1).
 */
@Component({
  selector: 'app-work-tracking',
  imports: [FormsModule, ButtonModule, DatePickerModule, SelectModule, TableModule, DatePipe, DecimalPipe],
  templateUrl: './work-tracking.html',
  styleUrl: './work-tracking.scss'
})
export class WorkTracking implements OnInit {
  private readonly data = inject(AgileDataService);
  private readonly router = inject(Router);
  // No zone.js — `projectId` (plain) mutated inside subscribe needs an
  // explicit markForCheck(). (`viewType`/`fromDate`/`toDate` are only ever
  // mutated synchronously in clear(), called directly from a template
  // event, so they don't need it.)
  private readonly cdr = inject(ChangeDetectorRef);

  readonly viewTypes = VIEW_TYPES;
  readonly projects = signal<LookupOption[]>([]);
  readonly rows = signal<WorkTrackingRow[]>([]);
  readonly loading = signal(false);

  viewType = 'TaskWise';
  projectId: number | null = null;
  fromDate: Date | null = null;
  toDate: Date | null = null;

  ngOnInit(): void {
    this.data.getAgileProjects().subscribe((projects) => {
      this.projects.set(projects);
      this.projectId = projects[0]?.value ?? null;
      this.cdr.markForCheck();
    });
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.data.getWorkTracking().subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }

  clear(): void {
    this.viewType = 'TaskWise';
    this.fromDate = null;
    this.toDate = null;
  }

  viewAction(row: WorkTrackingRow): void {
    this.router.navigate(['/agile/add-action'], { queryParams: { ProjectID: row.projectId, ModuleID: row.moduleId, TaskID: row.taskId, IsView: 1 } });
  }
}
