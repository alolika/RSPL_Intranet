import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';

import { AgileDataService, LookupOption } from '../agile-data.service';

/** Mirrors Agile_project_Manegment/Commendations.aspx ("Commendations" / "Recommendations", driven by ?ID=1|2): a To/Reason/Description appreciation form. */
@Component({
  selector: 'app-commendations',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, SelectModule, TextareaModule],
  templateUrl: './commendations.html',
  styleUrl: './commendations.scss'
})
export class Commendations implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly data = inject(AgileDataService);
  // No zone.js — `isCommendation`/`reason`/`description` (plain) mutated
  // inside subscribe callbacks need an explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly users = signal<LookupOption[]>([]);
  readonly saving = signal(false);

  isCommendation = true;
  toUserId = 0;
  reason = '';
  description = '';
  keepConfidential = true;

  ngOnInit(): void {
    this.data.getCommendationUsers().subscribe((users) => this.users.set(users));

    // Commendation and Recommendation both route to this same component
    // (only ?ID differs) — subscribe rather than reading a one-time
    // snapshot so switching between them while mounted actually updates.
    this.route.queryParamMap.subscribe((q) => {
      this.isCommendation = q.get('ID') !== '2';
      this.cdr.markForCheck();
    });
  }

  submit(): void {
    this.saving.set(true);
    this.data.addAppreciation(this.toUserId, this.reason, this.description, this.isCommendation, this.keepConfidential).subscribe(() => {
      this.saving.set(false);
      alert('Record added Sucessfully! ');
      this.reason = '';
      this.description = '';
      this.cdr.markForCheck();
    });
  }
}
