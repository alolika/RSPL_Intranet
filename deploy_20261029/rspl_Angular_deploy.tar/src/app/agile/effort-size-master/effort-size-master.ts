import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';

import { AgileDataService, EffortSizeRow } from '../agile-data.service';

/** Mirrors Agile_project_Manegment/EffortSizeMasteer.aspx: add-form + inline-editable grid over EffortSizeMaster. */
@Component({
  selector: 'app-effort-size-master',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, TableModule],
  templateUrl: './effort-size-master.html',
  styleUrl: './effort-size-master.scss'
})
export class EffortSizeMaster implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `effortSize`/`hours`/`description` (plain) mutated inside
  // subscribe (via clear()) need an explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly rows = signal<EffortSizeRow[]>([]);
  readonly saving = signal(false);
  readonly enabled = signal(true);

  effortSize = '';
  hours = 1;
  description = '';

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.data.getEffortSizes().subscribe((rows) => this.rows.set(rows));
  }

  submit(): void {
    this.saving.set(true);
    this.data
      .saveEffortSize({ effortSizeId: 0, effortSize: this.effortSize, hours: this.hours, description: this.description, enabled: this.enabled() })
      .subscribe(() => {
        this.saving.set(false);
        alert('Record inserted successfully.');
        this.clear();
        this.load();
        this.cdr.markForCheck();
      });
  }

  private clear(): void {
    this.effortSize = '';
    this.hours = 1;
    this.description = '';
    this.enabled.set(false);
  }

  cancel(): void {
    this.clear();
    this.enabled.set(true);
  }

  saveRow(row: EffortSizeRow): void {
    this.data.saveEffortSize(row).subscribe(() => {
      alert('Record updated successfully.');
      this.load();
    });
  }
}
