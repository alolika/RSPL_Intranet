import { Component, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

/**
 * Mirrors Agile_project_Manegment/ViewAttachments.aspx — the source page is
 * an empty shell with no markup and a Page_Load handler whose entire body
 * is commented out; it was never actually implemented. Replicated as-is: a
 * placeholder noting the source never built this feature, rather than
 * inventing an attachment viewer the app never had.
 */
@Component({
  selector: 'app-view-attachments',
  imports: [],
  templateUrl: './view-attachments.html',
  styleUrl: './view-attachments.scss'
})
export class ViewAttachments {
  private readonly route = inject(ActivatedRoute);

  readonly projectId = this.route.snapshot.queryParamMap.get('ProjectID');
  readonly projectBacklogId = this.route.snapshot.queryParamMap.get('ProjectBackLoID');
}
