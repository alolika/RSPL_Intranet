import { Component } from '@angular/core';

/**
 * Mirrors Agile_project_Manegment/TestManagement_Old.aspx — an empty shell
 * (no markup, no Page_Load) already superseded by TestManagement.aspx in
 * the source. Replicated as a placeholder noting the deprecation.
 */
@Component({
  selector: 'app-test-management-old',
  imports: [],
  templateUrl: './test-management-old.html',
  styleUrl: './test-management-old.scss'
})
export class TestManagementOld {}
