import { DatePipe, DecimalPipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelectModule } from 'primeng/multiselect';
import { TableModule } from 'primeng/table';

import { AgileDataService, AppreciationMessage, LookupOption, TaskTrackingRow } from '../agile-data.service';

/**
 * Mirrors Agile_project_Manegment/TaskTracking.aspx — the Agile module's
 * home page. The source has a second "Lead Dashboard" panel
 * (pnlLeadDashboard) with an extended Project/Module/Developer/Tester
 * filter set and a 3-level nested grid, but it's set Visible="false" in
 * markup and the one code path that would ever flip it to visible is
 * commented out — it's dead/unreachable code in the current app, so it is
 * not replicated here. This page mirrors the Developer/Tester panel, which
 * is what every user actually sees: an appreciation-message feed (the
 * source's scrolling &lt;marquee&gt; replaced with a static list), a task
 * filter bar, and "my tasks" grid with inline work-hours logging.
 */
@Component({
  selector: 'app-task-tracking',
  imports: [FormsModule, ButtonModule, CheckboxModule, InputTextModule, MultiSelectModule, TableModule, DatePipe, DecimalPipe],
  templateUrl: './task-tracking.html',
  styleUrl: './task-tracking.scss'
})
export class TaskTracking implements OnInit {
  private readonly data = inject(AgileDataService);
  private readonly router = inject(Router);
  // No zone.js — `selectedStatusIds` (plain) mutated inside subscribe needs
  // an explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly messages = signal<AppreciationMessage[]>([]);
  readonly statuses = signal<LookupOption[]>([]);
  readonly rows = signal<TaskTrackingRow[]>([]);
  readonly loading = signal(false);

  taskName = '';
  selectedStatusIds: number[] = [];
  showAllRelevantToMe = false;

  ngOnInit(): void {
    this.data.getAppreciationMessages().subscribe((m) => this.messages.set(m));
    this.data.getTaskStatuses().subscribe((s) => {
      this.statuses.set(s);
      this.selectedStatusIds = s.filter((o) => o.label === 'In Progress' || o.label === 'No status').map((o) => o.value);
      this.show();
      this.cdr.markForCheck();
    });
  }

  show(): void {
    this.loading.set(true);
    const statusNames = this.statuses()
      .filter((o) => this.selectedStatusIds.includes(o.value))
      .map((o) => o.label);
    this.data.getMyTasks(statusNames, this.showAllRelevantToMe, this.taskName).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }

  saveWork(row: TaskTrackingRow): void {
    if (row.workHoursToAdd > 10) {
      alert('Work hours can not be more than 10 hours !');
      return;
    }
    this.data.updateTaskWork(row).subscribe((res) => {
      alert(res.resultMsg);
      this.show();
    });
  }

  addTask(): void {
    this.router.navigate(['/agile/add-task']);
  }

  addAction(row: TaskTrackingRow): void {
    this.router.navigate(['/agile/add-action'], { queryParams: { ProjectID: row.projectId, ModuleID: row.moduleId, TaskID: row.taskId, IsView: 0 } });
  }
}
