import { Routes } from '@angular/router';

import { portalAuthGuard } from '../core/auth/portal-auth.guard';

export const agileRoutes: Routes = [
  {
    path: '',
    loadComponent: () => import('./layout/agile-layout').then((m) => m.AgileLayout),
    canActivate: [portalAuthGuard],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'task-tracking' },
      {
        path: 'priority-master',
        loadComponent: () => import('./priority-master/priority-master').then((m) => m.PriorityMaster)
      },
      {
        path: 'complexity-master',
        loadComponent: () => import('./complexity-master/complexity-master').then((m) => m.ComplexityMaster)
      },
      {
        path: 'status-master',
        loadComponent: () => import('./status-master/status-master').then((m) => m.StatusMaster)
      },
      {
        path: 'effort-size-master',
        loadComponent: () => import('./effort-size-master/effort-size-master').then((m) => m.EffortSizeMaster)
      },
      {
        path: 'module-master',
        loadComponent: () => import('./module-master/module-master').then((m) => m.ModuleMaster)
      },
      {
        path: 'rspl-projects',
        loadComponent: () => import('./rspl-projects/rspl-projects').then((m) => m.RsplProjects)
      },
      {
        path: 'task-tracking',
        loadComponent: () => import('./task-tracking/task-tracking').then((m) => m.TaskTracking)
      },
      {
        path: 'add-task',
        loadComponent: () => import('./add-task/add-task').then((m) => m.AddTask)
      },
      {
        path: 'add-action',
        loadComponent: () => import('./add-action/add-action').then((m) => m.AddAction)
      },
      {
        path: 'product-backlog-details',
        loadComponent: () => import('./product-backlog-details/product-backlog-details').then((m) => m.ProductBacklogDetails)
      },
      {
        path: 'story-master',
        loadComponent: () => import('./story-master/story-master').then((m) => m.StoryMaster)
      },
      {
        path: 'assign-team',
        loadComponent: () => import('./assign-team/assign-team').then((m) => m.AssignTeam)
      },
      {
        path: 'view-attachments',
        loadComponent: () => import('./view-attachments/view-attachments').then((m) => m.ViewAttachments)
      },
      {
        path: 'dashboard',
        loadComponent: () => import('./dashboard/agile-dashboard').then((m) => m.AgileDashboard)
      },
      {
        path: 'commendations',
        loadComponent: () => import('./commendations/commendations').then((m) => m.Commendations)
      },
      {
        path: 'appreciation-register',
        loadComponent: () => import('./appreciation-register/appreciation-register').then((m) => m.AppreciationRegister)
      },
      {
        path: 'sprint-planning',
        loadComponent: () => import('./sprint-planning/sprint-planning').then((m) => m.SprintPlanning)
      },
      {
        path: 'measurement-matrix',
        loadComponent: () => import('./measurement-matrix/measurement-matrix').then((m) => m.MeasurementMatrix)
      },
      {
        path: 'branch-wise-user-task',
        loadComponent: () => import('./branch-wise-user-task/branch-wise-user-task').then((m) => m.BranchWiseUserTask)
      },
      {
        path: 'reports',
        loadComponent: () => import('./reports/reports').then((m) => m.Reports)
      },
      {
        path: 'work-tracking',
        loadComponent: () => import('./work-tracking/work-tracking').then((m) => m.WorkTracking)
      },
      {
        path: 'testing-dashboard',
        loadComponent: () => import('./testing-dashboard/testing-dashboard').then((m) => m.TestingDashboard)
      },
      {
        path: 'testing-reports',
        loadComponent: () => import('./testing-reports/testing-reports').then((m) => m.TestingReports)
      },
      {
        path: 'test-management',
        loadComponent: () => import('./test-management/test-management').then((m) => m.TestManagement)
      },
      {
        path: 'testing-report',
        loadComponent: () => import('./testing-report/testing-report').then((m) => m.TestingReport)
      },
      {
        path: 'test-plan-master',
        loadComponent: () => import('./test-plan-master/test-plan-master').then((m) => m.TestPlanMaster)
      },
      {
        path: 'test-scenario-master',
        loadComponent: () => import('./test-scenario-master/test-scenario-master').then((m) => m.TestScenarioMaster)
      },
      {
        path: 'test-case-master',
        loadComponent: () => import('./test-case-master/test-case-master').then((m) => m.TestCaseMaster)
      },
      {
        path: 'test-case-execution-master',
        loadComponent: () => import('./test-case-execution-master/test-case-execution-master').then((m) => m.TestCaseExecutionMaster)
      },
      {
        path: 'test-management-old',
        loadComponent: () => import('./test-management-old/test-management-old').then((m) => m.TestManagementOld)
      }
    ]
  }
];
