import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { AgileDataService, AgileProjectForm, AgileProjectRow, LookupOption } from '../agile-data.service';
import { IndianNumberPipe } from '../../shared/indian-number.pipe';

/**
 * Mirrors Agile_project_Manegment/RSPL_Projects.aspx ("Projects"): a
 * project-creation form + master grid, inline-editable for FundsReceived/
 * WorkDone only (matching the source's read-only bound columns elsewhere).
 * The source's right-click grid context menu ("Add Product Backlog") is
 * replaced with a plain per-row action link, since a hidden context menu
 * has no discoverability advantage over a visible one.
 */
@Component({
  selector: 'app-rspl-projects',
  imports: [FormsModule, ButtonModule, InputTextModule, SelectModule, TableModule, TextareaModule, IndianNumberPipe],
  templateUrl: './rspl-projects.html',
  styleUrl: './rspl-projects.scss'
})
export class RsplProjects implements OnInit {
  private readonly data = inject(AgileDataService);
  private readonly router = inject(Router);
  // No zone.js — `form` (plain) mutated inside subscribe needs an explicit
  // markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly clients = signal<LookupOption[]>([]);
  readonly currencies = signal<LookupOption[]>([]);
  readonly leads = signal<LookupOption[]>([]);
  readonly rows = signal<AgileProjectRow[]>([]);
  readonly saving = signal(false);

  form: AgileProjectForm = this.blankForm();

  ngOnInit(): void {
    this.data.getProjectFormLookups().subscribe((l) => {
      this.clients.set(l.clients);
      this.currencies.set(l.currencies);
      this.leads.set(l.leads);
    });
    this.load();
  }

  private blankForm(): AgileProjectForm {
    return {
      clientId: 0,
      projectName: '',
      description: '',
      remark: '',
      projectValue: 0,
      fundsReceived: 0,
      currencyId: 0,
      spocName: '',
      spocEmail: '',
      spocMobile: '',
      workDone: 0,
      projectLeadId: 0
    };
  }

  private load(): void {
    this.data.getAgileProjectList().subscribe((rows) => this.rows.set(rows));
  }

  submit(): void {
    if (!this.form.projectName.trim()) {
      alert('Please enter project name');
      return;
    }
    if (this.form.projectLeadId === 0) {
      alert('Please select Project Lead');
      return;
    }
    if (this.form.clientId === 0) {
      alert('Please select client name');
      return;
    }
    if (!this.form.spocEmail.trim()) {
      alert('Please Provide (SPOC) Emailid');
      return;
    }
    if (!this.form.spocMobile.trim()) {
      alert('Please Provide(SPOC) Mobile.no');
      return;
    }
    if (this.form.fundsReceived > this.form.projectValue) {
      alert('Recieved funds cannot exceed project value.');
      return;
    }
    this.saving.set(true);
    this.data.addAgileProject(this.form).subscribe((res) => {
      this.saving.set(false);
      alert(res.resultMsg);
      this.form = this.blankForm();
      this.load();
      this.cdr.markForCheck();
    });
  }

  cancel(): void {
    this.form = this.blankForm();
  }

  saveRow(row: AgileProjectRow): void {
    if (row.fundsReceived > row.projectValue) {
      alert('Funds received should be less than or equal to project value');
      this.load();
      return;
    }
    this.data.updateAgileProjectProgress({ projectId: row.projectId, fundsReceived: row.fundsReceived, workDone: row.workDone }).subscribe(() => {
      alert('Information updated successfully');
      this.load();
    });
  }

  addProductBacklog(row: AgileProjectRow): void {
    this.router.navigate(['/agile/product-backlog-details'], { queryParams: { ProjectID: row.projectId } });
  }

  assignTeam(): void {
    this.router.navigate(['/agile/assign-team']);
  }
}
