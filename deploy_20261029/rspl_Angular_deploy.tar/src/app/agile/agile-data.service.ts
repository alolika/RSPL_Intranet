import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';

import { API_BASE_URL } from '../shared/api-config';

const BASE = `${API_BASE_URL}/agile`;

export interface LookupOption {
  label: string;
  value: number;
}

export interface PriorityRow {
  priorityId: number;
  priority: string;
  enabled: boolean;
}

export interface ComplexityRow {
  complexityId: number;
  complexity: string;
  enabled: boolean;
}

export interface StatusRow {
  statusId: number;
  statusName: string;
  color: string;
  enabled: boolean;
}

export interface EffortSizeRow {
  effortSizeId: number;
  effortSize: string;
  hours: number;
  description: string;
  enabled: boolean;
}

export interface AgileProjectRow {
  projectId: number;
  projectName: string;
  clientName: string;
  projectDescription: string;
  remark: string;
  projectValue: number;
  fundsReceived: number;
  percentReceived: number;
  workDone: number;
  leader: string;
  enabled: boolean;
}

export interface AgileProjectForm {
  clientId: number;
  projectName: string;
  description: string;
  remark: string;
  projectValue: number;
  fundsReceived: number;
  currencyId: number;
  spocName: string;
  spocEmail: string;
  spocMobile: string;
  workDone: number;
  projectLeadId: number;
}

export interface AppreciationMessage {
  comment: string;
  toUser: string;
  fromUser: string;
}

export interface TaskTrackingRow {
  projectId: number;
  projectName: string;
  moduleId: number;
  moduleName: string;
  taskId: number;
  task: string;
  statusId: number;
  statusName: string;
  forDate: string;
  assignedBy: string;
  assignedTo: string;
  manHours: number;
  totalWorkedHours: number;
  workComplete: number;
  currentTask: boolean;
  workHoursToAdd: number;
}

export interface ProductBacklogForm {
  projectId: number;
  moduleId: number;
  description: string;
  priorityId: number;
  complexityId: number;
  effortSizeId: number;
  manHours: number;
  developerId: number;
  testerId: number;
  comments: string;
}

export interface ProductBacklogRow {
  projectId: number;
  productBacklogId: number;
  projectName: string;
  moduleId: number;
  moduleName: string;
  description: string;
  complexityId: number;
  complexity: string;
  effortSizeId: number;
  effortSize: string;
  hours: number;
  priorityId: number;
  priority: string;
  developerId: number;
  developer: string;
  testerId: number;
  tester: string;
  statusName: string;
  attachments: string[];
  comments: string;
}

export interface TestPlanRow {
  testPlanId: number;
  projectId: number;
  projectName: string;
  sprintNo: number;
  description: string;
  effortSizeHours: number;
  date: string;
  attachments: string[];
  enabled: boolean;
}

export interface TestScenarioRow {
  testScenarioId: number;
  projectName: string;
  sprintNo: number;
  testPlan: string;
  moduleName: string;
  productBacklog: string;
  story: string;
  scenarioDescription: string;
  tester: string;
  statusName: string;
}

export interface TestCaseRow {
  testCaseId: number;
  projectName: string;
  sprintNo: number;
  testPlan: string;
  testScenario: string;
  caseType: string;
  isPositive: boolean;
  description: string;
}

export interface TestCaseExecutionRow {
  executionId: number;
  projectName: string;
  sprintNo: number;
  testPlan: string;
  testScenario: string;
  testCase: string;
  description: string;
  testData: string;
  expectedResult: string;
  actualResult: string;
  status: 'Pass' | 'Fail' | '';
  defectId: number | null;
}

export interface TestManagementForm {
  projectId: number;
  moduleId: number;
  productBacklogId: number;
  storyId: number;
  testPlanDescription: string;
  caseType: number;
  isPositive: boolean;
  caseDescription: string;
  testData: string;
  expectedResult: string;
  actualResult: string;
}

export interface RaiseDefectForm {
  defectDetails: string;
  stepsToReproduce: string;
  assignToId: number;
  reproductability: boolean;
  suggestionByTester: string;
}

export interface TestingReportRow {
  projectName: string;
  sprintNo: number;
  feature: string;
  caseDescription: string;
  testCaseType: string;
  creationDate: string;
  tester: string;
  statusName: string;
  isPositive: boolean;
}

export interface DefectReportRow {
  projectName: string;
  sprintNo: number;
  feature: string;
  defectDetails: string;
  causeOfDefect: string;
  severity: string;
  priority: string;
  status: string;
  developer: string;
  tester: string;
  creationDate: string;
  reproductability: boolean;
}

export interface WorkTrackingRow {
  projectId: number;
  projectName: string;
  moduleId: number;
  moduleName: string;
  taskId: number;
  task: string;
  actionDescription: string;
  statusName: string;
  date: string;
  assignedBy: string;
  assignedTo: string;
  manHours: number;
  totalWorkedHours: number;
  workComplete: number;
  currentTask: boolean;
}

export interface MeasurementMatrixRow {
  projectId: number;
  projectName: string;
  effortVariance: number;
  scheduleVariance: number;
  deliveryPoint: number;
  productivity: number;
}

export interface ProjectDetailRow {
  name: string;
  taskDescription: string;
  manHours: number;
  totalWorkHours: number;
}

export interface BranchWiseTaskRow {
  userId: number;
  productBacklogId: number;
  developer: string;
  task: string;
  projectName: string;
  priority: string;
  manHours: number;
  status: string;
  startDate: string;
  internalExternal: 'Internal' | 'External' | '';
  coreSkills: string[];
}

export interface SprintBacklogRow {
  projectId: number;
  productBacklogId: number;
  moduleName: string;
  description: string;
  complexity: string;
  effortSize: string;
  manHours: number;
  priority: string;
  developer: string;
  tester: string;
  status: string;
  sprintId: number;
}

export interface SprintRow {
  sprintNo: number;
  startDate: string;
  endDate: string;
  completedPercent: number;
}

export interface SprintStoryTask {
  task: string;
  status: string;
  manHours: number;
  workedHours: number;
  percentComplete: number;
}

export interface SprintStoryCriteria {
  criteria: string;
  verified: boolean;
}

export interface SprintStoryRow {
  storyId: number;
  description: string;
  feature: string;
  effortSize: string;
  manHours: number;
  workedHours: number;
  workComplete: number;
  developer: string;
  tester: string;
  status: string;
  asA: string;
  iWishTo: string;
  soThat: string;
  tasks: SprintStoryTask[];
  criteria: SprintStoryCriteria[];
}

export interface AppreciationRow {
  appreciationId: number;
  fromUser: string;
  toUser: string;
  reason: string;
  description: string;
}

export interface BalanceRevenueRow {
  projectName: string;
  paymentReceived: number;
  workDone: number;
}

export interface ProjectStatusRow {
  projectName: string;
  status: string;
}

export interface ProductBacklogTrackingRow {
  productBacklog: string;
  effortSize: string;
  manHours: number;
  priority: string;
  developer: string;
  status: string;
  workComplete: number;
}

export interface UserTaskRow {
  name: string;
  description: string;
  projectName: string;
  manHours: number;
  priority: string;
  status: string;
}

export interface TeamMember {
  userId: number;
  name: string;
}

export interface StoryForm {
  projectId: number;
  moduleId: number;
  productBacklogId: number;
  storyTitle: string;
  asA: string;
  iWishTo: string;
  soThatICan: string;
  complexityId: number;
  priorityId: number;
  effortSizeId: number;
  manDays: number;
  manHours: number;
  startDate: string;
  endDate: string;
  developerId: number;
  testerId: number;
  comments: string;
}

export interface StoryRow {
  storyId: number;
  projectId: number;
  moduleName: string;
  productBacklogDescription: string;
  feature: string;
  iWishTo: string;
  soThat: string;
  startDate: string;
  endDate: string;
  complexity: string;
  priority: string;
  statusName: string;
  effortSize: string;
  manHours: number;
  manDays: number;
  developer: string;
  tester: string;
  comments: string;
}

export interface StoryTaskForm {
  projectId: number;
  moduleId: number;
  storyId: number;
  taskDetails: string;
  taskHours: number;
}

export interface StoryTaskRow {
  taskId: number;
  task: string;
  statusName: string;
  hours: number;
}

export interface AcceptanceCriteriaForm {
  projectId: number;
  storyId: number;
  taskId: number;
  criteria: string;
}

export interface AcceptanceCriteriaRow {
  criteriaId: number;
  storyFeature: string;
  task: string;
  criteria: string;
}

export interface AddTaskForm {
  projectId: number;
  moduleId: number;
  taskDetails: string;
  taskHours: string;
  taskTypeId: number;
  assignedTo: number;
  assignedBy: number;
  statusId: number;
  forDate: string;
  isCurrentTask: boolean;
}

export interface TaskDetail {
  task: string;
  currentTask: boolean;
  workComplete: number;
  manHours: number;
  taskTypeId: number;
  statusId: number;
}

export interface ActionHistoryRow {
  actionId: number;
  actionDescription: string;
  taskType: string;
  userName: string;
  assignedBy: string;
  assignedTo: string;
  totalWorkedHours: number;
  date: string;
}

export interface AddActionForm {
  action: string;
  workedHoursType: 'Minute' | 'Hours' | 'Day';
  workedHours: number;
  forDate: string;
  percentComplete: number;
  taskTypeId: number;
  assignedBy: number;
  assignedTo: number;
  statusId: number;
  isCurrentTask: boolean;
}

export interface ModuleRow {
  moduleId: number;
  projectId: number;
  moduleName: string;
  description: string;
  enabled: boolean;
}

function toCamel(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map(toCamel);
  }
  if (value !== null && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const key of Object.keys(value as Record<string, unknown>)) {
      const camel = key.replace(/_([a-z])/g, (_, c: string) => c.toUpperCase());
      out[camel] = toCamel((value as Record<string, unknown>)[key]);
    }
    return out;
  }
  return value;
}

/** Recursively converts a snake_case API payload (including nested objects/arrays) to camelCase. */
function snakeRow<T>(r: Record<string, unknown>): T {
  return toCamel(r) as T;
}

/**
 * Mirrors Agile_project_Manegment's simple master pages (PriorityMaster,
 * ComplexityMaster, StatusMaster, EffortSizeMasteer, ModuleMaster): each is
 * an add-form + inline-editable grid over its own lookup table
 * (PriorityMaster/ComplexityMaster/StatusMaster/EffortSizeMaster/
 * Agile_ModuleMaster), all guarded in the source by Session("UserID").
 *
 * This module has by far the widest set of missing backend infrastructure
 * of any section migrated so far — confirmed live, ~15 stored procs the
 * source calls (Proc_UpdateTaskWork, Proc_GetActionDetail,
 * Proc_CheckUserType, Proc_GetTaskTrackingDetail, Add_AppreciationMaster,
 * and all the Test-Management "Get*Details" procs) don't exist on this
 * database, and two tables it depends on (Rspl_AppreciationMaster,
 * Agile_Sprints) don't exist at all. See rspl_Api's agile_*.py router
 * docstrings for the full breakdown of what was substituted with direct
 * SQL against the real tables versus genuinely left non-functional
 * (the appreciation/commendation feed, and per-entry task action history).
 */
@Injectable({ providedIn: 'root' })
export class AgileDataService {
  private readonly http = inject(HttpClient);

  getAgileProjects(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/projects`);
  }

  /** Mirrors TaskTracking.aspx.vb's Page_Load (Rspl_AppreciationMaster feed, top 10). Rspl_AppreciationMaster doesn't exist on this database — always empty. */
  getAppreciationMessages(): Observable<AppreciationMessage[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/appreciation-feed`)
      .pipe(map((rows) => rows.map((r) => snakeRow<AppreciationMessage>(r))));
  }

  getTaskStatuses(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/task-statuses`);
  }

  /** Mirrors TaskTracking.aspx.vb's FillDeveloperTestergv (EXEC Proc_GetTasksDetails). Proc's real signature has no status/name/relevant-to-me filters — fetched unfiltered and filtered client-side here to preserve the page's filter bar. */
  getMyTasks(statusNames: string[], showAllRelevant: boolean, taskName: string): Observable<TaskTrackingRow[]> {
    return this.http.get<Record<string, unknown>[]>(`${BASE}/my-tasks`).pipe(
      map((rows) => rows.map((r) => snakeRow<TaskTrackingRow>(r))),
      map((rows) =>
        rows.filter(
          (r) =>
            (statusNames.length === 0 || statusNames.includes(r.statusName)) &&
            (!taskName || r.task.toLowerCase().includes(taskName.toLowerCase()))
        )
      )
    );
  }

  /** Mirrors TaskTracking.aspx.vb's lbtnsave_Click (EXEC Proc_UpdateTaskWork — missing on this database, substituted with a direct Tasks update). Source blocks >10 hours in a single save (enforced client-side). */
  updateTaskWork(row: TaskTrackingRow): Observable<{ resultMsg: string }> {
    return this.http
      .post<{ result_msg: string }>(`${BASE}/tasks/log-work`, {
        project_id: row.projectId,
        task_id: row.taskId,
        worked_hours: row.workHoursToAdd,
        work_percent: 0,
        current_task: row.currentTask,
        for_date: new Date().toISOString().slice(0, 10)
      })
      .pipe(map((r) => ({ resultMsg: r.result_msg })));
  }

  /** Mirrors TestPlanMaster.aspx.vb's Page_Load dropdown fills (sprints per project). */
  getTestSprints(projectId: number): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/test-sprints`, { params: { project_id: projectId } });
  }

  /** Mirrors TestPlanMaster.aspx.vb's btnSubmit_OnClick (EXEC Proc_insertUpdateTestPlanMaster). */
  addTestPlan(projectId: number, sprintNo: number, description: string): Observable<{ resultCode: number; resultMsg: string }> {
    return this.http
      .post<{ result_code: number; result_msg: string }>(`${BASE}/test-plans`, null, {
        params: { project_id: projectId, sprint_no: sprintNo, description }
      })
      .pipe(map((r) => ({ resultCode: r.result_code, resultMsg: r.result_msg })));
  }

  getTestPlans(projectId: number, sprintNo: number): Observable<TestPlanRow[]> {
    const params: Record<string, number> = { project_id: projectId };
    if (sprintNo) {
      params['sprint_no'] = sprintNo;
    }
    return this.http.get<Record<string, unknown>[]>(`${BASE}/test-plans`, { params }).pipe(map((rows) => rows.map((r) => snakeRow<TestPlanRow>(r))));
  }

  updateTestPlan(row: TestPlanRow): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${BASE}/test-plans/${row.testPlanId}`, {
      test_plan_id: row.testPlanId,
      project_id: row.projectId,
      project_name: row.projectName,
      sprint_no: row.sprintNo,
      description: row.description,
      effort_size_hours: row.effortSizeHours,
      date: row.date,
      attachments: row.attachments,
      enabled: row.enabled
    });
  }

  /** Mirrors TestScenarioMaster.aspx.vb's cascading Project→Sprint→TestPlan→Module→ProductBacklog→Story dropdown fills. */
  getTestScenarioFormLookups(projectId: number): Observable<{
    sprints: LookupOption[];
    testPlans: LookupOption[];
    modules: LookupOption[];
    productBacklogs: LookupOption[];
    stories: LookupOption[];
    testers: LookupOption[];
    statuses: LookupOption[];
  }> {
    return this.http.get<{
      sprints: LookupOption[];
      testPlans: LookupOption[];
      modules: LookupOption[];
      productBacklogs: LookupOption[];
      stories: LookupOption[];
      testers: LookupOption[];
      statuses: LookupOption[];
    }>(`${BASE}/test-scenario-form-lookups`, { params: { project_id: projectId } });
  }

  addTestScenario(
    projectId: number,
    sprintNo: number,
    testPlanId: number,
    storyId: number,
    productBacklogId: number,
    description: string,
    isPositive: boolean
  ): Observable<{ resultCode: number; resultMsg: string }> {
    return this.http
      .post<{ result_code: number; result_msg: string }>(`${BASE}/test-scenarios`, null, {
        params: {
          project_id: projectId,
          sprint_no: sprintNo,
          test_plan_id: testPlanId,
          story_id: storyId,
          product_backlog_id: productBacklogId,
          description,
          is_positive: isPositive
        }
      })
      .pipe(map((r) => ({ resultCode: r.result_code, resultMsg: r.result_msg })));
  }

  getTestScenarios(projectId: number): Observable<TestScenarioRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/test-scenarios`, { params: { project_id: projectId } })
      .pipe(map((rows) => rows.map((r) => snakeRow<TestScenarioRow>(r))));
  }

  updateTestScenario(row: TestScenarioRow, projectId: number, testerId = 0): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(
      `${BASE}/test-scenarios/${row.testScenarioId}`,
      {
        test_scenario_id: row.testScenarioId,
        project_name: row.projectName,
        sprint_no: row.sprintNo,
        test_plan: row.testPlan,
        module_name: row.moduleName,
        product_backlog: row.productBacklog,
        story: row.story,
        scenario_description: row.scenarioDescription,
        tester: row.tester,
        status_name: row.statusName
      },
      { params: { project_id: projectId, tester_id: testerId } }
    );
  }

  /** Mirrors TestCaseMaster.aspx.vb's cascading dropdown fills (Project→Sprint→TestPlan→TestScenario). */
  getTestCaseFormLookups(projectId: number): Observable<{ sprints: LookupOption[]; testPlans: LookupOption[]; testScenarios: LookupOption[] }> {
    return this.http.get<{ sprints: LookupOption[]; testPlans: LookupOption[]; testScenarios: LookupOption[] }>(`${BASE}/test-case-form-lookups`, {
      params: { project_id: projectId }
    });
  }

  addTestCase(
    projectId: number,
    sprintNo: number,
    testPlanId: number,
    testScenarioId: number,
    description: string,
    isPositive: boolean,
    caseType: string
  ): Observable<{ resultCode: number; resultMsg: string }> {
    return this.http
      .post<{ result_code: number; result_msg: string }>(`${BASE}/test-cases`, null, {
        params: {
          project_id: projectId,
          sprint_no: sprintNo,
          test_plan_id: testPlanId,
          test_scenario_id: testScenarioId,
          description,
          is_positive: isPositive,
          case_type: caseType
        }
      })
      .pipe(map((r) => ({ resultCode: r.result_code, resultMsg: r.result_msg })));
  }

  getTestCases(projectId: number): Observable<TestCaseRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/test-cases`, { params: { project_id: projectId } })
      .pipe(map((rows) => rows.map((r) => snakeRow<TestCaseRow>(r))));
  }

  /** Mirrors TestCaseExecutionMaster.aspx.vb's cascading dropdown fills (Project→Sprint→TestPlan→TestScenario→TestCase). */
  getTestCaseExecutionFormLookups(
    projectId: number
  ): Observable<{ sprints: LookupOption[]; testPlans: LookupOption[]; testScenarios: LookupOption[]; testCases: LookupOption[] }> {
    return this.http.get<{ sprints: LookupOption[]; testPlans: LookupOption[]; testScenarios: LookupOption[]; testCases: LookupOption[] }>(
      `${BASE}/test-case-execution-form-lookups`,
      { params: { project_id: projectId } }
    );
  }

  addTestCaseExecution(
    projectId: number,
    sprintNo: number,
    testPlanId: number,
    testCaseId: number,
    testData: string,
    description: string,
    expectedResult: string,
    actualResult: string,
    passFail: boolean
  ): Observable<{ resultCode: number; resultMsg: string }> {
    return this.http
      .post<{ execution_id: number; result_msg: string }>(`${BASE}/test-case-executions`, null, {
        params: {
          project_id: projectId,
          sprint_no: sprintNo,
          test_plan_id: testPlanId,
          test_case_id: testCaseId,
          test_data: testData,
          description,
          expected_result: expectedResult,
          actual_result: actualResult,
          pass_fail: passFail
        }
      })
      .pipe(map((r) => ({ resultCode: 100, resultMsg: r.result_msg })));
  }

  getTestCaseExecutions(projectId: number): Observable<TestCaseExecutionRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/test-case-executions`, { params: { project_id: projectId } })
      .pipe(map((rows) => rows.map((r) => snakeRow<TestCaseExecutionRow>(r))));
  }

  /** Mirrors TestCaseExecutionMaster.aspx.vb's lbtnraiserror_Click (Raise Defect confirm + insert into defect table). */
  raiseDefect(executionId: number, projectId = 0): Observable<{ defectId: number; resultMsg: string }> {
    return this.http
      .post<{ defect_id: number; result_msg: string }>(`${BASE}/test-case-executions/${executionId}/raise-defect`, null, {
        params: { project_id: projectId }
      })
      .pipe(map((r) => ({ defectId: r.defect_id, resultMsg: r.result_msg })));
  }

  /** Mirrors TestManagement.aspx.vb's combined Add-Testing-Details save (test plan + test case + execution in one form). Simplified to just the test-case-execution write, since the source's chained 3-proc insert isn't reproducible without the missing "Get" procs to look up the intermediate IDs it needs. */
  saveTestManagementDetails(form: TestManagementForm): Observable<{ resultCode: number; resultMsg: string }> {
    return this.addTestCaseExecution(form.projectId, 0, 0, 0, form.testData, form.caseDescription, form.expectedResult, form.actualResult, true);
  }

  /** Mirrors TestManagement.aspx.vb's Raise Defect panel (DefectDetails/StepsToReproduce/AssignTo/Reproductability/Suggestion), guarded by a "Do you want to add defect?" confirm. */
  raiseDefectDetailed(form: RaiseDefectForm, projectId = 0): Observable<{ defectId: number; resultMsg: string }> {
    return this.http
      .post<{ defect_id: number; result_msg: string }>(
        `${BASE}/defects`,
        {
          defect_details: form.defectDetails,
          steps_to_reproduce: form.stepsToReproduce,
          assign_to_id: form.assignToId,
          reproductability: form.reproductability,
          suggestion_by_tester: form.suggestionByTester
        },
        { params: { project_id: projectId } }
      )
      .pipe(map((r) => ({ defectId: r.defect_id, resultMsg: r.result_msg })));
  }

  /** Mirrors TestingDashboard.aspx.vb's Tester Dashboard (own raised defects, filterable by severity/priority/status). */
  getTesterDashboardDefects(): Observable<DefectReportRow[]> {
    return this.getDefectReports(0, 0);
  }

  /** Mirrors TestingReports.aspx.vb's 9-way defect filter (By Project/Developer/Status/Priority/Severity/Date/Cause/Environment/Tester) — consolidated into one grid, report-engine simplification. */
  getTestingReportsDefects(filterType: number): Observable<DefectReportRow[]> {
    return this.getDefectReports(0, filterType);
  }

  /** Mirrors TestingReport.aspx.vb's Project+Tester filtered testing report grid. */
  getTestingReportByTester(projectId: number, testerId: number): Observable<TestingReportRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/testing-report-by-tester`, { params: { project_id: projectId, tester_id: testerId } })
      .pipe(map((rows) => rows.map((r) => snakeRow<TestingReportRow>(r))));
  }

  /** Mirrors TestingReport.aspx.vb's rdbtnSendMail_Click (mock — no mail server wired up in this frontend-only phase). */
  sendTestingReportMail(projectId: number, testerId: number): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/testing-report/send-mail`, null, { params: { project_id: projectId, tester_id: testerId } });
  }

  /** Mirrors Reports.aspx.vb's Testing Reports panel (test execution status / sprint / tester based test case repository — 3 report types share this shape). */
  getTestingReports(projectId: number, reportType: number): Observable<TestingReportRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/testing-reports`, { params: { project_id: projectId, report_type: reportType } })
      .pipe(map((rows) => rows.map((r) => snakeRow<TestingReportRow>(r))));
  }

  /** Mirrors Reports.aspx.vb's Defect Reports panel (6 filter types share this shape). */
  getDefectReports(projectId: number, defectType: number): Observable<DefectReportRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/defect-reports`, { params: { project_id: projectId, defect_type: defectType } })
      .pipe(map((rows) => rows.map((r) => snakeRow<DefectReportRow>(r))));
  }

  /** Mirrors WorkTracking.aspx.vb's rgvWorkTracking fill (Task Wise / Action Wise view, same shape as TaskTracking's grid + ActionDescription). */
  getWorkTracking(projectId = 0): Observable<WorkTrackingRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/work-tracking`, { params: { project_id: projectId } })
      .pipe(map((rows) => rows.map((r) => snakeRow<WorkTrackingRow>(r))));
  }

  /** Mirrors MeasurementMatrix.aspx.vb's report fill (Effort/Schedule Variance, Delivery Point, Productivity per project). */
  getMeasurementMatrix(): Observable<MeasurementMatrixRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/measurement-matrix`)
      .pipe(map((rows) => rows.map((r) => snakeRow<MeasurementMatrixRow>(r))));
  }

  /** Mirrors MeasurementMatrix.aspx.vb's lbtnProjectName_Click detail popup (per-developer task/hours breakdown for a project). */
  getMeasurementMatrixProjectDetail(projectId: number): Observable<ProjectDetailRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/measurement-matrix/${projectId}/detail`)
      .pipe(map((rows) => rows.map((r) => snakeRow<ProjectDetailRow>(r))));
  }

  /** Mirrors BrachWiseUserTask.aspx.vb's Page_Load branch combo fill (source has no dedicated Branch master — sourced from UserMaster.City here, matching the real filter column its grid query actually uses). */
  getBranches(): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/branches`);
  }

  /** Mirrors BrachWiseUserTask.aspx.vb's grid fill, filtered by branch. */
  getBranchWiseTasks(branchId: number, branches: LookupOption[] = []): Observable<BranchWiseTaskRow[]> {
    const city = branches.find((b) => b.value === branchId)?.label ?? '';
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/branch-wise-tasks`, { params: { city } })
      .pipe(map((rows) => rows.map((r) => snakeRow<BranchWiseTaskRow>(r))));
  }

  /** Mirrors BrachWiseUserTask.aspx.vb's rbtnInternal/rbtnExternal_CheckedChanged. */
  updateBranchTaskType(userId: number, productBacklogId: number, internalExternal: 'Internal' | 'External', projectId = 0): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/branch-wise-tasks/${projectId}/${productBacklogId}/type`, { internal_external: internalExternal });
  }

  /** Mirrors BrachWiseUserTask.aspx.vb's btnSubmit_Click (save selected core skills for a row). */
  updateBranchTaskCoreSkills(userId: number, productBacklogId: number, coreSkills: string[], projectId = 0): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/branch-wise-tasks/${projectId}/${productBacklogId}/core-skills`, { core_skills: coreSkills });
  }

  /** Mirrors Sprint Planning.aspx.vb's Page_Load dropdown fills (modules + empty/deletable sprints). */
  getSprintPlanningLookups(projectId: number): Observable<{ modules: LookupOption[]; sprints: LookupOption[] }> {
    return this.http.get<{ modules: LookupOption[]; sprints: LookupOption[] }>(`${BASE}/sprint-planning-lookups`, { params: { project_id: projectId } });
  }

  /** Mirrors Sprint Planning.aspx.vb's btnAdd_Click (EXEC Proc_AddRemoveSprints — missing on this database, substituted with the real AssignSprint.SprintCount counter). */
  addSprint(projectId: number, startDate: string, endDate: string): Observable<{ resultCode: number; resultMsg: string }> {
    return this.http
      .post<{ result_code: number; result_msg: string }>(`${BASE}/sprints`, null, { params: { project_id: projectId, start_date: startDate, end_date: endDate } })
      .pipe(map((r) => ({ resultCode: r.result_code, resultMsg: r.result_msg })));
  }

  /** Mirrors Sprint Planning.aspx.vb's btnDelete_Click (EXEC Proc_AddRemoveSprints, delete mode). */
  deleteSprint(projectId: number, sprintId: number): Observable<{ resultCode: number; resultMsg: string }> {
    return this.http
      .delete<{ result_code: number; result_msg: string }>(`${BASE}/sprints/${projectId}/${sprintId}`)
      .pipe(map((r) => ({ resultCode: r.result_code, resultMsg: r.result_msg })));
  }

  /** Mirrors Sprint Planning.aspx.vb's Fillgv (EXEC Proc_GetSprintDetails, sprintNo='0' = unassigned Product Backlog). */
  getProductBacklogForSprint(projectId: number, moduleId: number): Observable<SprintBacklogRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/product-backlog-for-sprint`, { params: { project_id: projectId, module_id: moduleId } })
      .pipe(map((rows) => rows.map((r) => snakeRow<SprintBacklogRow>(r))));
  }

  /** Mirrors Sprint Planning.aspx.vb's RadMenu1_ItemClick (EXEC InsertSprint) — moves a backlog item into a sprint. Right-click context menu replaced with a visible action. */
  moveBacklogToSprint(projectId: number, productBacklogId: number, sprintId: number): Observable<{ resultCode: number; resultMsg: string }> {
    return this.http
      .post<{ result_code: number; result_msg: string }>(`${BASE}/sprints/${sprintId}/backlog/${productBacklogId}`, null, {
        params: { project_id: projectId }
      })
      .pipe(map((r) => ({ resultCode: r.result_code, resultMsg: r.result_msg })));
  }

  /** Mirrors Sprint Planning.aspx.vb's sprint backlog grid fill (Agile_Sprints, per-sprint completion %). */
  getSprints(projectId: number): Observable<SprintRow[]> {
    return this.http.get<Record<string, unknown>[]>(`${BASE}/sprints`, { params: { project_id: projectId } }).pipe(map((rows) => rows.map((r) => snakeRow<SprintRow>(r))));
  }

  /** Mirrors Sprint Planning.aspx.vb's rgvSprintDetails detail-table bind (Proc_GetSprintDetails, per sprint) with nested Task/Acceptance-Criteria repeaters. */
  getSprintStories(projectId: number, sprintNo: number): Observable<SprintStoryRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/sprints/${projectId}/${sprintNo}/stories`)
      .pipe(map((rows) => rows.map((r) => snakeRow<SprintStoryRow>(r))));
  }

  /** Mirrors Commendations.aspx.vb's Page_Load (userMaster combo, excluding self). */
  getCommendationUsers(currentUserId = 0): Observable<LookupOption[]> {
    return this.http.get<LookupOption[]>(`${BASE}/appreciation-users`, { params: { current_user_id: currentUserId } });
  }

  /** Mirrors Commendations.aspx.vb's btnsubmit_Click (EXEC Add_AppreciationMaster — missing on this database, and so is the Rspl_AppreciationMaster table itself; this is a no-op success). */
  addAppreciation(toUserId: number, reason: string, description: string, isCommendation: boolean, keepConfidential: boolean): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/appreciations`, {
      to_user_id: toUserId,
      reason,
      description,
      is_commendation: isCommendation,
      keep_confidential: keepConfidential
    });
  }

  /** Mirrors AppriciationRegister.aspx.vb's Show button (filtered Appreciation register). Rspl_AppreciationMaster doesn't exist on this database — always empty. */
  getAppreciationRegister(userId: number, isCommendation: boolean): Observable<AppreciationRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/appreciations`, { params: { user_id: userId, is_commendation: isCommendation } })
      .pipe(map((rows) => rows.map((r) => snakeRow<AppreciationRow>(r))));
  }

  /** Mirrors Dashboard.aspx.vb's Top-Management-panel data (project status %, balance revenue, active/inactive projects). Page not linked from the Agile menu in the source. */
  getProjectStatusChart(): Observable<{ projectName: string; percentComplete: number }[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/dashboard/project-status-chart`)
      .pipe(map((rows) => rows.map((r) => snakeRow<{ projectName: string; percentComplete: number }>(r))));
  }

  getBalanceRevenue(): Observable<BalanceRevenueRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/dashboard/balance-revenue`)
      .pipe(map((rows) => rows.map((r) => snakeRow<BalanceRevenueRow>(r))));
  }

  getProjectStatusList(): Observable<ProjectStatusRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/dashboard/project-status-list`)
      .pipe(map((rows) => rows.map((r) => snakeRow<ProjectStatusRow>(r))));
  }

  getProductBacklogTracking(projectId = 0): Observable<ProductBacklogTrackingRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/dashboard/product-backlog-tracking`, { params: { project_id: projectId } })
      .pipe(map((rows) => rows.map((r) => snakeRow<ProductBacklogTrackingRow>(r))));
  }

  getUserWiseTaskList(userId = 0, projectId = 0): Observable<UserTaskRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/dashboard/user-tasks`, { params: { user_id: userId, project_id: projectId } })
      .pipe(map((rows) => rows.map((r) => snakeRow<UserTaskRow>(r))));
  }

  /** Mirrors Assign Team.aspx.vb's FillDeveloperlistbox/FillTesterlistbox (unassigned/assigned per project + team type). */
  getTeamLists(projectId: number, typeId: 1 | 2): Observable<{ unassigned: TeamMember[]; assigned: TeamMember[] }> {
    return this.http
      .get<{ unassigned: Record<string, unknown>[]; assigned: Record<string, unknown>[] }>(`${BASE}/team/${projectId}`, { params: { type_id: typeId } })
      .pipe(
        map((r) => ({
          unassigned: r.unassigned.map((m) => snakeRow<TeamMember>(m)),
          assigned: r.assigned.map((m) => snakeRow<TeamMember>(m))
        }))
      );
  }

  /** Mirrors Assign Team.aspx.vb's AssignUnAssign (EXEC Proc_AssignUnAssignTeam). */
  assignUnassignTeam(projectId: number, userIds: number[], typeId: 1 | 2, add: boolean): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/team/assign`, { project_id: projectId, user_ids: userIds, type_id: typeId, add });
  }

  /** Mirrors StoryMaster.aspx.vb's Story-tab dropdown fills (product backlog features, AsA options, master lookups, team). */
  getStoryFormLookups(projectId: number, moduleId: number): Observable<{
    productBacklogs: LookupOption[];
    asAOptions: LookupOption[];
    complexities: LookupOption[];
    priorities: LookupOption[];
    effortSizes: { label: string; value: number; days: number; hours: number }[];
    developers: LookupOption[];
    testers: LookupOption[];
  }> {
    return this.http.get<{
      productBacklogs: LookupOption[];
      asAOptions: LookupOption[];
      complexities: LookupOption[];
      priorities: LookupOption[];
      effortSizes: { label: string; value: number; days: number; hours: number }[];
      developers: LookupOption[];
      testers: LookupOption[];
    }>(`${BASE}/story-form-lookups`, { params: { project_id: projectId, module_id: moduleId } });
  }

  /** Mirrors StoryMaster.aspx.vb's SaveStory (EXEC PROC_StoryMasterInsUpdate). */
  addStory(form: StoryForm): Observable<{ resultCode: number; resultMsg: string; storyId: number }> {
    return this.http
      .post<{ result_code: number; result_msg: string; story_id: number }>(`${BASE}/stories`, {
        project_id: form.projectId,
        module_id: form.moduleId,
        product_backlog_id: form.productBacklogId,
        story_title: form.storyTitle,
        as_a: form.asA,
        i_wish_to: form.iWishTo,
        so_that_i_can: form.soThatICan,
        complexity_id: form.complexityId,
        priority_id: form.priorityId,
        effort_size_id: form.effortSizeId,
        man_days: form.manDays,
        man_hours: form.manHours,
        start_date: form.startDate,
        end_date: form.endDate,
        developer_id: form.developerId,
        tester_id: form.testerId,
        comments: form.comments
      })
      .pipe(map((r) => ({ resultCode: r.result_code, resultMsg: r.result_msg, storyId: r.story_id })));
  }

  /** Mirrors StoryMaster.aspx.vb's fillstoryMastergrid. */
  getStoryList(projectId: number, moduleId: number, productBacklogId: number): Observable<StoryRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/stories`, { params: { project_id: projectId, module_id: moduleId, product_backlog_id: productBacklogId } })
      .pipe(map((rows) => rows.map((r) => snakeRow<StoryRow>(r))));
  }

  /** Mirrors StoryMaster.aspx.vb's RadGridStoryMaster_UpdateCommand (source only allows editing IwishTodesc/Sothatdesc/dates/Comments in place). */
  updateStoryRow(row: StoryRow): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${BASE}/stories/${row.storyId}`, {
      story_id: row.storyId,
      project_id: row.projectId,
      module_name: row.moduleName,
      product_backlog_description: row.productBacklogDescription,
      feature: row.feature,
      i_wish_to: row.iWishTo,
      so_that: row.soThat,
      start_date: row.startDate,
      end_date: row.endDate,
      complexity: row.complexity,
      priority: row.priority,
      status_name: row.statusName,
      effort_size: row.effortSize,
      man_hours: row.manHours,
      man_days: row.manDays,
      developer: row.developer,
      tester: row.tester,
      comments: row.comments
    });
  }

  /** Mirrors StoryMaster.aspx.vb's Task-tab dropdown fill (story features for the selected project/module) and webProc_GetRemainingHrs. */
  getTaskFormLookups(projectId: number, moduleId: number): Observable<{ storyFeatures: LookupOption[] }> {
    return this.http.get<{ storyFeatures: LookupOption[] }>(`${BASE}/task-form-lookups`, { params: { project_id: projectId, module_id: moduleId } });
  }

  getStoryHours(storyId: number, projectId = 0): Observable<{ assignedHours: number; remainingHours: number }> {
    return this.http
      .get<{ assigned_hours: number; remaining_hours: number }>(`${BASE}/story-hours/${projectId}/${storyId}`)
      .pipe(map((r) => ({ assignedHours: r.assigned_hours, remainingHours: r.remaining_hours })));
  }

  /** Mirrors StoryMaster.aspx.vb's SaveTasks (EXEC Proc_InsertUpdateTaskMaster, StoryID set). */
  addStoryTask(form: StoryTaskForm): Observable<{ resultCode: number; resultMsg: string }> {
    return this.http
      .post<{ result_code: number; result_msg: string }>(`${BASE}/story-tasks`, {
        project_id: form.projectId,
        module_id: form.moduleId,
        story_id: form.storyId,
        task_details: form.taskDetails,
        task_hours: form.taskHours
      })
      .pipe(map((r) => ({ resultCode: r.result_code, resultMsg: r.result_msg })));
  }

  getTasksForStory(storyId: number): Observable<StoryTaskRow[]> {
    return this.http.get<Record<string, unknown>[]>(`${BASE}/story-tasks/${storyId}`).pipe(map((rows) => rows.map((r) => snakeRow<StoryTaskRow>(r))));
  }

  /** Mirrors StoryMaster.aspx.vb's Acceptance-Criteria-tab dropdown fill (story features + tasks). */
  getAcceptanceCriteriaFormLookups(projectId: number, moduleId = 0): Observable<{ storyFeatures: LookupOption[]; tasks: LookupOption[] }> {
    return this.http.get<{ storyFeatures: LookupOption[]; tasks: LookupOption[] }>(`${BASE}/acceptance-criteria-form-lookups`, {
      params: { project_id: projectId, module_id: moduleId }
    });
  }

  /** Mirrors StoryMaster.aspx.vb's SaveAcceptanceCriteria. */
  addAcceptanceCriteria(form: AcceptanceCriteriaForm): Observable<{ resultCode: number; resultMsg: string }> {
    return this.http
      .post<{ result_code: number; result_msg: string }>(`${BASE}/acceptance-criteria`, {
        project_id: form.projectId,
        story_id: form.storyId,
        task_id: form.taskId,
        criteria: form.criteria
      })
      .pipe(map((r) => ({ resultCode: r.result_code, resultMsg: r.result_msg })));
  }

  getAcceptanceCriteriaList(projectId: number, storyId: number): Observable<AcceptanceCriteriaRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/acceptance-criteria`, { params: { project_id: projectId, story_id: storyId } })
      .pipe(map((rows) => rows.map((r) => snakeRow<AcceptanceCriteriaRow>(r))));
  }

  /** Mirrors ProductBacklogDetails.aspx.vb's Page_Load dropdown fills (size/priority/complexity/developer/tester per project). */
  getProductBacklogFormLookups(projectId: number): Observable<{
    modules: LookupOption[];
    sizes: { label: string; value: number; hours: number }[];
    priorities: LookupOption[];
    complexities: LookupOption[];
    developers: LookupOption[];
    testers: LookupOption[];
  }> {
    return this.http.get<{
      modules: LookupOption[];
      sizes: { label: string; value: number; hours: number }[];
      priorities: LookupOption[];
      complexities: LookupOption[];
      developers: LookupOption[];
      testers: LookupOption[];
    }>(`${BASE}/product-backlog-form-lookups`, { params: { project_id: projectId } });
  }

  /** Mirrors ProductBacklogDetails.aspx.vb's SavePB (EXEC Proc_AddUpdateProductBacklogMaster, attachment upload). Attachment upload is not wired up without a backend. */
  addProductBacklog(form: ProductBacklogForm): Observable<{ success: boolean; message: string }> {
    return this.http.post<{ success: boolean; message: string }>(`${BASE}/product-backlog`, {
      project_id: form.projectId,
      module_id: form.moduleId,
      description: form.description,
      priority_id: form.priorityId,
      complexity_id: form.complexityId,
      effort_size_id: form.effortSizeId,
      man_hours: form.manHours,
      developer_id: form.developerId,
      tester_id: form.testerId,
      comments: form.comments
    });
  }

  /** Mirrors ProductBacklogDetails.aspx.vb's grid fill (per project/module). */
  getProductBacklogList(projectId: number, moduleId: number): Observable<ProductBacklogRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/product-backlog`, { params: { project_id: projectId, module_id: moduleId } })
      .pipe(map((rows) => rows.map((r) => snakeRow<ProductBacklogRow>(r))));
  }

  /** Mirrors ProductBacklogDetails.aspx.vb's Rdgridprodbackdetails_UpdateCommand. */
  updateProductBacklogRow(row: ProductBacklogRow): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${BASE}/product-backlog/${row.productBacklogId}`, {
      project_id: row.projectId,
      product_backlog_id: row.productBacklogId,
      project_name: row.projectName,
      module_id: row.moduleId,
      module_name: row.moduleName,
      description: row.description,
      complexity_id: row.complexityId,
      complexity: row.complexity,
      effort_size_id: row.effortSizeId,
      effort_size: row.effortSize,
      hours: row.hours,
      priority_id: row.priorityId,
      priority: row.priority,
      developer_id: row.developerId,
      developer: row.developer,
      tester_id: row.testerId,
      tester: row.tester,
      status_name: row.statusName,
      attachments: row.attachments,
      comments: row.comments
    });
  }

  /** Mirrors AddTask.aspx.vb's Page_Load dropdown fills. */
  getAddTaskLookups(projectId: number): Observable<{
    modules: LookupOption[];
    taskTypes: LookupOption[];
    users: LookupOption[];
    statuses: LookupOption[];
  }> {
    return this.http.get<{ modules: LookupOption[]; taskTypes: LookupOption[]; users: LookupOption[]; statuses: LookupOption[] }>(`${BASE}/add-task-lookups`, {
      params: { project_id: projectId }
    });
  }

  /** Mirrors AddTask.aspx.vb's SaveTask (EXEC Proc_InsertUpdateTaskMaster). */
  addTask(form: AddTaskForm): Observable<{ resultCode: number; resultMsg: string; taskId: number }> {
    return this.http
      .post<{ result_code: number; result_msg: string; task_id: number }>(
        `${BASE}/tasks`,
        {
          project_id: form.projectId,
          module_id: form.moduleId,
          task_details: form.taskDetails,
          task_hours: form.taskHours,
          task_type_id: form.taskTypeId,
          assigned_to: form.assignedTo,
          assigned_by: form.assignedBy,
          status_id: form.statusId,
          for_date: form.forDate,
          is_current_task: form.isCurrentTask
        },
        { params: { current_user_id: form.assignedBy } }
      )
      .pipe(map((r) => ({ resultCode: r.result_code, resultMsg: r.result_msg, taskId: r.task_id })));
  }

  /** Mirrors AddAction.aspx.vb's showTaskDetails (EXEC Proc_GetTasksDetails, single task). */
  getTaskDetail(projectId: number, moduleId: number, taskId: number): Observable<TaskDetail> {
    return this.http
      .get<Record<string, unknown>>(`${BASE}/tasks/${projectId}/${taskId}`, { params: { module_id: moduleId } })
      .pipe(map((r) => snakeRow<TaskDetail>(r)));
  }

  /** Mirrors AddAction.aspx.vb's FillGV (EXEC Proc_GetActionDetail — missing on this database, and there is no per-entry action-log table anywhere in the schema to substitute it with; always empty). */
  getActionHistory(projectId: number, moduleId: number, taskId: number): Observable<ActionHistoryRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/tasks/${projectId}/${taskId}/actions`, { params: { module_id: moduleId } })
      .pipe(map((rows) => rows.map((r) => snakeRow<ActionHistoryRow>(r))));
  }

  /** Mirrors AddAction.aspx.vb's SaveAction (converts duration to hours, EXEC Proc_UpdateTaskWork — substituted with a direct Tasks update, see agile_tasks.py). */
  addAction(projectId: number, moduleId: number, taskId: number, form: AddActionForm): Observable<{ resultCode: number; resultMsg: string; taskId: number }> {
    return this.http
      .post<{ result_code: number; result_msg: string; task_id: number }>(`${BASE}/tasks/${projectId}/${taskId}/actions`, {
        action: form.action,
        worked_hours_type: form.workedHoursType,
        worked_hours: form.workedHours,
        for_date: form.forDate,
        percent_complete: form.percentComplete,
        task_type_id: form.taskTypeId,
        assigned_by: form.assignedBy,
        assigned_to: form.assignedTo,
        status_id: form.statusId,
        is_current_task: form.isCurrentTask
      })
      .pipe(map((r) => ({ resultCode: r.result_code, resultMsg: r.result_msg, taskId: r.task_id })));
  }

  /** Mirrors RSPL_Projects.aspx.vb's Page_Load dropdown fills. */
  getProjectFormLookups(): Observable<{ clients: LookupOption[]; currencies: LookupOption[]; leads: LookupOption[] }> {
    return this.http.get<{ clients: LookupOption[]; currencies: LookupOption[]; leads: LookupOption[] }>(`${BASE}/project-form-lookups`);
  }

  /** Mirrors RSPL_Projects.aspx.vb's fillGV / main.getProjectList. */
  getAgileProjectList(): Observable<AgileProjectRow[]> {
    return this.http.get<Record<string, unknown>[]>(`${BASE}/project-list`).pipe(map((rows) => rows.map((r) => snakeRow<AgileProjectRow>(r))));
  }

  /** Mirrors RSPL_Projects.aspx.vb's btnAdd_Click (EXEC Proc_AddUpdate_RSPL_Project). */
  addAgileProject(form: AgileProjectForm): Observable<{ projectId: number; resultMsg: string }> {
    return this.http
      .post<{ project_id: number; result_msg: string }>(`${BASE}/projects`, {
        client_id: form.clientId,
        project_name: form.projectName,
        description: form.description,
        remark: form.remark,
        project_value: form.projectValue,
        funds_received: form.fundsReceived,
        currency_id: form.currencyId,
        spoc_name: form.spocName,
        spoc_email: form.spocEmail,
        spoc_mobile: form.spocMobile,
        work_done: form.workDone,
        project_lead_id: form.projectLeadId
      })
      .pipe(map((r) => ({ projectId: r.project_id, resultMsg: r.result_msg })));
  }

  /** Mirrors RSPL_Projects.aspx.vb's GV_UpdateCommand (Update Agile_ProjectMaster set FundsRecieved/workDone/Enabled). */
  updateAgileProjectProgress(row: { projectId: number; fundsReceived: number; workDone: number }): Observable<{ success: boolean }> {
    return this.http.put<{ success: boolean }>(`${BASE}/projects/${row.projectId}`, {
      project_id: row.projectId,
      funds_received: row.fundsReceived,
      work_done: row.workDone
    });
  }

  getPriorities(): Observable<PriorityRow[]> {
    return this.http.get<Record<string, unknown>[]>(`${BASE}/priorities`).pipe(map((rows) => rows.map((r) => snakeRow<PriorityRow>(r))));
  }

  savePriority(row: { priorityId: number; priority: string; enabled: boolean }): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/priorities`, { priority_id: row.priorityId, priority: row.priority, enabled: row.enabled });
  }

  getComplexities(): Observable<ComplexityRow[]> {
    return this.http.get<Record<string, unknown>[]>(`${BASE}/complexities`).pipe(map((rows) => rows.map((r) => snakeRow<ComplexityRow>(r))));
  }

  saveComplexity(row: { complexityId: number; complexity: string; enabled: boolean }): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/complexities`, { complexity_id: row.complexityId, complexity: row.complexity, enabled: row.enabled });
  }

  getStatuses(): Observable<StatusRow[]> {
    return this.http.get<Record<string, unknown>[]>(`${BASE}/statuses`).pipe(map((rows) => rows.map((r) => snakeRow<StatusRow>(r))));
  }

  saveStatus(row: { statusId: number; statusName: string; color: string; enabled: boolean }): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/statuses`, { status_id: row.statusId, status_name: row.statusName, color: row.color, enabled: row.enabled });
  }

  getEffortSizes(): Observable<EffortSizeRow[]> {
    return this.http.get<Record<string, unknown>[]>(`${BASE}/effort-sizes`).pipe(map((rows) => rows.map((r) => snakeRow<EffortSizeRow>(r))));
  }

  saveEffortSize(row: { effortSizeId: number; effortSize: string; hours: number; description: string; enabled: boolean }): Observable<{ success: boolean }> {
    return this.http.post<{ success: boolean }>(`${BASE}/effort-sizes`, {
      effort_size_id: row.effortSizeId,
      effort_size: row.effortSize,
      hours: row.hours,
      description: row.description,
      enabled: row.enabled
    });
  }

  getModules(projectId: number): Observable<ModuleRow[]> {
    return this.http
      .get<Record<string, unknown>[]>(`${BASE}/modules`, { params: { project_id: projectId } })
      .pipe(map((rows) => rows.map((r) => snakeRow<ModuleRow>(r))));
  }

  saveModule(row: { moduleId: number; projectId: number; moduleName: string; description: string; enabled: boolean }): Observable<{ resultMsg: string; resultCode: number }> {
    return this.http
      .post<{ result_msg: string; result_code: number }>(`${BASE}/modules`, {
        module_id: row.moduleId,
        project_id: row.projectId,
        module_name: row.moduleName,
        description: row.description,
        enabled: row.enabled
      })
      .pipe(map((r) => ({ resultMsg: r.result_msg, resultCode: r.result_code })));
  }
}
