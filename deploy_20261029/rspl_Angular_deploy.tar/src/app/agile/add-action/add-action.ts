import { DatePipe, DecimalPipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { DatePickerModule } from 'primeng/datepicker';
import { InputNumberModule } from 'primeng/inputnumber';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { ActionHistoryRow, AddActionForm, AgileDataService, LookupOption, TaskDetail } from '../agile-data.service';

const DURATION_TYPES: string[] = ['Minute', 'Hours', 'Day'];

/**
 * Mirrors Agile_project_Manegment/AddAction.aspx ("Add Action" / "View
 * Action"), driven by ?ProjectID=&ModuleID=&TaskID=&IsView=. Migrated as a
 * routed page (was a RadWindow popup) navigating back to
 * /agile/task-tracking on Save/Close. IsView=1 shows only the action
 * history (the add-action form is hidden, matching the source's
 * pnladdAction.Visible = False).
 */
@Component({
  selector: 'app-add-action',
  imports: [FormsModule, ButtonModule, CheckboxModule, DatePickerModule, InputNumberModule, SelectModule, TableModule, TextareaModule, DatePipe, DecimalPipe],
  templateUrl: './add-action.html',
  styleUrl: './add-action.scss'
})
export class AddAction implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly data = inject(AgileDataService);
  // No zone.js in this app — plain (non-signal) properties like `projectId`/
  // `form`/`taskId` mutated inside RxJS subscribe callbacks need an explicit
  // markForCheck() to actually get the new values on screen.
  private readonly cdr = inject(ChangeDetectorRef);

  readonly durationTypes = DURATION_TYPES;
  readonly statuses = signal<LookupOption[]>([]);
  readonly taskTypes = signal<LookupOption[]>([]);
  readonly users = signal<LookupOption[]>([]);
  readonly taskDetail = signal<TaskDetail | null>(null);
  readonly history = signal<ActionHistoryRow[]>([]);
  readonly saving = signal(false);

  isView = false;
  projectId = 0;
  moduleId = 0;
  taskId = 0;

  forDate: Date | null = new Date();
  form: AddActionForm = this.blankForm();

  ngOnInit(): void {
    // Reached repeatedly from Task Tracking's grid with a different ?TaskID
    // each time — subscribe rather than reading a one-time snapshot so
    // clicking "Add Action" on a different task while this component is
    // already mounted actually reloads that task's details instead of
    // showing the previous task's stale data.
    this.route.queryParamMap.subscribe((q) => {
      this.projectId = Number(q.get('ProjectID') ?? 0);
      this.moduleId = Number(q.get('ModuleID') ?? 0);
      this.taskId = Number(q.get('TaskID') ?? 0);
      this.isView = q.get('IsView') === '1';
      this.form = this.blankForm();
      this.taskDetail.set(null);

      this.data.getAddTaskLookups(this.projectId).subscribe((l) => {
        this.statuses.set(l.statuses);
        this.taskTypes.set(l.taskTypes);
        this.users.set(l.users);
      });

      if (!this.isView) {
        this.data.getTaskDetail(this.projectId, this.moduleId, this.taskId).subscribe((detail) => {
          this.taskDetail.set(detail);
          this.form.isCurrentTask = detail.currentTask;
          this.form.percentComplete = detail.workComplete;
          this.form.taskTypeId = detail.taskTypeId;
          this.form.statusId = detail.statusId;
          this.cdr.markForCheck();
        });
      }
      this.loadHistory();
      this.cdr.markForCheck();
    });
  }

  private blankForm(): AddActionForm {
    return {
      action: '',
      workedHoursType: 'Minute',
      workedHours: 0,
      forDate: '',
      percentComplete: 0,
      taskTypeId: 0,
      assignedBy: 0,
      assignedTo: 0,
      statusId: 0,
      isCurrentTask: false
    };
  }

  private loadHistory(): void {
    this.data.getActionHistory(this.projectId, this.moduleId, this.taskId).subscribe((rows) => this.history.set(rows));
  }

  private validate(): boolean {
    if (!this.form.statusId) {
      alert('Please select status !');
      return false;
    }
    if (this.form.action.length < 15) {
      alert('Minimum 15 character should be enter in Action details !');
      return false;
    }
    if (this.forDate && this.forDate.getTime() > Date.now()) {
      alert('Please select valid for date !');
      return false;
    }
    if (!this.form.taskTypeId) {
      alert('Please select task type !');
      return false;
    }
    if (this.form.workedHours === 0) {
      alert('Please enter duration of work !');
      return false;
    }
    if (this.form.percentComplete === 0) {
      alert('Please enter task completion(%) !');
      return false;
    }
    return true;
  }

  private save(closeAfter: boolean): void {
    if (!this.validate()) {
      return;
    }
    this.saving.set(true);
    this.form.forDate = (this.forDate ?? new Date()).toISOString();
    this.data.addAction(this.projectId, this.moduleId, this.taskId, this.form).subscribe((res) => {
      this.saving.set(false);
      if (res.resultCode !== 100) {
        alert('Failed to add task.');
        return;
      }
      alert(res.resultMsg);
      if (closeAfter) {
        this.router.navigate(['/agile/task-tracking']);
      } else {
        this.form.action = '';
        this.form.workedHours = 0;
        this.form.percentComplete = 0;
        this.loadHistory();
      }
      this.cdr.markForCheck();
    });
  }

  saveAndStay(): void {
    this.save(false);
  }

  save2(): void {
    this.save(true);
  }

  close(): void {
    this.router.navigate(['/agile/task-tracking']);
  }
}
