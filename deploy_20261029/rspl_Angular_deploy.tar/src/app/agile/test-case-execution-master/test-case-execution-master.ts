import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { RadioButtonModule } from 'primeng/radiobutton';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';
import { TextareaModule } from 'primeng/textarea';

import { AgileDataService, LookupOption, TestCaseExecutionRow } from '../agile-data.service';

/** Mirrors Agile_project_Manegment/TestCaseExecutionMaster.aspx: cascading Project→Sprint→TestPlan→TestScenario→TestCase add-form + grid, with Pass/Fail status and a Raise Defect action. */
@Component({
  selector: 'app-test-case-execution-master',
  imports: [FormsModule, ButtonModule, RadioButtonModule, SelectModule, TableModule, TextareaModule],
  templateUrl: './test-case-execution-master.html',
  styleUrl: './test-case-execution-master.scss'
})
export class TestCaseExecutionMaster implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `projectId`/`filterProjectId`/`description` (plain)
  // mutated inside subscribe callbacks need an explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly projects = signal<LookupOption[]>([]);
  readonly sprints = signal<LookupOption[]>([]);
  readonly testPlans = signal<LookupOption[]>([]);
  readonly testScenarios = signal<LookupOption[]>([]);
  readonly testCases = signal<LookupOption[]>([]);
  readonly rows = signal<TestCaseExecutionRow[]>([]);
  readonly saving = signal(false);

  projectId: number | null = null;
  sprintNo: number | null = null;
  testPlanId: number | null = null;
  testScenarioId: number | null = null;
  testCaseId: number | null = null;
  description = '';
  testData = '';
  expectedResult = '';
  actualResult = '';
  status: 'Pass' | 'Fail' | '' = '';

  filterProjectId: number | null = null;

  ngOnInit(): void {
    this.data.getAgileProjects().subscribe((projects) => {
      this.projects.set(projects);
      this.projectId = projects[0]?.value ?? null;
      this.filterProjectId = this.projectId;
      this.onProjectChange();
      this.show();
      this.cdr.markForCheck();
    });
  }

  onProjectChange(): void {
    if (!this.projectId) {
      return;
    }
    this.data.getTestCaseExecutionFormLookups(this.projectId).subscribe((l) => {
      this.sprints.set(l.sprints);
      this.testPlans.set(l.testPlans);
      this.testScenarios.set(l.testScenarios);
      this.testCases.set(l.testCases);
    });
  }

  submit(): void {
    if (!this.projectId || !this.sprintNo || !this.testPlanId || !this.testScenarioId || !this.testCaseId || !this.expectedResult.trim() || !this.actualResult.trim()) {
      alert('* Fields are compulsory');
      return;
    }
    this.saving.set(true);
    this.data
      .addTestCaseExecution(
        this.projectId,
        this.sprintNo,
        this.testPlanId ?? 0,
        this.testCaseId,
        this.testData,
        this.description,
        this.expectedResult,
        this.actualResult,
        this.status === 'Pass'
      )
      .subscribe((res) => {
      this.saving.set(false);
      alert(res.resultMsg);
      this.description = '';
      this.testData = '';
      this.expectedResult = '';
      this.actualResult = '';
      this.status = '';
      this.show();
      this.cdr.markForCheck();
    });
  }

  show(): void {
    if (!this.filterProjectId) {
      return;
    }
    this.data.getTestCaseExecutions(this.filterProjectId).subscribe((rows) => this.rows.set(rows));
  }

  raiseDefect(row: TestCaseExecutionRow): void {
    if (!confirm('Do you want to add defect?')) {
      return;
    }
    this.data.raiseDefect(row.executionId, this.filterProjectId ?? 0).subscribe((res) => {
      row.defectId = res.defectId;
      alert(res.resultMsg);
      this.cdr.markForCheck();
    });
  }
}
