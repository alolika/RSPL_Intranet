import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { AgileDataService, LookupOption, TestingReportRow } from '../agile-data.service';

/** Mirrors Agile_project_Manegment/TestingReport.aspx ("Testing Report"): a Project + Tester filtered test-execution grid with a Send Mail action (mocked — no mail server wired up in this frontend-only phase). */
@Component({
  selector: 'app-testing-report',
  imports: [FormsModule, ButtonModule, SelectModule, TableModule, DatePipe],
  templateUrl: './testing-report.html',
  styleUrl: './testing-report.scss'
})
export class TestingReport implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `projectId` (plain) mutated inside subscribe needs an
  // explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly projects = signal<LookupOption[]>([]);
  readonly testers = signal<LookupOption[]>([]);
  readonly rows = signal<TestingReportRow[]>([]);
  readonly sending = signal(false);

  projectId: number | null = null;
  testerId: number | null = null;

  ngOnInit(): void {
    this.data.getAgileProjects().subscribe((projects) => {
      this.projects.set(projects);
      this.projectId = projects[0]?.value ?? null;
      this.show();
      this.cdr.markForCheck();
    });
    this.testers.set([{ label: 'Demo Tester', value: 2 }]);
  }

  show(): void {
    if (!this.projectId) {
      return;
    }
    this.data.getTestingReportByTester(this.projectId, this.testerId ?? 0).subscribe((rows) => this.rows.set(rows));
  }

  sendMail(): void {
    if (!this.projectId) {
      return;
    }
    this.sending.set(true);
    this.data.sendTestingReportMail(this.projectId, this.testerId ?? 0).subscribe(() => {
      this.sending.set(false);
      alert('Mail sent successfully.');
    });
  }
}
