import { DatePipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { AgileDataService, DefectReportRow, LookupOption, TestingReportRow } from '../agile-data.service';

const REPORT_TYPES = [
  { label: 'Test execution status report', value: 1 },
  { label: 'Sprint base test case repository', value: 2 },
  { label: 'Tester base test case repository', value: 3 }
];

const DEFECT_TYPES = [
  { label: 'Sprint based Defects', value: 1 },
  { label: 'Tester base Defects', value: 2 },
  { label: 'Severity base Defects', value: 3 },
  { label: 'Priority base Defects', value: 4 },
  { label: 'Defect Tracebility', value: 5 },
  { label: 'Repoen by Developers', value: 6 }
];

/**
 * Mirrors Agile_project_Manegment/Reports.aspx ("Testing Reports" +
 * "Defect Reports"): the source's 3 testing-report types and 6 defect-
 * filter types each rebind the same grid shape server-side — consolidated
 * here into one grid per section, driven by Project + Type + Filter
 * selects, consistent with the report-engine simplification used
 * throughout this app.
 */
@Component({
  selector: 'app-reports',
  imports: [FormsModule, ButtonModule, SelectModule, TableModule, DatePipe],
  templateUrl: './reports.html',
  styleUrl: './reports.scss'
})
export class Reports implements OnInit {
  private readonly data = inject(AgileDataService);
  // No zone.js — `testProjectId`/`defectProjectId` (plain) mutated inside
  // subscribe need an explicit markForCheck().
  private readonly cdr = inject(ChangeDetectorRef);

  readonly projects = signal<LookupOption[]>([]);
  readonly reportTypes = REPORT_TYPES;
  readonly defectTypes = DEFECT_TYPES;
  readonly testingRows = signal<TestingReportRow[]>([]);
  readonly defectRows = signal<DefectReportRow[]>([]);

  testProjectId: number | null = null;
  reportType = 1;
  defectProjectId: number | null = null;
  defectType = 1;

  ngOnInit(): void {
    this.data.getAgileProjects().subscribe((projects) => {
      this.projects.set(projects);
      this.testProjectId = projects[0]?.value ?? null;
      this.defectProjectId = projects[0]?.value ?? null;
      this.showTestingReport();
      this.showDefectReport();
      this.cdr.markForCheck();
    });
  }

  showTestingReport(): void {
    if (!this.testProjectId) {
      return;
    }
    this.data.getTestingReports(this.testProjectId, this.reportType).subscribe((rows) => this.testingRows.set(rows));
  }

  showDefectReport(): void {
    if (!this.defectProjectId) {
      return;
    }
    this.data.getDefectReports(this.defectProjectId, this.defectType).subscribe((rows) => this.defectRows.set(rows));
  }
}
