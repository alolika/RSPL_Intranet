import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { RadioButtonModule } from 'primeng/radiobutton';
import { SelectModule } from 'primeng/select';
import { TableModule } from 'primeng/table';

import { AgileDataService, AppreciationRow, LookupOption } from '../agile-data.service';

/** Mirrors Agile_project_Manegment/AppriciationRegister.aspx ("Appreciation"): a User + Commendation/Recommendation filtered register grid. */
@Component({
  selector: 'app-appreciation-register',
  imports: [FormsModule, ButtonModule, RadioButtonModule, SelectModule, TableModule],
  templateUrl: './appreciation-register.html',
  styleUrl: './appreciation-register.scss'
})
export class AppreciationRegister implements OnInit {
  private readonly data = inject(AgileDataService);

  readonly users = signal<LookupOption[]>([]);
  readonly rows = signal<AppreciationRow[]>([]);
  readonly loading = signal(false);

  userId = 0;
  isCommendation = true;

  ngOnInit(): void {
    this.data.getCommendationUsers().subscribe((users) => this.users.set(users));
    this.show();
  }

  show(): void {
    this.loading.set(true);
    this.data.getAppreciationRegister(this.userId, this.isCommendation).subscribe((rows) => {
      this.rows.set(rows);
      this.loading.set(false);
    });
  }
}
